# expand "@W <duree>" -> wait + garde du run (za_pro_ok)
import sys, re
src, dst = sys.argv[1], sys.argv[2]
out = []
for l in open(src, encoding='utf-8').read().split('\n'):
    m = re.match(r'^(\s*)@W (.+)$', l)
    if m:
        i = m.group(1)
        out.append(f'{i}wait {m.group(2)}')
        out.append(f'{i}if za_pro_ok({{_p}}, {{_run}}) is false:')
        out.append(f'{i}    stop')
    else:
        out.append(l)
open(dst, 'w', encoding='utf-8').write('\n'.join(out))
