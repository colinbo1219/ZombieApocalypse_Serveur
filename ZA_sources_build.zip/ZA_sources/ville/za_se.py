# -*- coding: utf-8 -*-
"""Secteur SE : poste de police, station-service (gaz bar) + autobus scolaire, école primaire."""
from za_blocs import S, AIR, OPP, CW, CCW
from za_meubles import (Repere, porte, porte_double, lit, chaise, table, tabouret, table_basse, canape, fauteuil, tapis,
                        plante, grande_plante, commode, bibliotheque, tele, bureau, cadre, horloge, lettres, lavabo,
                        toilette, _VEC)
from za_batir import fenetre
from za_commerces import repere_nord
import za_rue as RU


# ============================================================================ poste de police
def police(ctx):
    """x[88,110] z[88,104] ; a = 110-x (0..22), b = 104-z (0..16) ; façade b=16 (z=88)."""
    Z = 'police'
    ctx.zones[Z] = (99, 96)
    R = repere_nord(ctx, 110, 104)
    m = ctx.m
    rng = ctx.rng
    w = RU.Ecrivain(ctx)
    R.fill(0, 59, 0, 22, 63, 16, S('stone'))
    R.fill(0, 64, 0, 22, 68, 16, S('bricks'))
    R.vide(1, 64, 1, 21, 67, 15)
    R.fill(0, 68, 0, 22, 68, 16, S('gray_concrete'))
    R.fill(1, 63, 1, 21, 63, 15, S('light_gray_concrete'))
    for (a1, b1, a2, b2) in ((0, 0, 22, 0), (0, 16, 22, 16), (0, 0, 0, 16), (22, 0, 22, 16)):
        R.fill(a1, 64, b1, a2, 64, b2, S('polished_andesite'))
        R.fill(a1, 69, b1, a2, 69, b2, S('polished_andesite'))
        R.fill(a1, 70, b1, a2, 70, b2, S('smooth_stone_slab', type='bottom'))
    # bandeau bleu en façade + enseignes POLICE lumineuses
    R.fill(0, 68, 16, 22, 69, 16, S('blue_concrete'))
    R.fill(0, 68, 17, 22, 68, 17, S('smooth_quartz_slab', type='top'))
    for a, txt in ((16, ['SERVICE DE', 'POLICE', '', '']), (11, ['', 'POLICE', '', '']), (6, ['SAINT-AURÈLE', '', '', ''])):
        R.set(a, 69, 17, R.S('birch_wall_sign', facing='south'))
        R.sign(a, 69, 17, txt, 'blue' if a != 11 else 'blue', True)
    for a in (3, 8, 14, 19):
        R.lampe(a, 69, 17, S('sea_lantern'), S('light_gray_concrete'), Z)
    # porte double + fenêtres
    porte_double(R, 10, 64, 16, 'north', 'dark_oak')
    R.fill(10, 66, 16, 11, 66, 16, S('glass_pane'))
    for a in list(range(2, 8)) + list(range(14, 21)):
        R.fill(a, 65, 16, a, 66, 16, S('glass_pane') if a % 3 else S('polished_andesite'))
    for b in range(2, 15, 3):
        R.fill(0, 65, b, 0, 66, b, S('glass_pane'))
        R.fill(22, 65, b, 22, 66, b, S('glass_pane'))
    # marquise d'entrée
    for a in range(8, 14):
        for b in (17, 18):
            R.set(a, 67, b, S('smooth_stone_slab', type='top'))
    R.lampe(11, 67, 17, S('sea_lantern'), S('light_gray_concrete'), Z)
    R.poi('police_entree', 11, 64, 18, 'north')
    # ---------------------------------------------------------------- hall + comptoir (b 10)
    for a in range(8, 15):
        R.set(a, 64, 10, S('polished_andesite'))
        R.set(a, 65, 10, S('smooth_stone_slab', type='bottom'))
        R.set(a, 66, 10, S('glass_pane'))
        R.set(a, 67, 10, S('bricks'))
    R.set(11, 66, 10, AIR)
    R.set(14, 64, 10, R.S('dark_oak_trapdoor', facing='south', half='bottom', open=True))
    R.set(14, 65, 10, AIR)
    R.set(14, 66, 10, AIR)
    R.fill(7, 64, 10, 7, 67, 15, S('bricks'))
    R.fill(15, 64, 10, 15, 67, 15, S('bricks'))
    R.poi('police_comptoir', 11, 64, 9, 'south')
    R.set(12, 65, 10, S('black_stained_glass_pane')) if False else None
    for a in (9, 12):
        R.set(a, 64, 9, R.S('dark_oak_stairs', facing='north', half='bottom'))
    # banc + affiches dans le hall
    for a in (12, 13):
        R.set(a, 64, 15, R.S('spruce_stairs', facing='north' if False else 'south', half='bottom'))
    R.set(8, 65, 14, R.S('oak_wall_sign', facing='west' if False else 'east'))
    R.set(8, 65, 13, R.S('oak_wall_sign', facing='east'))
    R.sign(8, 65, 13, ['AVIS DE', 'RECHERCHE', 'Chien perdu :', '« Biscuit »'], 'black')
    R.set(8, 65, 14, R.S('oak_wall_sign', facing='east'))
    R.sign(8, 65, 14, ['URGENCE', 'composez le', '9-1-1', ''], 'red')
    R.set(14, 66, 15, R.S('blue_wall_banner', facing='north' if False else 'north')) if False else None
    grande_plante(R, 8, 64, 15, rng)
    R.lampe(11, 68, 13, S('sea_lantern'), S('light_gray_concrete'), Z)
    # ---------------------------------------------------------------- bureaux (a 8..21, b 1..9)
    for (a, b) in ((10, 6), (13, 6), (10, 3), (13, 3), (17, 6), (17, 3)):
        R.set(a, 64, b, R.S('dark_oak_trapdoor', facing='north', half='top', open=False))
        R.set(a + 1, 64, b, R.S('dark_oak_trapdoor', facing='north', half='top', open=False))
        R.set(a, 65, b, S('black_stained_glass_pane'))
        R.set(a + 1, 65, b, S('flower_pot') if (a + b) % 2 else S('white_carpet'))
        chaise(R, a, 64, b + 1, 'north', 'dark_oak')
    for b in range(1, 10):
        R.set(21, 64, b, R.S('barrel', facing='west', open=False))
        R.set(21, 65, b, S('bookshelf') if b % 2 else R.S('barrel', facing='west', open=False))
    for a in range(8, 20, 2):
        R.set(a, 64, 1, S('chiseled_bookshelf', facing='south'))
    R.set(15, 66, 1, R.S('white_wall_banner', facing='south'))
    R.set(16, 66, 1, R.S('blue_wall_banner', facing='south'))
    R.set(12, 66, 1, R.S('oak_wall_sign', facing='south'))
    R.sign(12, 66, 1, ['HORAIRE', 'Roy : jour', 'Pelletier : soir', ''], 'black')
    # bureau du chef (a 16..21, b 11..15)
    porte(R, 15, 64, 12, 'east', 'dark_oak', 'left')
    bureau(R, 19, 64, 13, 'west', 'dark_oak')
    R.set(21, 64, 15, S('bookshelf'))
    R.set(21, 65, 15, S('bookshelf'))
    R.set(17, 64, 15, R.S('spruce_stairs', facing='south', half='bottom'))
    tapis(R, 16, 11, 20, 14, 64, 'blue')
    # ---------------------------------------------------------------- cellules (a 1..6, b 1..8)
    R.fill(7, 64, 1, 7, 67, 9, S('bricks'))
    porte(R, 7, 64, 8, 'west', 'iron', 'left')
    R.fill(1, 64, 5, 6, 67, 5, S('iron_bars'))
    R.fill(3, 64, 1, 3, 67, 4, S('bricks'))
    R.set(2, 64, 5, S('iron_door', facing='south', half='lower', hinge='left', open=False, powered=False)) if False else None
    porte(R, 2, 64, 5, 'north', 'iron', 'left')
    porte(R, 5, 64, 5, 'north', 'iron', 'right')
    for a in (1, 4):
        R.set(a, 64, 1, S('smooth_stone_slab', type='top'))
        R.set(a, 64, 2, S('smooth_stone_slab', type='top'))
        R.set(a + 1, 64, 1, S('cauldron'))
    R.set(1, 65, 6, R.S('oak_wall_sign', facing='south')) if False else None
    R.poi('police_cellule', 5, 64, 3, 'south')
    # vestiaires (a 1..6, b 10..15)
    porte(R, 7, 64, 12, 'west', 'dark_oak', 'left')
    R.fill(1, 64, 9, 6, 67, 9, S('bricks'))
    for a in range(1, 7):
        porte(R, a, 64, 15, 'south', 'iron', 'left') if a % 2 else None
    for a in range(2, 6):
        R.set(a, 64, 11, R.S('spruce_slab', type='bottom'))
    for (a, b) in ((3, 3), (3, 7), (4, 12), (11, 4), (16, 4), (18, 13)):
        R.lampe(a, 68, b, S('sea_lantern'), S('light_gray_concrete'), Z)
    # ---------------------------------------------------------------- abords : mât, cour, voitures de police
    for x in range(86, 113):
        for z in range(84, 88):
            m.set(x, 63, z, S('smooth_stone'))
    for x in range(88, 111):
        m.set(x, 63, 84, RU.ASPHALTE) if False else None
    for y in range(64, 72):
        m.set(112, y, 86, S('iron_bars'))
    m.set(112, 72, 86, S('lightning_rod', facing='up', powered=False))
    m.set(113, 71, 86, S('blue_wall_banner', facing='east'))
    m.set(111, 71, 86, S('white_wall_banner', facing='west'))
    for (cx, d) in ((93, 'west'), (105, 'east')):
        ctx.gyros.extend(RU.voiture(w, cx, 85, d, kind='police'))
    # stationnement latéral (ouest) x 84..87
    for x in range(84, 88):
        for z in range(88, 105):
            m.set(x, 63, z, RU.ASPHALTE)


# ============================================================================ station-service
def station(ctx):
    Z = 'station'
    ctx.zones[Z] = (134, 104)
    m = ctx.m
    w = RU.Ecrivain(ctx)
    rng = ctx.rng
    for x in range(116, 155):
        for z in range(84, 122):
            m.set(x, 63, z, RU.ASPHALTE)
    for (x1, x2) in ((120, 126), (144, 150)):
        m.fill(x1, 63, 81, x2, 63, 83, RU.ASPHALTE)
    # îlots de pompes (x=129, x=135 ; z 90..97)
    for xi in (129, 135):
        for z in range(90, 98):
            m.set(xi, 64, z, S('smooth_stone_slab', type='bottom'))
        for z in (90, 97):
            m.set(xi, 64, z, S('yellow_concrete'))
        for zp in (91, 96):
            m.set(xi, 64, zp, S('white_concrete'))
            m.set(xi, 65, zp, S('red_concrete'))
            m.set(xi, 66, zp, S('white_concrete'))
            for (dx, fa) in ((-1, 'west'), (1, 'east')):
                m.set(xi + dx, 65, zp, S('birch_wall_sign', facing=fa))
                m.sign(xi + dx, 65, zp, ['ORDINAIRE', '1,89 $/L', 'SUPER', '2,09 $/L'], 'black', False)
            m.set(xi, 64, zp + (1 if zp == 91 else -1), S('lever', face='floor', facing='north', powered=False))
        for y in range(64, 69):
            m.set(xi, y, 93, S('quartz_pillar', axis='y'))
            m.set(xi, y, 94, S('quartz_pillar', axis='y'))
        m.set(xi, 64, 95, S('cauldron'))
    # marquise x 122..142 z 88..99, y 69..70
    for x in range(122, 143):
        for z in range(88, 100):
            bord = x in (122, 142) or z in (88, 99)
            m.set(x, 69, z, S('red_concrete') if bord else S('white_concrete'))
            m.set(x, 70, z, S('white_concrete') if bord else S('smooth_stone_slab', type='bottom'))
    for x in range(122, 143, 4):
        for z in range(91, 99, 3):
            if 123 <= x <= 141:
                ctx.lampe(x + 1, 69, z, S('sea_lantern'), S('light_gray_concrete'), Z)
    for x, txt in ((126, ['', 'GAZ BAR', '', '']), (132, ['GAZ BAR', 'SAINT-AURÈLE', '', '']), (138, ['Dépanneur', 'Café - Glace', 'Propane', ''])):
        m.set(x, 69, 87, S('birch_wall_sign', facing='north'))
        m.sign(x, 69, 87, txt, 'red', True)
    # pylône des prix (coin de la rue)
    for x in (117, 119):
        for y in range(64, 71):
            m.set(x, y, 85, S('andesite_wall'))
    for y in range(68, 72):
        m.set(118, y, 85, S('white_concrete'))
    m.set(118, 72, 85, S('red_concrete'))
    ctx.lampe(118, 67, 85, S('sea_lantern'), S('light_gray_concrete'), Z)
    for (y, txt) in ((71, ['GAZ BAR', 'SAINT-AURÈLE', '', '']), (70, ['ORDINAIRE', '1,89', '', '']), (69, ['SUPER', '2,09', '', '']),
                     (68, ['DIESEL', '1,99', '', ''])):
        m.set(118, y, 84, S('birch_wall_sign', facing='north'))
        m.sign(118, y, 84, txt, 'red' if y == 71 else 'black', True)
    # magasin x 140..152 z 101..111 (porte au nord)
    Rm = repere_nord(ctx, 152, 111)   # a = 152-x (0..12), b = 111-z (0..10)
    Rm.fill(0, 59, 0, 12, 63, 10, S('stone'))
    Rm.fill(0, 64, 0, 12, 68, 10, S('white_concrete'))
    Rm.vide(1, 64, 1, 11, 67, 9)
    Rm.fill(1, 63, 1, 11, 63, 9, S('polished_diorite'))
    Rm.fill(0, 68, 0, 12, 68, 10, S('light_gray_concrete'))
    for (a1, b1, a2, b2) in ((0, 0, 12, 0), (0, 10, 12, 10), (0, 0, 0, 10), (12, 0, 12, 10)):
        Rm.fill(a1, 67, b1, a2, 68, b2, S('red_concrete'))
    for a in list(range(1, 5)) + list(range(8, 12)):
        Rm.fill(a, 64, 10, a, 66, 10, S('glass_pane'))
    porte(Rm, 6, 64, 10, 'north', 'birch', 'left')
    Rm.set(6, 66, 10, S('glass_pane'))
    for a in range(3, 8):
        Rm.set(a, 64, 7, S('white_concrete'))
        Rm.set(a, 65, 7, S('smooth_quartz_slab', type='bottom'))
    Rm.set(4, 65, 7, S('heavy_weighted_pressure_plate'))
    Rm.set(6, 65, 7, S('black_stained_glass_pane'))
    Rm.set(8, 64, 7, R_barrel(Rm))
    for b in range(1, 10):
        Rm.set(11, 64, b, S('white_concrete'))
        Rm.set(11, 65, b, S('light_blue_stained_glass'))
        Rm.set(11, 66, b, S('light_blue_stained_glass'))
    for a in (1, 2):
        for b in range(1, 6):
            Rm.set(a, 64, b, Rm.S('barrel', facing='east', open=False))
            Rm.set(a, 65, b, S('chiseled_bookshelf', facing='east') if b % 2 else S('bookshelf'))
    for b in range(2, 6):
        Rm.set(7, 64, b, Rm.S('barrel', facing='west', open=False))
        Rm.set(7, 65, b, S('beehive', facing='west', honey_level=0) if b % 2 else S('composter', level=0))
    Rm.set(4, 64, 1, S('hopper', enabled=True, facing='down'))
    Rm.set(5, 64, 1, S('water_cauldron', level=2))
    Rm.set(6, 64, 1, Rm.S('smoker', facing='south', lit=False))
    Rm.set(5, 66, 2, Rm.S('birch_wall_sign', facing='south'))
    Rm.sign(5, 66, 2, ['CAFÉ FRAIS', '1,75 $', 'HOT-DOG', '2,25 $'], 'red')
    for (a, b) in ((3, 3), (8, 3), (5, 8), (9, 7)):
        Rm.lampe(a, 68, b, S('sea_lantern'), S('light_gray_concrete'), Z)
    Rm.set(10, 64, 11, S('white_concrete'))
    Rm.set(10, 65, 11, S('smooth_quartz_slab', type='bottom'))
    Rm.set(10, 64, 12, S('birch_wall_sign', facing='north')) if False else None
    for b in range(2, 8):
        pass
    # cases de stationnement devant le magasin, flèches peintes, conteneur à déchets, aspirateur/gonfleur
    for x in range(141, 153, 3):
        for z in range(113, 118):
            m.set(x, 63, z, RU.BLANC)
    for (cx, c) in ((143, 'light_gray'), (149, 'blue')):
        RU.voiture(w, cx, 115, 'north', c)
    for (x, z) in ((126, 104), (127, 104), (128, 104), (127, 103), (138, 104), (137, 104), (136, 104), (137, 105)):
        m.set(x, 63, z, RU.BLANC)
    m.fill(117, 64, 116, 119, 65, 118, S('green_concrete'))
    m.fill(117, 66, 116, 119, 66, 118, S('green_terracotta'))
    m.set(120, 64, 104, S('red_concrete'))
    m.set(120, 65, 104, S('red_concrete'))
    m.set(121, 64, 104, S('lever', face='floor', facing='east', powered=False))
    m.set(120, 64, 103, S('birch_wall_sign', facing='north'))
    m.sign(120, 64, 103, ['AIR', 'Aspirateur', '2,00 $', ''], 'red')
    for x in range(116, 155):
        m.set(x, 64, 121, S('spruce_leaves', persistent=True, distance=1, waterlogged=False)) if x % 7 else None
    # cage à propane et gonfleur
    for z in range(102, 106):
        m.set(153, 64, z, S('white_shulker_box', facing='up'))
        m.set(154, 64, z, S('iron_bars'))
    ctx.poi('station_service', 146, 64, 99, 0)
    # voitures (à la pompe, au magasin)
    RU.voiture(w, 132, 93, 'north', 'white')
    RU.voiture(w, 144, 116, 'west', 'gray') if False else None
    # autobus scolaire d'évacuation (x 128..139, z 114..118)
    info = RU.autobus_scolaire_blocs(w, 128, 114)
    px, py, pz = info['porte']
    ctx.poi('bus_porte', px, 64, pz, 0)
    x1, y1, z1, x2, y2, z2 = info['interieur']
    ctx.pois['bus_interieur'] = {'x1': x1, 'y1': y1, 'z1': z1, 'x2': x2, 'y2': y2, 'z2': z2}
    ctx.poi('bus_siege', 134, 65, 116, 90)
    # lampadaires du terrain
    for (x, z) in ((118, 110), (152, 90)):
        for y in range(64, 69):
            m.set(x, y, z, S('andesite_wall'))
        m.set(x, 69, z, S('smooth_stone_slab', type='bottom'))
        for (dx, dz) in ((1, 0), (-1, 0)):
            if 116 <= x + dx <= 154:
                m.set(x + dx, 69, z, S('smooth_stone_slab', type='bottom'))
                ctx.lampe(x + dx, 68, z, S('ochre_froglight', axis='y'), S('gray_stained_glass'), Z)


def R_barrel(R):
    return R.S('barrel', facing='up', open=False)


# ============================================================================ école primaire
def ecole(ctx):
    """École primaire du Boisé : façade à l'OUEST sur la rue des Érables.
    a = z-124 (0..32), b = 104-x (0..16) ; façade b=16 (x=88)."""
    Z = 'ecole'
    ctx.zones[Z] = (96, 140)
    R = Repere(ctx, 104, 124, (0, 1), (-1, 0))
    m = ctx.m
    rng = ctx.rng
    R.fill(0, 59, 0, 32, 63, 16, S('stone'))
    R.fill(0, 64, 0, 32, 69, 16, S('bricks'))
    R.vide(1, 64, 1, 31, 67, 15)
    R.fill(0, 68, 0, 32, 68, 16, S('andesite'))
    for (a1, b1, a2, b2) in ((0, 0, 32, 0), (0, 16, 32, 16), (0, 0, 0, 16), (32, 0, 32, 16)):
        R.fill(a1, 69, b1, a2, 69, b2, S('bricks'))
        R.fill(a1, 70, b1, a2, 70, b2, S('stone_brick_slab', type='bottom'))
        R.fill(a1, 64, b1, a2, 64, b2, S('stone_bricks'))
    R.fill(1, 63, 1, 31, 63, 15, S('smooth_quartz'))
    # corridor b 7..9 ; classes avant (b 10..15), arrière (b 1..6)
    R.fill(1, 64, 10, 31, 67, 10, S('white_concrete'))
    R.fill(1, 64, 6, 31, 67, 6, S('white_concrete'))
    for a in range(1, 32):
        R.set(a, 63, 8, S('yellow_concrete') if a % 4 == 0 else S('light_blue_concrete'))
    classes = [(1, 10), (12, 21), (23, 31)]
    for (a1, a2) in classes:
        R.fill(a2 + 1, 64, 10, a2 + 1, 67, 15, S('white_concrete')) if a2 < 31 else None
        R.fill(a2 + 1, 64, 1, a2 + 1, 67, 6, S('white_concrete')) if a2 < 31 else None
    entree_a = 16
    for i, (a1, a2) in enumerate(classes):
        ca = (a1 + a2) // 2
        if a1 <= entree_a <= a2:
            continue
        porte(R, ca, 64, 10, 'south', 'birch', 'left')
        # fenêtres
        for a in range(a1 + 1, a2):
            R.fill(a, 65, 16, a, 66, 16, S('glass_pane'))
        # tableau noir sur le mur du fond (a2 côté), pupitres
        for b in range(11, 15):
            R.set(a1, 65, b, R.S('dark_oak_wall_sign', facing='east')) if False else None
        R.fill(a1, 65, 11, a1, 66, 14, S('black_concrete')) if False else None
        for b in range(11, 15):
            R.set(a1 + 1, 65, b, S('green_terracotta')) if False else None
        for a in range(a1 + 2, a2, 2):
            for b in (11, 13):
                R.set(a, 64, b, R.S('birch_trapdoor', facing='south', half='top', open=False))
                R.set(a, 64, b + 1, R.S('spruce_stairs', facing='south' if False else 'north', half='bottom'))
        R.set(a2, 64, 14, R.S('spruce_trapdoor', facing='west', half='top', open=False))
        chaise(R, a2, 64, 13, 'west', 'spruce') if False else None
        tapis(R, a1 + 1, 11, a1 + 1, 15, 64, ['red', 'lime', 'light_blue'][i])
        R.set(a2 - 1, 66, 15, R.S('oak_wall_sign', facing='north'))
        R.sign(a2 - 1, 66, 15, ['Classe de', ['1re année', '3e année', '5e année'][i], 'Mme Ouellet' if i == 0 else ('M. Nadeau' if i == 1 else 'Mme Côté'), ''], 'black')
        for b in (12, 14):
            R.lampe(ca, 68, b, S('sea_lantern'), S('light_gray_concrete'), Z)
    # entrée principale (a 15..17) sur la rue des Érables
    porte_double(R, 15, 64, 16, 'north', 'birch')
    R.fill(15, 66, 16, 16, 66, 16, S('glass_pane'))
    R.vide(13, 64, 10, 19, 66, 10)
    for a in range(12, 21):
        for b in (17, 18):
            R.set(a, 67, b, S('smooth_stone_slab', type='top'))
    lettres(R, 5, 71, 16, 'ÉCOLE', S('white_concrete'), 'east') if False else None
    R.fill(9, 69, 16, 23, 72, 16, S('bricks'))
    R.fill(9, 73, 16, 23, 73, 16, S('stone_brick_slab', type='bottom'))
    for a, txt in ((18, ['ÉCOLE', 'PRIMAIRE', '', '']), (16, ['', 'DU BOISÉ', '', '']), (14, ['', 'Fondée en', '1962', ''])):
        R.set(a, 71, 17, R.S('birch_wall_sign', facing='south'))
        R.sign(a, 71, 17, txt, 'blue', True)
    ctx.poi('ecole_entree', *R.xz(16, 18)[:1], 64, R.xz(16, 18)[1], 90)
    # bibliothèque et bureau à l'arrière (b 1..5)
    for a in range(1, 11):
        R.set(a, 64, 1, S('bookshelf'))
        R.set(a, 65, 1, S('bookshelf'))
    table(R, 5, 64, 3, 'birch')
    table(R, 6, 64, 3, 'birch')
    porte(R, 5, 64, 6, 'north', 'birch', 'left')
    porte(R, 17, 64, 6, 'north', 'birch', 'left')
    porte(R, 27, 64, 6, 'north', 'birch', 'left')
    bureau(R, 16, 64, 3, 'south')
    for a in range(24, 31):
        R.set(a, 64, 1, R.S('barrel', facing='south', open=False))
    for a in (5, 16, 27):
        R.lampe(a, 68, 3, S('sea_lantern'), S('light_gray_concrete'), Z)
    for a in (4, 12, 20, 28):
        R.lampe(a, 68, 8, S('sea_lantern'), S('light_gray_concrete'), Z)
    # cour d'école (x 106..150, z 124..157)
    for x in range(106, 151):
        for z in range(124, 158):
            m.set(x, 63, z, S('gray_concrete') if x < 132 else RU.GAZON)
    for x in range(106, 151):
        m.set(x, 64, 123, S('iron_bars'))
        m.set(x, 64, 158, S('iron_bars'))
    for z in range(123, 159):
        m.set(151, 64, z, S('iron_bars'))
    # jeu de marelle (carrés colorés)
    for k, (dx, dz) in enumerate(((0, 0), (0, 1), (-1, 2), (1, 2), (0, 3), (-1, 4), (1, 4), (0, 5))):
        m.set(110 + dx, 63, 130 + dz, S(['red_concrete', 'yellow_concrete', 'lime_concrete', 'light_blue_concrete'][k % 4]))
    # panier de basket
    for (x, z, fa) in ((120, 126, 'south'), (120, 155, 'north')):
        for y in range(64, 68):
            m.set(x, y, z, S('polished_blackstone_wall'))
        dz = 1 if fa == 'south' else -1
        m.set(x, 67, z + dz, S('white_concrete'))
        m.set(x, 66, z + 2 * dz, S('orange_carpet')) if False else None
        m.set(x, 66, z + 2 * dz, S('iron_trapdoor', facing=fa, half='top', open=False))
    for z in range(128, 154):
        m.set(120, 63, z, S('white_concrete')) if z == 140 else None
    # module de jeu
    for x in range(138, 146):
        for z in range(128, 138):
            m.set(x, 63, z, S('orange_terracotta'))
    for (x, z) in ((139, 129), (144, 129), (139, 136), (144, 136)):
        for y in range(64, 68):
            m.set(x, y, z, S('red_nether_brick_wall') if False else S('spruce_fence'))
    for x in range(139, 145):
        for z in range(129, 137):
            m.set(x, 68, z, S('red_concrete') if (x + z) % 2 else S('yellow_concrete'))
    for x in range(140, 144):
        for z in range(130, 136):
            m.set(x, 67, z, S('spruce_slab', type='top'))
    for k in range(3):
        m.set(141, 64 + k, 137 + k, S('quartz_stairs', facing='north', half='bottom', shape='straight', waterlogged=False)) if False else None
    for k in range(3):
        m.set(142, 66 - k, 137 + k, S('yellow_concrete') if False else S('quartz_slab', type='top' if k == 0 else 'bottom'))
    for k in range(3):
        m.set(138, 64 + k, 132 - 0, S('ladder', facing='west', waterlogged=False)) if False else None
    # mât du drapeau
    for y in range(64, 73):
        m.set(90, y, 146, S('iron_bars'))
    m.set(91, 72, 146, S('blue_wall_banner', facing='east'))
    # autobus garés ? arbres
    for (x, z) in ((106, 140), (130, 150), (148, 128), (148, 150)):
        RU.feuillu(m, x, 64, z, rng, h=5, feuilles='oak_leaves')
