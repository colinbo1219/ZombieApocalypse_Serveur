# -*- coding: utf-8 -*-
"""Calques (blocs factices envoyés par joueur) : quarantaine, gyro_a/b, incident, chaos, checkpoint.
(depanneur_ferme est produit par za_commerces.depanneur)."""
from za_blocs import S, AIR, parse, nom_court, avec, DIRS
import za_rue as RU

FEU = S('fire', age=0, east=False, north=False, south=False, up=False, west=False)
LUMIERE = S('light', level=13, waterlogged=False)


def _mur(ctx, nom, pts):
    for (x, y, z, st) in pts:
        ctx.calque(nom, x, y, z, st)


def quarantaine(ctx):
    m = ctx.m
    w = RU.EcrivainCalque(ctx, 'quarantaine')
    C = 'quarantaine'
    bar, ruban = S('iron_bars'), S('yellow_stained_glass_pane')

    def cloture(x, z):
        ctx.calque(C, x, 64, z, bar)
        ctx.calque(C, x, 65, z, ruban)
        ctx.calque(C, x, 66, z, bar)
    # côté rue (z=68), ouverture gardée x 115..117 devant l'entrée
    for x in range(84, 154):
        if 115 <= x <= 117:
            continue
        cloture(x, 68)
    for x in range(115, 118):
        ctx.calque(C, x, 64, 67, AIR)          # on ouvre la haie
        ctx.calque(C, x, 63, 67, S('smooth_stone'))
        ctx.calque(C, x, 63, 68, S('smooth_stone'))
    RU.chevalet(w, 113, 69, 'x')
    RU.chevalet(w, 119, 69, 'x')
    ctx.poi('hopital_barriere', 116, 64, 69, 0)
    # côtés : ouest (x=84, z 2..67, chevalets devant la baie d'ambulance) et est (x=153)
    for z in range(2, 68):
        if 37 <= z <= 49:
            continue
        cloture(84, z)
        cloture(153, z)
    for z in range(37, 50):
        cloture(153, z)
    for zc in (39, 43, 47):
        RU.chevalet(w, 82, zc, 'z')
    # nord (fermeture derrière l'hôpital)
    for x in range(84, 154):
        cloture(x, 2)
    # voiture de police garée en travers devant l'entrée
    gy = RU.voiture(w, 116, 57, 'east', kind='police')
    ctx.gyros_quarantaine = gy
    # projecteurs sur trépieds
    for (x, z) in ((104, 63), (128, 63), (116, 66), (90, 63), (146, 63), (86, 50)):
        for y in (64, 65, 66):
            ctx.calque(C, x, y, z, S('iron_bars'))
        ctx.calque(C, x, 67, z, S('redstone_lamp', lit=True))
        ctx.calque(C, x, 68, z, S('iron_trapdoor', facing='north', half='bottom', open=False))
    # tente de triage blanche dans le stationnement (x 100..106, z 58..61)
    for x in range(100, 107):
        for z in (58, 61):
            ctx.calque(C, x, 64, z, S('white_wool'))
            ctx.calque(C, x, 65, z, S('white_wool'))
        for z in (59, 60):
            ctx.calque(C, x, 66, z, S('white_wool'))
            ctx.calque(C, x, 64, z, AIR)
            ctx.calque(C, x, 65, z, AIR)
        ctx.calque(C, x, 67, 59, S('white_carpet'))
        ctx.calque(C, x, 67, 60, S('white_carpet'))
    for z in (59, 60):
        ctx.calque(C, 100, 64, z, S('white_wool'))
    ctx.calque(C, 102, 64, 59, S('white_bed', facing='east', part='foot', occupied=False))
    ctx.calque(C, 103, 64, 59, S('white_bed', facing='east', part='head', occupied=False))
    ctx.calque(C, 104, 64, 60, S('white_bed', facing='east', part='foot', occupied=False))
    ctx.calque(C, 105, 64, 60, S('white_bed', facing='east', part='head', occupied=False))
    ctx.calque(C, 106, 64, 59, AIR)
    ctx.calque(C, 106, 64, 60, AIR)
    ctx.calque(C, 106, 65, 59, AIR)
    ctx.calque(C, 106, 65, 60, AIR)
    ctx.calque(C, 107, 64, 58, S('red_banner', rotation=4))


def gyros(ctx):
    """gyro_a = rouge, gyro_b = bleu ; + lumière invisible au-dessus quand possible."""
    tous = list(ctx.gyros) + list(getattr(ctx, 'gyros_quarantaine', []))
    for nom, col in (('gyro_a', 'red_concrete'), ('gyro_b', 'blue_concrete')):
        for (x, y, z) in tous:
            ctx.calque(nom, x, y, z, S(col))
            if ctx.m.est_air(x, y + 1, z):
                ctx.calque(nom, x, y + 1, z, LUMIERE)
    # variantes séparées (poste + ambulance / quarantaine seulement)
    for nom, col in (('gyro_poste_a', 'red_concrete'), ('gyro_poste_b', 'blue_concrete')):
        for (x, y, z) in ctx.gyros:
            ctx.calque(nom, x, y, z, S(col))
    for nom, col in (('gyro_quarantaine_a', 'red_concrete'), ('gyro_quarantaine_b', 'blue_concrete')):
        for (x, y, z) in getattr(ctx, 'gyros_quarantaine', []):
            ctx.calque(nom, x, y, z, S(col))


def incident(ctx):
    m, rng = ctx.m, ctx.rng
    C = 'incident'
    # vitres brisées à l'entrée de l'hôpital (façade vitrée x 107..125, z 52, et vestibule)
    for x in range(107, 126):
        for y in range(64, 68):
            if nom_court(m.get(x, y, 52)).endswith('glass_pane'):
                if (x < 113 or x > 119) or rng.random() < 0.7:
                    ctx.calque(C, x, y, 52, AIR)
    for x in range(113, 120):
        for z in range(48, 53):
            for y in range(64, 67):
                if nom_court(m.get(x, y, z)).endswith('glass_pane'):
                    ctx.calque(C, x, y, z, AIR)
    # éclats de verre au sol
    for _ in range(25):
        x, z = rng.randint(106, 126), rng.randint(53, 58)
        if m.est_air(x, 64, z):
            ctx.calque(C, x, 64, z, S('light_gray_carpet') if rng.random() < 0.6 else S('white_carpet'))
    # traînée de sang du stationnement vers l'entrée
    trace = [(104, 61), (106, 60), (108, 60), (110, 59), (112, 58), (113, 57), (114, 56), (115, 55), (116, 54), (116, 53)]
    for (x, z) in trace:
        if m.est_air(x, 64, z):
            ctx.calque(C, x, 64, z, S('red_carpet'))
        if rng.random() < 0.5:
            ctx.calque(C, x + 1, 63, z, S('red_concrete'))
    for (x, z) in ((115, 54), (116, 55), (117, 54), (117, 56), (115, 56)):
        ctx.calque(C, x, 63, z, S('red_concrete'))
    # civière renversée
    ctx.calque(C, 110, 64, 57, S('iron_trapdoor', facing='south', half='bottom', open=True))
    ctx.calque(C, 111, 64, 57, S('iron_trapdoor', facing='south', half='bottom', open=True))
    ctx.calque(C, 110, 64, 58, S('white_carpet'))
    ctx.calque(C, 111, 64, 58, S('white_carpet'))
    ctx.calque(C, 112, 64, 58, S('white_wool'))
    ctx.calque(C, 109, 64, 57, S('iron_bars'))


def chaos(ctx):
    m, rng = ctx.m, ctx.rng
    C = 'chaos'
    w = RU.EcrivainCalque(ctx, C)
    # 1) vitres brisées un peu partout (≈30 %) + feux dans quelques fenêtres
    panes = [i for i, st in enumerate(m.pal) if nom_court(st) in ('glass_pane', 'light_blue_stained_glass_pane')]
    pos = m.positions(set(panes))
    pos = [p for p in pos if 0 <= p[0] <= 159 and 0 <= p[2] <= 159]
    rng.shuffle(pos)
    feux_fen = 0
    for (x, y, z) in pos[: int(len(pos) * 0.3)]:
        x, y, z = int(x), int(y), int(z)
        dessous = m.get(x, y - 1, z)
        if feux_fen < 28 and nom_court(dessous) not in ('air',) and not nom_court(dessous).endswith('pane') \
                and rng.random() < 0.12:
            ctx.calque(C, x, y, z, FEU)
            if nom_court(m.get(x, y + 1, z)).endswith('pane'):
                ctx.calque(C, x, y + 1, z, AIR)
            feux_fen += 1
        else:
            ctx.calque(C, x, y, z, AIR)
    # 2) feux et feux de camp (fumée) sur les toits
    toits = [(20, 79, 46), (26, 79, 58), (40, 79, 50), (100, 79, 20), (130, 79, 30), (110, 79, 44), (56, 69, 92),
             (36, 69, 95), (98, 69, 96), (60, 74, 50), (95, 70, 140), (48, 72, 113), (146, 69, 106), (122, 79, 12)]
    for i, (x, y, z) in enumerate(toits):
        for (dx, dz) in ((0, 0), (1, 0), (0, 1), (-1, 0), (1, 1), (2, 0), (0, -1)):
            xx, zz = x + dx, z + dz
            if m.est_air(xx, y, zz) and not m.est_air(xx, y - 1, zz):
                ctx.calque(C, xx, y, zz, FEU)
        if i % 2 == 0 and m.est_air(x - 2, y, z - 2) and not m.est_air(x - 2, y - 1, z - 2):
            ctx.calque(C, x - 2, y, z - 2, S('campfire', facing='north', lit=True, signal_fire=True, waterlogged=False))
    # feux de camp allumés dans la rue (barils brûlés)
    for (x, z) in ((40, 70), (90, 82), (70, 120), (140, 70), (82, 30)):
        if m.est_air(x, 64, z):
            ctx.calque(C, x, 64, z, S('campfire', facing='north', lit=True, signal_fire=True, waterlogged=False))
    # 3) voitures abandonnées au milieu de la rue (portières ouvertes), hors de la voie du convoi (z 77..80)
    for (cx, cz, d, c) in ((32, 74, 'west', 'white'), (60, 75, 'east', 'blue'), (104, 74, 'west', 'red'),
                           (76, 32, 'north', 'gray'), (75, 118, 'south', 'black'), (148, 74, 'west', 'green')):
        RU.voiture(w, cx, cz, d, c, portes=True)
    RU.voiture(w, 76, 52, 'south', kind='brulee')
    # 4) portes ouvertes (toutes les portes de bois, les deux moitiés)
    ids = {i for i, st in enumerate(m.pal) if nom_court(st).endswith('_door') and not nom_court(st).startswith('iron')}
    for (x, y, z) in m.positions(ids):
        st = m.get(x, y, z)
        if 0 <= x <= 159 and 0 <= z <= 159:
            ctx.calque(C, int(x), int(y), int(z), avec(st, open=True))
    # 5) poubelles renversées, débris, papiers, sang
    caul = {i for i, st in enumerate(m.pal) if nom_court(st) == 'cauldron'}
    for (x, y, z) in m.positions(caul):
        x, y, z = int(x), int(y), int(z)
        if y == 64 and (69 <= z <= 83 or 69 <= x <= 83):
            ctx.calque(C, x, y, z, S('barrel', facing=rng.choice(['east', 'west', 'north', 'south']), open=True))
            for (dx, dz) in ((1, 0), (0, 1), (-1, 0)):
                if m.est_air(x + dx, 64, z + dz) and rng.random() < 0.7:
                    ctx.calque(C, x + dx, 64, z + dz, S(rng.choice(['white_carpet', 'brown_carpet', 'light_gray_carpet'])))
    debris = [S('cobblestone_slab', type='bottom', waterlogged=False), S('andesite_slab', type='bottom', waterlogged=False),
              S('stone_brick_slab', type='bottom', waterlogged=False), S('white_carpet'), S('light_gray_carpet'),
              S('brown_carpet'), S('red_carpet'), S('red_carpet'), S('cobweb'), S('dead_bush'),
              S('barrel', facing='east', open=True), S('iron_trapdoor', facing='north', half='bottom', open=False),
              S('spruce_trapdoor', facing='east', half='bottom', open=False), S('bricks'), S('polished_andesite_slab', type='bottom', waterlogged=False)]
    n = 0
    while n < 260:
        if rng.random() < 0.5:
            x, z = rng.randint(0, 159), rng.randint(69, 83)
        else:
            x, z = rng.randint(69, 83), rng.randint(0, 159)
        if 77 <= z <= 80 and not (69 <= x <= 83):
            continue            # voie du convoi dégagée
        if not m.est_air(x, 64, z) or (x, 64, z) in ctx.calques.get(C, {}):
            continue
        ctx.calque(C, x, 64, z, rng.choice(debris))
        n += 1
    for _ in range(60):
        x, z = rng.randint(0, 159), rng.randint(0, 159)
        if RU.dans_emprise_rue(x, z) and m.get(x, 63, z) in (RU.ASPHALTE, RU.TROTTOIR):
            ctx.calque(C, x, 63, z, S('red_concrete') if rng.random() < 0.5 else S('black_concrete'))
    # vitrine du dépanneur défoncée et barreaux arrachés
    for x in range(49, 64):
        for y in (65, 66, 67):
            if nom_court(m.get(x, y, 86)) == 'glass_pane':
                ctx.calque(C, x, y, 86, AIR)


def checkpoint(ctx):
    m, rng = ctx.m, ctx.rng
    C = 'checkpoint'
    sac = S('smooth_sandstone')
    sac_h = S('sandstone_slab', type='bottom', waterlogged=False)
    muret = S('light_gray_concrete')
    muret_h = S('smooth_stone_slab', type='bottom', waterlogged=False)

    def sacs(x, z):
        ctx.calque(C, x, 64, z, sac)
        ctx.calque(C, x, 65, z, sac_h)

    def jersey(x, z):
        ctx.calque(C, x, 64, z, muret)
        ctx.calque(C, x, 65, z, muret_h)
    # bras ouest : barrage x=66, z 69..83, passage gardé z 77..78
    for z in range(67, 86):
        if z in (77, 78):
            continue
        (sacs if z < 72 or z > 80 else jersey)(66, z)
    for z in (76, 79):
        sacs(65, z)
    ctx.poi('checkpoint_vega', 67, 64, 77, 90)
    ctx.poi('checkpoint_passage', 66, 64, 77, -90)
    # bras nord et sud fermés
    for x in range(67, 86):
        jersey(x, 66)
        jersey(x, 86)
    # sud-est : couloir balisé vers la station (barrières le long de la voie sud)
    for x in range(86, 118, 2):
        ctx.calque(C, x, 64, 81, S('iron_bars'))
        ctx.calque(C, x, 65, 81, S('yellow_stained_glass_pane'))
    # tente militaire verte (x 73..79, z 67..70) contre le barrage nord
    for x in range(73, 80):
        for z in (67, 70):
            ctx.calque(C, x, 64, z, S('green_wool'))
            ctx.calque(C, x, 65, z, S('green_wool'))
        for z in (68, 69):
            ctx.calque(C, x, 66, z, S('green_wool'))
        ctx.calque(C, x, 67, 68, S('green_carpet'))
        ctx.calque(C, x, 67, 69, S('green_carpet'))
    for z in (68, 69):
        ctx.calque(C, 73, 64, z, S('green_wool'))
        ctx.calque(C, 73, 65, z, S('green_wool'))
    ctx.calque(C, 77, 64, 70, AIR)
    ctx.calque(C, 77, 65, 70, AIR)
    ctx.calque(C, 75, 64, 68, S('spruce_trapdoor', facing='north', half='top', open=False))
    ctx.calque(C, 76, 64, 68, S('green_shulker_box', facing='up'))
    ctx.calque(C, 78, 64, 69, S('barrel', facing='up', open=False))
    # caisses et génératrice
    for (x, z) in ((70, 74), (70, 75), (71, 74), (82, 74), (82, 75)):
        ctx.calque(C, x, 64, z, S('barrel', facing='up', open=False) if (x + z) % 2 else S('spruce_planks'))
    ctx.calque(C, 70, 65, 74, S('green_shulker_box', facing='up'))
    ctx.calque(C, 83, 64, 72, S('iron_block'))
    ctx.calque(C, 83, 65, 72, S('iron_trapdoor', facing='north', half='bottom', open=False))
    # projecteurs sur poteaux
    for (x, z) in ((67, 72), (67, 82), (84, 67), (84, 85)):
        for y in range(64, 68):
            ctx.calque(C, x, y, z, S('iron_bars'))
        ctx.calque(C, x, 68, z, S('redstone_lamp', lit=True))
        ctx.calque(C, x, 69, z, S('iron_trapdoor', facing='north', half='bottom', open=False))
    # barrière levante au passage (trappes de fer ouvertes)
    ctx.calque(C, 66, 64, 76, S('iron_block'))
    ctx.calque(C, 66, 65, 76, S('polished_blackstone_wall'))


def tous(ctx):
    quarantaine(ctx)
    gyros(ctx)
    incident(ctx)
    chaos(ctx)
    checkpoint(ctx)
