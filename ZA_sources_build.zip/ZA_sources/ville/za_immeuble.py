# -*- coding: utf-8 -*-
"""Immeuble des Érables (1250, rue Principale) : 3 étages, 6 logements, cage d'escalier, hall.
Repère local : origine (16,42), a = x-16 (0..30), b = z-42 (0..22), façade (b=22) au sud sur la rue Principale."""
from za_blocs import S, AIR, OPP, CW, CCW
from za_meubles import (Repere, porte, porte_double, lit, chaise, table, table_basse, canape, fauteuil, tapis, plante,
                        grande_plante, commode, bibliotheque, tele, cuisiniere, evier, armoire_haute, lampe_plafond,
                        toilette, baignoire, lavabo, bureau, cadre, horloge, accoudoir, lettres, _VEC)
from za_batir import murs, dalle, fenetre, cage_escalier
import za_rue as RU

X0, Z0 = 16, 42
NIVEAUX = (64, 69, 74)          # niveaux de marche
TOIT = 78                        # dalle de toit (on marche à 79)
ZONE = 'immeuble'

BRIQUE = S('bricks')
PIERRE = S('stone_bricks')
BANDE = S('smooth_stone')
MUR_INT = S('white_concrete')


def construire(ctx):
    ctx.zones[ZONE] = (31, 53)
    R = Repere(ctx, X0, Z0)
    m = ctx.m
    # ------------------------------------------------------------------ gros œuvre
    R.fill(0, 59, 0, 30, 63, 22, S('stone'))
    R.fill(0, 64, 0, 30, TOIT, 22, BRIQUE)
    R.vide(1, 64, 1, 29, TOIT - 1, 21)
    for h in NIVEAUX[1:]:
        dalle(R, 1, 1, 29, 21, h - 1, S('spruce_planks'))
    dalle(R, 0, 0, 30, 22, TOIT, S('andesite'))
    # soubassement, bandeaux, chaînages d'angle
    R.fill(0, 64, 0, 30, 64, 0, PIERRE)
    R.fill(0, 64, 22, 30, 64, 22, PIERRE)
    R.fill(0, 64, 0, 0, 64, 22, PIERRE)
    R.fill(30, 64, 0, 30, 64, 22, PIERRE)
    for yb in (68, 73):
        for (a1, b1, a2, b2) in ((0, 0, 30, 0), (0, 22, 30, 22), (0, 0, 0, 22), (30, 0, 30, 22)):
            R.fill(a1, yb, b1, a2, yb, b2, BANDE)
    for y in range(65, TOIT + 1):
        if (y - 65) % 2 == 0:
            for (a, b) in ((0, 0), (30, 0), (0, 22), (30, 22), (1, 22), (29, 22), (0, 21), (30, 21)):
                R.set(a, y, b, PIERRE)
    # pilastres du corps central (entrée)
    for a in (12, 18):
        R.fill(a, 65, 22, a, TOIT, 22, S('stone_bricks'))
    # ------------------------------------------------------------------ circulation verticale
    # murs de la cage + hall (a=12 et a=18, b 1..21)
    for a in (12, 18):
        R.fill(a, 64, 1, a, TOIT - 1, 21, BRIQUE)
    # cage : intérieur a 13..17, b 1..7 ; le hall/corridor b 8..21
    niveaux = cage_escalier(R, 13, 1, 64, 3, marche='stone_brick_stairs', palier='polished_andesite',
                            diviseur='stone_bricks')
    # sol du hall et des corridors
    for i, h in enumerate(NIVEAUX):
        R.fill(13, h - 1, 8, 17, h - 1, 21, S('polished_andesite'))
        # bordure de carreaux
        for b in range(8, 22):
            R.set(13, h - 1, b, S('stone_bricks'))
            R.set(17, h - 1, b, S('stone_bricks'))
        tapis(R, 15, 9, 15, 20, h, 'red')
        # lampes du corridor
        for b in (12, 18):
            lampe_plafond(R, 15, h + 4 if h < 74 else TOIT, b, 'ochre_froglight', 'white_concrete', ZONE)
        # lampes de cage (sous chaque palier)
        if i > 0:
            lampe_plafond(R, 15, h + 1 - 5 + 5, 1, 'ochre_froglight', 'white_concrete', ZONE) if False else None
    for h in (69, 74):
        R.lampe(15, h + 1, 1, S('ochre_froglight', axis='y'), S('white_concrete'), ZONE)
    R.lampe(15, TOIT, 3, S('ochre_froglight', axis='y'), S('white_concrete'), ZONE)
    # porte arrière vers le parc (sous le premier palier)
    porte(R, 16, 64, 0, 'north', 'spruce', 'left')
    R.set(16, 66, 0, PIERRE)
    # ------------------------------------------------------------------ hall d'entrée (rez)
    porte(R, 15, 64, 22, 'north', 'spruce', 'left')
    R.set(14, 65, 22, S('glass_pane'))
    R.set(16, 65, 22, S('glass_pane'))
    R.set(14, 64, 22, PIERRE)
    R.set(16, 64, 22, PIERRE)
    R.fill(14, 66, 22, 16, 66, 22, S('glass_pane'))
    # boîtes aux lettres (barils) sur le mur ouest du hall
    for b in (15, 16, 17):
        for y in (65, 66):
            R.set(13, y, b, R.S('barrel', facing='east', open=False))
    R.set(13, 64, 16, R.S('spruce_stairs', facing='west', half='bottom'))
    R.set(13, 67, 16, R.S('birch_wall_sign', facing='east'))
    R.sign(13, 67, 16, ['Courrier', '1A 1B 2A', '2B 3A 3B', ''])
    # babillard et banc
    R.set(17, 65, 14, R.S('oak_wall_sign', facing='west'))
    R.sign(17, 65, 14, ['AVIS', 'Collecte des', 'ordures : mardi', '- Le concierge'])
    R.set(17, 65, 19, R.S('oak_wall_sign', facing='west'))
    R.sign(17, 65, 19, ['À VENDRE', 'Vélo 10 vitesses', '40 $ - voir 3B', ''])
    grande_plante(R, 17, 64, 21, ctx.rng)
    grande_plante(R, 13, 64, 21, ctx.rng)
    R.set(17, 64, 16, R.S('spruce_stairs', facing='east', half='bottom'))
    R.set(17, 64, 17, R.S('spruce_stairs', facing='east', half='bottom'))
    # fenêtres du corridor en façade (étages)
    for h in (69, 74):
        fenetre(R, 14, h + 1, 22, 3, 2, 'south', appui='smooth_stone_slab', linteau='stone_bricks')
    # fenêtre arrière de la cage
    for h in (69, 74):
        fenetre(R, 14, h + 3, 0, 3, 1, 'north', appui=None)
    # ------------------------------------------------------------------ logements
    styles = {
        (64, 'A'): dict(nom='1A', sol='spruce_planks', mur='white_concrete', porte='spruce', meuble='simple', coul='cyan'),
        (64, 'B'): dict(nom='1B', sol='birch_planks', mur='white_terracotta', porte='birch', meuble='simple', coul='lime'),
        (69, 'A'): dict(nom='2A', sol='oak_planks', mur='white_concrete', porte='birch', meuble='joueur', coul='blue'),
        (69, 'B'): dict(nom='2B', sol='dark_oak_planks', mur='white_terracotta', porte='oak', meuble='gagnon', coul='red'),
        (74, 'A'): dict(nom='3A', sol='spruce_planks', mur='light_gray_concrete', porte='spruce', meuble='simple', coul='orange'),
        (74, 'B'): dict(nom='3B', sol='oak_planks', mur='white_concrete', porte='jungle', meuble='vide', coul='gray'),
    }
    for (h, cote), st in styles.items():
        if cote == 'A':
            Ra = R.sous(0, 0)
        else:
            Ra = R.sous(18, 0, miroir=True, largeur=13)
        logement(ctx, Ra, h, st, cote)
    # ------------------------------------------------------------------ toit
    toit(ctx, R)
    # ------------------------------------------------------------------ extérieur avant
    facade_avant(ctx, R)
    cour(ctx, R)


def logement(ctx, R, h, st, cote):
    """R : repère du logement (a'=0 mur extérieur latéral, a'=12 mur du hall ; b=0 arrière, b=22 façade)."""
    rng = ctx.rng
    nom = st['nom']
    sol = S(st['sol'])
    mur = S(st['mur'])
    bois = st['porte']
    plafond = h + 4 if h < 74 else TOIT
    # sols : bois partout, carrelage cuisine / salle de bain
    R.fill(1, h - 1, 1, 11, h - 1, 21, sol)
    carreau = S('smooth_quartz') if nom != '2B' else None
    for a in range(1, 8):
        for b in range(1, 8):
            if nom == '2B':
                R.set(a, h - 1, b, S('white_concrete') if (a + b) % 2 == 0 else S('black_concrete'))
            else:
                R.set(a, h - 1, b, carreau)
    R.fill(8, h - 1, 1, 11, h - 1, 6, S('polished_diorite'))
    # cloisons
    R.fill(7, h, 1, 7, h + 3, 6, mur)          # salle de bain / cuisine
    R.fill(7, h, 7, 11, h + 3, 7, mur)
    R.fill(1, h, 14, 5, h + 3, 14, mur)        # chambre
    R.fill(6, h, 14, 6, h + 3, 21, mur)
    # habillage intérieur des murs de briques (plâtre) sauf 2A (brique apparente au salon)
    for b in range(1, 22):
        for y in range(h, h + 4):
            if R.get(1, y, b) == AIR and R.get(0, y, b) == BRIQUE and nom != '2A':
                pass
    # portes intérieures
    porte(R, 9, h, 7, 'north', bois, 'left')          # salle de bain
    porte(R, 4, h, 14, 'south', bois, 'left')         # chambre
    # porte d'entrée depuis le hall (a'=12, b=10), entrer = aller vers a'=0 ('west' local)
    porte(R, 12, h, 10, 'west', bois, 'right')
    # numéro de porte côté hall
    R.set(13, h + 1, 11, R.S('oak_wall_sign', facing='east'))
    R.sign(13, h + 1, 11, ['', nom, '', ''], 'black', False)
    # ------------------------------------------------ fenêtres (sur les murs de l'immeuble)
    fenetre(R, 2, h + 1, 0, 3, 2, 'north', linteau='stone_bricks')      # cuisine (arrière)
    fenetre(R, 9, h + 2, 0, 2, 1, 'north', appui=None)                  # salle de bain
    fenetre(R, 0, h + 1, 3, 2, 2, 'west', linteau='stone_bricks')       # cuisine (côté)
    fenetre(R, 0, h + 1, 10, 2, 2, 'west', linteau='stone_bricks')      # salle à manger
    fenetre(R, 0, h + 1, 17, 2, 2, 'west', linteau='stone_bricks')      # chambre (côté)
    fenetre(R, 2, h + 1, 22, 3, 2, 'south', linteau='stone_bricks')     # chambre (façade)
    fenetre(R, 7, h + 1, 22, 1, 2, 'south', linteau='stone_bricks')     # salon
    fenetre(R, 9, h + 1, 22, 2, 2, 'south', linteau='stone_bricks')
    if h > 64:
        porte(R, 8, h, 22, 'north', 'spruce', 'left')                  # porte-fenêtre du balcon
        R.set(8, h + 2, 22, S('stone_bricks'))
        balcon(ctx, R, h, nom)
    else:
        fenetre(R, 8, h + 1, 22, 1, 2, 'south', linteau='stone_bricks')
    # ------------------------------------------------ éclairage (plafonniers)
    for (a, b) in ((3, 4), (9, 3), (4, 11), (11, 10), (9, 17), (3, 18)):
        R.lampe(a, plafond, b, S('ochre_froglight', axis='y'), S('white_concrete'), ZONE)
    # ------------------------------------------------ mobilier
    m = st['meuble']
    if m == 'vide':
        # logement à louer : quelques boîtes, un escabeau
        for (a, b) in ((3, 10), (4, 10), (3, 11), (9, 18)):
            R.set(a, h, b, R.S('barrel', facing='up', open=False) if (a + b) % 2 else S('brown_wool'))
        R.set(10, h, 19, R.S('spruce_stairs', facing='west', half='bottom'))
        R.set(4, h, 1, R.S('barrel', facing='south', open=False))
        R.set(1, h, 16, S('white_wool'))
        R.set(11, h, 1, R.S('quartz_stairs', facing='east', half='bottom'))
        R.set(13, h + 1, 12, R.S('oak_wall_sign', facing='east'))
        R.sign(13, h + 1, 12, ['À LOUER', '5 1/2', 'Libre le 1er', 'juillet'], 'red', False)
        return
    # cuisine : comptoir le long du mur arrière, évier sous la fenêtre
    for a in range(1, 7):
        if a == 3:
            R.set(a, h, 1, S('water_cauldron', level=2))
        elif a == 5:
            R.set(a, h, 1, R.S('smoker', facing='south', lit=False))
        elif a == 6:
            R.set(a, h, 1, S('iron_block'))
            R.set(a, h + 1, 1, S('iron_block'))
            R.set(a, h + 1, 2, R.S('lever', face='wall', facing='south', powered=False))
            continue
        else:
            R.set(a, h, 1, R.S('barrel', facing='south', open=False))
        if a in (1, 5):
            R.set(a, h + 2, 1, R.S('spruce_trapdoor', facing='south', half='top', open=True))
    R.set(1, h + 1, 1, S('potted_fern') if nom != '2B' else S('potted_red_tulip'))
    R.set(4, h + 1, 1, R.S('tripwire_hook', facing='south', attached=False, powered=False))
    # îlot / comptoir le long du mur ouest
    for b in (4, 5):
        R.set(1, h, b, R.S('barrel', facing='east', open=False))
    R.set(1, h + 1, 5, S('potted_cactus') if nom == '1B' else S('flower_pot'))
    # salle à manger
    for (a, b) in ((3, 10), (4, 10)):
        table(R, a, h, b, 'spruce' if nom != '2B' else 'dark_oak', nappe='white' if nom == '2B' else None)
    chaise(R, 2, h, 10, 'east')
    chaise(R, 5, h, 10, 'west')
    chaise(R, 3, h, 9, 'south')
    chaise(R, 4, h, 11, 'north')
    tapis(R, 2, 9, 5, 12, h, st['coul'] if nom != '2B' else 'brown') if False else None
    # salle de bain
    baignoire(R, 8, h, 1, 'south', 2)
    toilette(R, 11, h, 1, 'south')
    lavabo(R, 11, h, 5, 'west')
    R.set(8, h, 5, R.S('barrel', facing='east', open=False))
    # entrée : crochets, banc à chaussures
    R.set(11, h + 1, 11, R.S('tripwire_hook', facing='west', attached=False, powered=False))
    # salon
    canape(R, 7, h, 15, 'east', 3, 'dark_oak' if nom != '2B' else 'spruce', 'dark_oak')
    R.set(11, h, 16, R.S('spruce_slab', type='top'))
    R.set(11, h, 17, R.S('spruce_slab', type='top'))
    tele(R, 11, h + 1, 16, 'west', 2)
    table_basse(R, 9, h, 16)
    tapis(R, 8, 15, 10, 18, h, st['coul'])
    R.set(9, h, 20, R.S('dark_oak_stairs', facing='south', half='bottom'))
    plante(R, 11, h, 21, 'potted_bamboo')
    R.set(7, h, 21, S('bookshelf'))
    R.set(7, h + 1, 21, S('bookshelf'))
    R.set(11, h, 13, S('bookshelf'))
    # chambre
    tete = lit(R, 2, h, 16, 'north', st['coul'])
    R.set(1, h, 15, R.S('barrel', facing='up', open=False))
    R.set(3, h, 15, R.S('barrel', facing='up', open=False))
    R.set(1, h + 1, 15, S('potted_blue_orchid') if nom == '2B' else S('flower_pot'))
    commode(R, 1, h, 18, 'east', 2)
    tapis(R, 2, 17, 4, 19, h, 'white' if nom != '2B' else 'pink')
    if m == 'joueur':
        joueur_2A(ctx, R, h)
    elif m == 'gagnon':
        gagnon_2B(ctx, R, h, tete)
    else:
        bureau(R, 5, h, 20, 'north')
        R.set(5, h, 16, R.S('spruce_door', facing='west', half='lower', hinge='left', open=False, powered=False))
        R.set(5, h + 1, 16, R.S('spruce_door', facing='west', half='upper', hinge='left', open=False, powered=False))


def joueur_2A(ctx, R, h):
    """Détails de l'appartement du joueur."""
    # radio (jukebox) sur la commode
    R.set(1, h + 1, 19, S('jukebox', has_record=False))
    R.poi('radio_2A', 1, h + 1, 19, 'east')
    # bureau de jeu + chaise de bureau
    bureau(R, 5, h, 20, 'north', 'dark_oak')
    R.set(5, h, 21, R.S('dark_oak_stairs', facing='south', half='bottom'))
    # garde-robe
    R.set(5, h, 16, R.S('spruce_door', facing='west', half='lower', hinge='left', open=False, powered=False))
    R.set(5, h + 1, 16, R.S('spruce_door', facing='west', half='upper', hinge='left', open=False, powered=False))
    # coffre près de la porte d'entrée
    R.set(11, h, 9, R.S('chest', facing='west', type='single', waterlogged=False))
    R.container(11, h, 9, [
        {'slot': 0, 'id': 'minecraft:paper', 'n': 1, 'name': "Facture d'électricité"},
        {'slot': 4, 'id': 'minecraft:leather_helmet', 'n': 1, 'name': 'Tuque des Canadiens'},
    ])
    R.poi('coffre_2A', 11, h, 9, 'west')
    # bâton de baseball : présentoir (crochets) sur le mur du vestibule
    R.set(10, h + 1, 11, R.S('tripwire_hook', facing='north', attached=False, powered=False))
    R.poi('baton_2A', 10, h, 11, 'south')
    # affiche de la ligue de balle (bannière bleue) et fanion
    R.set(10, h + 2, 13, R.S('blue_wall_banner', facing='south')) if R.est_air(10, h + 2, 13) else None
    # réveil : case à côté du lit, regard vers la fenêtre (sud)
    R.poi('reveil', 3, h, 16, 'south')
    R.poi('porte_2A', 13, h, 10, 'west')
    # affiche/horloge
    horloge(R, 4, h + 2, 21, 'north')
    # table de chevet : réveille-matin (bouton) et lampe (pot)
    # vaisselle sale dans l'évier, boîte de pizza (trappe)
    R.set(9, h, 16, R.S('spruce_trapdoor', facing='north', half='bottom', open=False))
    R.set(9, h + 1, 16, S('birch_pressure_plate'))


def gagnon_2B(ctx, R, h, tete):
    """Mme Thérèse Gagnon : chambre, fauteuil, cadres (bannières)."""
    # fauteuil près du lit
    fauteuil(R, 4, h, 16, 'west', 'spruce', 'dark_oak')
    # cadres (bannières murales)
    cadre(R, 1, h + 2, 17, 'east', 'light_blue')
    cadre(R, 1, h + 2, 19, 'east', 'yellow')
    cadre(R, 3, h + 2, 21, 'north', 'pink')
    cadre(R, 9, h + 2, 21, 'north', 'green')
    cadre(R, 7, h + 2, 18, 'east', 'purple') if R.est_air(7, h + 2, 18) else None
    # coffre à couvertures au pied du lit et tricot
    R.set(2, h, 18, R.S('chest', facing='south', type='single', waterlogged=False))
    R.set(5, h, 20, R.S('barrel', facing='up', open=False))
    R.set(5, h + 1, 20, S('white_carpet'))
    R.set(4, h + 2, 21, R.S('stone_button', face='wall', facing='north', powered=False))
    # berçante au salon, bibelots
    R.set(9, h, 20, R.S('spruce_stairs', facing='south', half='bottom'))
    R.set(10, h, 20, R.S('barrel', facing='up', open=False))
    R.set(10, h + 1, 20, S('potted_red_tulip'))
    R.set(5, h, 15, S('potted_azalea_bush')) if R.est_air(5, h, 15) else None
    # POIs
    R.poi('lit_2B', tete[0], h, tete[1], 'south')
    R.poi('gagnon_debout', 3, h, 16, 'west')
    R.poi('porte_2B', 13, h, 10, R.d('west') and 'west')
    x1, z1 = R.xz(1, 1)
    x2, z2 = R.xz(11, 21)
    ctx.pois['appart_2B'] = {'x1': min(x1, x2), 'y1': h, 'z1': min(z1, z2), 'x2': max(x1, x2), 'y2': h + 3, 'z2': max(z1, z2)}


def balcon(ctx, R, h, nom):
    y = h - 1
    for a in range(6, 12):
        for b in range(23, 26):
            R.set(a, y, b, S('spruce_slab', type='top'))
    for a in range(6, 12):
        R.set(a, h, 25, S('iron_bars'))
    for b in (23, 24):
        R.set(6, h, b, S('iron_bars'))
        R.set(11, h, b, S('iron_bars'))
    # consoles
    for a in (6, 11):
        R.set(a, y - 1, 23, R.S('stone_brick_stairs', facing='north', half='top'))
    if nom in ('2A', '3A'):
        R.set(10, h, 24, R.S('spruce_stairs', facing='north', half='bottom'))
        R.set(9, h, 24, S('potted_red_tulip') if nom == '3A' else S('flower_pot'))
    elif nom == '2B':
        R.set(7, h, 24, S('potted_azalea_bush'))
        R.set(9, h, 24, S('potted_red_tulip'))
        R.set(10, h, 24, S('potted_blue_orchid'))
    else:
        R.set(7, h, 23, R.S('spruce_stairs', facing='west', half='bottom'))


def toit(ctx, R):
    y = TOIT + 1
    # parapet + chaperon
    for (a1, b1, a2, b2) in ((0, 0, 30, 0), (0, 22, 30, 22), (0, 0, 0, 22), (30, 0, 30, 22)):
        R.fill(a1, y, b1, a2, y, b2, BRIQUE)
        R.fill(a1, y + 1, b1, a2, y + 1, b2, S('smooth_stone_slab', type='bottom'))
    # corniche (escaliers inversés en saillie)
    for a in range(0, 31):
        R.set(a, TOIT, 23, R.S('stone_brick_stairs', facing='north', half='top'))
        R.set(a, TOIT, -1, R.S('stone_brick_stairs', facing='south', half='top'))
    for b in range(0, 23):
        R.set(-1, TOIT, b, R.S('stone_brick_stairs', facing='east', half='top'))
        R.set(31, TOIT, b, R.S('stone_brick_stairs', facing='west', half='top'))
    # fronton central avec le numéro civique 1250 (lettres de quartz sur brique)
    R.fill(6, y, 22, 24, y + 6, 22, BRIQUE)
    R.fill(6, y + 7, 22, 24, y + 7, 22, S('stone_brick_slab', type='bottom'))
    R.fill(8, y + 7, 22, 22, y + 7, 22, S('stone_bricks'))
    R.fill(9, y + 8, 22, 21, y + 8, 22, S('stone_brick_slab', type='bottom'))
    for a in range(6, 25):
        R.set(a, y + 6, 23, R.S('stone_brick_stairs', facing='north', half='top'))
    lettres(R, 8, y + 1, 22, '1250', S('smooth_quartz'), 'east')
    # édicule de la cage d'escalier
    R.fill(12, y, 0, 18, y + 3, 8, BRIQUE)
    R.fill(12, y + 4, 0, 18, y + 4, 8, S('smooth_stone_slab', type='bottom'))
    porte(R, 15, y, 8, 'north', 'spruce', 'left')
    # équipements : unités de climatisation, évents, antennes
    for (a, b) in ((3, 4), (24, 5), (4, 15), (25, 16)):
        R.fill(a, y, b, a + 1, y, b + 1, S('light_gray_concrete'))
        R.fill(a, y + 1, b, a + 1, y + 1, b + 1, R.S('iron_trapdoor', facing='north', half='bottom', open=False))
    for (a, b) in ((8, 3), (21, 12), (7, 18), (27, 10)):
        R.set(a, y, b, S('cauldron'))
    for (a, b) in ((2, 10), (28, 3)):
        for k in range(3):
            R.set(a, y + k, b, S('lightning_rod', facing='up', powered=False))
    # cheminées de briques
    for (a, b) in ((1, 1), (29, 1)):
        R.fill(a, y, b, a, y + 2, b, BRIQUE)
        R.set(a, y + 3, b, S('stone_brick_slab', type='bottom'))


def facade_avant(ctx, R):
    # auvent de l'entrée (dalles + lumières encastrées), marches
    for a in range(12, 19):
        for b in (23, 24):
            R.set(a, 67, b, S('spruce_slab', type='top'))
    for a in range(12, 19):
        R.set(a, 67, 25, R.S('spruce_trapdoor', facing='south', half='top', open=True))
    R.lampe(15, 67, 23, S('ochre_froglight', axis='y'), S('smooth_stone'), ZONE)
    # colonnes de l'auvent
    for a in (12, 18):
        for y in (64, 65, 66):
            R.set(a, y, 24, S('stone_brick_wall'))
    # adresse
    R.set(15, 66, 23, R.S('spruce_wall_sign', facing='south'))
    R.sign(15, 66, 23, ['1250', 'Immeuble', 'des Érables', ''], 'white', True)
    R.poi('entree_immeuble', 15, 64, 24, 'north')
    # nom gravé sur plaque au-dessus du 3e (sous le fronton)
    for a, txt in ((14, ['IMMEUBLE']), (15, ['DES']), (16, ['ÉRABLES'])):
        pass


def cour(ctx, R):
    """Cour avant (b 23..26 = z 65..68) : allée, pelouse, plates-bandes, haie basse ; côté parc à l'arrière."""
    rng = ctx.rng
    # allée centrale
    for b in range(23, 27):
        for a in (14, 15, 16):
            R.set(a, 63, b, S('polished_andesite') if a == 15 else S('stone_bricks'))
    # plates-bandes le long de la façade
    fleurs = ['poppy', 'dandelion', 'azure_bluet', 'oxeye_daisy', 'cornflower', 'allium', 'red_tulip', 'orange_tulip']
    for a in list(range(1, 12)) + list(range(19, 30)):
        R.set(a, 63, 23, S('rooted_dirt'))
        if R.est_air(a, 64, 23):
            if a % 4 == 0:
                RU.buisson(ctx.m, *R.xz(a, 23)[:1], 64, R.xz(a, 23)[1], rng, 'azalea_leaves') if False else None
                R.set(a, 64, 23, S('azalea_leaves', persistent=True, distance=1, waterlogged=False))
            else:
                R.set(a, 64, 23, S(rng.choice(fleurs)))
    # haie basse sur la limite du trottoir (z=68), ouverture à l'allée
    for a in range(-1, 32):
        if a in (14, 15, 16):
            continue
        R.set(a, 64, 26, S('spruce_leaves', persistent=True, distance=1, waterlogged=False))
    # support à vélos + banc dans la cour
    for a in (3, 4, 5):
        R.set(a, 64, 25, S('iron_bars'))
    R.set(24, 64, 25, R.S('spruce_stairs', facing='south', half='bottom'))
    R.set(25, 64, 25, R.S('spruce_stairs', facing='south', half='bottom'))
    # lampadaire bas près de l'allée
    for (a, b) in ((13, 26), (17, 26)):
        R.set(a, 64, b, S('polished_blackstone_wall'))
        R.set(a, 65, b, S('polished_blackstone_wall'))
        R.lampe(a, 66, b, S('ochre_froglight', axis='y'), S('gray_stained_glass'), ZONE)
        R.set(a, 67, b, S('polished_blackstone_slab', type='bottom'))
    # arrière : dalle de béton devant la porte arrière + bacs
    for a in range(14, 19):
        R.set(a, 63, -1, S('smooth_stone'))
        R.set(a, 63, -2, S('smooth_stone'))
    R.set(19, 64, -1, S('blue_shulker_box', facing='up'))
    R.set(20, 64, -1, S('green_shulker_box', facing='up'))
    R.set(21, 64, -1, S('black_shulker_box', facing='up'))
