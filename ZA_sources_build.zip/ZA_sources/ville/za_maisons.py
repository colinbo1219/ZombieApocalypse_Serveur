# -*- coding: utf-8 -*-
"""Bungalows (3, rue des Érables côté ouest), terrain de balle, stationnement du SO."""
from za_blocs import S, AIR, OPP, CW, CCW
from za_meubles import (Repere, porte, lit, chaise, table, table_basse, canape, fauteuil, tapis, plante, grande_plante,
                        commode, bibliotheque, tele, bureau, cadre, horloge, lavabo, toilette, baignoire, _VEC)
from za_batir import fenetre
import za_rue as RU

STYLES = [
    dict(bardage='smooth_sandstone', avant='bricks', toit='deepslate_tile_slab', porte='spruce', volets='dark_oak',
         sol='oak_planks', coul='blue', auto='red'),
    dict(bardage='cyan_terracotta', avant='stone_bricks', toit='polished_blackstone_brick_slab', porte='oak',
         volets='spruce', sol='birch_planks', coul='yellow', auto=None),
    dict(bardage='calcite', avant='bricks', toit='spruce_slab', porte='dark_oak', volets='dark_oak',
         sol='spruce_planks', coul='green', auto='light_gray'),
]
X_ARR = 44          # mur arrière des maisons (b=0)


def bungalow(ctx, i, z_sud):
    """Façade à l'EST (sur la rue des Érables) : a = z_sud - z (vers le nord), b = x - 44 (vers la rue)."""
    st = STYLES[i]
    Z = 'maison%d' % (i + 1)
    R = Repere(ctx, X_ARR, z_sud, (0, -1), (1, 0))
    ctx.zones[Z] = R.xz(8, 5)
    rng = ctx.rng
    bard = S(st['bardage'])
    R.fill(0, 59, 0, 16, 63, 9, S('stone'))
    R.fill(0, 64, 0, 12, 67, 9, bard)
    R.fill(13, 64, 1, 16, 67, 9, bard)
    R.vide(1, 64, 1, 11, 67, 8)
    R.vide(13, 64, 2, 15, 67, 8)
    R.fill(0, 68, 0, 16, 68, 9, bard)
    R.fill(1, 68, 1, 11, 68, 8, S('white_concrete'))
    # fondation apparente
    R.fill(0, 64, 0, 16, 64, 0, S('stone_bricks'))
    R.fill(0, 64, 9, 16, 64, 9, S('stone_bricks'))
    # section avant en brique/pierre (autour du salon)
    R.fill(6, 65, 9, 12, 67, 9, S(st['avant']))
    # sols
    R.fill(1, 63, 1, 11, 63, 8, S(st['sol']))
    R.fill(6, 63, 1, 11, 63, 3, S('white_concrete'))
    R.fill(1, 63, 1, 4, 63, 3, S('smooth_quartz'))
    R.fill(13, 63, 2, 15, 63, 8, S('smooth_stone'))
    # toit à faible pente (dalles) le long de a, pignons en a=-1 / a=18
    prof = [(-1, 68, 'bottom'), (0, 68, 'top'), (1, 69, 'bottom'), (2, 69, 'top'), (3, 70, 'bottom'), (4, 70, 'top')]
    for (b, y, t) in prof:
        for bb in (b, 9 - b):
            for a in range(0, 17):
                R.set(a, y, bb, S(st['toit'], type=t))
    for a in range(0, 17):
        R.set(a, 71, 4, S(st['toit'], type='bottom'))
        R.set(a, 71, 5, S(st['toit'], type='bottom'))
    for a in (0, 16):
        R.fill(a, 69, 3, a, 69, 6, bard)
        R.fill(a, 70, 4, a, 70, 5, S('white_concrete'))
    # bordure de toit (fascia blanche)
    for a in range(-1, 19):
        R.set(a, 67, 10, R.S('quartz_stairs', facing='north', half='top')) if False else None
    # cloisons intérieures
    R.fill(5, 64, 1, 5, 67, 8, S('white_concrete'))
    R.fill(1, 64, 4, 4, 67, 4, S('white_concrete'))
    porte(R, 5, 64, 6, 'north' if False else 'west', 'birch', 'left')
    porte(R, 5, 64, 2, 'west', 'birch', 'right')
    porte(R, 12, 64, 3, 'east', 'birch', 'left')
    # porte d'entrée, perron, lumière
    porte(R, 7, 64, 9, 'north' if False else 'west', st['porte'], 'left') if False else None
    R.set(7, 64, 9, R.S(st['porte'] + '_door', facing='west', half='lower', hinge='left', open=False, powered=False)) if False else None
    porte(R, 7, 64, 9, 'north', st['porte'], 'left') if False else None
    # (repère : entrer = aller vers b décroissant = direction locale 'north')
    porte(R, 7, 64, 9, 'north', st['porte'], 'left')
    for a in (6, 7, 8):
        R.set(a, 63, 10, S('smooth_stone'))
        R.set(a, 64, 10, S('smooth_stone_slab', type='bottom')) if False else None
    R.lampe(8, 67, 10, S('ochre_froglight', axis='y'), S('smooth_stone'), Z)
    R.poi('maison%d' % (i + 1), 7, 64, 11, 'north')
    # numéro civique
    R.set(6, 66, 10, R.S('spruce_wall_sign', facing='south'))
    R.sign(6, 66, 10, ['', str(1300 + i * 10), '', ''], 'white', True)
    # fenêtres avec volets
    fenetre(R, 9, 65, 9, 3, 2, 'south', appui='smooth_stone_slab', volets=st['volets'])
    fenetre(R, 2, 65, 9, 2, 2, 'south', appui='smooth_stone_slab', volets=st['volets'])
    fenetre(R, 2, 65, 0, 2, 2, 'north', appui=None)
    fenetre(R, 8, 65, 0, 3, 2, 'north', appui=None)
    fenetre(R, 0, 65, 6, 2, 2, 'west', appui=None) if False else None
    for b in (6, 7):
        R.fill(0, 65, b, 0, 66, b, S('glass_pane'))
    R.fill(0, 66, 2, 0, 66, 2, S('glass_pane'))
    # porte de garage (sectionnelle blanche)
    R.fill(13, 64, 9, 15, 66, 9, S('smooth_quartz'))
    R.fill(13, 67, 9, 15, 67, 9, S('white_concrete'))
    for a in (13, 14, 15):
        R.set(a, 65, 9, S('quartz_bricks'))
    # ------------------------------------------------ intérieur
    # salon (a 6..11, b 5..8)
    canape(R, 6, 64, 6, 'east' if False else 'south', 3, 'spruce', 'dark_oak') if False else None
    canape(R, 11, 64, 5, 'north' if False else 'south', 3, 'dark_oak', 'dark_oak') if False else None
    for a in (8, 9, 10):
        R.set(a, 64, 5, R.S('dark_oak_stairs', facing='north', half='bottom'))
    R.set(7, 64, 5, R.S('dark_oak_trapdoor', facing='east', half='bottom', open=True))
    R.set(11, 64, 5, R.S('dark_oak_trapdoor', facing='west', half='bottom', open=True))
    table_basse(R, 9, 64, 7)
    tapis(R, 8, 6, 10, 8, 64, st['coul'])
    R.set(11, 64, 8, S('bookshelf'))
    plante(R, 6, 64, 8, 'potted_fern')
    fauteuil(R, 6, 64, 6, 'east', 'spruce', 'spruce') if False else R.set(6, 64, 6, R.S('spruce_stairs', facing='west', half='bottom'))
    # cuisine (a 6..11, b 1..3)
    for a in range(6, 12):
        if a == 8:
            R.set(a, 64, 1, S('water_cauldron', level=1))
        elif a == 10:
            R.set(a, 64, 1, R.S('smoker', facing='south', lit=False))
        elif a == 11:
            R.set(a, 64, 1, S('iron_block'))
            R.set(a, 65, 1, S('iron_block'))
            continue
        else:
            R.set(a, 64, 1, R.S('barrel', facing='south', open=False))
        R.set(a, 66, 1, R.S('spruce_trapdoor', facing='south', half='top', open=True))
    table(R, 8, 64, 3, 'spruce')
    table(R, 9, 64, 3, 'spruce')
    chaise(R, 7, 64, 3, 'east')
    chaise(R, 10, 64, 3, 'west')
    # chambre (a 1..4, b 5..8)
    lit(R, 2, 64, 6, 'north' if False else 'west', st['coul']) if False else lit(R, 2, 64, 7, 'west', st['coul'])
    R.set(1, 64, 8, R.S('barrel', facing='up', open=False))
    R.set(1, 64, 6, R.S('barrel', facing='up', open=False))
    commode(R, 4, 64, 5, 'north' if False else 'west', 1) if False else R.set(4, 64, 5, R.S('chiseled_bookshelf', facing='north'))
    # salle de bain (a 1..4, b 1..3)
    baignoire(R, 1, 64, 1, 'east', 2) if False else None
    R.set(1, 64, 1, S('water_cauldron', level=3))
    R.set(1, 64, 2, S('water_cauldron', level=3))
    toilette(R, 4, 64, 1, 'south')
    lavabo(R, 3, 64, 3, 'north') if False else R.set(3, 64, 1, S('water_cauldron', level=1))
    # garage : établi, étagères
    R.set(13, 64, 2, S('crafting_table'))
    R.set(14, 64, 2, R.S('barrel', facing='south', open=False))
    R.set(15, 64, 2, R.S('barrel', facing='south', open=False))
    R.set(15, 65, 2, R.S('barrel', facing='south', open=False))
    for (a, b) in ((3, 6), (3, 2), (9, 6), (9, 2), (14, 5)):
        R.lampe(a, 68, b, S('ochre_froglight', axis='y'), S('white_concrete'), Z)
    # ------------------------------------------------ terrain avant (b 10..24 = x 54..68)
    for a in range(-1, 18):
        for b in range(10, 25):
            R.set(a, 63, b, RU.GAZON)
    for a in (13, 14, 15):
        for b in range(10, 25):
            R.set(a, 63, b, S('gray_concrete'))
    for b in range(11, 25):
        R.set(7, 63, b, S('smooth_stone'))
    for b in range(11, 14):
        R.set(8, 63, b, S('smooth_stone'))
    # boîte aux lettres sur poteau
    R.set(5, 64, 23, S('spruce_fence'))
    R.set(5, 65, 23, R.S('barrel', facing='east' if False else 'south', open=False))
    # plates-bandes devant la maison
    fl = ['poppy', 'dandelion', 'azure_bluet', 'red_tulip', 'white_tulip', 'pink_tulip', 'allium', 'cornflower']
    for a in range(0, 13):
        if a in (6, 7, 8):
            continue
        R.set(a, 63, 10, S('rooted_dirt'))
        R.set(a, 64, 10, S(rng.choice(fl)) if a % 3 else S('azalea_leaves', persistent=True, distance=1, waterlogged=False))
    # arbre de façade
    tx, tz = R.xz(3, 17)
    RU.feuillu(ctx.m, tx, 64, tz, rng, h=5, tronc='oak_log' if i != 1 else 'birch_log',
               feuilles='oak_leaves' if i != 1 else 'birch_leaves', r=2)
    # bacs de recyclage près de l'entrée de garage
    R.set(12, 64, 22, S('blue_shulker_box', facing='up'))
    R.set(12, 64, 23, S('brown_shulker_box', facing='up'))
    # voiture dans l'entrée
    w = RU.Ecrivain(ctx)
    if st['auto']:
        cx, cz = R.xz(14, 14)
        RU.voiture(w, cx, cz, R.d('south'), st['auto'])
    # ------------------------------------------------ cour arrière (b -10..-1) clôturée
    for a in range(-1, 17):
        R.set(a, 64, -10, S('spruce_fence'))
    for b in range(-10, 0):
        R.set(-1, 64, b, S('spruce_fence'))
        R.set(17, 64, b, S('spruce_fence'))
    if i == 0:
        # remise
        R.fill(12, 64, -8, 16, 66, -5, S('spruce_planks'))
        R.fill(12, 67, -8, 16, 67, -5, S('spruce_slab', type='bottom'))
        porte(R, 14, 64, -5, 'north', 'spruce', 'left')
        R.set(4, 64, -3, R.S('smoker', facing='south', lit=False))
        R.set(3, 64, -5, R.S('spruce_stairs', facing='north', half='bottom'))
    elif i == 1:
        # piscine hors-terre
        for a in range(4, 11):
            for b in range(-8, -2):
                bord = a in (4, 10) or b in (-8, -3)
                R.set(a, 64, b, S('light_blue_concrete') if bord else S('water'))
                if not bord:
                    R.set(a, 63, b, S('light_blue_concrete'))
                R.set(a, 65, b, S('white_carpet')) if bord else None
        R.set(11, 64, -5, R.S('spruce_stairs', facing='east', half='bottom'))
    else:
        # patio, parasol, corde à linge
        for a in range(2, 8):
            for b in range(-4, 0):
                R.set(a, 63, b, S('stone_bricks'))
        table(R, 4, 64, -2, 'birch', nappe='white')
        chaise(R, 3, 64, -2, 'east', 'birch')
        chaise(R, 5, 64, -2, 'west', 'birch')
        for k in range(3):
            R.set(12, 64 + k, -7, S('spruce_fence'))
            R.set(16, 64 + k, -7, S('spruce_fence'))
        for a in range(13, 16):
            R.set(a, 66, -7, S('tripwire', attached=False, disarmed=False, powered=False, east=False, west=False,
                                north=False, south=False))
        R.set(14, 65, -7, S('white_banner', rotation=0)) if False else None


def bungalows(ctx):
    for i, z_sud in enumerate((121, 140, 159)):
        bungalow(ctx, i, z_sud)


def terrain_balle(ctx):
    """Terrain de balle-molle (x 2..34, z 104..157). Marbre au sud-est."""
    m = ctx.m
    rng = ctx.rng
    Z = 'balle'
    ctx.zones[Z] = (18, 130)
    hx, hz = 30, 152
    # champ intérieur (terre battue) : quart de disque + carré
    for x in range(2, 35):
        for z in range(104, 158):
            d = ((x - hx) ** 2 + (z - hz) ** 2) ** 0.5
            if d <= 16 and x <= hx + 1 and z <= hz + 1:
                if d >= 11.5 or (x >= hx - 1 or z >= hz - 1) or ((x - (hx - 6)) ** 2 + (z - (hz - 6)) ** 2) <= 2.3:
                    m.set(x, 63, z, S('packed_mud'))
    for (x, z) in ((hx, hz - 9), (hx - 9, hz - 9), (hx - 9, hz)):
        m.set(x, 64, z, S('white_carpet'))
    m.set(hx, 64, hz, S('quartz_slab', type='bottom'))
    m.set(hx - 5, 63, hz - 5, S('packed_mud'))
    m.set(hx - 5, 64, hz - 5, S('white_carpet'))
    # lignes de fausse balle (craie)
    for k in range(1, 46):
        if hz - k >= 105:
            m.set(hx, 64, hz - k, S('white_carpet')) if m.est_air(hx, 64, hz - k) else None
        if hx - k >= 3:
            m.set(hx - k, 64, hz, S('white_carpet')) if m.est_air(hx - k, 64, hz) else None
    # arrêt-balle derrière le marbre
    for k in range(-3, 4):
        for y in range(64, 68):
            m.set(hx + 3, y, hz + k, S('iron_bars'))
            m.set(hx + k, y, hz + 3, S('iron_bars'))
    # clôture du champ extérieur
    for x in range(2, 36):
        m.set(x, 64, 104, S('iron_bars'))
        m.set(x, 65, 104, S('iron_bars'))
    for z in range(104, 158):
        m.set(2, 64, z, S('iron_bars'))
        m.set(2, 65, z, S('iron_bars'))
    for z in range(104, 158):
        m.set(35, 64, z, S('iron_bars')) if not (140 <= z <= 142) else None
    for x in range(2, 36):
        m.set(x, 64, 158, S('iron_bars')) if not (20 <= x <= 22) else None
    # gradins (1re base, côté est) x 32..34
    for z in range(130, 148):
        for k, x in enumerate((32, 33, 34)):
            m.set(x, 64 + k, z, S('spruce_stairs', facing='east', half='bottom', shape='straight', waterlogged=False))
            for y in range(64, 64 + k):
                m.set(x, y, z, S('spruce_planks'))
    # abris des joueurs
    for (x1, z1, x2, z2, reg) in ((22, 154, 27, 155, 'north'),):
        for x in range(x1, x2 + 1):
            m.set(x, 64, z1, S('spruce_stairs', facing='south', half='bottom', shape='straight', waterlogged=False))
            m.set(x, 64, z2, S('spruce_planks'))
            m.set(x, 65, z2, S('spruce_planks'))
            m.set(x, 66, z1, S('spruce_slab', type='bottom'))
            m.set(x, 66, z2, S('spruce_slab', type='bottom'))
    # tableau indicateur
    for x in range(4, 12):
        for y in range(64, 70):
            if x in (5, 10) and y < 67:
                m.set(x, y, 105, S('spruce_fence'))
            elif y >= 67:
                m.set(x, y, 105, S('green_concrete'))
    for x, txt in ((10, ['VISITEURS', '3', '', '']), (8, ['PRÉ', '7e manche', '', '']), (6, ['SAINT-AURÈLE', '5', '', ''])):
        m.set(x, 68, 106, S('birch_wall_sign', facing='south'))
        m.sign(x, 68, 106, txt, 'white', True)
    m.set(8, 67, 106, S('birch_wall_sign', facing='south'))
    m.sign(8, 67, 106, ['LIGUE DE BALLE', 'DE SAINT-AURÈLE', '', ''], 'yellow', True)
    # tours d'éclairage
    for (x, z) in ((3, 105), (34, 106), (3, 156)):
        for y in range(64, 72):
            m.set(x, y, z, S('andesite_wall'))
        for dx in (-1, 0, 1):
            xx = x + dx
            if 0 <= xx:
                ctx.lampe(xx, 72, z, S('sea_lantern'), S('light_gray_concrete'), Z)
        m.set(x, 73, z, S('smooth_stone_slab', type='bottom'))
    # quelques arbres autour, bancs
    RU.banc(RU.Ecrivain(ctx), 30, 128, 'west', n=3)
    ctx.poi('terrain_balle', 23, 64, 145, 135)


def stationnement_so(ctx):
    """Petit stationnement public x 4..26 z 86..100 (clients de Rita / dépanneur)."""
    m = ctx.m
    w = RU.Ecrivain(ctx)
    for x in range(3, 28):
        for z in range(86, 101):
            m.set(x, 63, z, RU.ASPHALTE)
    for x in range(4, 28, 4):
        for z in list(range(86, 91)) + list(range(96, 101)):
            m.set(x, 63, z, RU.BLANC)
    # accès par la rue Principale
    for x in range(12, 18):
        for z in range(84, 86):
            m.set(x, 63, z, RU.ASPHALTE)
    for x in range(3, 28):
        if not 12 <= x <= 17:
            m.set(x, 64, 85, S('spruce_leaves', persistent=True, distance=1, waterlogged=False))
    for (cx, cz, d, c) in ((6, 88, 'north', 'blue'), (18, 88, 'north', 'white'), (22, 98, 'south', 'orange'),
                           (10, 98, 'south', 'light_blue')):
        RU.voiture(w, cx, cz, d, c)
    m.set(28, 64, 93, S('andesite_wall'))
    for y in range(64, 69):
        m.set(15, y, 93, S('andesite_wall'))
    for (dx, dz) in ((1, 0), (-1, 0)):
        m.set(15 + dx, 69, 93, S('smooth_stone_slab', type='bottom'))
        ctx.lampe(15 + dx, 68, 93, S('ochre_froglight', axis='y'), S('gray_stained_glass'), 'rita')
    m.set(15, 69, 93, S('smooth_stone_slab', type='bottom'))
