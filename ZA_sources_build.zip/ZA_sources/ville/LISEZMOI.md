# Saint-Aurèle — ville du prologue + structures du monde principal

Généré par `python3 gen_ville.py` (déterministe, graine 1250 ; ~12 s avec aperçus, ~4 s avec `--sans-apercus` ;
`--structures` = seulement arrivée/hall/zone neutre). Deux exécutions donnent des fichiers identiques (octet pour octet).
Blocs vanilla 1.20.1 + mods décoratifs (Handcrafted, Macaw's, Create Deco : voir za_moderne.py ; `ZA_VANILLE=1` = vanilla seul) ; chaque état (palette, calques, lampes, props) est validé contre le rapport officiel
`server.jar --reports` (copie compacte : `blocs_1_20_1.json.gz`) et écrit **complet** (toutes les propriétés).

## Fichiers
| fichier | contenu |
|---|---|
| `town.json.gz` | ville : size [288,48,288], offset [-64,58,-64] (x,z ∈ [-64,223], y 58..105), 772 279 blocs non-air, palette 483, 132 panneaux, 1 coffre |
| `layers.json` | calques factices : depanneur_ferme 71, quarantaine 938, gyro_a 16, gyro_b 16, incident 118, chaos 1198, checkpoint 241 (+ gyro_poste_a/b 8, gyro_quarantaine_a/b 2) |
| `lamps.json` | 321 sources lumineuses (toutes celles de la ville), groupes g = 0..11 |
| `pois.json` | 78 entrées : points, zones, chemins, caméras |
| `props.json` | ambulance (38 pièces), voiture_police (25), camion_militaire (33), helicoptere (33), autobus_scolaire (53) |
| `arrivee.json.gz` + `_pois` | 48×14×48, offset [-24,-1,-24], 3 335 blocs ; POIs reveil, coffre_depart, bus, feu |
| `hall.json.gz` + `_pois` | 32×16×24, offset [-16,-1,-12], 3 900 blocs ; POIs entree, socle1..8, plaque (+ `plaques` : les 44 panneaux vierges) |
| `zone_neutre.json.gz` + `_pois` | 40×16×40, offset [-20,-1,-20], 2 578 blocs ; POIs centre, portail, tableau, etal1..4, rayon=18 |
| `apercus/*.png` | vues du dessus, isométriques (SE/NO), gros plans, coupes, plans d'étage, calques appliqués |
| `za_*.py` | modules : blocs/validation, rendu, mobilier, rue, bâtiments, calques, POIs, props, vérifications |

Les structures du monde principal : base = point de pose, sol de marche à y=0, socle de sol plein à y=-1 sur toute l'emprise,
air implicite jusqu'à y=+12 (utiliser `placer … degager`).

## Conventions
- y des POIs = pieds (sol de marche 64) ; x,z au centre du bloc (+0,5). yaw : 0 sud, 90 ouest, 180 nord, -90 est.
- Portes : 2 moitiés, lits : 2 parties, plantes hautes : 2 blocs ; clôtures/vitres/barreaux/murets et formes d'escaliers
  **pré-calculés** comme le ferait le jeu (le plugin pose sans physique) ; feuilles `persistent=true` ; aucun bloc à gravité.
- Plafonniers encastrés : un tapis assorti est posé dessus à l'étage supérieur (pas de « tuile lumineuse » dans le plancher).
- Lampes : `off` = bloc plein non lumineux assorti (gray_stained_glass pour lampadaires, light_gray_concrete pour
  sea_lantern, white_concrete pour plafonniers ochre_froglight…). Groupes : 0 = station/autobus, puis anneaux de distance ;
  **l'hôpital (sur lequel finit la caméra) s'éteint en dernier (g=11)**.
- Gyrophares : `gyro_a` = rouge, `gyro_b` = bleu (+ bloc `light` invisible au-dessus quand la case est libre).
  `gyro_a/b` contiennent AUSSI la voiture de police du calque quarantaine : n'activer qu'avec `quarantaine`, sinon utiliser
  `gyro_poste_a/b` (poste de police + ambulance statique).
- Vérifié automatiquement : 0 état invalide, toutes les sources lumineuses listées, tous les POIs de position accessibles à
  pied depuis l'intersection (BFS mode aventure, portes de bois ouvrables).

## POIs (principaux)
reveil (19.5,69,58.5) · radio_2A (17.5,70,61.5) · coffre_2A (27.5,69,51.5) · porte_2A (29.5,69,52.5) · couloir_2e (31.5,69,55.5) ·
porte_2B (33.5,69,52.5) · lit_2B (44.5,69,57.5) · gagnon_debout (43.5,69,58.5) · entree_immeuble (31.5,64,66.5) ·
depanneur_porte (60.5,64,85.5) · depanneur_comptoir (62.5,64,90.5) · depanneur_client (60.5,64,90.5) · rita_comptoir (37.5,64,93.5) ·
hopital_entree (116.5,64,56.5) · hopital_accueil (110.5,64,34.5) · hopital_pharmacie (125.5,64,41.5) · hopital_chambre1..4 ·
hopital_lit1..8 (têtes, y=64, z=11.5) · hopital_barriere (116.5,64,69.5) · hopital_cour_incident (118.5,64,60.5) ·
ambulance_baie (87.5,64,44.5) · police_entree (99.5,64,86.5) · police_comptoir (99.5,64,95.5) · intersection (76.5,64,76.5) ·
checkpoint_vega (67.5,64,77.5) · station_service (146.5,64,99.5) · bus_porte (131.5,64,113.5) · maison1..3 (55.5,64,114.5/133.5/152.5) ·
parc_banc (22.5,64,21.5) · abribus (126.5,64,70.5) · passant1..12.
Zones : bus_interieur, zone_citoyens (rue Principale ; + zone_citoyens_erables), appart_2B.
Chemins : chemin_ambulance (13 pts, x=200 → baie), chemin_convoi (z=78.5), chemin_patient, spawn_chaos (12).
Caméras : camera_blackout (260 ticks), camera_intro (160 ticks, finit devant la fenêtre de la chambre du 2A).
Extras : baton_2A, hopital_pharmacien, hopital_infirmiere(_ext), hopital_heliport, cafe_comptoir, parc_kiosque, parc_jeux,
police_cellule, bus_siege, ecole_entree, terrain_balle, checkpoint_passage, spawn.

## Limites connues
- Pas de poteaux électriques ni de panneaux « ARRÊT » (optionnels). Les panneaux ne peuvent pas changer de texte via les
  calques (ex. « Fermé pour cause de maladie » : à afficher par Skript).
- Le rendu des aperçus est fait par notre propre moteur (modèles/textures vanilla) : pas d'éclairage ni de fumée.
- Validé hors jeu uniquement (aucun serveur lancé, conformément à la consigne).
