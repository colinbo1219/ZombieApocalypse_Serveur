# -*- coding: utf-8 -*-
"""za_rendu : aperçus PNG (vue du dessus, plans d'étage, isométrique) rendus avec les
modèles de blocs et textures vanilla 1.20.1 (lus depuis le client extrait).
Outil de vérification visuelle uniquement (le générateur fonctionne sans)."""
import json
import math
import os

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from za_blocs import parse

ASSETS = os.environ.get('ZA_ASSETS', '/tmp/claude-0/-home-claude/11e94848-bd76-5e3f-a43b-90e28f9e6572/scratchpad/assets/assets/minecraft')

TEINTE = {
    'grass_block': (0x91, 0xBD, 0x59), 'grass': (0x91, 0xBD, 0x59), 'tall_grass': (0x91, 0xBD, 0x59),
    'fern': (0x91, 0xBD, 0x59), 'large_fern': (0x91, 0xBD, 0x59), 'sugar_cane': (0x91, 0xBD, 0x59),
    'potted_fern': (0x91, 0xBD, 0x59),
    'oak_leaves': (0x77, 0xAB, 0x2F), 'jungle_leaves': (0x77, 0xAB, 0x2F), 'acacia_leaves': (0x77, 0xAB, 0x2F),
    'dark_oak_leaves': (0x77, 0xAB, 0x2F), 'mangrove_leaves': (0x8D, 0xB1, 0x27), 'vine': (0x77, 0xAB, 0x2F),
    'spruce_leaves': (0x61, 0x99, 0x61), 'birch_leaves': (0x80, 0xA7, 0x55),
    'water': (0x3F, 0x76, 0xE4), 'water_cauldron': (0x3F, 0x76, 0xE4), 'lily_pad': (0x20, 0x80, 0x30),
}

LAINE = {
    'white': (234, 236, 237), 'orange': (241, 118, 20), 'magenta': (190, 69, 180), 'light_blue': (58, 175, 217),
    'yellow': (249, 198, 40), 'lime': (112, 185, 26), 'pink': (238, 141, 172), 'gray': (63, 68, 72),
    'light_gray': (142, 142, 135), 'cyan': (21, 138, 145), 'purple': (122, 42, 173), 'blue': (53, 57, 157),
    'brown': (114, 72, 41), 'green': (85, 110, 28), 'red': (161, 39, 35), 'black': (21, 21, 26),
}
BOIS = ['oak', 'spruce', 'birch', 'jungle', 'acacia', 'dark_oak', 'mangrove', 'cherry', 'bamboo', 'crimson', 'warped']


class Modeles:
    def __init__(self, assets=ASSETS):
        self.assets = assets
        self._bs = {}
        self._mod = {}
        self._tex = {}
        self._elems = {}

    # ---------------------------------------------------------------- fichiers
    def blockstate(self, nom):
        if nom not in self._bs:
            p = os.path.join(self.assets, 'blockstates', nom + '.json')
            self._bs[nom] = json.load(open(p)) if os.path.exists(p) else None
        return self._bs[nom]

    def modele(self, ref):
        ref = ref.split(':', 1)[-1]
        if ref not in self._mod:
            p = os.path.join(self.assets, 'models', ref + '.json')
            self._mod[ref] = json.load(open(p)) if os.path.exists(p) else {}
        return self._mod[ref]

    def texture(self, ref):
        ref = ref.split(':', 1)[-1]
        if ref not in self._tex:
            p = os.path.join(self.assets, 'textures', ref + '.png')
            if os.path.exists(p):
                im = Image.open(p).convert('RGBA')
                w, h = im.size
                if h > w:  # animée : 1re image
                    im = im.crop((0, 0, w, w))
                if w != 16:
                    im = im.resize((16, 16), Image.NEAREST)
            else:
                im = None
            self._tex[ref] = im
        return self._tex[ref]

    def resoudre(self, ref):
        """(textures fusionnées, éléments) en remontant les parents."""
        textures = {}
        elements = None
        chaine = []
        r = ref
        while r:
            m = self.modele(r)
            chaine.append(m)
            r = m.get('parent')
            if r and r.split(':', 1)[-1].startswith('builtin/'):
                break
        for m in reversed(chaine):
            textures.update(m.get('textures', {}))
        for m in chaine:
            if 'elements' in m:
                elements = m['elements']
                break
        return textures, elements or []

    @staticmethod
    def _tex_var(textures, v):
        n = 0
        while v and v.startswith('#') and n < 10:
            v = textures.get(v[1:])
            n += 1
        return v

    # ---------------------------------------------------------------- sélection des variantes
    @staticmethod
    def _match(cond, props):
        if 'OR' in cond:
            return any(Modeles._match(c, props) for c in cond['OR'])
        if 'AND' in cond:
            return all(Modeles._match(c, props) for c in cond['AND'])
        for k, v in cond.items():
            if props.get(k) not in str(v).split('|'):
                return False
        return True

    def variantes(self, st):
        n, props = parse(st)
        c = n.split(':', 1)[1]
        bs = self.blockstate(c)
        if not bs:
            return []
        out = []
        if 'variants' in bs:
            for key, v in bs['variants'].items():
                ok = True
                if key:
                    for kv in key.split(','):
                        k, val = kv.split('=')
                        if props.get(k) != val:
                            ok = False
                            break
                if ok:
                    out.append(v[0] if isinstance(v, list) else v)
                    break
        else:
            for part in bs.get('multipart', []):
                if 'when' not in part or self._match(part['when'], props):
                    ap = part['apply']
                    out.append(ap[0] if isinstance(ap, list) else ap)
        return out

    # ---------------------------------------------------------------- géométrie
    @staticmethod
    def _rot_vec(v, rx, ry):
        x, y, z = v
        for _ in range((rx // 90) % 4):   # up -> north
            y, z = z, -y
        for _ in range((ry // 90) % 4):   # north -> east
            x, z = -z, x
        return (x, y, z)

    _DIRV = {'up': (0, 1, 0), 'down': (0, -1, 0), 'north': (0, 0, -1), 'south': (0, 0, 1), 'west': (-1, 0, 0),
             'east': (1, 0, 0)}
    _VDIR = {v: k for k, v in _DIRV.items()}

    def elements(self, st, rot_vue=0):
        """Liste d'éléments : (x1,y1,z1,x2,y2,z2, {dir: (img, teinte_bool)}, rot_haut) en 0..16."""
        key = (st, rot_vue)
        if key in self._elems:
            return self._elems[key]
        n, props = parse(st)
        c = n.split(':', 1)[1]
        res = []
        for var in self.variantes(st):
            textures, els = self.resoudre(var['model'])
            rx, ry = var.get('x', 0), var.get('y', 0) + rot_vue
            for e in els:
                f, t = e['from'], e['to']
                faces = {}
                for d, fd in e.get('faces', {}).items():
                    tex = self._tex_var(textures, fd.get('texture', ''))
                    if not tex or tex.startswith('#'):
                        continue
                    im = self.texture(tex)
                    if im is None:
                        continue
                    uv = fd.get('uv')
                    if uv is None:
                        x1, y1, z1 = f
                        x2, y2, z2 = t
                        uv = {'up': [x1, z1, x2, z2], 'down': [x1, 16 - z2, x2, 16 - z1],
                              'north': [16 - x2, 16 - y2, 16 - x1, 16 - y1], 'south': [x1, 16 - y2, x2, 16 - y1],
                              'west': [z1, 16 - y2, z2, 16 - y1], 'east': [16 - z2, 16 - y2, 16 - z1, 16 - y1]}[d]
                    u1, v1, u2, v2 = uv
                    a, b = sorted((u1, u2)), sorted((v1, v2))
                    box = (int(math.floor(a[0])), int(math.floor(b[0])), max(int(math.ceil(a[1])), int(math.floor(a[0])) + 1),
                           max(int(math.ceil(b[1])), int(math.floor(b[0])) + 1))
                    sub = im.crop(box)
                    if u1 > u2:
                        sub = sub.transpose(Image.FLIP_LEFT_RIGHT)
                    if v1 > v2:
                        sub = sub.transpose(Image.FLIP_TOP_BOTTOM)
                    r = fd.get('rotation', 0)
                    if r:
                        sub = sub.rotate(-r, expand=True)
                    teinte = TEINTE.get(c) if 'tintindex' in fd else None
                    if teinte:
                        arr = np.asarray(sub).astype(np.float32)
                        arr[..., :3] *= np.array(teinte, np.float32) / 255.0
                        sub = Image.fromarray(arr.clip(0, 255).astype(np.uint8), 'RGBA')
                    nd = self._VDIR[self._rot_vec(self._DIRV[d], rx, ry)]
                    if nd == 'up' or nd == 'down':
                        # rotation de la texture de dessus selon ry (et rx=180)
                        ang = ry % 360
                        if rx % 360 == 180:
                            ang = (ang + 180) % 360
                        if ang:
                            sub = sub.rotate(-ang, expand=True)
                    faces[nd] = sub
                # coins tournés autour du centre
                pts = []
                for px in (f[0], t[0]):
                    for py in (f[1], t[1]):
                        for pz in (f[2], t[2]):
                            v = self._rot_vec((px - 8, py - 8, pz - 8), rx, ry)
                            pts.append((v[0] + 8, v[1] + 8, v[2] + 8))
                xs, ys, zs = zip(*pts)
                rot_el = e.get('rotation')
                croix = rot_el is not None and abs(rot_el.get('angle', 0)) >= 45 and rot_el.get('axis') == 'y'
                res.append((min(xs), min(ys), min(zs), max(xs), max(ys), max(zs), faces, croix))
        if not res:
            res = self._repli(c, props, rot_vue)
        self._elems[key] = res
        return res

    # ---------------------------------------------------------------- blocs sans modèle (entités de bloc…)
    def _couleur_img(self, rgb, a=255):
        return Image.new('RGBA', (16, 16), tuple(rgb) + (a,))

    def _repli(self, c, props, rot_vue):
        def boite(x1, y1, z1, x2, y2, z2, im_haut, im_cote=None):
            im_cote = im_cote or im_haut
            return [(x1, y1, z1, x2, y2, z2, {'up': im_haut, 'south': im_cote, 'east': im_cote,
                                              'north': im_cote, 'west': im_cote}, False)]

        def tourner(el, facing):
            # facing -> rotation de la boîte (modèle défini pour facing=south)
            ang = {'south': 0, 'west': 90, 'north': 180, 'east': 270}.get(facing, 0) + rot_vue
            out = []
            for (x1, y1, z1, x2, y2, z2, fa, cr) in el:
                pts = []
                for px in (x1, x2):
                    for pz in (z1, z2):
                        v = self._rot_vec((px - 8, 0, pz - 8), 0, ang)
                        pts.append((v[0] + 8, v[2] + 8))
                xs, zs = zip(*pts)
                out.append((min(xs), y1, min(zs), max(xs), y2, max(zs), fa, cr))
            return out

        if c.endswith('_bed'):
            col = LAINE.get(c[:-4], (200, 200, 200))
            laine = self._couleur_img(col)
            if props.get('part') == 'head':
                oreiller = self._couleur_img((235, 235, 235))
                el = [(0, 0, 0, 16, 9, 16, {'up': laine, 'south': laine, 'east': laine}, False),
                      (2, 9, 8, 14, 10, 15, {'up': oreiller, 'south': oreiller, 'east': oreiller}, False)]
                # modèle défini vers le sud : tête vers +z
                return tourner(el, props.get('facing', 'south'))
            return boite(0, 0, 0, 16, 9, 16, laine)
        if c in ('chest', 'trapped_chest', 'ender_chest'):
            im = self.texture('block/oak_planks') if c != 'ender_chest' else self.texture('block/obsidian')
            return boite(1, 0, 1, 15, 14, 15, im)
        if c.endswith('_sign'):
            bois = next((b for b in BOIS if c.startswith(b)), 'oak')
            im = self.texture('block/%s_planks' % bois) or self._couleur_img((160, 120, 70))
            if 'wall_hanging' in c:
                return tourner([(0, 2, 7, 16, 12, 9, {'up': im, 'south': im, 'east': im}, False)], props.get('facing', 'south'))
            if 'hanging' in c:
                return boite(1, 0, 7, 15, 10, 9, im)
            if 'wall' in c:
                # panneau mural : face vers `facing`, collé côté opposé
                return tourner([(0, 4, 0, 16, 12, 2, {'up': im, 'south': im, 'east': im}, False)], props.get('facing', 'south'))
            return boite(0, 7, 7, 16, 16, 9, im) + boite(7, 0, 7, 9, 7, 9, im)
        if c.endswith('_banner'):
            col = LAINE.get(c.replace('_wall_banner', '').replace('_banner', ''), (200, 200, 200))
            im = self._couleur_img(col)
            if 'wall' in c:
                return tourner([(1, 0, 0, 15, 16, 1, {'up': im, 'south': im, 'east': im}, False)], props.get('facing', 'south'))
            return boite(1, 0, 7, 15, 16, 9, im)
        if c in ('water',):
            im = self.texture('block/water_still')
            if im is not None:
                arr = np.asarray(im).astype(np.float32)
                arr[..., :3] *= np.array(TEINTE['water'], np.float32) / 255.0
                arr[..., 3] = 190
                im = Image.fromarray(arr.clip(0, 255).astype(np.uint8), 'RGBA')
            return boite(0, 0, 0, 16, 14, 16, im or self._couleur_img((63, 118, 228), 190))
        if c == 'lava':
            return boite(0, 0, 0, 16, 14, 16, self.texture('block/lava_still') or self._couleur_img((230, 90, 10)))
        if c.endswith('shulker_box'):
            col = LAINE.get(c.replace('_shulker_box', ''), (150, 110, 150))
            return boite(0, 0, 0, 16, 16, 16, self._couleur_img(col))
        if c == 'decorated_pot':
            return boite(1, 0, 1, 15, 16, 15, self.texture('block/terracotta'))
        if c.endswith('_head') or c.endswith('_skull'):
            return boite(4, 0, 4, 12, 8, 12, self._couleur_img((180, 180, 160)))
        if c == 'bell':
            return boite(4, 4, 4, 12, 13, 12, self.texture('block/gold_block'))
        if c in ('air', 'cave_air', 'void_air', 'barrier', 'light', 'structure_void'):
            return []
        im = self.texture('block/' + c)
        if im is not None:
            return boite(0, 0, 0, 16, 16, 16, im)
        return boite(3, 0, 3, 13, 10, 13, self._couleur_img((255, 0, 255)))

    # ---------------------------------------------------------------- tuiles vue du dessus
    def tuile_haut(self, st, N, rot_vue=0):
        """Tuile N×N RGBA vue du dessus."""
        key = ('T', st, N, rot_vue)
        if key in self._elems:
            return self._elems[key]
        t = Image.new('RGBA', (N, N), (0, 0, 0, 0))
        els = self.elements(st, rot_vue)
        vide = True
        a_non_croix = any(not e[7] for e in els)
        for (x1, y1, z1, x2, y2, z2, faces, croix) in sorted(els, key=lambda e: e[4]):
            im = faces.get('up')
            if croix and a_non_croix:
                continue
            if im is None and not croix:
                src = next(iter(faces.values()), None)
                if src is None:
                    continue
                col = moyenne(src)
                if col is None:
                    continue
                a = int(round(x1 / 16 * N)), int(round(z1 / 16 * N))
                b = int(round(x2 / 16 * N)), int(round(z2 / 16 * N))
                w, h = max(1, b[0] - a[0]), max(1, b[1] - a[1])
                t.alpha_composite(Image.new('RGBA', (w, h), tuple(int(c * 0.85) for c in col[:3]) + (255,)), a)
                vide = False
                continue
            if croix:
                # plante en croix / sans face du dessus : croix de couleur moyenne
                src = next(iter(faces.values()), None)
                if src is None:
                    continue
                col = moyenne(src)
                if col is None:
                    continue
                d = ImageDraw.Draw(t)
                m = max(1, N // 5)
                d.line([(m, m), (N - m, N - m)], fill=col, width=max(1, N // 6))
                d.line([(N - m, m), (m, N - m)], fill=col, width=max(1, N // 6))
                vide = False
                continue
            a = int(round(x1 / 16 * N)), int(round(z1 / 16 * N))
            b = int(round(x2 / 16 * N)), int(round(z2 / 16 * N))
            w, h = max(1, b[0] - a[0]), max(1, b[1] - a[1])
            sub = im.resize((w, h), Image.NEAREST if w >= 8 else Image.BILINEAR)
            t.alpha_composite(sub, a)
            vide = False
        self._elems[key] = t
        return t

    # ---------------------------------------------------------------- lutins isométriques
    def lutin(self, st, U, rot_vue=0):
        key = ('I', st, U, rot_vue)
        if key in self._elems:
            return self._elems[key]
        spr = Image.new('RGBA', (2 * U, 2 * U), (0, 0, 0, 0))
        els = self.elements(st, rot_vue)

        def ecran(px, py, pz):
            return ((px - pz) * U + U, (px + pz) * U / 2 - py * U + U)

        for (x1, y1, z1, x2, y2, z2, faces, croix) in sorted(els, key=lambda e: (e[0] + e[3] + e[1] + e[4] + e[2] + e[5])):
            X1, Y1, Z1, X2, Y2, Z2 = [v / 16.0 for v in (x1, y1, z1, x2, y2, z2)]
            if croix:
                src = next(iter(faces.values()), None)
                if src is None:
                    continue
                # deux plans diagonaux
                for (a, b) in (((X1, Z1), (X2, Z2)), ((X1, Z2), (X2, Z1))):
                    O = ecran(a[0], Y2, a[1])
                    E1 = np.subtract(ecran(b[0], Y2, b[1]), O)
                    E2 = np.subtract(ecran(a[0], Y1, a[1]), O)
                    _plaquer(spr, src, O, E1, E2, 0.9)
                continue
            for d in ('east', 'south', 'up'):
                im = faces.get(d)
                if im is None:
                    continue
                if d == 'up':
                    O = ecran(X1, Y2, Z1)
                    E1 = np.subtract(ecran(X2, Y2, Z1), O)
                    E2 = np.subtract(ecran(X1, Y2, Z2), O)
                    sh = 1.0
                elif d == 'south':
                    O = ecran(X1, Y2, Z2)
                    E1 = np.subtract(ecran(X2, Y2, Z2), O)
                    E2 = np.subtract(ecran(X1, Y1, Z2), O)
                    sh = 0.8
                else:
                    O = ecran(X2, Y2, Z2)
                    E1 = np.subtract(ecran(X2, Y2, Z1), O)
                    E2 = np.subtract(ecran(X2, Y1, Z2), O)
                    sh = 0.62
                _plaquer(spr, im, O, E1, E2, sh)
        self._elems[key] = spr
        return spr


def moyenne(im):
    a = np.asarray(im).astype(np.float32)
    m = a[..., 3] > 20
    if not m.any():
        return None
    c = a[m][:, :3].mean(0)
    return tuple(int(v) for v in c) + (255,)


def _plaquer(spr, im, O, E1, E2, sh):
    M = np.array([[E1[0], E2[0]], [E1[1], E2[1]]], float)
    det = np.linalg.det(M)
    if abs(det) < 1e-6:
        # face dégénérée (épaisseur nulle vue par la tranche) : trait
        return
    Mi = np.linalg.inv(M)
    tw, th = im.size
    a, b = tw * Mi[0, 0], tw * Mi[0, 1]
    d, e = th * Mi[1, 0], th * Mi[1, 1]
    c = -(a * O[0] + b * O[1])
    f = -(d * O[0] + e * O[1])
    src = im
    if sh != 1.0:
        arr = np.asarray(im).astype(np.float32)
        arr[..., :3] *= sh
        src = Image.fromarray(arr.clip(0, 255).astype(np.uint8), 'RGBA')
    out = src.transform(spr.size, Image.AFFINE, (a, b, c, d, e, f), resample=Image.NEAREST)
    spr.alpha_composite(out)


_MOD = None


def modeles():
    global _MOD
    if _MOD is None:
        _MOD = Modeles()
    return _MOD


def _police(t=12):
    for p in ('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'):
        if os.path.exists(p):
            return ImageFont.truetype(p, t)
    return ImageFont.load_default()


# ============================================================================ rendus
def vue_dessus(monde, chemin, px=3, region=None, ombrage=True, grille=0, marques=None, titre=None):
    """1 bloc = px pixels ; couleur = texture moyenne de la face du dessus du bloc visible le plus haut."""
    M = modeles()
    a = monde.a
    H, D, W = a.shape
    x1, z1, x2, z2 = region or (monde.x0, monde.z0, monde.x0 + W - 1, monde.z0 + D - 1)
    sub = a[:, z1 - monde.z0:z2 - monde.z0 + 1, x1 - monde.x0:x2 - monde.x0 + 1]
    # ignorer barrières / lumière invisibles
    invis = np.array([i for i, s in enumerate(monde.pal) if parse(s)[0] in ('minecraft:barrier', 'minecraft:light')] or [0], np.uint16)
    nonair = (sub != 0) & ~np.isin(sub, invis)
    hauteur = np.where(nonair.any(0), H - 1 - np.argmax(nonair[::-1], axis=0), -1)
    haut = np.take_along_axis(sub, np.clip(hauteur, 0, H - 1)[None], 0)[0]
    cols = {}
    for i in np.unique(haut):
        t = M.tuile_haut(monde.pal[int(i)], 8)
        c = moyenne(t)
        cols[int(i)] = c[:3] if c else (255, 0, 255)
    lut = np.zeros((len(monde.pal), 3), np.float32)
    for i, c in cols.items():
        lut[i] = c
    img = lut[haut]
    if ombrage:
        h = hauteur.astype(np.float32)
        gx = np.zeros_like(h)
        gx[1:, 1:] = (h[1:, 1:] - h[:-1, :-1])
        img *= (1.0 + np.clip(gx, -3, 3)[..., None] * 0.08)
        img *= (0.82 + 0.18 * np.clip((h - 60) / 30.0, 0, 1))[..., None]
    img[hauteur < 0] = (20, 20, 30)
    im = Image.fromarray(img.clip(0, 255).astype(np.uint8), 'RGB')
    im = im.resize((im.width * px, im.height * px), Image.NEAREST)
    _decorer(im, px, x1, z1, x2, z2, grille, marques, titre)
    im.save(chemin, optimize=True)
    return im


def _decorer(im, px, x1, z1, x2, z2, grille, marques, titre):
    d = ImageDraw.Draw(im)
    f = _police(max(9, min(14, px * 2 + 4)))
    if grille:
        for x in range((x1 // grille + 1) * grille, x2 + 1, grille):
            X = (x - x1) * px
            d.line([(X, 0), (X, im.height)], fill=(255, 255, 255, 60), width=1)
            d.text((X + 2, 2), str(x), fill=(255, 255, 0), font=f)
        for z in range((z1 // grille + 1) * grille, z2 + 1, grille):
            Z = (z - z1) * px
            d.line([(0, Z), (im.width, Z)], fill=(255, 255, 255, 60), width=1)
            d.text((2, Z + 2), str(z), fill=(255, 255, 0), font=f)
    if marques:
        for (nom, x, z) in marques:
            X, Z = (x - x1) * px, (z - z1) * px
            r = max(3, px // 2)
            d.ellipse([X - r, Z - r, X + r, Z + r], fill=(255, 0, 60), outline=(255, 255, 255))
            d.text((X + r + 1, Z - r - 2), nom, fill=(255, 255, 255), font=f, stroke_width=2, stroke_fill=(0, 0, 0))
    if titre:
        d.text((6, im.height - 22), titre, fill=(255, 255, 255), font=_police(16), stroke_width=2, stroke_fill=(0, 0, 0))


def plan_etage(monde, chemin, y_pied, region, N=12, hauteur=3, marques=None, titre=None, grille=5):
    """Plan d'un étage : empile les tuiles de y_pied-1 à y_pied+hauteur-1 (murs, meubles, sol)."""
    M = modeles()
    x1, z1, x2, z2 = region
    Wd, Dd = x2 - x1 + 1, z2 - z1 + 1
    img = Image.new('RGBA', (Wd * N, Dd * N), (25, 25, 32, 255))
    for y in range(y_pied - 1, y_pied + hauteur):
        if not (monde.y0 <= y < monde.y0 + monde.H):
            continue
        tranche = monde.a[y - monde.y0, z1 - monde.z0:z2 - monde.z0 + 1, x1 - monde.x0:x2 - monde.x0 + 1]
        assomb = 1.0 if y < y_pied + hauteur - 1 else 0.72
        for (zz, xx) in zip(*np.nonzero(tranche)):
            st = monde.pal[int(tranche[zz, xx])]
            t = M.tuile_haut(st, N)
            if assomb != 1.0:
                arr = np.asarray(t).astype(np.float32)
                arr[..., :3] *= assomb
                t = Image.fromarray(arr.astype(np.uint8), 'RGBA')
            img.alpha_composite(t, (int(xx) * N, int(zz) * N))
    img = img.convert('RGB')
    _decorer(img, N, x1, z1, x2, z2, grille, [(n, x, z) for (n, x, z) in (marques or []) if x1 <= x <= x2 + 1 and z1 <= z <= z2 + 1], titre)
    img.save(chemin, optimize=True)
    return img


def vue_iso(monde, chemin, U=6, region=None, y_max=None, rot=0, fond=(186, 214, 238), titre=None, y_min=None):
    """Isométrique 2:1 texturée, vue depuis le sud-est (rot=0) ; rot=180 : depuis le nord-ouest."""
    M = modeles()
    a = monde.a
    H, D, W = a.shape
    x1, z1, x2, z2 = region or (monde.x0, monde.z0, monde.x0 + W - 1, monde.z0 + D - 1)
    sub = a[:, z1 - monde.z0:z2 - monde.z0 + 1, x1 - monde.x0:x2 - monde.x0 + 1].copy()
    if y_max is not None:
        sub[y_max - monde.y0 + 1:] = 0
    if y_min is not None:
        sub[:max(0, y_min - monde.y0)] = 0
    invis = [i for i, s in enumerate(monde.pal) if parse(s)[0] in ('minecraft:barrier', 'minecraft:light')]
    for i in invis:
        sub[sub == i] = 0
    k = (rot // 90) % 4
    if k:
        sub = np.rot90(sub, k=k, axes=(2, 1)).copy()   # tourne la vue : k*90° sens horaire
    Hh, Dd, Ww = sub.shape
    # opacité (bloc plein non transparent)
    opaque_ids = np.zeros(len(monde.pal) + 1, bool)
    for i, s in enumerate(monde.pal):
        c = parse(s)[0].split(':', 1)[1]
        els = M.elements(s)
        plein = len(els) >= 1 and any(e[0] == 0 and e[1] == 0 and e[2] == 0 and e[3] == 16 and e[4] == 16 and e[5] == 16 for e in els)
        transp = 'glass' in c or 'leaves' in c or c in ('ice', 'slime_block', 'honey_block', 'spawner', 'water', 'beacon')
        opaque_ids[i] = plein and not transp
    op = opaque_ids[sub]
    nz = sub != 0
    cache = np.ones_like(nz)
    cache[:-1, :, :] &= op[1:, :, :]
    cache[:, :-1, :] &= op[:, 1:, :]
    cache[:, :, :-1] &= op[:, :, 1:]
    cache[-1] = False
    cache[:, -1, :] = False
    cache[:, :, -1] = False
    vis = nz & ~cache
    ys, zs, xs = np.nonzero(vis)
    ordre = np.lexsort((ys, xs + zs, xs + ys + zs))
    Wimg = (Ww + Dd) * U + 2 * U
    Himg = (Ww + Dd) * U // 2 + Hh * U + 2 * U
    img = Image.new('RGB', (Wimg, Himg), fond)
    ox = Dd * U
    oy = Hh * U
    for j in ordre:
        x, y, z = int(xs[j]), int(ys[j]), int(zs[j])
        st = monde.pal[int(sub[y, z, x])]
        spr = M.lutin(st, U, rot_vue=(k * 90) % 360)
        sx = (x - z) * U - U + ox
        sy = (x + z) * U // 2 - y * U - U + oy
        img.paste(spr, (sx, sy), spr)
    if titre:
        d = ImageDraw.Draw(img)
        d.text((10, 10), titre, fill=(20, 20, 20), font=_police(18))
    # recadrage sur le contenu
    bg = Image.new('RGB', img.size, fond)
    from PIL import ImageChops
    bb = ImageChops.difference(img, bg).getbbox()
    if bb:
        img = img.crop((max(0, bb[0] - 10), max(0, bb[1] - 10), min(img.width, bb[2] + 10), min(img.height, bb[3] + 10)))
    img.save(chemin, optimize=True)
    return img
