# -*- coding: utf-8 -*-
"""za_blocs : monde voxel, états de blocs validés (1.20.1), passes de connexion vanilla, export.

Tous les états de blocs passent par S(nom, **props) qui valide contre le rapport officiel
(blocs_1_20_1.json.gz, extrait de `server.jar --reports`) et complète les propriétés
manquantes avec l'état par défaut -> chaîne BlockData Bukkit complète et canonique.
"""
import base64
import gzip
import json
import os
import zlib

import numpy as np

ICI = os.path.dirname(os.path.abspath(__file__))

with gzip.open(os.path.join(ICI, 'blocs_1_20_1.json.gz'), 'rt', encoding='utf-8') as _f:
    REG = json.load(_f)

# ----------------------------------------------------------------------------- directions
DIRS = {'north': (0, -1), 'south': (0, 1), 'west': (-1, 0), 'east': (1, 0)}
OPP = {'north': 'south', 'south': 'north', 'west': 'east', 'east': 'west', 'up': 'down', 'down': 'up'}
CW = {'north': 'east', 'east': 'south', 'south': 'west', 'west': 'north'}      # sens horaire (vu du dessus)
CCW = {v: k for k, v in CW.items()}
YAW = {'south': 0, 'west': 90, 'north': 180, 'east': -90}                      # yaw Minecraft du regard


def dvec(d):
    return DIRS[d]


def dir_de(dx, dz):
    for k, v in DIRS.items():
        if v == (dx, dz):
            return k
    raise ValueError((dx, dz))


class ErreurBloc(Exception):
    pass


_CACHE = {}


def _norm(v):
    if isinstance(v, bool):
        return 'true' if v else 'false'
    return str(v).lower()


def S(nom, **props):
    """État de bloc validé et complet. `nom` avec ou sans 'minecraft:'."""
    key = (nom, tuple(sorted(props.items())))
    r = _CACHE.get(key)
    if r is not None:
        return r
    n = nom if ':' in nom else 'minecraft:' + nom
    if n not in REG:
        raise ErreurBloc('bloc inconnu en 1.20.1 : %s' % n)
    spec = REG[n]
    pdef = spec['p']
    vals = dict(spec['d'])
    for k, v in props.items():
        if k not in pdef:
            raise ErreurBloc('propriété %s invalide pour %s (valides : %s)' % (k, n, list(pdef)))
        v = _norm(v)
        if v not in pdef[k]:
            raise ErreurBloc('valeur %s=%s invalide pour %s (valides : %s)' % (k, v, n, pdef[k]))
        vals[k] = v
    if pdef:
        r = n + '[' + ','.join('%s=%s' % (k, vals[k]) for k in pdef) + ']'
    else:
        r = n
    _CACHE[key] = r
    return r


def parse(st):
    """'minecraft:x[a=b,c=d]' -> ('minecraft:x', {'a':'b','c':'d'})"""
    if '[' in st:
        n, rest = st.split('[', 1)
        rest = rest.rstrip(']')
        d = {}
        if rest:
            for kv in rest.split(','):
                k, v = kv.split('=')
                d[k] = v
        return n, d
    return st, {}


def valide(st):
    """Vérifie strictement un état complet (toutes les propriétés présentes et valides)."""
    n, p = parse(st)
    if n not in REG:
        return 'bloc inconnu %s' % n
    pdef = REG[n]['p']
    for k, v in p.items():
        if k not in pdef:
            return 'propriété inconnue %s dans %s' % (k, st)
        if v not in pdef[k]:
            return 'valeur invalide %s=%s dans %s' % (k, v, st)
    manq = [k for k in pdef if k not in p]
    if manq:
        return 'propriétés manquantes %s dans %s' % (manq, st)
    return None


def avec(st, **props):
    """Retourne l'état `st` avec des propriétés remplacées (validé)."""
    n, p = parse(st)
    p.update({k: _norm(v) for k, v in props.items()})
    return S(n, **p)


def nom_court(st):
    return parse(st)[0].split(':', 1)[1]


AIR = S('air')

# ----------------------------------------------------------------------------- familles
GRAVITE = {'sand', 'red_sand', 'gravel', 'suspicious_sand', 'suspicious_gravel', 'anvil', 'chipped_anvil',
           'damaged_anvil', 'dragon_egg', 'pointed_dripstone', 'scaffolding'}
GRAVITE |= {c + '_concrete_powder' for c in
            ['white', 'orange', 'magenta', 'light_blue', 'yellow', 'lime', 'pink', 'gray', 'light_gray', 'cyan',
             'purple', 'blue', 'brown', 'green', 'red', 'black']}

LUMINEUX = {  # blocs émettant de la lumière (1.20.1)
    'glowstone', 'sea_lantern', 'ochre_froglight', 'pearlescent_froglight', 'verdant_froglight', 'shroomlight',
    'lantern', 'soul_lantern', 'torch', 'wall_torch', 'soul_torch', 'soul_wall_torch', 'redstone_torch',
    'redstone_wall_torch', 'jack_o_lantern', 'end_rod', 'beacon', 'conduit', 'campfire', 'soul_campfire', 'fire',
    'soul_fire', 'lava', 'magma_block', 'glow_lichen', 'redstone_lamp', 'crying_obsidian', 'respawn_anchor',
    'sea_pickle', 'brewing_stand', 'enchanting_table', 'ender_chest', 'furnace', 'smoker', 'blast_furnace',
    'redstone_ore', 'deepslate_redstone_ore', 'amethyst_cluster', 'large_amethyst_bud', 'medium_amethyst_bud',
    'small_amethyst_bud', 'sculk_sensor', 'calibrated_sculk_sensor', 'sculk_catalyst', 'light', 'end_portal',
    'end_gateway', 'nether_portal', 'cave_vines', 'cave_vines_plant', 'dragon_egg', 'brown_mushroom',
    'end_portal_frame', 'candle', 'lava_cauldron'} | {c + '_candle' for c in
    ['white', 'orange', 'magenta', 'light_blue', 'yellow', 'lime', 'pink', 'gray', 'light_gray', 'cyan', 'purple',
     'blue', 'brown', 'green', 'red', 'black']}


def emet_lumiere(st):
    n, p = parse(st)
    c = n.split(':', 1)[1]
    if c not in LUMINEUX:
        return False
    if c in ('redstone_lamp', 'redstone_ore', 'deepslate_redstone_ore', 'furnace', 'smoker', 'blast_furnace',
             'campfire', 'soul_campfire') or c.endswith('candle'):
        return p.get('lit') == 'true'
    if c in ('redstone_torch', 'redstone_wall_torch'):
        return p.get('lit') == 'true'
    if c == 'sea_pickle':
        return p.get('waterlogged') == 'true'
    if c in ('cave_vines', 'cave_vines_plant'):
        return p.get('berries') == 'true'
    if c == 'respawn_anchor':
        return p.get('charges') != '0'
    if c == 'light':
        return p.get('level') != '0'
    return True


def est_mur(c):
    return c.endswith('_wall') and c in _MURS


_MURS = {k.split(':', 1)[1] for k, v in REG.items() if k.endswith('_wall') and 'up' in v['p']}
_PANES = {k.split(':', 1)[1] for k in REG if k.endswith('glass_pane')} | {'iron_bars'}
_CLOTURES_BOIS = {k.split(':', 1)[1] for k in REG if k.endswith('_fence') and k != 'minecraft:nether_brick_fence'}
_PORTILLONS = {k.split(':', 1)[1] for k in REG if k.endswith('_fence_gate')}
_ESCALIERS = {k.split(':', 1)[1] for k in REG if k.endswith('_stairs')}

# blocs pleins « solides » (face robuste) : tout sauf les formes partielles connues.
_NON_PLEINS_SUFFIXES = ('_slab', '_stairs', '_wall', '_fence', '_fence_gate', '_pane', '_door', '_trapdoor',
                        '_carpet', '_sign', '_banner', '_button', '_pressure_plate', '_bed', '_torch', '_leaves',
                        '_sapling', '_candle', '_rail', '_head', '_skull', '_coral', '_coral_fan', '_bars',
                        '_tulip', '_orchid', '_wall_fan', '_mushroom', '_roots', '_fungus', '_sprouts', '_vines',
                        '_plant', '_bush', '_petals', '_shulker_box', 'chest', '_cauldron', '_pot', 'lantern',
                        '_lichen', '_bud', '_cluster', '_web', '_hanging_sign', '_rod', '_pickle')
_NON_PLEINS = {'air', 'water', 'lava', 'barrier', 'light', 'grass', 'tall_grass', 'fern', 'large_fern', 'dandelion',
               'poppy', 'blue_orchid', 'allium', 'azure_bluet', 'oxeye_daisy', 'cornflower', 'lily_of_the_valley',
               'sunflower', 'lilac', 'rose_bush', 'peony', 'dead_bush', 'sugar_cane', 'lily_pad', 'vine', 'ladder',
               'lever', 'chain', 'cauldron', 'hopper', 'composter', 'lectern', 'flower_pot', 'bell', 'anvil',
               'brewing_stand', 'enchanting_table', 'end_rod', 'campfire', 'soul_campfire', 'fire', 'soul_fire',
               'snow', 'cobweb', 'tripwire', 'tripwire_hook', 'redstone_wire', 'repeater', 'comparator',
               'daylight_detector', 'stonecutter', 'grindstone', 'bamboo', 'scaffolding', 'dirt_path', 'farmland',
               'cake', 'conduit', 'dragon_egg', 'turtle_egg', 'sea_pickle', 'seagrass', 'tall_seagrass', 'kelp',
               'kelp_plant', 'azalea', 'flowering_azalea', 'big_dripleaf', 'small_dripleaf', 'spore_blossom',
               'moss_carpet', 'pointed_dripstone', 'decorated_pot', 'wither_rose', 'torchflower', 'pink_petals',
               'glass_pane', 'iron_bars', 'iron_door', 'iron_trapdoor', 'mangrove_propagule', 'hanging_roots',
               'nether_sprouts', 'chest', 'trapped_chest', 'ender_chest', 'glow_lichen', 'sculk_vein', 'pitcher_plant',
               'pitcher_crop', 'torchflower_crop', 'sniffer_egg', 'frogspawn', 'cactus', 'bamboo_sapling',
               'structure_void', 'water_cauldron', 'lava_cauldron', 'powder_snow_cauldron', 'lantern', 'soul_lantern',
               'potted_fern', 'bedrock_x'}


def est_plein(st):
    n, p = parse(st)
    c = n.split(':', 1)[1]
    if c in _NON_PLEINS or c.startswith('potted_'):
        return False
    if c.endswith('_slab'):
        return p.get('type') == 'double'
    for s in _NON_PLEINS_SUFFIXES:
        if c.endswith(s):
            return False
    return True


def _face_robuste(st, cote):
    """La face `cote` (direction depuis le bloc voisin vers ce bloc, inversée) est-elle pleine ?
    cote = direction de la face du bloc `st` (ex. 'north' = sa face nord)."""
    n, p = parse(st)
    c = n.split(':', 1)[1]
    if c in ('barrier',) or c.endswith('_leaves'):
        return False
    if est_plein(st):
        return True
    if c in _ESCALIERS:
        return p.get('facing') == cote and p.get('shape') == 'straight'
    if c.endswith('_slab'):
        return p.get('type') == 'double'
    return False


# ----------------------------------------------------------------------------- monde
class Monde:
    """Tableau de blocs [y][z][x] (uint16, index de palette), coordonnées absolues (x0,y0,z0 = coin min)."""

    def __init__(self, x0, y0, z0, W, H, D):
        self.x0, self.y0, self.z0 = x0, y0, z0
        self.W, self.H, self.D = W, H, D
        self.a = np.zeros((H, D, W), np.uint16)
        self.pal = [AIR]
        self.idx = {AIR: 0}
        self.signs = []
        self.containers = []

    # --- palette
    def id(self, st):
        i = self.idx.get(st)
        if i is None:
            i = len(self.pal)
            self.pal.append(st)
            self.idx[st] = i
        return i

    def dedans(self, x, y, z):
        return 0 <= x - self.x0 < self.W and 0 <= y - self.y0 < self.H and 0 <= z - self.z0 < self.D

    # --- accès
    def set(self, x, y, z, st):
        if not self.dedans(x, y, z):
            return
        self.a[y - self.y0, z - self.z0, x - self.x0] = self.id(st)

    def get(self, x, y, z):
        if not self.dedans(x, y, z):
            return AIR
        return self.pal[self.a[y - self.y0, z - self.z0, x - self.x0]]

    def est_air(self, x, y, z):
        if not self.dedans(x, y, z):
            return True
        return self.a[y - self.y0, z - self.z0, x - self.x0] == 0

    def fill(self, x1, y1, z1, x2, y2, z2, st):
        xa, xb = sorted((x1, x2))
        ya, yb = sorted((y1, y2))
        za, zb = sorted((z1, z2))
        xa, xb = max(xa, self.x0), min(xb, self.x0 + self.W - 1)
        ya, yb = max(ya, self.y0), min(yb, self.y0 + self.H - 1)
        za, zb = max(za, self.z0), min(zb, self.z0 + self.D - 1)
        if xa > xb or ya > yb or za > zb:
            return
        self.a[ya - self.y0:yb - self.y0 + 1, za - self.z0:zb - self.z0 + 1, xa - self.x0:xb - self.x0 + 1] = self.id(st)

    def vide(self, x1, y1, z1, x2, y2, z2):
        self.fill(x1, y1, z1, x2, y2, z2, AIR)

    def sign(self, x, y, z, lignes, couleur='black', glow=False):
        l = list(lignes) + [''] * 4
        self.signs = [s for s in self.signs if (s['x'], s['y'], s['z']) != (x, y, z)]
        self.signs.append({'x': x, 'y': y, 'z': z, 'front': l[:4], 'color': couleur, 'glow': bool(glow)})

    def container(self, x, y, z, items):
        self.containers = [c for c in self.containers if (c['x'], c['y'], c['z']) != (x, y, z)]
        self.containers.append({'x': x, 'y': y, 'z': z, 'items': items})

    # --- passes « physiques » (connexions calculées comme vanilla, car le plugin pose sans physique)
    def _ids_par(self, pred):
        return {i for i, st in enumerate(self.pal) if pred(st)}

    def positions(self, ids):
        if not ids:
            return []
        m = np.isin(self.a, np.array(sorted(ids), dtype=np.uint16))
        ys, zs, xs = np.nonzero(m)
        return list(zip(xs + self.x0, ys + self.y0, zs + self.z0))

    def passe_connexions(self):
        """Clôtures, vitres, barreaux, murets : calcule north/south/east/west (+ up des murets)."""
        def fam(st):
            c = nom_court(st)
            if c in _PANES:
                return 'pane'
            if c in _CLOTURES_BOIS:
                return 'fence'
            if c == 'nether_brick_fence':
                return 'nfence'
            if c in _MURS:
                return 'wall'
            return None

        ids = self._ids_par(lambda st: fam(st) is not None)
        pos = self.positions(ids)
        maj = []
        for (x, y, z) in pos:
            st = self.get(x, y, z)
            f = fam(st)
            res = {}
            for d, (dx, dz) in DIRS.items():
                nb = self.get(x + dx, y, z + dz)
                fn = fam(nb)
                cn = nom_court(nb)
                ok = False
                if f == 'pane':
                    ok = fn in ('pane', 'wall') or _face_robuste(nb, OPP[d])
                elif f in ('fence', 'nfence'):
                    ok = (fn == f) or _face_robuste(nb, OPP[d])
                    if cn in _PORTILLONS:
                        fa = parse(nb)[1]['facing']
                        ok = (fa in ('north', 'south')) == (d in ('east', 'west'))
                elif f == 'wall':
                    ok = fn in ('wall', 'pane') or _face_robuste(nb, OPP[d])
                    if cn in _PORTILLONS:
                        fa = parse(nb)[1]['facing']
                        ok = (fa in ('north', 'south')) == (d in ('east', 'west'))
                res[d] = ok
            if f == 'wall':
                au = self.get(x, y + 1, z)
                cau = nom_court(au)
                haut_plein = est_plein(au) or (cau.endswith('_slab') and parse(au)[1].get('type') in ('bottom', 'double'))
                props = {d: (('tall' if haut_plein else 'low') if v else 'none') for d, v in res.items()}
                n_, s_, e_, w_ = res['north'], res['south'], res['east'], res['west']
                droit = (n_ and s_ and not e_ and not w_) or (e_ and w_ and not n_ and not s_)
                if droit:
                    up = haut_plein or cau in ('lantern', 'soul_lantern', 'torch', 'soul_torch', 'redstone_torch') \
                        or cau.endswith('_pressure_plate') or cau.endswith('_sign') or cau.endswith('_banner') \
                        or (cau in _MURS and parse(au)[1].get('up') == 'true')
                else:
                    up = True
                props['up'] = up
                nouv = avec(st, **props)
            else:
                nouv = avec(st, **{d: v for d, v in res.items()})
            if nouv != st:
                maj.append((x, y, z, nouv))
        for (x, y, z, st) in maj:
            self.set(x, y, z, st)
        return len(pos)

    def passe_escaliers(self):
        """Forme des escaliers (straight / inner / outer) selon la logique vanilla StairBlock.getStairsShape."""
        ids = self._ids_par(lambda st: nom_court(st) in _ESCALIERS)
        pos = self.positions(ids)

        def info(st):
            n, p = parse(st)
            if n.split(':', 1)[1] in _ESCALIERS:
                return p['facing'], p['half']
            return None

        def peut_prendre(fa, ha, x, y, z, face):
            dx, dz = DIRS[face]
            i = info(self.get(x + dx, y, z + dz))
            return i is None or i[0] != fa or i[1] != ha

        maj = []
        for (x, y, z) in pos:
            st = self.get(x, y, z)
            fa, ha = info(st)
            forme = 'straight'
            dx, dz = DIRS[fa]
            i1 = info(self.get(x + dx, y, z + dz))
            trouve = False
            if i1 and i1[1] == ha:
                d1 = i1[0]
                if (d1 in ('north', 'south')) != (fa in ('north', 'south')) and peut_prendre(fa, ha, x, y, z, OPP[d1]):
                    forme = 'outer_left' if d1 == CCW[fa] else 'outer_right'
                    trouve = True
            if not trouve:
                i2 = info(self.get(x - dx, y, z - dz))
                if i2 and i2[1] == ha:
                    d2 = i2[0]
                    if (d2 in ('north', 'south')) != (fa in ('north', 'south')) and peut_prendre(fa, ha, x, y, z, d2):
                        forme = 'inner_left' if d2 == CCW[fa] else 'inner_right'
            if parse(st)[1]['shape'] != forme:
                maj.append((x, y, z, avec(st, shape=forme)))
        for (x, y, z, st) in maj:
            self.set(x, y, z, st)
        return len(pos)

    # --- vérifications
    def verifier(self, strict_paires=True):
        erreurs = []
        for st in self.pal:
            e = valide(st)
            if e:
                erreurs.append(e)
            c = nom_court(st)
            if c in GRAVITE:
                erreurs.append('bloc soumis à la gravité : %s' % st)
            if c.endswith('_leaves') and 'persistent=true' not in st:
                erreurs.append('feuilles non persistantes : %s' % st)
        # paires : portes, lits, plantes hautes
        for i, st in enumerate(self.pal):
            n, p = parse(st)
            c = n.split(':', 1)[1]
            if c.endswith('_door') and p.get('half') == 'lower':
                for (x, y, z) in self.positions({i}):
                    h = self.get(x, y + 1, z)
                    hn, hp = parse(h)
                    if hn != n or hp.get('half') != 'upper' or hp['facing'] != p['facing'] or hp['hinge'] != p['hinge'] \
                            or hp['open'] != p['open']:
                        erreurs.append('porte sans moitié haute cohérente en %s' % ((x, y, z),))
            if c.endswith('_door') and p.get('half') == 'upper':
                for (x, y, z) in self.positions({i}):
                    b = self.get(x, y - 1, z)
                    if parse(b)[0] != n or parse(b)[1].get('half') != 'lower':
                        erreurs.append('porte sans moitié basse en %s' % ((x, y, z),))
            if c.endswith('_bed'):
                for (x, y, z) in self.positions({i}):
                    dx, dz = DIRS[p['facing']]
                    if p['part'] == 'foot':
                        o = self.get(x + dx, y, z + dz)
                        if parse(o)[0] != n or parse(o)[1].get('part') != 'head' or parse(o)[1]['facing'] != p['facing']:
                            erreurs.append('lit sans tête en %s' % ((x, y, z),))
                    else:
                        o = self.get(x - dx, y, z - dz)
                        if parse(o)[0] != n or parse(o)[1].get('part') != 'foot':
                            erreurs.append('lit sans pied en %s' % ((x, y, z),))
            if 'half' in p and p['half'] in ('upper', 'lower') and not c.endswith('_door'):
                for (x, y, z) in self.positions({i}):
                    o = self.get(x, y + (1 if p['half'] == 'lower' else -1), z)
                    if parse(o)[0] != n:
                        erreurs.append('plante haute incomplète %s en %s' % (c, (x, y, z)))
        return erreurs

    def compacter(self):
        """Retire de la palette les états inutilisés (air reste en 0)."""
        used = np.unique(self.a)
        nouv = [AIR]
        remap = np.zeros(len(self.pal), np.uint16)
        for i in used:
            i = int(i)
            if i == 0:
                continue
            remap[i] = len(nouv)
            nouv.append(self.pal[i])
        self.a = remap[self.a]
        self.pal = nouv
        self.idx = {s: i for i, s in enumerate(nouv)}

    def non_air(self):
        return int(np.count_nonzero(self.a))

    def exporter(self, chemin, offset=None, base=(0, 0, 0)):
        """Écrit le .json.gz au format de la spec. offset = position du coin (0,0,0) du tableau
        relativement à la base ; par défaut la position absolue du coin min."""
        self.compacter()
        if offset is None:
            offset = [self.x0 - base[0], self.y0 - base[1], self.z0 - base[2]]
        raw = self.a.astype('<u2').tobytes()
        blob = base64.b64encode(zlib.compress(raw, 9)).decode('ascii')
        doc = {'size': [self.W, self.H, self.D], 'offset': list(offset), 'palette': self.pal, 'blocks': blob,
               'signs': self.signs, 'containers': self.containers}
        with open(chemin, 'wb') as brut, gzip.GzipFile(filename='', fileobj=brut, mode='wb', compresslevel=9, mtime=0) as f:
            f.write(json.dumps(doc, ensure_ascii=False, separators=(',', ':')).encode('utf-8'))
        return os.path.getsize(chemin)


def relire(chemin):
    """Relit un .json.gz (contrôle de format)."""
    with gzip.open(chemin, 'rt', encoding='utf-8') as f:
        doc = json.load(f)
    W, H, D = doc['size']
    raw = zlib.decompress(base64.b64decode(doc['blocks']))
    a = np.frombuffer(raw, dtype='<u2').reshape(H, D, W)
    return doc, a
