# -*- coding: utf-8 -*-
"""Modèles d'accessoires (véhicules) pour BlockDisplay : pièces = boîtes (coin min t, taille s), unités = blocs,
origine = centre au sol, avant vers +X. Tags : body, light_a, light_b, rotor (+pivot), rotor_queue (+pivot), wheel."""


def P(b, t, s, tag='body', pivot=None):
    d = {'b': 'minecraft:' + b if ':' not in b else b, 't': [round(v, 3) for v in t], 's': [round(v, 3) for v in s],
         'tag': tag}
    if pivot is not None:
        d['pivot'] = [round(v, 3) for v in pivot]
    return d


def roues(xs, demi_larg, d=0.9, ep=0.32):
    out = []
    for x in xs:
        for z in (-demi_larg, demi_larg - ep):
            out.append(P('black_concrete', [x - d / 2, 0, z], [d, d, ep], 'wheel'))
            out.append(P('light_gray_concrete', [x - d * 0.22, d * 0.28, z + (-0.02 if z < 0 else ep - 0.02)],
                         [d * 0.44, d * 0.44, 0.04], 'wheel'))
    return out


def ambulance():
    p = []
    p += roues([-2.3, 2.1], 1.45, 0.9)
    p.append(P('gray_concrete', [-3.45, 0.35, -1.3], [6.9, 0.25, 2.6]))                 # châssis
    p.append(P('white_concrete', [-3.5, 0.55, -1.4], [4.9, 2.05, 2.8]))                 # caisse
    p.append(P('white_concrete', [1.4, 0.55, -1.3], [1.5, 1.4, 2.6]))                   # cabine
    p.append(P('white_concrete', [2.9, 0.55, -1.25], [0.6, 0.8, 2.5]))                  # capot
    p.append(P('black_stained_glass', [2.82, 1.25, -1.15], [0.1, 0.62, 2.3]))           # pare-brise
    for z in (-1.33, 1.28):
        p.append(P('black_stained_glass', [1.6, 1.25, z], [1.05, 0.55, 0.05]))          # vitres latérales
        p.append(P('red_concrete', [-3.52, 1.05, z - 0.08 if z < 0 else z + 0.07], [6.1, 0.28, 0.06]))  # bande rouge
        zz = -1.43 if z < 0 else 1.38
        p.append(P('red_concrete', [-1.35, 1.45, zz], [0.3, 0.95, 0.05]))              # croix
        p.append(P('red_concrete', [-1.68, 1.78, zz], [0.96, 0.3, 0.05]))
        p.append(P('orange_concrete', [-3.52, 0.62, zz], [6.9, 0.1, 0.05]))
    p.append(P('black_stained_glass', [-3.53, 1.5, -1.0], [0.05, 0.6, 0.85]))           # vitres arrière
    p.append(P('black_stained_glass', [-3.53, 1.5, 0.15], [0.05, 0.6, 0.85]))
    p.append(P('red_concrete', [-3.55, 0.8, -1.35], [0.06, 0.3, 0.3]))                  # feux arrière
    p.append(P('red_concrete', [-3.55, 0.8, 1.05], [0.06, 0.3, 0.3]))
    p.append(P('light_gray_concrete', [3.45, 0.3, -1.3], [0.2, 0.25, 2.6]))            # pare-chocs
    p.append(P('light_gray_concrete', [-3.65, 0.3, -1.3], [0.2, 0.25, 2.6]))
    p.append(P('sea_lantern', [3.49, 0.72, -1.1], [0.04, 0.22, 0.45]))                  # phares
    p.append(P('sea_lantern', [3.49, 0.72, 0.65], [0.04, 0.22, 0.45]))
    p.append(P('black_concrete', [1.5, 1.95, -1.1], [0.5, 0.08, 2.2]))                  # base rampe
    p.append(P('red_concrete', [1.55, 2.03, -1.05], [0.4, 0.18, 1.0], 'light_a'))       # rampe de gyrophares
    p.append(P('blue_concrete', [1.55, 2.03, 0.05], [0.4, 0.18, 1.0], 'light_b'))
    for (x, z, t) in ((1.0, -1.35, 'light_a'), (1.0, 1.0, 'light_b'), (-3.45, -1.35, 'light_b'), (-3.45, 1.0, 'light_a')):
        p.append(P('red_concrete', [x, 2.6, z], [0.35, 0.18, 0.35], t))
    return {'parts': p, 'taille': [7.0, 2.8, 2.9]}


def voiture_police():
    p = []
    p += roues([-1.45, 1.45], 0.92, 0.7, 0.28)
    p.append(P('white_concrete', [-2.3, 0.3, -0.9], [4.6, 0.62, 1.8]))                  # carrosserie
    p.append(P('black_concrete', [-1.1, 0.34, -0.93], [2.1, 0.5, 1.86]))                # portières noires
    p.append(P('white_concrete', [-1.15, 0.92, -0.82], [2.3, 0.08, 1.64]))              # ceinture
    p.append(P('black_stained_glass', [-1.1, 1.0, -0.8], [2.1, 0.5, 1.6]))              # habitacle vitré
    p.append(P('black_stained_glass', [0.95, 0.95, -0.75], [0.35, 0.45, 1.5]))          # pare-brise incliné
    p.append(P('white_concrete', [-1.05, 1.48, -0.8], [2.0, 0.08, 1.6]))                # toit
    p.append(P('blue_concrete', [-2.31, 0.72, -0.93], [4.62, 0.1, 0.03]))               # bande bleue
    p.append(P('blue_concrete', [-2.31, 0.72, 0.9], [4.62, 0.1, 0.03]))
    p.append(P('black_concrete', [-0.3, 1.56, -0.72], [0.5, 0.07, 1.44]))               # rampe
    p.append(P('red_concrete', [-0.26, 1.63, -0.7], [0.42, 0.15, 0.66], 'light_a'))
    p.append(P('blue_concrete', [-0.26, 1.63, 0.04], [0.42, 0.15, 0.66], 'light_b'))
    p.append(P('sea_lantern', [2.29, 0.6, -0.75], [0.04, 0.16, 0.4]))
    p.append(P('sea_lantern', [2.29, 0.6, 0.35], [0.04, 0.16, 0.4]))
    p.append(P('red_concrete', [-2.33, 0.62, -0.8], [0.04, 0.16, 0.35]))
    p.append(P('red_concrete', [-2.33, 0.62, 0.45], [0.04, 0.16, 0.35]))
    p.append(P('black_concrete', [2.25, 0.28, -0.88], [0.15, 0.2, 1.76]))               # pare-chocs + barre de poussée
    p.append(P('black_concrete', [-2.4, 0.28, -0.88], [0.15, 0.2, 1.76]))
    return {'parts': p, 'taille': [4.6, 1.8, 1.9]}


def camion_militaire():
    p = []
    p += roues([-2.7, -1.55, 2.4], 1.3, 1.05, 0.4)
    p.append(P('coal_block', [-3.8, 0.5, -1.05], [7.5, 0.3, 2.1]))                      # châssis
    p.append(P('green_terracotta', [1.6, 0.8, -1.25], [1.8, 1.55, 2.5]))                # cabine
    p.append(P('green_terracotta', [3.4, 0.8, -1.15], [0.55, 1.0, 2.3]))                # capot
    p.append(P('black_concrete', [3.93, 0.9, -0.9], [0.05, 0.7, 1.8]))                  # calandre
    p.append(P('black_stained_glass', [3.38, 1.75, -1.1], [0.06, 0.5, 2.2]))            # pare-brise
    for z in (-1.28, 1.23):
        p.append(P('black_stained_glass', [2.2, 1.7, z], [0.9, 0.45, 0.05]))
        p.append(P('white_concrete', [1.9, 1.1, z - 0.01 if z < 0 else z + 0.01], [0.3, 0.3, 0.05]))   # étoile/insigne
    p.append(P('green_terracotta', [-3.8, 0.8, -1.3], [5.3, 0.6, 2.6]))                 # benne
    p.append(P('lime_terracotta', [-3.85, 1.4, -1.32], [5.3, 1.45, 2.64]))              # bâche
    for x in (-3.4, -2.0, -0.6, 0.8):
        p.append(P('green_terracotta', [x, 2.84, -1.33], [0.12, 0.06, 2.66]))           # arceaux
    p.append(P('black_concrete', [-3.9, 1.45, -1.1], [0.05, 1.2, 2.2]))                  # arrière ouvert (sombre)
    p.append(P('coal_block', [3.9, 0.45, -1.2], [0.25, 0.25, 2.4]))                     # pare-chocs
    p.append(P('sea_lantern', [3.95, 1.1, -1.1], [0.05, 0.22, 0.3]))
    p.append(P('sea_lantern', [3.95, 1.1, 0.8], [0.05, 0.22, 0.3]))
    p.append(P('black_concrete', [2.0, 1.2, -1.45], [1.0, 1.0, 0.18]))                  # roue de secours
    p.append(P('iron_block', [3.3, 2.35, 0.9], [0.08, 0.7, 0.08]))                      # antenne
    return {'parts': p, 'taille': [7.8, 2.9, 2.7]}


def helicoptere():
    p = []
    O = 'green_terracotta'
    p.append(P(O, [-1.6, 0.9, -1.1], [4.1, 2.0, 2.2]))                                  # fuselage
    p.append(P(O, [2.5, 1.0, -0.95], [1.0, 1.1, 1.9]))                                  # nez bas
    p.append(P('black_stained_glass', [2.5, 2.1, -0.9], [1.05, 0.75, 1.8]))             # verrière
    p.append(P('black_stained_glass', [3.5, 1.25, -0.7], [0.35, 0.8, 1.4]))
    p.append(P(O, [-1.3, 2.9, -0.65], [2.8, 0.6, 1.3]))                                 # capot moteur
    p.append(P('coal_block', [-1.4, 3.05, -0.5], [0.3, 0.35, 1.0]))                     # tuyères
    p.append(P(O, [-6.6, 1.85, -0.32], [5.1, 0.65, 0.64]))                              # poutre de queue
    p.append(P(O, [-7.3, 1.85, -0.12], [0.85, 1.9, 0.24]))                              # dérive
    p.append(P(O, [-6.1, 2.0, -1.1], [0.7, 0.1, 2.2]))                                  # stabilisateur
    for z in (-1.4, 1.25):
        p.append(P('coal_block', [-1.9, 0.0, z], [4.8, 0.12, 0.15]))                    # patins
        for x in (-0.9, 1.5):
            p.append(P('coal_block', [x, 0.1, z + (0.05 if z < 0 else 0.0)], [0.12, 0.85, 0.12]))
        zz = -1.13 if z < 0 else 1.08
        p.append(P('black_stained_glass', [0.2, 1.8, zz], [1.6, 0.8, 0.06]))            # hublots / porte
        p.append(P('white_concrete', [-1.2, 1.4, zz], [0.8, 0.8, 0.06]))                # carré blanc
        p.append(P('red_concrete', [-0.95, 1.5, zz - 0.01 if z < 0 else zz + 0.01], [0.3, 0.6, 0.06]))  # croix rouge
        p.append(P('red_concrete', [-1.1, 1.65, zz - 0.01 if z < 0 else zz + 0.01], [0.6, 0.3, 0.06]))
    p.append(P('gray_concrete', [0.35, 3.5, -0.15], [0.3, 0.35, 0.3]))                  # mât
    hub = [0.5, 3.9, 0.0]
    p.append(P('gray_concrete', [0.2, 3.82, -0.3], [0.6, 0.18, 0.6], 'rotor', hub))
    p.append(P('gray_concrete', [0.5, 3.86, -0.15], [5.0, 0.07, 0.3], 'rotor', hub))
    p.append(P('gray_concrete', [-4.5, 3.86, -0.15], [5.0, 0.07, 0.3], 'rotor', hub))
    p.append(P('gray_concrete', [0.35, 3.86, 0.0], [0.3, 0.07, 5.0], 'rotor', hub))
    p.append(P('gray_concrete', [0.35, 3.86, -5.0], [0.3, 0.07, 5.0], 'rotor', hub))
    q = [-7.0, 3.0, 0.2]
    p.append(P('gray_concrete', [-7.08, 2.0, 0.17], [0.16, 2.0, 0.05], 'rotor_queue', q))
    p.append(P('gray_concrete', [-8.0, 2.92, 0.17], [2.0, 0.16, 0.05], 'rotor_queue', q))
    p.append(P('red_concrete', [-7.15, 3.72, -0.1], [0.2, 0.15, 0.2], 'light_a'))       # feu anticollision
    p.append(P('red_concrete', [0.3, 0.75, -0.1], [0.2, 0.15, 0.2], 'light_b'))
    return {'parts': p, 'taille': [11.0, 4.0, 10.0]}


def autobus_scolaire():
    p = []
    J = 'yellow_concrete'
    p += roues([4.3, -3.1, -4.1], 1.28, 1.0, 0.36)
    p.append(P('black_concrete', [-6.0, 0.45, -1.2], [11.8, 0.3, 2.4]))                 # châssis
    p.append(P(J, [-6.0, 0.7, -1.3], [10.0, 2.4, 2.6]))                                 # caisse
    p.append(P(J, [4.0, 0.7, -1.05], [1.8, 1.15, 2.1]))                                 # capot
    p.append(P('black_concrete', [5.78, 0.8, -0.8], [0.05, 0.8, 1.6]))                  # calandre
    p.append(P('black_concrete', [5.7, 0.45, -1.2], [0.3, 0.3, 2.4]))                   # pare-chocs
    p.append(P('white_concrete', [-6.0, 3.1, -1.25], [10.0, 0.08, 2.5]))                # toit blanc
    p.append(P('black_stained_glass', [3.97, 1.9, -1.15], [0.06, 0.95, 2.3]))           # pare-brise
    for z in (-1.33, 1.28):
        p.append(P('black_stained_glass', [-5.6, 1.95, z], [9.3, 0.75, 0.05]))          # bande de fenêtres
        for x in [-5.6 + i * 1.25 for i in range(8)]:
            p.append(P(J, [x, 1.95, z - 0.005 if z < 0 else z + 0.005], [0.12, 0.75, 0.06]))  # montants
        for y in (1.05, 1.55):
            p.append(P('black_concrete', [-6.0, y, z - 0.01 if z < 0 else z + 0.01], [10.0, 0.08, 0.06]))  # rails
    p.append(P('black_stained_glass', [3.0, 1.0, -1.34], [0.8, 1.75, 0.05]))            # porte (côté droit = -z)
    p.append(P('red_concrete', [3.0, 1.8, 1.34], [0.5, 0.5, 0.06]))                     # bras d'arrêt ARRÊT (gauche)
    p.append(P('black_stained_glass', [-6.03, 1.8, -0.9], [0.05, 0.9, 1.8]))            # lunette arrière
    p.append(P('black_concrete', [3.9, 2.75, -0.7], [0.1, 0.3, 1.4]))                   # plaque « ÉCOLIERS »
    p.append(P('sea_lantern', [5.83, 1.35, -0.95], [0.04, 0.25, 0.35]))
    p.append(P('sea_lantern', [5.83, 1.35, 0.6], [0.04, 0.25, 0.35]))
    for (x, z, t) in ((3.85, -1.25, 'light_a'), (3.85, 0.95, 'light_b'), (-6.05, -1.25, 'light_b'), (-6.05, 0.95, 'light_a')):
        p.append(P('orange_concrete', [x, 2.8, z], [0.2, 0.22, 0.3], t))
    p.append(P('red_concrete', [-6.08, 1.0, -1.15], [0.05, 0.3, 0.3]))
    p.append(P('red_concrete', [-6.08, 1.0, 0.85], [0.05, 0.3, 0.3]))
    return {'parts': p, 'taille': [12.0, 3.2, 2.6]}


def tous():
    return {'ambulance': ambulance(), 'voiture_police': voiture_police(), 'camion_militaire': camion_militaire(),
            'helicoptere': helicoptere(), 'autobus_scolaire': autobus_scolaire()}
