# -*- coding: utf-8 -*-
"""Commerces : Dépanneur Chez Ginette, Casse-croûte Chez Rita (SO, façades au nord), Café du Coin (NO)."""
from za_blocs import S, AIR, OPP, CW, CCW
from za_meubles import (Repere, porte, porte_double, lit, chaise, table, tabouret, table_basse, canape, fauteuil, tapis,
                        plante, grande_plante, commode, bibliotheque, tele, bureau, cadre, horloge, lettres, lavabo,
                        toilette, baignoire, _VEC)
from za_batir import murs, dalle, fenetre, cage_escalier
import za_rue as RU


def repere_nord(ctx, x_est, z_sud):
    """Bâtiment dont la façade donne au NORD : a croît vers l'ouest, b vers le nord."""
    return Repere(ctx, x_est, z_sud, (-1, 0), (0, -1))


# ============================================================================ Dépanneur Chez Ginette
def depanneur(ctx):
    """x[48,64] z[86,98] ; a = 64-x (0..16), b = 98-z (0..12) ; façade b=12 (z=86)."""
    Z = 'depanneur'
    ctx.zones[Z] = (56, 92)
    R = repere_nord(ctx, 64, 98)
    rng = ctx.rng
    h = 64
    R.fill(0, 59, 0, 16, 63, 12, S('stone'))
    R.fill(0, 64, 0, 16, 69, 12, S('mud_bricks'))
    R.vide(1, 64, 1, 15, 67, 11)
    R.fill(0, 68, 0, 16, 68, 12, S('gray_concrete'))
    R.fill(0, 69, 0, 16, 69, 12, AIR)
    # parapet
    for (a1, b1, a2, b2) in ((0, 0, 16, 0), (0, 12, 16, 12), (0, 0, 0, 12), (16, 0, 16, 12)):
        R.fill(a1, 69, b1, a2, 69, b2, S('mud_bricks'))
        R.fill(a1, 70, b1, a2, 70, b2, S('mud_brick_slab', type='bottom'))
    # sol intérieur : damier gris/blanc
    for a in range(1, 16):
        for b in range(1, 12):
            R.set(a, 63, b, S('white_concrete') if (a + b) % 2 else S('light_gray_concrete'))
    # soubassement de pierre, vitrine, porte
    R.fill(0, 64, 12, 16, 64, 12, S('stone_bricks'))
    for a in list(range(1, 3)) + list(range(6, 16)):
        R.fill(a, 65, 12, a, 67, 12, S('glass_pane'))
    porte(R, 4, 64, 12, 'north', 'spruce', 'left')
    R.set(4, 66, 12, S('glass_pane'))
    R.set(3, 64, 12, S('stone_bricks'))
    R.fill(3, 65, 12, 3, 67, 12, S('dark_oak_planks'))
    R.fill(5, 64, 12, 5, 67, 12, S('dark_oak_planks'))
    # côté est (sur la rue des Érables) : fenêtres + affiches
    for b in (4, 5, 8, 9):
        R.fill(0, 65, b, 0, 66, b, S('glass_pane'))
    # bandeau d'enseigne (rouge) et enseignes lumineuses
    R.fill(0, 68, 13, 16, 69, 13, S('red_concrete'))
    R.fill(0, 70, 13, 16, 70, 13, S('red_nether_brick_slab', type='bottom'))
    for a, txt in ((13, ['', 'DÉPANNEUR', '', '']), (10, ['', 'CHEZ', 'GINETTE', '']), (7, ['Bière froide', 'Loterie', 'Journaux', '']),
                   (2, ['OUVERT', '7 h à 23 h', '7 jours', ''])):
        R.set(a, 68, 14, R.S('birch_wall_sign', facing='south'))
        R.sign(a, 68, 14, txt, 'white' if a != 2 else 'black', a != 2)
        R.set(a + 1, 69, 14, R.S('birch_wall_sign', facing='south')) if False else None
    for a in (1, 4, 8, 12, 15):
        R.lampe(a, 69, 14, S('ochre_froglight', axis='y'), S('gray_stained_glass'), Z)
        R.set(a, 70, 14, S('red_nether_brick_slab', type='bottom'))
    # auvent rayé au-dessus de la vitrine
    for a in range(0, 17):
        st = 'quartz_stairs' if a % 2 else 'red_nether_brick_stairs'
        R.set(a, 67, 13, R.S(st, facing='north', half='bottom'))
    # enseigne côté est
    R.set(-1, 67, 6, R.S('birch_wall_sign', facing='east'))
    R.sign(-1, 67, 6, ['DÉPANNEUR', 'Chez Ginette', 'Depuis 1987', ''], 'red', True)
    R.set(-1, 65, 7, R.S('oak_wall_sign', facing='east'))
    R.sign(-1, 65, 7, ['LAIT 2 %', '4,99 $', 'PAIN TRANCHÉ', '3,49 $'])
    # ---------------------------------------------------------------- intérieur
    # comptoir-caisse (a=3, b 5..10), caissière en a=2, client en a=4
    for b in range(5, 11):
        R.set(3, 64, b, S('spruce_planks') if b != 8 else S('spruce_planks'))
        R.set(3, 65, b, S('spruce_slab', type='bottom'))
    R.set(3, 65, 8, S('heavy_weighted_pressure_plate'))
    R.set(3, 65, 7, S('black_stained_glass_pane'))
    R.set(3, 65, 9, S('potted_cactus'))
    R.set(3, 64, 11, AIR)
    R.set(2, 64, 5, R.S('spruce_stairs', facing='west', half='bottom'))
    R.poi('depanneur_comptoir', 2, 64, 8, 'east')
    R.poi('depanneur_client', 4, 64, 8, 'west')
    R.poi('depanneur_porte', 4, 64, 13, 'north')
    # mur des cigarettes / loterie derrière la caisse
    for b in range(3, 11):
        R.set(1, 64, b, R.S('barrel', facing='west', open=False))
        R.set(1, 65, b, S('chiseled_bookshelf', facing='west'))
        R.set(1, 66, b, S('bookshelf'))
    R.set(2, 66, 10, R.S('oak_wall_sign', facing='west'))
    R.sign(2, 66, 10, ['LOTERIE', '6/49 - Lotto', 'Gros lot :', '12 000 000 $'], 'blue')
    # frigos le long du mur du fond (b=1)
    for a in range(5, 16):
        R.set(a, 64, 1, S('white_concrete'))
        R.set(a, 65, 1, S('light_blue_stained_glass'))
        R.set(a, 66, 1, S('light_blue_stained_glass'))
        R.set(a, 67, 1, S('white_concrete'))
        if a % 3 == 2:
            R.set(a, 65, 2, R.S('lever', face='wall', facing='south', powered=False))
    for a, txt in ((6, ['LAIT', 'Crème', 'Beurre', '']), (10, ['BIÈRE', 'FROIDE', '', '']), (14, ['BOISSONS', 'Jus - Eau', '', ''])):
        R.set(a, 67, 2, R.S('birch_wall_sign', facing='south'))
        R.sign(a, 67, 2, txt, 'blue')
    # gondoles (a = 7, 10, 13 ; b 4..8)
    produits = ['chiseled_bookshelf', 'bookshelf', 'barrel', 'beehive', 'composter', 'hay_block', 'melon',
                'pumpkin', 'brown_mushroom_block', 'dried_kelp_block']
    for a in (7, 10, 13):
        for b in range(4, 9):
            R.set(a, 64, b, R.S('barrel', facing='east', open=False))
            p = produits[(a * 3 + b) % len(produits)]
            if p == 'chiseled_bookshelf':
                R.set(a, 65, b, R.S(p, facing='west'))
            elif p == 'beehive':
                R.set(a, 65, b, R.S(p, facing='east', honey_level=0))
            elif p == 'composter':
                R.set(a, 65, b, S(p, level=0))
            elif p == 'barrel':
                R.set(a, 65, b, R.S(p, facing='up', open=False))
            elif p == 'hay_block':
                R.set(a, 65, b, S(p, axis='y'))
            elif p == 'brown_mushroom_block':
                R.set(a, 65, b, S(p))
            else:
                R.set(a, 65, b, S(p))
        R.set(a, 64, 9, R.S('oak_wall_sign', facing='north'))
        R.sign(a, 64, 9, [['CHIPS', 'CHOCOLAT'], ['CONSERVES', 'CÉRÉALES'], ['PAIN', 'BISCUITS']][(a - 7) // 3] + ['', ''])
    # présentoir à journaux et bonbons près de la vitrine
    for a in (8, 9, 12):
        R.set(a, 64, 11, R.S('spruce_trapdoor', facing='north', half='top', open=False))
        R.set(a, 65, 11, S(['red_carpet', 'yellow_carpet', 'white_carpet'][a % 3]))
    R.set(14, 64, 11, S('white_shulker_box', facing='up'))
    R.set(15, 64, 11, R.S('barrel', facing='up', open=False))
    # plafonniers
    for (a, b) in ((3, 4), (3, 9), (8, 3), (8, 8), (12, 3), (12, 8)):
        R.lampe(a, 68, b, S('sea_lantern'), S('light_gray_concrete'), Z)
    # réserve à l'arrière (a 1..4, b 1..2)
    R.set(2, 64, 1, R.S('barrel', facing='south', open=False))
    R.set(3, 64, 1, R.S('barrel', facing='south', open=False))
    R.set(2, 65, 1, R.S('barrel', facing='south', open=False))
    # extérieur : congélateur à glace, poubelle, bac à journaux
    R.set(7, 64, 13, S('white_concrete'))
    R.set(7, 65, 13, S('smooth_quartz_slab', type='bottom'))
    R.set(7, 64, 14, R.S('birch_wall_sign', facing='south'))
    R.sign(7, 64, 14, ['GLACE', 'ICE', '', ''], 'blue')
    R.set(2, 64, 13, S('cauldron'))
    # bitume du côté est (stationnement de 3 places) et devant
    for a in range(-4, 17):
        for b in (13, 14, 15):
            if R.est_air(a, 64, b) or True:
                R.set(a, 63, b, S('smooth_stone'))
    for a in range(-4, 0):
        for b in range(0, 13):
            R.set(a, 63, b, RU.ASPHALTE)
    # --------------------------------------------------------------- calque « dépanneur fermé »
    for a in list(range(1, 3)) + list(range(6, 16)) + [4]:
        for y in (64, 65, 66, 67):
            if a == 4 and y == 67:
                continue
            R.calque('depanneur_ferme', a, y, 13, S('iron_bars'))
    for b in (4, 5, 8, 9):
        for y in (65, 66):
            R.calque('depanneur_ferme', -1, y, b, S('iron_bars'))
    for l in ctx.lampes:
        if l['zone'] == Z:
            ctx.calque('depanneur_ferme', l['x'], l['y'], l['z'], l['off'])
    # affiche « FERMÉ » : pancarte rouge devant la porte
    R.calque('depanneur_ferme', 4, 64, 14, S('red_concrete'))


# ============================================================================ Casse-croûte Chez Rita
def rita(ctx):
    """x[30,44] z[86,98] ; a = 44-x (0..14), b = 98-z (0..12)."""
    Z = 'rita'
    ctx.zones[Z] = (37, 92)
    R = repere_nord(ctx, 44, 98)
    rng = ctx.rng
    R.fill(0, 59, 0, 14, 63, 12, S('stone'))
    R.fill(0, 64, 0, 14, 68, 12, S('white_terracotta'))
    R.vide(1, 64, 1, 13, 67, 11)
    R.fill(0, 68, 0, 14, 68, 12, S('gray_concrete'))
    # bandes rouges rétro
    for (a1, b1, a2, b2) in ((0, 0, 14, 0), (0, 12, 14, 12), (0, 0, 0, 12), (14, 0, 14, 12)):
        R.fill(a1, 64, b1, a2, 64, b2, S('red_concrete'))
        R.fill(a1, 68, b1, a2, 68, b2, S('red_concrete'))
        R.fill(a1, 69, b1, a2, 69, b2, S('quartz_slab', type='bottom'))
    for a in range(0, 15):
        for b in range(0, 13):
            if R.get(a, 64, b) == AIR:
                pass
    for a in range(1, 14):
        for b in range(1, 12):
            R.set(a, 63, b, S('black_concrete') if (a + b) % 2 else S('white_concrete'))
    # vitrines et porte (centre a=7)
    for a in list(range(1, 6)) + list(range(9, 14)):
        R.fill(a, 65, 12, a, 66, 12, S('glass_pane'))
    porte(R, 7, 64, 12, 'north', 'birch', 'left')
    R.set(7, 66, 12, S('glass_pane'))
    for b in (3, 4, 8, 9):
        R.fill(0, 65, b, 0, 66, b, S('glass_pane'))
        R.fill(14, 65, b, 14, 66, b, S('glass_pane'))
    # auvent rayé rouge/blanc
    for a in range(0, 15):
        R.set(a, 67, 13, R.S('quartz_stairs' if a % 2 else 'red_nether_brick_stairs', facing='north', half='bottom'))
    # panneau publicitaire sur le toit « POUTINE »
    for a in range(2, 13):
        R.set(a, 69, 6, S('red_concrete'))
        R.set(a, 70, 6, S('red_concrete'))
        R.set(a, 71, 6, S('red_concrete'))
        R.set(a, 72, 6, S('yellow_concrete'))
    for a in (3, 11):
        R.set(a, 69, 5, S('iron_bars'))
        R.set(a, 69, 7, S('iron_bars'))
    for a, txt in ((10, ['', '★ POUTINE ★', '', '']), (8, ['', 'POUTINE', '', '']), (6, ['CHEZ', 'RITA', '', '']),
                   (4, ['Frites', 'Hot-dogs', 'Guédilles', ''])):
        R.set(a, 70, 7, R.S('birch_wall_sign', facing='south'))
        R.sign(a, 70, 7, txt, 'white' if a != 4 else 'yellow', True)
        R.set(a, 71, 7, R.S('birch_wall_sign', facing='south'))
        R.sign(a, 71, 7, (['', 'POUTINE', '', ''] if a == 8 else ['', '', '', '']), 'yellow', True)
    for a in (2, 5, 9, 12):
        R.lampe(a, 69, 7, S('shroomlight'), S('red_terracotta'), Z)
    # enseigne au-dessus de la porte
    for a, txt in ((9, ['CASSE-CROÛTE', '', '', '']), (7, ['CHEZ RITA', '', '', '']), (5, ['POUTINE', 'depuis 1979', '', ''])):
        R.set(a, 68, 13, R.S('birch_wall_sign', facing='south'))
        R.sign(a, 68, 13, txt, 'red', True)
    # --------------------------------------------------------------- cuisine (b 1..5) + comptoir (b 6) + tabourets (b 7)
    for a in range(2, 13):
        R.set(a, 64, 6, S('red_concrete') if a % 2 else S('white_concrete'))
        R.set(a, 65, 6, S('smooth_quartz_slab', type='bottom'))
        if a != 7:
            tabouret(R, a, 64, 7, 'dark_oak') if a % 2 == 0 else None
    R.vide(13, 64, 6, 13, 65, 6)
    R.set(13, 64, 6, R.S('birch_trapdoor', facing='south', half='bottom', open=True))
    R.poi('rita_comptoir', 7, 64, 5, 'south')
    # appareils de cuisine le long du mur du fond
    for a in range(1, 14):
        if a in (2, 3):
            R.set(a, 64, 1, S('water_cauldron', level=2))      # friteuses
        elif a in (5, 6):
            R.set(a, 64, 1, R.S('smoker', facing='south', lit=False))
        elif a == 8:
            R.set(a, 64, 1, R.S('furnace', facing='south', lit=False))
        elif a in (10, 11):
            R.set(a, 64, 1, S('iron_block'))
            R.set(a, 65, 1, S('iron_block'))
            continue
        else:
            R.set(a, 64, 1, R.S('barrel', facing='south', open=False))
        R.set(a, 66, 1, R.S('iron_trapdoor', facing='south', half='top', open=True))
    for a in range(2, 12):
        R.set(a, 64, 4, S('smooth_quartz'))
        R.set(a, 65, 4, S('smooth_quartz_slab', type='bottom'))
    R.set(4, 65, 4, S('cake', bites=2))
    R.set(9, 65, 4, S('flower_pot'))
    # menu mural
    for a, txt in ((10, ['POUTINE', 'P 8,95 $  M 10,95 $', 'G 12,95 $', '']), (7, ['HOT-DOG', 'steamé 2,75 $', 'toasté 2,95 $', '']),
                   (4, ['FRITES', '4,50 $', 'Guédille 6,50 $', 'Liqueur 2,00 $'])):
        R.set(a, 67, 1, R.S('birch_wall_sign', facing='south')) if False else None
        R.set(a, 67, 2, R.S('dark_oak_wall_sign', facing='south'))
        R.sign(a, 67, 2, txt, 'white', True)
    # banquettes près des fenêtres (b 9..11)
    for a0 in (1, 11):
        R.set(a0, 64, 9, R.S('red_nether_brick_stairs', facing='north', half='bottom'))
        R.set(a0 + 1, 64, 9, R.S('red_nether_brick_stairs', facing='north', half='bottom'))
        table(R, a0, 64, 10, 'dark_oak', nappe='red')
        table(R, a0 + 1, 64, 10, 'dark_oak', nappe='red')
        R.set(a0, 64, 11, R.S('red_nether_brick_stairs', facing='south', half='bottom'))
        R.set(a0 + 1, 64, 11, R.S('red_nether_brick_stairs', facing='south', half='bottom'))
    R.set(5, 64, 11, S('jukebox', has_record=False))
    R.set(9, 64, 11, S('potted_fern'))
    for (a, b) in ((4, 3), (10, 3), (4, 9), (10, 9), (7, 9)):
        R.lampe(a, 68, b, S('shroomlight'), S('red_terracotta'), Z)
    # tables à pique-nique dehors (côté ouest)
    for (a, b) in ((16, 4), (16, 8)):
        R.set(a, 63, b, S('smooth_stone'))
        table(R, a, 64, b, 'spruce')
        R.set(a, 64, b - 1, R.S('spruce_slab', type='bottom'))
        R.set(a, 64, b + 1, R.S('spruce_slab', type='bottom'))
    for a in range(-2, 18):
        for b in (13, 14, 15):
            R.set(a, 63, b, S('smooth_stone'))


# ============================================================================ Café du Coin (NO)
def cafe(ctx):
    """x[50,66] z[42,62] façade sud ; a = x-50 (0..16), b = z-42 (0..20). 2 étages : café + logement ; terrasse z 63..68."""
    Z = 'cafe'
    ctx.zones[Z] = (58, 52)
    R = Repere(ctx, 50, 42)
    R.fill(0, 59, 0, 16, 63, 20, S('stone'))
    R.fill(0, 64, 0, 16, 73, 20, S('granite'))
    R.fill(0, 64, 0, 16, 73, 20, S('bricks'))
    R.vide(1, 64, 1, 15, 72, 19)
    R.fill(1, 68, 1, 15, 68, 19, S('spruce_planks'))
    R.fill(0, 73, 0, 16, 73, 20, S('andesite'))
    for (a1, b1, a2, b2) in ((0, 0, 16, 0), (0, 20, 16, 20), (0, 0, 0, 20), (16, 0, 16, 20)):
        R.fill(a1, 74, b1, a2, 74, b2, S('bricks'))
        R.fill(a1, 75, b1, a2, 75, b2, S('stone_brick_slab', type='bottom'))
        R.fill(a1, 68, b1, a2, 68, b2, S('stone_bricks'))
    for a in range(0, 17):
        R.set(a, 73, 21, R.S('stone_brick_stairs', facing='north', half='top'))
    for a in range(1, 16):
        for b in range(1, 20):
            R.set(a, 63, b, S('spruce_planks') if (a // 2 + b) % 2 else S('oak_planks'))
    # vitrine du café, porte à gauche, porte du logement à droite
    for a in range(2, 12):
        R.fill(a, 64, 20, a, 66, 20, S('glass_pane'))
    porte(R, 13, 64, 20, 'north', 'dark_oak', 'left')
    R.set(13, 66, 20, S('glass_pane'))
    # auvent vert (prismarine) + enseigne
    for a in range(1, 15):
        R.set(a, 67, 21, R.S('dark_prismarine_stairs', facing='north', half='bottom'))
    for a, txt in ((9, ['', 'CAFÉ DU COIN', '', '']), (6, ['Espresso', 'Pâtisseries', 'Déjeuners', ''])):
        R.set(a, 68, 21, R.S('spruce_wall_sign', facing='south'))
        R.sign(a, 68, 21, txt, 'white', True)
    # terrasse devant (b 21..24) : tables bistro et parasols
    for a in range(-1, 18):
        for b in range(21, 27):
            R.set(a, 63, b, S('stone_bricks') if (a + b) % 3 else S('polished_andesite'))
    for a in (3, 8):
        table(R, a, 64, 23, 'dark_oak')
        chaise(R, a - 1, 64, 23, 'east', 'dark_oak')
        chaise(R, a + 1, 64, 23, 'west', 'dark_oak')
    for a in range(-1, 12):
        R.set(a, 64, 26, S('dark_oak_fence')) if a not in (5, 6) else None
    # intérieur café
    for a in range(2, 9):
        R.set(a, 64, 6, S('dark_oak_planks'))
        R.set(a, 65, 6, S('smooth_quartz_slab', type='bottom'))
    R.set(4, 65, 6, S('hopper', enabled=True, facing='down'))
    R.set(6, 65, 6, S('cake', bites=0))
    R.set(8, 65, 6, S('heavy_weighted_pressure_plate'))
    for a in range(1, 10):
        R.set(a, 64, 1, R.S('barrel', facing='south', open=False))
        R.set(a, 66, 1, R.S('spruce_trapdoor', facing='south', half='top', open=True))
    R.set(5, 64, 1, S('water_cauldron', level=2))
    R.set(2, 66, 2, R.S('dark_oak_wall_sign', facing='south'))
    R.sign(2, 66, 2, ['MENU', 'Café 2,25 $', 'Latté 4,50 $', 'Muffin 3,25 $'], 'white', True)
    R.poi('cafe_comptoir', 5, 64, 4, 'south')
    for (a, b) in ((3, 11), (8, 11), (3, 16), (8, 16), (12, 12)):
        table(R, a, 64, b, 'spruce')
        chaise(R, a - 1, 64, b, 'east', 'spruce')
        chaise(R, a + 1, 64, b, 'west', 'spruce')
    bibliotheque(R, 15, 64, 3)
    bibliotheque(R, 15, 64, 4)
    grande_plante(R, 1, 64, 19, ctx.rng)
    grande_plante(R, 11, 64, 19, ctx.rng)
    # escalier intérieur vers le logement (a 13..15)
    R.fill(12, 64, 8, 12, 67, 19, S('bricks'))
    for i in range(4):
        R.set(14, 64 + i, 18 - i, R.S('spruce_stairs', facing='north', half='bottom'))
        R.set(15, 64 + i, 18 - i, R.S('spruce_stairs', facing='north', half='bottom'))
        R.vide(14, 68, 18 - i, 15, 68, 18 - i) if i >= 1 else None
    for a in (13, 14, 15):
        R.set(a, 69, 11, S('spruce_fence')) if a == 13 else None
    for (a, b) in ((3, 4), (4, 10), (9, 10), (4, 16), (9, 16), (14, 12)):
        R.lampe(a, 68, b, S('ochre_froglight', axis='y'), S('white_concrete'), Z)
    # étage : logement simple
    for a in range(2, 11):
        R.fill(a, 70, 20, a, 71, 20, S('glass_pane')) if a % 3 else None
    for b in (4, 5, 10, 11, 15, 16):
        R.fill(0, 70, b, 0, 71, b, S('glass_pane'))
        R.fill(16, 70, b, 16, 71, b, S('glass_pane'))
    R.fill(1, 69, 9, 11, 72, 9, S('white_concrete'))
    porte(R, 6, 69, 9, 'north', 'birch', 'left')
    lit(R, 3, 69, 3, 'north', 'green')
    R.set(2, 69, 2, R.S('barrel', facing='up', open=False))
    commode(R, 9, 69, 1, 'south', 2)
    canape(R, 2, 69, 13, 'east', 3, 'spruce', 'spruce')
    tele(R, 8, 70, 14, 'west', 2)
    R.set(8, 69, 14, R.S('spruce_slab', type='top'))
    R.set(8, 69, 15, R.S('spruce_slab', type='top'))
    tapis(R, 4, 12, 7, 16, 69, 'lime')
    for a in range(1, 6):
        R.set(a, 69, 19, R.S('barrel', facing='north', open=False))
    R.set(3, 69, 19, S('water_cauldron', level=1))
    for (a, b) in ((4, 5), (6, 14), (3, 17)):
        R.lampe(a, 73, b, S('ochre_froglight', axis='y'), S('white_concrete'), Z)
    # balcon + escalier extérieur en fer (typique) sur la façade
    for a in range(1, 12):
        for b in (21, 22):
            R.set(a, 68, b, S('spruce_slab', type='top'))
        R.set(a, 69, 23, S('iron_bars')) if False else None
    for a in range(1, 12):
        R.set(a, 69, 22, S('iron_bars'))
    R.set(1, 69, 21, S('iron_bars'))
    porte(R, 7, 69, 20, 'north', 'spruce', 'left')
    R.set(9, 69, 21, S('potted_red_tulip'))
