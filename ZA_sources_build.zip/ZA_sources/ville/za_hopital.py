# -*- coding: utf-8 -*-
"""Hôpital Saint-Aurèle : x[92,140] z[10,52], 3 étages (marche 64/69/74), toit 78.
Repère local : origine (92,10), a = x-92 (0..48), b = z-10 (0..42) ; façade principale au sud (b=42, z=52).
Baie d'ambulance à l'ouest (sur la rue des Érables), stationnement au sud z[53,66]."""
from za_blocs import S, AIR, OPP, CW, CCW
from za_meubles import (Repere, porte, porte_double, lit, chaise, table, table_basse, canape, fauteuil, tapis, plante,
                        grande_plante, commode, bibliotheque, tele, bureau, cadre, horloge, accoudoir, lettres, lavabo,
                        toilette, _VEC)
from za_batir import murs, dalle, fenetre, cage_escalier
import za_rue as RU

X0, Z0 = 92, 10
NIV = (64, 69, 74)
TOIT = 78
ZONE = 'hopital'
BLANC = S('white_concrete')
GRIS = S('light_gray_concrete')
QUARTZ = S('smooth_quartz')
VITRE = S('light_blue_stained_glass_pane')
SOL = S('white_concrete')
LAMPE_ON = S('sea_lantern')
LAMPE_OFF = S('light_gray_concrete')


def lampe(R, a, h, b):
    R.lampe(a, h + 4 if h < 74 else TOIT, b, LAMPE_ON, LAMPE_OFF, ZONE)


def construire(ctx):
    ctx.zones[ZONE] = (116, 31)
    ctx.zones['hopital_parc'] = (116, 60)
    R = Repere(ctx, X0, Z0)
    rng = ctx.rng
    # ---------------------------------------------------------------- coque
    R.fill(0, 59, 0, 48, 63, 42, S('stone'))
    R.fill(0, 64, 0, 48, TOIT, 42, BLANC)
    R.vide(1, 64, 1, 47, TOIT - 1, 41)
    dalle(R, 1, 1, 47, 41, 63, SOL)
    for h in NIV[1:]:
        dalle(R, 1, 1, 47, 41, h - 1, SOL)
    dalle(R, 0, 0, 48, 42, TOIT, GRIS)
    # bandeaux de plancher gris et fenêtres en bandes (meneaux de quartz)
    for yb in (63, 68, 73):
        for (a1, b1, a2, b2) in ((0, 0, 48, 0), (0, 42, 48, 42), (0, 0, 0, 42), (48, 0, 48, 42)):
            R.fill(a1, yb + 1 if yb == 63 else yb, b1, a2, yb + 1 if yb == 63 else yb, b2, GRIS)
    for h in NIV:
        for a in range(1, 48):
            if a % 4 != 0:
                R.fill(a, h + 1, 0, a, h + 2, 0, VITRE)
                if not (15 <= a <= 33 and h == 64):
                    R.fill(a, h + 1, 42, a, h + 2, 42, VITRE)
            else:
                R.fill(a, h + 1, 0, a, h + 3, 0, QUARTZ)
                R.fill(a, h + 1, 42, a, h + 3, 42, QUARTZ)
        for b in range(1, 42):
            if b % 4 != 0:
                R.fill(0, h + 1, b, 0, h + 2, b, VITRE)
                R.fill(48, h + 1, b, 48, h + 2, b, VITRE)
            else:
                R.fill(0, h + 1, b, 0, h + 3, b, QUARTZ)
                R.fill(48, h + 1, b, 48, h + 3, b, QUARTZ)
    # ---------------------------------------------------------------- cloisons communes à tous les étages
    for h in NIV:
        top = h + 3
        # corridor b 14..17 ; mur nord b=13, mur sud b=18
        R.fill(1, h, 13, 47, top, 13, BLANC)
        R.fill(1, h, 18, 47, top, 18, BLANC)
        # chambres nord : murs a=10,20,28,38
        for a in (10, 20, 28, 38):
            R.fill(a, h, 1, a, top, 12, BLANC)
        # plinthes bleues dans le corridor + bande de guidage
        for a in range(1, 48):
            R.set(a, h - 1, 15, S('light_blue_concrete') if h == 64 else SOL)
        for a in range(2, 47, 5):
            lampe(R, a, h, 15)
    # cage d'escalier (a 21..25, b 6..12) + ascenseurs
    for h in NIV:
        R.vide(21, h, 13, 25, h + 2, 13)
    R.fill(20, 64, 5, 26, TOIT - 1, 5, BLANC)
    R.fill(26, 64, 6, 26, TOIT - 1, 12, BLANC)
    cage_escalier(R, 21, 6, 64, 3, marche='quartz_stairs', palier='smooth_quartz', diviseur='white_concrete')
    for h in NIV:
        for a in (26, 27):
            R.fill(a, h, 13, a, h + 2, 13, BLANC)
        porte(R, 27, h, 13, 'north', 'iron', 'left')
        R.set(26, h + 1, 14, R.S('stone_button', face='wall', facing='south', powered=False))
        R.set(26, h + 2, 14, R.S('birch_wall_sign', facing='south'))
        R.sign(26, h + 2, 14, ['ASCENSEUR', 'Étage %d' % (NIV.index(h) + 1), '', ''])
        R.fill(27, h, 6, 27, h + 3, 12, S('iron_block'))
        # locaux d'entretien derrière la cage
        R.fill(21, h, 1, 27, h + 3, 4, AIR)
        porte(R, 24, h, 5, 'north', 'birch', 'left')
        for a in (21, 22, 26, 27):
            R.set(a, h, 1, R.S('barrel', facing='south', open=False))
            R.set(a, h + 1, 1, R.S('barrel', facing='south', open=False))
        R.set(23, h, 1, S('water_cauldron', level=3))
        lampe(R, 24, h, 3)
        # plan d'évacuation
        R.set(22, h + 2, 14, R.S('birch_wall_sign', facing='south'))
        R.sign(22, h + 2, 14, ['ESCALIER', 'En cas', "d'incendie", 'utilisez-moi'], 'red')
    # ---------------------------------------------------------------- rez-de-chaussée
    rez(ctx, R)
    etage_chambres(ctx, R, 69)
    etage_admin(ctx, R, 74)
    toit(ctx, R)
    exterieur(ctx, R)


# ============================================================================ chambres
def chambre(ctx, R, a1, b1, a2, b2, h, porte_pos, porte_dir, lits_nord=True, n=None, pois=True):
    """Chambre à 2 lits. porte_pos=(a,b) dans le mur, porte_dir = direction pour entrer."""
    porte(R, porte_pos[0], h, porte_pos[1], porte_dir, 'birch', 'left')
    # numéro
    if n is not None:
        pa, pb = porte_pos
        da, db = _VEC[OPP[porte_dir]]
        sa, sb = pa + da + (1 if porte_dir in ('north', 'south') else 0), pb + db + (1 if porte_dir in ('east', 'west') else 0)
        R.set(sa, h + 1, sb, R.S('birch_wall_sign', facing=OPP[porte_dir]))
        R.sign(sa, h + 1, sb, ['Chambre', str(n), '', ''])
    ca = (a1 + a2) // 2
    tete_b = b1 if lits_nord else b2
    sens = 'north' if lits_nord else 'south'
    pied_b = b1 + 1 if lits_nord else b2 - 1
    tetes = []
    for (la, cote) in ((ca - 2, -1), (ca + 2, 1)):
        t = lit(R, la, h, pied_b, sens, 'white')
        tetes.append(t)
        # table de chevet + moniteur, potence à soluté
        R.set(la + cote, h, tete_b, S('smooth_quartz'))
        R.set(la + cote, h + 1, tete_b, S('black_stained_glass_pane'))
        R.set(la - cote, h, tete_b, S('iron_bars'))
        R.set(la - cote, h + 1, tete_b, S('iron_bars'))
        R.set(la - cote, h + 2, tete_b, R.S('tripwire_hook', facing='south' if lits_nord else 'north', attached=False, powered=False))
        # chaise visiteur au pied
        R.set(la + cote, h, pied_b + (2 if lits_nord else -2), R.S('quartz_stairs', facing=sens, half='bottom'))
    # rideau entre les lits
    for b in range(min(tete_b, pied_b + (2 if lits_nord else -2)), max(tete_b, pied_b + (2 if lits_nord else -2)) + 1):
        if R.est_air(ca, h + 1, b):
            R.set(ca, h + 1, b, S('white_stained_glass_pane'))
            R.set(ca, h + 2, b, S('white_stained_glass_pane'))
    # lavabo près de la porte
    lampe(R, ca - 2, h, (b1 + b2) // 2)
    lampe(R, ca + 2, h, (b1 + b2) // 2)
    return tetes


def rez(ctx, R):
    h = 64
    rng = ctx.rng
    # chambres 1..4 au nord (lits contre le mur extérieur nord)
    rooms = [(1, 9), (11, 19), (29, 37), (39, 47)]
    k = 1
    for i, (a1, a2) in enumerate(rooms):
        ca = (a1 + a2) // 2
        tetes = chambre(ctx, R, a1, 1, a2, 12, h, (ca, 13), 'north', True, n=100 + i + 1)
        for t in tetes:
            R.poi('hopital_lit%d' % k, t[0], h, t[1], 'south')
            k += 1
        R.poi('hopital_chambre%d' % (i + 1), ca, h, 5, 'north')
    # ---------------------------------------------------------------- bande b 18..22 : admissions, poste, toilettes
    R.fill(14, h, 19, 14, h + 3, 41, BLANC)          # mur urgence / hall
    R.fill(34, h, 19, 34, h + 3, 41, BLANC)          # mur pharmacie / hall
    R.fill(15, h, 22, 33, h + 3, 22, BLANC)          # fond du hall
    R.fill(20, h, 19, 20, h + 3, 21, BLANC)
    R.fill(28, h, 19, 28, h + 3, 21, BLANC)
    # passage hall <-> corridor (a 29..33)
    R.vide(29, h, 18, 33, h + 2, 22)
    R.vide(29, h, 19, 33, h + 3, 21)
    R.fill(28, h, 19, 28, h + 3, 21, BLANC)
    # poste des infirmières (a 21..27, b 19..21) ouvert sur le corridor
    R.vide(21, h, 18, 27, h + 2, 18)
    for a in range(21, 28):
        R.set(a, h, 18, S('white_concrete'))
        R.set(a, h + 1, 18, S('smooth_quartz_slab', type='bottom'))
    R.vide(24, h, 18, 24, h + 1, 18)
    R.set(24, h, 18, R.S('birch_trapdoor', facing='south', half='bottom', open=True))
    for a in (22, 23, 25, 26):
        R.set(a, h, 20, R.S('birch_trapdoor', facing='north', half='top', open=False))
        R.set(a, h + 1, 20, S('black_stained_glass_pane'))
        R.set(a, h, 21, R.S('quartz_stairs', facing='south', half='bottom'))
    R.set(21, h, 21, R.S('barrel', facing='east', open=False))
    R.set(27, h, 21, S('chiseled_bookshelf', facing='west'))
    R.set(27, h, 19, R.S('barrel', facing='west', open=False))
    R.set(21, h + 1, 21, S('potted_fern'))
    R.set(24, h + 3, 18, S('white_concrete'))
    R.set(24, h + 2, 17, R.S('birch_wall_sign', facing='north')) if False else None
    R.set(23, h + 2, 17, R.S('birch_wall_sign', facing='north'))
    R.sign(23, h + 2, 17, ['POSTE DES', 'INFIRMIÈRES', '', ''], 'blue')
    lampe(R, 24, h, 20)
    ctx.poi('hopital_infirmiere', *R.xz(24, 19)[:1], h, R.xz(24, 19)[1], R.yaw('north'))
    # admissions (a 15..19)
    porte(R, 17, h, 22, 'north', 'birch', 'left')
    bureau(R, 16, h, 20, 'south')
    bureau(R, 18, h, 20, 'south')
    R.set(15, h, 19, S('bookshelf'))
    R.set(19, h, 19, R.S('barrel', facing='south', open=False))
    lampe(R, 17, h, 20)
    # ---------------------------------------------------------------- hall d'entrée (a 15..33, b 23..41)
    for a in range(15, 34):
        for b in range(23, 42):
            R.set(a, h - 1, b, QUARTZ if (a + b) % 2 else S('polished_diorite'))
    # grande verrière de façade (a 15..33) + vestibule
    for a in range(15, 34):
        R.fill(a, h, 42, a, h + 3, 42, VITRE if a % 4 else QUARTZ)
    R.vide(23, h, 42, 25, h + 2, 42)            # portes coulissantes (ouvertes)
    R.fill(21, h, 38, 21, h + 2, 41, VITRE)
    R.fill(27, h, 38, 27, h + 2, 41, VITRE)
    R.fill(21, h, 38, 27, h + 2, 38, VITRE)
    R.vide(23, h, 38, 25, h + 2, 38)
    R.fill(21, h + 3, 38, 27, h + 3, 41, BLANC)
    for a in (21, 27):
        R.set(a, h, 42, QUARTZ)
    for (a, b) in ((22, 42), (26, 42)):
        R.fill(a, h, b, a, h + 2, b, VITRE)
    R.fill(22, h - 1, 39, 26, h - 1, 41, S('gray_carpet') if False else S('light_gray_concrete'))
    # comptoir d'accueil (b 25, a 16..21) ; personnel derrière (b 24)
    for a in range(16, 22):
        R.set(a, h, 25, S('white_concrete'))
        R.set(a, h + 1, 25, S('smooth_quartz_slab', type='bottom'))
    R.set(21, h, 24, S('white_concrete'))
    R.set(21, h + 1, 24, S('smooth_quartz_slab', type='bottom'))
    for a in (17, 19):
        R.set(a, h + 1, 25, S('black_stained_glass_pane'))
        R.set(a, h, 24, R.S('quartz_stairs', facing='north', half='bottom'))
    R.set(15, h, 23, S('chiseled_bookshelf', facing='south'))
    R.set(16, h, 23, R.S('barrel', facing='south', open=False))
    R.set(18, h + 2, 23, R.S('birch_wall_sign', facing='south'))
    R.sign(18, h + 2, 23, ['ACCUEIL', 'Information', 'Admissions', ''], 'blue')
    R.poi('hopital_accueil', 18, h, 24, 'south')
    # attente : rangées de chaises face au nord
    for b in (29, 32, 35):
        for a in range(24, 33):
            if a == 28:
                R.set(a, h, b, S('potted_fern'))
                continue
            R.set(a, h, b, R.S('quartz_stairs', facing='south', half='bottom'))
    tele(R, 30, h + 2, 22, 'south', 3) if False else None
    for a in (30, 31, 32):
        R.set(a, h + 2, 23, S('black_stained_glass_pane'))
    grande_plante(R, 15, h, 41, rng)
    grande_plante(R, 33, h, 41, rng)
    grande_plante(R, 15, h, 30, rng)
    # distributrices
    R.fill(33, h, 26, 33, h + 1, 26, S('red_concrete'))
    R.set(32, h + 1, 26, S('glass_pane')) if False else None
    R.fill(33, h, 27, 33, h + 1, 27, S('blue_concrete'))
    # signalisation
    R.set(15, h + 2, 34, R.S('birch_wall_sign', facing='east'))
    R.sign(15, h + 2, 34, ['<-- URGENCE', '', 'CHAMBRES', '100 à 104 -->'], 'red')
    R.set(33, h + 2, 34, R.S('birch_wall_sign', facing='west'))
    R.sign(33, h + 2, 34, ['PHARMACIE -->', '', 'Heures :', '8 h à 20 h'], 'dark_green')
    for (a, b) in ((18, 30), (24, 27), (30, 27), (18, 37), (24, 34), (30, 38)):
        lampe(R, a, h, b)
    # ---------------------------------------------------------------- pharmacie (a 35..47, b 19..41)
    for a in range(35, 48):
        for b in range(19, 42):
            R.set(a, h - 1, b, S('polished_diorite'))
    # comptoir-guichet dans le mur a=34 (b 29..33)
    for b in range(29, 34):
        R.set(34, h, b, S('white_concrete'))
        R.set(34, h + 1, b, S('smooth_quartz_slab', type='bottom'))
        R.set(34, h + 2, b, S('glass_pane'))
    R.set(34, h + 1, 31, AIR)
    R.set(34, h + 1, 31, S('smooth_quartz_slab', type='bottom'))
    R.set(34, h + 2, 31, AIR)
    R.set(34, h + 3, 31, R.S('birch_wall_sign', facing='west')) if False else None
    R.set(33, h + 3, 31, R.S('birch_wall_sign', facing='west'))
    R.sign(33, h + 3, 31, ['PHARMACIE', 'Ordonnances', '', ''], 'dark_green', True)
    R.poi('hopital_pharmacie', 33, h, 31, 'east')
    R.poi('hopital_pharmacien', 35, h, 31, 'west')
    # étagères à médicaments
    for b in range(20, 41):
        if b % 6 == 0:
            continue
        R.set(47, h, b, S('chiseled_bookshelf', facing='west'))
        R.set(47, h + 1, b, S('bookshelf') if b % 2 else S('chiseled_bookshelf', facing='west'))
    for a in (40, 43):
        for b in range(22, 38):
            if b in (29, 30):
                continue
            R.set(a, h, b, R.S('barrel', facing='east' if a == 40 else 'west', open=False))
            R.set(a, h + 1, b, S('chiseled_bookshelf', facing='east' if a == 40 else 'west') if b % 3 else S('flower_pot'))
    R.set(36, h, 35, R.S('birch_trapdoor', facing='north', half='top', open=False))
    R.set(36, h + 1, 35, S('black_stained_glass_pane'))
    R.set(37, h, 35, R.S('quartz_stairs', facing='west', half='bottom'))
    R.set(36, h, 40, S('white_concrete'))
    R.set(36, h + 1, 40, S('iron_block'))
    porte(R, 41, h, 18, 'south', 'birch', 'left')
    R.set(41, h + 2, 17, R.S('birch_wall_sign', facing='north'))
    R.sign(41, h + 2, 17, ['PHARMACIE', 'Personnel', 'seulement', ''], 'dark_green')
    for (a, b) in ((37, 24), (37, 32), (45, 24), (45, 32), (41, 39), (37, 39)):
        lampe(R, a, h, b)
    # ---------------------------------------------------------------- urgence (a 1..13, b 19..41)
    for a in range(1, 14):
        for b in range(19, 42):
            R.set(a, h - 1, b, S('light_gray_concrete') if (a + b) % 5 == 0 else SOL)
    # grande porte de la baie d'ambulance (mur ouest a=0, b 32..36)
    R.vide(0, h, 32, 0, h + 3, 36)
    R.fill(0, h + 4, 31, 0, h + 4, 37, S('red_concrete'))
    # accès au hall
    R.vide(14, h, 35, 14, h + 2, 37)
    # triage : comptoir
    for b in range(22, 27):
        R.set(8, h, b, S('white_concrete'))
        R.set(8, h + 1, b, S('smooth_quartz_slab', type='bottom'))
    R.set(10, h, 24, R.S('quartz_stairs', facing='west', half='bottom'))
    R.set(9, h, 24, R.S('birch_trapdoor', facing='west', half='top', open=False))
    R.set(9, h + 1, 24, S('black_stained_glass_pane'))
    R.set(13, h + 2, 30, R.S('birch_wall_sign', facing='west'))
    R.sign(13, h + 2, 30, ['URGENCE', 'Triage', 'Attendez', "d'être appelé"], 'red')
    # civières en attente et boxes à rideaux
    for b in (29, 39):
        lit(R, 3, h, b, 'west', 'white')
        R.set(2, h + 1, b + (1 if b == 29 else -1), S('white_stained_glass_pane'))
    for b in range(19, 27):
        if b % 3 == 0:
            R.set(1, h, b, R.S('quartz_stairs', facing='west', half='bottom'))
    for (a, b) in ((10, 38), (11, 38)):
        R.set(a, h, b, R.S('iron_trapdoor', facing='north', half='top', open=False))
    R.set(12, h, 40, S('white_shulker_box', facing='up'))
    R.set(13, h, 40, S('red_shulker_box', facing='up'))
    for (a, b) in ((4, 22), (10, 22), (4, 29), (10, 30), (4, 38), (10, 40)):
        lampe(R, a, h, b)
    # toilettes publiques derrière le hall (dans le couloir du poste)
    # ---------------------------------------------------------------- corridor : bancs, signalisation
    for a in (5, 44):
        R.set(a, h, 17, R.S('quartz_stairs', facing='south', half='bottom'))
        R.set(a + 1, h, 17, R.S('quartz_stairs', facing='south', half='bottom'))
    R.set(1, h, 16, S('red_shulker_box', facing='up'))
    R.set(47, h, 16, R.S('barrel', facing='west', open=False))


def etage_chambres(ctx, R, h):
    rooms = [(1, 9), (11, 19), (29, 37), (39, 47)]
    for i, (a1, a2) in enumerate(rooms):
        ca = (a1 + a2) // 2
        chambre(ctx, R, a1, 1, a2, 12, h, (ca, 13), 'north', True, n=200 + i + 1)
    # sud : 4 chambres (b 19..29) + salle de repos et poste (b 31..41)
    for a in (12, 24, 36):
        R.fill(a, h, 19, a, h + 3, 41, BLANC)
    R.fill(1, h, 30, 47, h + 3, 30, BLANC)
    south = [(1, 11), (13, 23), (25, 35), (37, 47)]
    for i, (a1, a2) in enumerate(south):
        ca = (a1 + a2) // 2
        chambre(ctx, R, a1, 19, a2, 29, h, (ca, 18), 'south', False, n=205 + i)
    # rangée avant : salle des familles, poste, bureaux (accès par porte dans le mur b=30)
    for i, (a1, a2) in enumerate(south):
        ca = (a1 + a2) // 2
        porte(R, ca + 3, h, 30, 'south', 'birch', 'left')
        # passage : la porte donne sur la chambre ; ajoute un couloir latéral simple
    # salle des familles (a 13..23, b 31..41)
    canape(R, 14, h, 33, 'south', 4, 'dark_oak', 'dark_oak')
    canape(R, 14, h, 39, 'north', 4, 'dark_oak', 'dark_oak')
    table_basse(R, 16, h, 36)
    tapis(R, 15, 35, 18, 37, h, 'light_blue')
    grande_plante(R, 22, h, 40, ctx.rng)
    # poste d'étage (a 25..35)
    for a in range(26, 34):
        R.set(a, h, 36, S('white_concrete'))
        R.set(a, h + 1, 36, S('smooth_quartz_slab', type='bottom'))
    for a in (27, 30, 33):
        R.set(a, h, 38, R.S('quartz_stairs', facing='north', half='bottom'))
    # lits d'appoint (a 1..11) et réserve (a 37..47)
    for b in (32, 35, 38):
        lit(R, 3, h, b, 'west', 'light_blue')
        lit(R, 9, h, b, 'east', 'light_blue')
    for b in range(31, 42):
        R.set(47, h, b, R.S('barrel', facing='west', open=False))
        R.set(47, h + 1, b, R.S('barrel', facing='west', open=False))
    for a in range(38, 46, 3):
        R.set(a, h, 41, S('white_shulker_box', facing='up'))
    for (a, b) in ((6, 36), (18, 36), (30, 36), (42, 36)):
        lampe(R, a, h, b)


def etage_admin(ctx, R, h):
    rooms = [(1, 9), (11, 19), (29, 37), (39, 47)]
    noms = ['Dr É. Lefort', 'Dre M. Tremblay', 'Direction', 'Archives']
    for i, (a1, a2) in enumerate(rooms):
        ca = (a1 + a2) // 2
        porte(R, ca, h, 13, 'north', 'dark_oak', 'left')
        R.set(ca + 1, h + 1, 14, R.S('birch_wall_sign', facing='south'))
        R.sign(ca + 1, h + 1, 14, ['Bureau', noms[i], '', ''])
        if i < 3:
            bureau(R, ca, h, 5, 'south', 'dark_oak')
            R.set(ca - 1, h, 5, R.S('dark_oak_trapdoor', facing='south', half='top', open=False))
            R.set(ca + 1, h, 5, R.S('dark_oak_trapdoor', facing='south', half='top', open=False))
            R.set(ca, h, 7, R.S('quartz_stairs', facing='south', half='bottom'))
            R.set(ca, h, 6, AIR)
            chaise(R, ca, h, 4, 'south', 'dark_oak')
            for a in range(a1, a2 + 1):
                if a != ca:
                    R.set(a, h, 1, S('bookshelf'))
            grande_plante(R, a1, h, 12, ctx.rng)
            tapis(R, ca - 2, 4, ca + 2, 8, h, 'gray')
        else:
            for a in range(a1, a2 + 1, 2):
                for b in range(2, 11, 3):
                    R.set(a, h, b, R.S('barrel', facing='south', open=False))
                    R.set(a, h + 1, b, R.S('barrel', facing='south', open=False))
        lampe(R, ca, h, 7)
    # sud : laboratoire (a 1..23), salle de conférence (a 25..47)
    R.fill(24, h, 19, 24, h + 3, 41, BLANC)
    porte(R, 12, h, 18, 'south', 'iron', 'left')
    R.set(13, h, 17, R.S('stone_button', face='wall', facing='north', powered=False)) if False else None
    R.set(11, h + 2, 17, R.S('birch_wall_sign', facing='north'))
    R.sign(11, h + 2, 17, ['LABORATOIRE', 'ACCÈS RESTREINT', 'Partenaire :', 'NORDA Biotech'], 'red')
    R.vide(12, h, 18, 12, h + 1, 18)
    porte(R, 12, h, 18, 'south', 'birch', 'left')
    for a in range(3, 22, 1):
        for b in (24, 30, 36):
            R.set(a, h, b, S('white_concrete') if a % 6 else S('iron_block'))
            R.set(a, h + 1, b, S('glass') if a % 5 == 0 else (S('flower_pot') if a % 3 == 0 else AIR))
    for b in range(20, 41, 4):
        R.set(1, h, b, S('white_shulker_box', facing='east'))
        R.set(1, h + 1, b, R.S('barrel', facing='east', open=False))
    R.set(22, h, 40, S('blue_shulker_box', facing='up'))
    R.set(22, h + 1, 40, S('white_banner', rotation=0))
    R.set(23, h, 40, S('blue_shulker_box', facing='up'))
    R.set(21, h, 40, S('light_blue_shulker_box', facing='up'))
    R.set(20, h + 2, 41, R.S('birch_wall_sign', facing='north'))
    R.sign(20, h + 2, 41, ['NORDA', 'BIOTECH', 'Échantillons', 'Z-01 : NE PAS OUVRIR'], 'blue', True)
    for (a, b) in ((6, 27), (16, 27), (6, 33), (16, 33), (6, 39), (16, 39)):
        lampe(R, a, h, b)
    # salle de conférence
    porte(R, 36, h, 18, 'south', 'dark_oak', 'left')
    for a in range(29, 44):
        for b in (29, 30):
            R.set(a, h, b, R.S('dark_oak_slab', type='top'))
    for a in range(29, 44, 2):
        R.set(a, h, 28, R.S('dark_oak_stairs', facing='north', half='bottom'))
        R.set(a, h, 31, R.S('dark_oak_stairs', facing='south', half='bottom'))
    for a in (34, 35, 36, 37):
        R.set(a, h + 1, 41, S('black_stained_glass_pane'))
    tapis(R, 27, 25, 45, 34, h, 'gray')
    for (a, b) in ((30, 25), (36, 30), (42, 25), (30, 36), (42, 36)):
        lampe(R, a, h, b)


def toit(ctx, R):
    y = TOIT + 1
    for (a1, b1, a2, b2) in ((0, 0, 48, 0), (0, 42, 48, 42), (0, 0, 0, 42), (48, 0, 48, 42)):
        R.fill(a1, y, b1, a2, y, b2, BLANC)
        R.fill(a1, y + 1, b1, a2, y + 1, b2, S('smooth_quartz_slab', type='bottom'))
    # tour centrale avec « HÔPITAL » en lettres rouges
    R.fill(8, y, 36, 40, y + 7, 42, BLANC)
    R.fill(9, y, 37, 39, y + 7, 41, GRIS)
    R.fill(8, y + 8, 36, 40, y + 8, 42, S('smooth_quartz_slab', type='bottom'))
    for a in range(8, 41):
        R.set(a, y, 42, GRIS)
    lettres(R, 11, y + 1, 42, 'HÔPITAL', S('red_concrete'), 'east')
    # croix rouge sur la face ouest de la tour
    for (da, dy) in ((0, 2), (0, 3), (0, 4), (0, 5), (0, 6)):
        pass
    for k in range(-2, 3):
        R.set(8, y + 4 + k, 39, S('red_concrete'))
        R.set(8, y + 4, 39 + k, S('red_concrete'))
    for k in range(-2, 3):
        R.set(40, y + 4 + k, 39, S('red_concrete'))
        R.set(40, y + 4, 39 + k, S('red_concrete'))
    # héliport (a 32..46, b 4..18) : carré gris, bordure jaune, H blanc
    for a in range(32, 47):
        for b in range(3, 18):
            bord = a in (32, 46) or b in (3, 17)
            R.set(a, TOIT, b, S('yellow_concrete') if bord else S('gray_concrete'))
    for b in range(6, 15):
        R.set(36, TOIT, b, BLANC)
        R.set(37, TOIT, b, BLANC)
        R.set(41, TOIT, b, BLANC)
        R.set(42, TOIT, b, BLANC)
    for a in range(38, 41):
        R.set(a, TOIT, 10, BLANC)
    ctx.poi('hopital_heliport', *R.xz(39, 10)[:1], y, R.xz(39, 10)[1], 0)
    for (a, b) in ((32, 3), (46, 3), (32, 17), (46, 17)):
        R.lampe(a, y, b, S('verdant_froglight', axis='y'), S('green_terracotta'), ZONE)
    # local technique
    R.fill(3, y, 4, 14, y + 3, 12, GRIS)
    R.fill(3, y + 4, 4, 14, y + 4, 12, S('smooth_stone_slab', type='bottom'))
    porte(R, 8, y, 12, 'north', 'iron', 'left')
    for (a, b) in ((17, 4), (17, 8), (20, 4), (20, 8)):
        R.fill(a, y, b, a + 1, y + 1, b + 2, S('iron_block'))
        R.fill(a, y + 2, b, a + 1, y + 2, b + 2, S('iron_trapdoor', facing='north', half='bottom', open=False))
    for (a, b) in ((4, 20), (12, 26), (20, 22), (28, 28), (44, 26), (5, 32)):
        R.set(a, y, b, S('cauldron'))
        R.set(a, y + 1, b, S('lightning_rod', facing='up', powered=False)) if a % 2 == 0 else None
    for k in range(6):
        R.set(46, y + k, 40, S('lightning_rod', facing='up', powered=False))
    R.set(4, y + 5, 8, S('lightning_rod', facing='up', powered=False))


def exterieur(ctx, R):
    m = ctx.m
    rng = ctx.rng
    w = RU.Ecrivain(ctx)
    # ---------------------------------------------------------------- marquise de l'entrée (a 18..30, b 43..48)
    for a in range(18, 31):
        for b in range(43, 49):
            R.set(a, 68, b, S('smooth_quartz_slab', type='bottom') if (a in (18, 30) or b == 48) else S('white_concrete'))
    for a in range(18, 31):
        R.set(a, 69, 48, S('smooth_quartz_slab', type='bottom'))
    for a in (18, 30):
        for y in range(64, 68):
            R.set(a, y, 48, S('quartz_pillar', axis='y'))
    for (a, b) in ((21, 45), (24, 45), (27, 45), (21, 47), (27, 47)):
        R.lampe(a, 68, b, LAMPE_ON, LAMPE_OFF, 'hopital_parc')
    for a, txt in ((22, ['', 'HÔPITAL', '', '']), (24, ['', 'SAINT-AURÈLE', '', '']), (26, ['Entrée', 'principale', '', ''])):
        R.set(a, 68, 49, R.S('birch_wall_sign', facing='south'))
        R.sign(a, 68, 49, txt, 'red' if a != 26 else 'black', True)
    # débarcadère (sol) + îlots
    for a in range(16, 33):
        for b in range(43, 51):
            R.set(a, 63, b, S('smooth_stone') if b <= 44 else RU.ASPHALTE)
    R.poi('hopital_entree', 24, 64, 46, 'north')
    # ---------------------------------------------------------------- stationnement z 53..66 (b 43..56), x 86..152
    for x in range(86, 153):
        for z in range(53, 67):
            if 108 <= x <= 124 and z <= 60:
                continue
            m.set(x, 63, z, RU.ASPHALTE)
    # voie de circulation z 59..61 ; rangées nord z 53..57 (sauf devant l'entrée) et sud z 62..66
    voitures = [('red', 'north'), ('white', 'north'), ('blue', 'south'), ('light_gray', 'south'), ('black', 'north'),
                ('green', 'south'), ('white', 'north'), ('cyan', 'south'), ('brown', 'north'), ('gray', 'south')]
    k = 0
    stalls = []
    for x in range(88, 150, 4):
        for (z1, z2, rang) in ((53, 57, 'n'), (62, 66, 's')):
            if rang == 'n' and 104 <= x <= 128:
                continue
            if rang == 's' and (96 <= x <= 101 or 132 <= x <= 137):
                continue
            # ligne de séparation
            for z in range(z1, z2 + 1):
                m.set(x, 63, z, RU.BLANC)
            stalls.append((x + 2, (z1 + z2) // 2, rang))
    for i, (cx, cz, rang) in enumerate(stalls):
        if rng.random() < 0.42 and cx not in (98, 134):
            col, _ = voitures[k % len(voitures)]
            k += 1
            RU.voiture(w, cx, cz, 'north' if rang == 'n' else 'south', col)
    # places réservées (fauteuil roulant) près de l'entrée
    for x in (130, 131, 132):
        for z in range(53, 58):
            m.set(x, 63, z, S('blue_concrete') if x == 131 else RU.ASPHALTE)
    # entrées depuis la rue Principale
    for (x1, x2) in ((96, 100), (132, 136)):
        for x in range(x1, x2 + 1):
            for z in range(62, 72):
                m.set(x, 63, z, RU.ASPHALTE if z < 69 else S('smooth_stone'))
        m.fill(x1, 63, 71, x2, 63, 71, S('smooth_stone'))
    # bande de gazon + haie le long du trottoir (z 67..68)
    for x in range(86, 153):
        if 96 <= x <= 100 or 132 <= x <= 136:
            continue
        m.set(x, 63, 67, RU.GAZON)
        m.set(x, 63, 68, RU.GAZON)
        m.set(x, 64, 67, S('spruce_leaves', persistent=True, distance=1, waterlogged=False))
    # lampadaires du stationnement (doubles)
    for (x, z) in ((94, 60), (116, 61), (140, 60)):
        for y in range(64, 69):
            m.set(x, y, z, S('andesite_wall'))
        for (dx, dz) in ((1, 0), (-1, 0)):
            m.set(x + dx, 69, z + dz, S('smooth_stone_slab', type='bottom'))
            ctx.lampe(x + dx, 68, z + dz, S('ochre_froglight', axis='y'), S('gray_stained_glass'), 'hopital_parc')
        m.set(x, 69, z, S('smooth_stone_slab', type='bottom'))
    ctx.poi('hopital_cour_incident', 118, 64, 60, 90)
    # panneau monument près du trottoir (x 142..146, z 64..65)
    for x in range(141, 148):
        m.set(x, 64, 65, S('stone_bricks'))
        m.set(x, 65, 65, S('white_concrete'))
        m.set(x, 66, 65, S('white_concrete'))
        m.set(x, 67, 65, S('smooth_stone_slab', type='bottom'))
    for (x, y) in ((142, 65), (142, 66)):
        pass
    for x, txt in ((144, ['HÔPITAL', 'SAINT-AURÈLE', '', '']), (146, ['Urgence 24 h', '<-- rue des', 'Érables', ''])):
        m.set(x, 66, 66, S('birch_wall_sign', facing='south'))
        m.sign(x, 66, 66, txt, 'red' if x == 144 else 'black', True)
    m.set(142, 66, 66, S('red_concrete'))
    m.set(142, 65, 66, S('red_wall_banner', facing='south')) if False else None
    ctx.lampe(143, 64, 66, S('sea_lantern'), S('light_gray_concrete'), 'hopital_parc')
    ctx.lampe(145, 64, 66, S('sea_lantern'), S('light_gray_concrete'), 'hopital_parc')
    # ---------------------------------------------------------------- baie d'ambulance (ouest) x 84..91 z 38..48
    for x in range(81, 92):
        for z in range(38, 49):
            m.set(x, 63, z, RU.ASPHALTE if x >= 84 else S('smooth_stone'))
    m.fill(81, 63, 38, 81, 63, 48, S('smooth_stone'))
    for x in range(84, 92):
        for z in range(37, 50):
            m.set(x, 68, z, S('white_concrete') if z in (37, 49) or x == 84 else S('smooth_quartz_slab', type='top'))
    for z in (37, 49):
        for y in range(64, 68):
            m.set(84, y, z, S('quartz_pillar', axis='y'))
    for (x, z) in ((87, 40), (87, 45), (90, 42)):
        ctx.lampe(x, 68, z, LAMPE_ON, LAMPE_OFF, ZONE)
    # croix rouge et « URGENCE » au-dessus de la baie (façade ouest)
    for k in range(-2, 3):
        m.set(92, 73 + k, 44, S('red_concrete'))
        m.set(92, 73, 44 + k, S('red_concrete'))
    for z, txt in ((41, ['', 'URGENCE', '', '']), (47, ['AMBULANCES', 'SEULEMENT', '', ''])):
        m.set(83, 68, z, S('birch_wall_sign', facing='west'))
        m.sign(83, 68, z, txt, 'red', True)
    gy = RU.ambulance_blocs(w, 88, 40, 'west')
    ctx.gyros.extend(gy)
    ctx.poi('ambulance_baie', 87, 64, 44, 90)
    # bollards
    for z in (38, 48):
        m.set(82, 64, z, S('yellow_concrete'))
    # arbres et pelouses autour (nord et est)
    for (x, z) in ((96, 4), (106, 5), (126, 4), (138, 6), (146, 14), (147, 30), (146, 46), (86, 8), (86, 24)):
        RU.feuillu(m, x, 64, z, rng, h=5, feuilles='oak_leaves' if rng.random() < 0.6 else 'birch_leaves' if False else 'dark_oak_leaves')
    for (x, z) in ((151, 8), (152, 22), (150, 38), (89, 15)):
        RU.epinette(m, x, 64, z, rng, h=9)
    # quai de livraison arrière
    for x in range(126, 135):
        for z in range(4, 10):
            m.set(x, 63, z, RU.ASPHALTE)
    porte_double(Repere(ctx, 0, 0), 129, 64, 10, 'south', 'iron')
