# -*- coding: utf-8 -*-
"""POIs complémentaires, zones, chemins et caméras de la ville."""


def completer(ctx):
    P = ctx.pois
    ctx.poi('couloir_2e', 31, 69, 55, 0)
    ctx.poi('intersection', 76, 64, 76, 0)
    ctx.poi('hopital_infirmiere_ext', 116, 64, 55, 0)
    ctx.poi('spawn', 76, 64, 60, 180)
    # passants (trottoirs + parc)
    pts = [(10, 70, -90), (36, 70, 90), (58, 82, -90), (96, 70, 90), (126, 82, -90), (150, 70, 90),
           (70, 20, 0), (82, 50, 180), (70, 108, 0), (82, 140, 180), (36, 24, 90), (20, 20, 180)]
    for i, (x, z, yaw) in enumerate(pts, 1):
        ctx.poi('passant%d' % i, x, 64, z, yaw)
    # zones
    P['zone_citoyens'] = {'x1': 0, 'y1': 64, 'z1': 69, 'x2': 159, 'y2': 67, 'z2': 83}
    P['zone_citoyens_erables'] = {'x1': 69, 'y1': 64, 'z1': 0, 'x2': 83, 'y2': 67, 'z2': 159}
    # chemins (y = sol de marche)
    P['chemin_ambulance'] = [[200.5, 64, 74.5], [160.5, 64, 74.5], [120.5, 64, 74.5], [90.5, 64, 74.5],
                             [83.5, 64, 74.5], [79.5, 64, 72.5], [78.5, 64, 68.5], [78.5, 64, 58.5],
                             [78.5, 64, 49.5], [79.5, 64, 46.5], [82.5, 64, 45.0], [85.5, 64, 44.5], [87.5, 64, 44.5]]
    P['chemin_convoi'] = [[-60.5, 64, 78.5], [0.5, 64, 78.5], [76.5, 64, 78.5], [160.5, 64, 78.5], [222.5, 64, 78.5]]
    P['chemin_patient'] = [[100.5, 64, 62.5], [104.5, 64, 61.0], [108.5, 64, 60.0], [112.5, 64, 58.5], [115.5, 64, 56.5],
                           [116.5, 64, 55.5]]
    P['spawn_chaos'] = [[x + 0.5, 64, z + 0.5] for (x, z) in
                        ((12, 76), (30, 73), (48, 79), (60, 70), (92, 75), (110, 79), (140, 74), (76, 12), (77, 40),
                         (74, 100), (78, 130), (70, 150))]
    # caméra du blackout : départ près de l'autobus (y=67, regard NO), montée jusqu'à y≈115 au-dessus du centre,
    # panoramique lent, fin cadrée sur l'hôpital. [x,y,z,yaw,pitch,ticks_jusqua_la_suivante]
    P['camera_blackout'] = [
        [140.5, 67.0, 121.5, 135.0, 2.0, 54],
        [130.0, 74.0, 112.0, 138.0, 10.0, 54],
        [115.0, 88.0, 100.0, 140.0, 22.0, 54],
        [96.0, 104.0, 90.0, 145.0, 34.0, 54],
        [80.0, 115.0, 80.0, 160.0, 40.0, 47],
        [74.0, 115.0, 78.0, 185.0, 40.0, 47],
        [84.0, 110.0, 86.0, 200.0, 36.0, 40],
        [116.0, 100.0, 96.0, 180.0, 32.0, 0],
    ]
    # caméra d'intro : survol au lever du soleil (depuis l'est), fin à la fenêtre de la chambre du 2A
    P['camera_intro'] = [
        [150.5, 98.0, 110.5, 60.0, 28.0, 40],
        [110.0, 90.0, 92.0, 75.0, 25.0, 40],
        [60.0, 80.0, 82.0, 100.0, 18.0, 40],
        [26.0, 73.0, 72.0, 160.0, 8.0, 25],
        [19.5, 70.5, 66.2, 180.0, 5.0, 15],
        [19.5, 70.5, 65.4, 180.0, 5.0, 0],
    ]


def duree(chemin):
    return sum(k[5] for k in chemin)
