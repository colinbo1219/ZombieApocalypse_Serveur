# -*- coding: utf-8 -*-
"""Générateur déterministe de la ville du prologue « Saint-Aurèle » (ZombieApocalypse)
+ structures du monde principal + modèles d'accessoires.

Usage : python3 gen_ville.py [--sans-apercus]
Sorties (dans ce dossier) : town.json.gz, layers.json, lamps.json, pois.json, props.json,
arrivee.json.gz(+_pois), hall.json.gz(+_pois), zone_neutre.json.gz(+_pois), apercus/*.png
"""
import json
import math
import os
import sys
import time

from za_blocs import Monde, S, AIR, valide, parse, emet_lumiere, nom_court
from za_meubles import Ctx
import za_rue as RU

ICI = os.path.dirname(os.path.abspath(__file__))
APERCUS = os.path.join(ICI, 'apercus')
GRAINE = 1250


def monde_ville():
    return Monde(RU.MIN, 58, RU.MIN, RU.MAX - RU.MIN + 1, 48, RU.MAX - RU.MIN + 1)


# =========================================================================== forêt & périmètre
def foret(ctx):
    m, rng = ctx.m, ctx.rng
    # couvre-sol hors ville
    for _ in range(9000):
        x, z = rng.randint(RU.MIN, RU.MAX), rng.randint(RU.MIN, RU.MAX)
        if -4 <= x <= 163 and -4 <= z <= 163:
            continue
        if RU.dans_emprise_rue(x, z):
            continue
        r = rng.random()
        if r < 0.35:
            m.set(x, 63, z, S('podzol', snowy=False))
        elif r < 0.5:
            m.set(x, 63, z, S('coarse_dirt'))
        elif r < 0.6:
            m.set(x, 63, z, S('moss_block'))
        elif r < 0.66:
            m.set(x, 63, z, S('rooted_dirt'))
    # arbres (grille jitterée)
    pas = 4
    for gx in range(RU.MIN, RU.MAX + 1, pas):
        for gz in range(RU.MIN, RU.MAX + 1, pas):
            x = gx + rng.randint(0, pas - 1)
            z = gz + rng.randint(0, pas - 1)
            # distance à la ville
            dx = max(0 - x, x - 159, 0)
            dz = max(0 - z, z - 159, 0)
            d = max(dx, dz)
            if d < 9:
                continue
            if abs(z - 76) <= 7 or abs(x - 76) <= 7:
                continue
            dens = min(1.0, 0.55 + (d - 9) * 0.03)
            if rng.random() > dens:
                continue
            if x < RU.MIN + 1 or x > RU.MAX - 1 or z < RU.MIN + 1 or z > RU.MAX - 1:
                continue
            r = rng.random()
            if r < 0.46:
                RU.epinette(m, x, 64, z, rng)
            elif r < 0.64:
                RU.bouleau(m, x, 64, z, rng)
            elif r < 0.84:
                RU.feuillu(m, x, 64, z, rng, h=rng.randint(4, 6), feuilles='oak_leaves')
            else:
                RU.feuillu(m, x, 64, z, rng, h=rng.randint(5, 7), tronc='dark_oak_log', feuilles='dark_oak_leaves', r=3)
    # sous-bois : fougères, herbes, buissons, rochers
    for _ in range(14000):
        x, z = rng.randint(RU.MIN, RU.MAX), rng.randint(RU.MIN, RU.MAX)
        if -2 <= x <= 161 and -2 <= z <= 161:
            continue
        if RU.dans_emprise_rue(x, z) or not m.est_air(x, 64, z):
            continue
        sol = nom_court(m.get(x, 63, z))
        if sol not in ('grass_block', 'podzol', 'moss_block', 'coarse_dirt', 'rooted_dirt'):
            continue
        r = rng.random()
        if r < 0.3:
            m.set(x, 64, z, S('fern'))
        elif r < 0.45:
            m.set(x, 64, z, S('grass'))
        elif r < 0.53 and m.est_air(x, 65, z):
            m.set(x, 64, z, S('large_fern', half='lower'))
            m.set(x, 65, z, S('large_fern', half='upper'))
        elif r < 0.6:
            RU.buisson(m, x, 64, z, rng, rng.choice(['oak_leaves', 'spruce_leaves', 'azalea_leaves']))
        elif r < 0.63:
            for (dx, dz, dy) in ((0, 0, 0), (1, 0, 0), (0, 1, 0), (0, 0, 1)):
                if rng.random() < 0.8 and m.est_air(x + dx, 64 + dy, z + dz):
                    m.set(x + dx, 64 + dy, z + dz, S(rng.choice(['mossy_cobblestone', 'cobblestone', 'andesite', 'stone'])))
        elif r < 0.65:
            m.set(x, 64, z, S('moss_carpet'))
        elif r < 0.68:
            m.set(x, 64, z, S(rng.choice(['lily_of_the_valley', 'oxeye_daisy', 'dandelion', 'cornflower'])))
        elif r < 0.69:
            # tronc couché
            ax = rng.choice(['x', 'z'])
            for i in range(rng.randint(3, 5)):
                xx, zz = (x + i, z) if ax == 'x' else (x, z + i)
                if m.est_air(xx, 64, zz):
                    m.set(xx, 64, zz, S('spruce_log' if rng.random() < 0.5 else 'birch_log', axis=ax))


def perimetre(ctx):
    m = ctx.m
    b = S('barrier')
    m.fill(-6, 64, -6, -6, 100, 165, b)
    m.fill(165, 64, -6, 165, 100, 165, b)
    m.fill(-6, 64, -6, 165, 100, -6, b)
    m.fill(-6, 64, 165, 165, 100, 165, b)
    w = RU.Ecrivain(ctx)
    txt = ['ROUTE FERMÉE', '', 'Circulation', 'locale seulement']
    # Chaque sortie : la voie SORTANTE et son trottoir sont barrés (chevalets rayés + panneau tourné vers
    # la ville), la voie entrante reste libre (véhicules d'urgence, convoi) et est balisée de cônes.
    # rue Principale ouest (x=-3) : sortante = voie nord (z 72..75)
    for zc in (70, 73):
        RU.chevalet(w, -3, zc, 'z', sign=txt if zc == 73 else None, regard='east')
    RU.cone(w, -3, 75)
    # rue Principale est (x=162) : sortante = voie sud (z 77..80)
    for zc in (79, 82):
        RU.chevalet(w, 162, zc, 'z', sign=txt if zc == 79 else None, regard='west')
    RU.cone(w, 162, 77)
    # rue des Érables nord (z=-3) : sortante = voie est (x 77..80)
    for xc in (79, 82):
        RU.chevalet(w, xc, -3, 'x', sign=txt if xc == 79 else None, regard='south')
    RU.cone(w, 77, -3)
    # rue des Érables sud (z=162) : sortante = voie ouest (x 72..75)
    for xc in (70, 73):
        RU.chevalet(w, xc, 162, 'x', sign=txt if xc == 73 else None, regard='north')
    RU.cone(w, 75, 162)
    # cônes sur la ligne centrale de part et d'autre
    for k in (-1, 1, 3):
        RU.cone(w, -3 + k * 2, 76)
        RU.cone(w, 162 - k * 2, 76)
        RU.cone(w, 76, -3 + k * 2)
        RU.cone(w, 76, 162 - k * 2)


def etape_base(ctx):
    RU.terrain(ctx)
    RU.rues(ctx)
    foret(ctx)
    perimetre(ctx)


CARPETTE = {'white': 'white', 'smooth_quartz': 'white', 'quartz': 'white', 'polished_diorite': 'white',
            'calcite': 'white', 'light_gray': 'light_gray', 'smooth_stone': 'light_gray', 'polished_andesite': 'light_gray',
            'andesite': 'gray', 'gray': 'gray', 'spruce': 'brown', 'dark_oak': 'brown', 'oak': 'brown',
            'birch': 'white', 'jungle': 'orange', 'black': 'black'}


def couvrir_plafonniers(ctx):
    """Un plafonnier encastré dans une dalle serait visible comme tuile lumineuse depuis l'étage du dessus :
    on pose un tapis assorti au sol par-dessus (ou rien si un meuble le couvre déjà)."""
    m = ctx.m
    n = 0
    for l in ctx.lampes:
        x, y, z = l['x'], l['y'], l['z']
        if not m.est_air(x, y - 1, z) or not m.est_air(x, y + 1, z):
            continue
        # couleur du sol voisin
        voisins = [nom_court(m.get(x + dx, y, z + dz)) for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1))]
        coul = None
        for v in voisins:
            for k, c in CARPETTE.items():
                if v.startswith(k):
                    coul = c
                    break
            if coul:
                break
        if coul is None:
            continue
        m.set(x, y + 1, z, S(coul + '_carpet'))
        n += 1
    return n


def details_toit(ctx, x1, z1, x2, z2, y, n=3):
    """Équipements de toit plat (climatiseurs, évents, puits de lumière) pour la vue aérienne."""
    m, rng = ctx.m, ctx.rng
    for k in range(n):
        x = rng.randint(x1 + 1, x2 - 3)
        z = rng.randint(z1 + 1, z2 - 3)
        if all(m.est_air(xx, y, zz) for xx in (x, x + 1) for zz in (z, z + 1)):
            m.fill(x, y, z, x + 1, y, z + 1, S('light_gray_concrete'))
            m.fill(x, y + 1, z, x + 1, y + 1, z + 1, S('iron_trapdoor', facing='north', half='bottom', open=False))
    for k in range(n + 1):
        x, z = rng.randint(x1 + 1, x2 - 1), rng.randint(z1 + 1, z2 - 1)
        if m.est_air(x, y, z):
            m.set(x, y, z, S('cauldron') if k % 2 else S('lightning_rod', facing='up', powered=False))


def batiments(ctx):
    import za_immeuble, za_hopital, za_commerces, za_maisons, za_se, za_parc
    za_parc.parc(ctx)
    za_parc.stationnement_immeuble(ctx)
    za_immeuble.construire(ctx)
    za_commerces.cafe(ctx)
    za_hopital.construire(ctx)
    za_commerces.depanneur(ctx)
    za_commerces.rita(ctx)
    za_maisons.stationnement_so(ctx)
    za_maisons.bungalows(ctx)
    za_maisons.terrain_balle(ctx)
    za_se.police(ctx)
    za_se.station(ctx)
    za_se.ecole(ctx)
    za_parc.mobilier(ctx)
    details_toit(ctx, 48, 86, 64, 98, 69, 2)       # dépanneur
    details_toit(ctx, 30, 86, 44, 92, 69, 1)       # Rita
    details_toit(ctx, 88, 88, 110, 104, 69, 3)     # police
    details_toit(ctx, 88, 124, 104, 156, 69, 4)    # école
    details_toit(ctx, 140, 101, 152, 111, 69, 2)   # magasin de la station
    details_toit(ctx, 50, 42, 66, 62, 74, 2)       # café


def generer_ville(apercus=True):
    t0 = time.time()
    ctx = Ctx(monde_ville(), GRAINE)
    etape_base(ctx)
    batiments(ctx)
    for l in ctx.lampes:          # les planchers posés après coup ont pu écraser des plafonniers
        ctx.m.set(l['x'], l['y'], l['z'], l['on'])
    n = couvrir_plafonniers(ctx)
    nettoyer_plantes(ctx.m)
    ctx.m.passe_connexions()
    ctx.m.passe_escaliers()
    print('ville construite en %.1fs (%d tapis sur plafonniers)' % (time.time() - t0, n))
    return ctx


def apercu_rapide(ctx, nom, region=None, px=3, grille=16):
    import za_rendu as RD
    os.makedirs(APERCUS, exist_ok=True)
    RD.vue_dessus(ctx.m, os.path.join(APERCUS, nom), px=px, region=region, grille=grille,
                  marques=[(k, v['x'], v['z']) for k, v in ctx.pois.items() if isinstance(v, dict) and 'yaw' in v])


BUS = (134, 116)
N_GROUPES = 14


def groupes_lampes(ctx):
    """g = ordre d'extinction du blackout : 0 = station-service / autobus, puis on s'éloigne quartier par
    quartier (anneaux de distance, groupes de taille comparable). Les lampes d'un même bâtiment partagent le centre
    de leur zone (le bâtiment s'éteint d'un coup). L'hôpital, sur lequel la caméra finit, s'éteint en dernier."""
    ds = []
    for l in ctx.lampes:
        c = ctx.zones.get(l['zone']) if l['zone'] else None
        px, pz = c if c else (l['x'], l['z'])
        ds.append(math.hypot(px - BUS[0], pz - BUS[1]))
    autres = sorted(d for l, d in zip(ctx.lampes, ds) if l['zone'] not in ('hopital',))
    n = len(autres)
    ng = N_GROUPES - 1
    seuils = [autres[min(n - 1, int(n * k / ng))] for k in range(1, ng)]
    for l, d in zip(ctx.lampes, ds):
        if l['zone'] == 'hopital':
            l['g'] = N_GROUPES - 1
        else:
            l['g'] = sum(1 for s in seuils if d >= s and s > autres[0]) if d > autres[0] else 0
            l['g'] = min(l['g'], ng - 1)
    rang = {v: i for i, v in enumerate(sorted({l['g'] for l in ctx.lampes}))}
    for l in ctx.lampes:
        l['g'] = rang[l['g']]


def nettoyer_plantes(m):
    """Retire les moitiés orphelines de plantes hautes (écrasées par un autre élément)."""
    n = 0
    for i, st in enumerate(list(m.pal)):
        nm, p = parse(st)
        c = nm.split(':', 1)[1]
        if p.get('half') in ('upper', 'lower') and not c.endswith('_door'):
            for (x, y, z) in m.positions({i}):
                x, y, z = int(x), int(y), int(z)
                o = m.get(x, y + (1 if p['half'] == 'lower' else -1), z)
                if parse(o)[0] != nm:
                    m.set(x, y, z, AIR)
                    n += 1
    return n


def exporter(ctx):
    import za_calques, za_pois, za_props, za_verif
    m = ctx.m
    t0 = time.time()
    za_calques.tous(ctx)
    za_pois.completer(ctx)
    groupes_lampes(ctx)
    # ---------------------------------------------------------------- vérifications
    err = m.verifier()
    for nom, c in ctx.calques.items():
        for st in set(c.values()):
            e = valide(st)
            if e:
                err.append('calque %s : %s' % (nom, e))
    for l in ctx.lampes:
        for k in ('on', 'off'):
            e = valide(l[k])
            if e:
                err.append('lampe : ' + e)
        if m.get(l['x'], l['y'], l['z']) != l['on']:
            err.append('lampe %s : bloc de base %s != on' % ((l['x'], l['y'], l['z']), m.get(l['x'], l['y'], l['z'])))
    manq = za_verif.lampes_manquantes(m, ctx.lampes)
    for x in manq:
        err.append('source lumineuse absente de lamps.json : %s' % (x,))
    cibles = {k: (int(math.floor(v['x'])), int(v['y']), int(math.floor(v['z']))) for k, v in ctx.pois.items()
              if isinstance(v, dict) and 'yaw' in v and k not in ('hopital_heliport', 'police_cellule', 'bus_siege', 'radio_2A', 'lit_2B') and not k.startswith('hopital_lit')}
    acc, n = za_verif.accessibilite(m, (76, 64, 76), cibles)
    inacc = sorted(k for k, v in acc.items() if not v)
    print('accessibilité : %d cases atteintes ; POIs inaccessibles : %s' % (n, inacc))
    print('erreurs de validation : %d' % len(err))
    for e in err[:40]:
        print('  ', e)
    # ---------------------------------------------------------------- écriture
    taille = m.exporter(os.path.join(ICI, 'town.json.gz'))
    nonair = m.non_air()
    calques = {nom: [{'x': x, 'y': y, 'z': z, 'b': st} for (x, y, z), st in sorted(c.items())]
               for nom, c in ctx.calques.items()}
    with open(os.path.join(ICI, 'layers.json'), 'w', encoding='utf-8') as f:
        json.dump(calques, f, ensure_ascii=False, separators=(',', ':'))
    lampes = [{'x': l['x'], 'y': l['y'], 'z': l['z'], 'on': l['on'], 'off': l['off'], 'g': l['g']}
              for l in sorted(ctx.lampes, key=lambda l: (l['g'], l['x'], l['z'], l['y']))]
    with open(os.path.join(ICI, 'lamps.json'), 'w', encoding='utf-8') as f:
        json.dump(lampes, f, ensure_ascii=False, separators=(',', ':'))
    with open(os.path.join(ICI, 'pois.json'), 'w', encoding='utf-8') as f:
        json.dump(ctx.pois, f, ensure_ascii=False, indent=1)
    props = za_props.tous()
    for k in props:
        props[k].pop('taille', None)
    with open(os.path.join(ICI, 'props.json'), 'w', encoding='utf-8') as f:
        json.dump(props, f, ensure_ascii=False, separators=(',', ':'))
    stats = {'town_octets': taille, 'town_non_air': nonair, 'palette': len(m.pal), 'W_H_D': [m.W, m.H, m.D],
             'calques': {k: len(v) for k, v in calques.items()}, 'lampes': len(lampes),
             'groupes': sorted({l['g'] for l in lampes}), 'pois': len(ctx.pois), 'erreurs': len(err),
             'inaccessibles': inacc, 'duree_blackout': za_pois.duree(ctx.pois['camera_blackout']),
             'duree_intro': za_pois.duree(ctx.pois['camera_intro'])}
    print(json.dumps(stats, ensure_ascii=False))
    print('export en %.1fs' % (time.time() - t0))
    return stats


def apercus(ctx):
    import za_rendu as RD
    os.makedirs(APERCUS, exist_ok=True)
    m = ctx.m
    mk = [(k, v['x'], v['z']) for k, v in ctx.pois.items() if isinstance(v, dict) and 'yaw' in v]
    RD.vue_dessus(m, os.path.join(APERCUS, 'ville_dessus.png'), px=3, titre='Saint-Aurèle - vue du dessus (1 bloc = 3 px)')
    RD.vue_dessus(m, os.path.join(APERCUS, 'ville_dessus_pois.png'), px=5, region=(-8, -8, 167, 167), grille=16, marques=mk)
    RD.vue_iso(m, os.path.join(APERCUS, 'ville_iso_se.png'), U=5, region=(-10, -10, 169, 169), titre='Saint-Aurèle (vue du sud-est)')
    RD.vue_iso(m, os.path.join(APERCUS, 'ville_iso_no.png'), U=5, region=(-10, -10, 169, 169), rot=180, titre='Saint-Aurèle (vue du nord-ouest)')
    gros = [('gros_plan_immeuble', (-2, 34, 70, 92), 11, 0, None), ('gros_plan_intersection', (42, 60, 110, 112), 10, 180, None),
            ('gros_plan_hopital', (80, 0, 156, 74), 8, 0, None), ('gros_plan_station', (84, 80, 158, 124), 9, 0, None),
            ('gros_plan_maisons', (30, 100, 70, 160), 9, 0, None), ('gros_plan_parc', (-2, -2, 70, 42), 9, 0, None),
            ('coupe_immeuble_2e', (14, 40, 48, 70), 16, 0, 72), ('coupe_hopital_rdc', (84, 8, 142, 60), 10, 0, 67),
            ('coupe_commerces', (28, 84, 66, 100), 16, 180, 67), ('coupe_police', (86, 86, 112, 106), 16, 180, 67),
            ('coupe_maison', (42, 102, 70, 124), 16, 0, 67), ('coupe_ecole_station', (86, 98, 156, 160), 8, 0, 67)]
    for (nom, reg, U, rot, ymax) in gros:
        RD.vue_iso(m, os.path.join(APERCUS, nom + '.png'), U=U, region=reg, rot=rot, y_max=ymax)
    # calques appliqués (copie du monde)
    import copy
    def avec_calques(noms):
        c = Monde(m.x0, m.y0, m.z0, m.W, m.H, m.D)
        c.a = m.a.copy()
        c.pal = list(m.pal)
        c.idx = dict(m.idx)
        for n in noms:
            for (x, y, z), st in ctx.calques.get(n, {}).items():
                c.set(x, y, z, st)
        return c
    c1 = avec_calques(['quarantaine', 'gyro_a', 'incident'])
    RD.vue_iso(c1, os.path.join(APERCUS, 'calques_quarantaine_incident.png'), U=9, region=(80, 36, 158, 76))
    c2 = avec_calques(['depanneur_ferme', 'chaos', 'checkpoint'])
    RD.vue_iso(c2, os.path.join(APERCUS, 'calques_chaos_checkpoint.png'), U=5, region=(-10, -10, 169, 169))
    RD.vue_iso(c2, os.path.join(APERCUS, 'calques_checkpoint_gros_plan.png'), U=12, region=(56, 60, 96, 96), rot=180)
    for h, nom in ((64, 'rdc'), (69, '2e'), (74, '3e')):
        RD.plan_etage(m, os.path.join(APERCUS, 'immeuble_%s.png' % nom), h, (12, 38, 50, 72), N=14, marques=mk,
                      titre='Immeuble des Érables - niveau %d' % h)
        RD.plan_etage(m, os.path.join(APERCUS, 'hopital_%s.png' % nom), h, (82, 6, 144, 60), N=10, marques=mk,
                      titre='Hôpital Saint-Aurèle - niveau %d' % h)


def structures(apercus=True):
    import za_structures as ZS
    res = {}
    for nom, fn in (('arrivee', ZS.arrivee), ('hall', ZS.hall), ('zone_neutre', ZS.zone_neutre)):
        m, P = fn()
        err = m.verifier()
        taille = m.exporter(os.path.join(ICI, nom + '.json.gz'), offset=[m.x0, m.y0, m.z0])
        with open(os.path.join(ICI, nom + '_pois.json'), 'w', encoding='utf-8') as f:
            json.dump(P, f, ensure_ascii=False, indent=1)
        res[nom] = {'octets': taille, 'non_air': m.non_air(), 'taille': [m.W, m.H, m.D], 'offset': [m.x0, m.y0, m.z0],
                    'erreurs': err, 'pois': sorted(P)}
        print(nom, json.dumps(res[nom], ensure_ascii=False)[:400])
        if apercus:
            import za_rendu as RD
            os.makedirs(APERCUS, exist_ok=True)
            mk = [(k, v['x'], v['z']) for k, v in P.items() if isinstance(v, dict) and 'yaw' in v]
            RD.vue_dessus(m, os.path.join(APERCUS, nom + '_dessus.png'), px=10, grille=8, marques=mk, ombrage=True)
            RD.vue_iso(m, os.path.join(APERCUS, nom + '_iso.png'), U=12)
    return res


if __name__ == '__main__':
    sans = '--sans-apercus' in sys.argv
    if '--structures' not in sys.argv:
        ctx = generer_ville()
        exporter(ctx)
        if not sans:
            apercus(ctx)
    structures(not sans)
