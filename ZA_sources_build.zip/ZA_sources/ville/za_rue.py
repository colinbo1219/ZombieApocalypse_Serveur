# -*- coding: utf-8 -*-
"""za_rue : terrain, rues, trottoirs, mobilier urbain, arbres, véhicules en blocs, barricades."""
import math

from za_blocs import S, AIR, DIRS, OPP, CW, CCW, YAW, parse, nom_court, est_plein, MODERNE
from za_meubles import _VEC

# --------------------------------------------------------------------------- géométrie imposée (spec)
PR_Z = (72, 80)          # rue Principale (asphalte)
PR_TN = (69, 71)         # trottoir nord
PR_TS = (81, 83)         # trottoir sud
ER_X = (72, 80)          # rue des Érables
ER_TO = (69, 71)
ER_TE = (81, 83)
MIN, MAX = -64, 223      # emprise totale
VILLE = (0, 159)
SOL = 63                 # blocs de sol ; on marche à y=64

ASPHALTE = S('gray_concrete')
RUSTINES = [S('andesite'), S('cyan_terracotta')]
# trottoirs en pavés carrés (Macaw's Paths) si les mods décoratifs sont là
TROTTOIR = S('mcwpaths:andesite_square_paving') if MODERNE else S('smooth_stone')
BORDURE = S('polished_andesite')
JAUNE = S('yellow_concrete')
BLANC = S('white_concrete')
GAZON = S('grass_block', snowy=False)


class Ecrivain:
    """Écrit dans le monde de base."""

    def __init__(self, ctx):
        self.ctx = ctx
        self.m = ctx.m

    def set(self, x, y, z, st):
        self.m.set(x, y, z, st)

    def get(self, x, y, z):
        return self.m.get(x, y, z)

    def lampe(self, x, y, z, on, off, zone=None):
        self.ctx.lampe(x, y, z, on, off, zone)

    def sign(self, x, y, z, lignes, couleur='black', glow=False):
        self.m.sign(x, y, z, lignes, couleur, glow)


class EcrivainCalque(Ecrivain):
    """Écrit dans un calque (blocs factices) ; get() voit le calque par-dessus la base."""

    def __init__(self, ctx, nom):
        super().__init__(ctx)
        self.nom = nom

    def set(self, x, y, z, st):
        self.ctx.calque(self.nom, x, y, z, st)

    def get(self, x, y, z):
        c = self.ctx.calques.get(self.nom, {})
        if (x, y, z) in c:
            return c[(x, y, z)]
        return self.m.get(x, y, z)

    def lampe(self, x, y, z, on, off, zone=None):
        self.set(x, y, z, on)

    def sign(self, *a, **k):
        pass


def dans_route(x, z, marge=0):
    return (PR_Z[0] - marge <= z <= PR_Z[1] + marge) or (ER_X[0] - marge <= x <= ER_X[1] + marge)


def dans_emprise_rue(x, z):
    """Asphalte + trottoirs."""
    return (PR_TN[0] <= z <= PR_TS[1]) or (ER_TO[0] <= x <= ER_TE[1])


# =========================================================================== terrain & rues
def terrain(ctx):
    m = ctx.m
    m.fill(MIN, 58, MIN, MAX, 58, MAX, S('stone'))
    m.fill(MIN, 59, MIN, MAX, 62, MAX, S('dirt'))
    m.fill(MIN, SOL, MIN, MAX, SOL, MAX, GAZON)


def rues(ctx):
    m = ctx.m
    rng = ctx.rng
    # sous-couche de pierre sous l'emprise des rues
    for (a, b) in ((PR_TN[0], PR_TS[1]),):
        m.fill(MIN, 59, a, MAX, 62, b, S('stone'))
    m.fill(ER_TO[0], 59, MIN, ER_TE[1], 62, MAX, S('stone'))
    # trottoirs (dans la ville seulement, +2 de marge) ; ailleurs accotement de gazon
    lo, hi = VILLE[0] - 3, VILLE[1] + 3
    for z0, z1, zb in ((PR_TN[0], PR_TN[1], PR_TN[1]), (PR_TS[0], PR_TS[1], PR_TS[0])):
        m.fill(lo, SOL, z0, hi, SOL, z1, TROTTOIR)
        m.fill(lo, SOL, zb, hi, SOL, zb, BORDURE)
        # accotements hors ville : gazon + bordure
        m.fill(MIN, SOL, zb, lo - 1, SOL, zb, S('coarse_dirt'))
        m.fill(hi + 1, SOL, zb, MAX, SOL, zb, S('coarse_dirt'))
    for x0, x1, xb in ((ER_TO[0], ER_TO[1], ER_TO[1]), (ER_TE[0], ER_TE[1], ER_TE[0])):
        m.fill(x0, SOL, lo, x1, SOL, hi, TROTTOIR)
        m.fill(xb, SOL, lo, xb, SOL, hi, BORDURE)
        m.fill(xb, SOL, MIN, xb, SOL, lo - 1, S('coarse_dirt'))
        m.fill(xb, SOL, hi + 1, xb, SOL, MAX, S('coarse_dirt'))
    # coins de trottoirs à l'intersection
    for (xa, xb_) in (ER_TO, ER_TE):
        for (za, zb) in (PR_TN, PR_TS):
            m.fill(xa, SOL, za, xb_, SOL, zb, TROTTOIR)
    for (x, z) in ((71, 69), (71, 70), (71, 71), (69, 71), (70, 71), (81, 69), (81, 70), (81, 71), (82, 71), (83, 71),
                   (71, 81), (70, 81), (69, 81), (71, 82), (71, 83), (81, 81), (82, 81), (83, 81), (81, 82), (81, 83)):
        m.set(x, SOL, z, BORDURE)
    # asphalte
    m.fill(MIN, SOL, PR_Z[0], MAX, SOL, PR_Z[1], ASPHALTE)
    m.fill(ER_X[0], SOL, MIN, ER_X[1], SOL, MAX, ASPHALTE)
    # rustines (déterministes)
    for _ in range(420):
        if rng.random() < 0.5:
            x, z = rng.randint(MIN, MAX), rng.randint(PR_Z[0], PR_Z[1])
        else:
            x, z = rng.randint(ER_X[0], ER_X[1]), rng.randint(MIN, MAX)
        w, d = rng.randint(1, 3), rng.randint(1, 2)
        st = RUSTINES[0] if rng.random() < 0.7 else RUSTINES[1]
        for i in range(w):
            for j in range(d):
                xx, zz = x + i, z + j
                if dans_route(xx, zz) and (PR_Z[0] <= zz <= PR_Z[1] or ER_X[0] <= xx <= ER_X[1]):
                    m.set(xx, SOL, zz, st)
    # lignes jaunes pointillées (3 on / 3 off), interrompues à l'intersection
    for x in range(MIN, MAX + 1):
        if 66 <= x <= 86:
            continue
        m.set(x, SOL, 76, JAUNE if (x // 3) % 2 == 0 else ASPHALTE)
    for z in range(MIN, MAX + 1):
        if 66 <= z <= 86:
            continue
        m.set(76, SOL, z, JAUNE if (z // 3) % 2 == 0 else ASPHALTE)
    # passages piétons (zébrures parallèles à la circulation)
    for x in range(69, 72):
        for z in range(72, 81):
            m.set(x, SOL, z, BLANC if z % 2 == 0 else ASPHALTE)
    for x in range(81, 84):
        for z in range(72, 81):
            m.set(x, SOL, z, BLANC if z % 2 == 0 else ASPHALTE)
    for z in range(69, 72):
        for x in range(72, 81):
            m.set(x, SOL, z, BLANC if x % 2 == 0 else ASPHALTE)
    for z in range(81, 84):
        for x in range(72, 81):
            m.set(x, SOL, z, BLANC if x % 2 == 0 else ASPHALTE)
    # lignes d'arrêt
    m.fill(67, SOL, 77, 67, SOL, 80, BLANC)
    m.fill(85, SOL, 72, 85, SOL, 75, BLANC)
    m.fill(72, SOL, 67, 75, SOL, 67, BLANC)
    m.fill(77, SOL, 85, 80, SOL, 85, BLANC)
    # intersection : asphalte propre
    m.fill(72, SOL, 72, 80, SOL, 80, ASPHALTE)
    # flèches de virage peintes (petites) sur chaque approche
    for (x, z) in ((64, 78), (88, 74), (74, 64), (78, 88)):
        m.set(x, SOL, z, BLANC)


def entree_charretiere(ctx, x1, z1, x2, z2, st=ASPHALTE):
    """Abaisse le trottoir (sans bordure) pour une entrée de stationnement."""
    ctx.m.fill(x1, SOL, z1, x2, SOL, z2, st)


# =========================================================================== arbres
def _feuille(m, x, y, z, st):
    if m.est_air(x, y, z):
        m.set(x, y, z, st)


def feuillu(m, x, y, z, rng, h=None, tronc='oak_log', feuilles='oak_leaves', r=None, extra=None):
    """Arbre feuillu : tronc + couronne ellipsoïdale irrégulière (feuilles persistantes)."""
    h = h or rng.randint(4, 6)
    r = r or rng.choice([2, 2, 3])
    fl = S(feuilles, persistent=True, distance=1, waterlogged=False) if feuilles.endswith('leaves') else S(feuilles)
    for k in range(h):
        m.set(x, y + k, z, S(tronc, axis='y'))
    cy = y + h - 1
    for dy in range(-1, r + 1):
        rr = r + 0.6 - max(0, dy) * 0.55 - (0.6 if dy < 0 else 0)
        for dx in range(-r - 1, r + 2):
            for dz in range(-r - 1, r + 2):
                d = math.sqrt(dx * dx + dz * dz)
                if d <= rr and not (d > rr - 0.8 and rng.random() < 0.35):
                    st = fl
                    if extra and rng.random() < extra[1]:
                        st = extra[0]
                    _feuille(m, x + dx, cy + dy, z + dz, st)
    # branches
    for _ in range(rng.randint(0, 2)):
        dx, dz = rng.choice([(1, 0), (-1, 0), (0, 1), (0, -1)])
        m.set(x + dx, cy - 1, z + dz, S(tronc, axis='x' if dx else 'z'))


def bouleau(m, x, y, z, rng, h=None):
    h = h or rng.randint(5, 7)
    fl = S('birch_leaves', persistent=True, distance=1, waterlogged=False)
    for k in range(h):
        m.set(x, y + k, z, S('birch_log', axis='y'))
    top = y + h
    for dy in range(-3, 2):
        r = 1 if dy in (-3, 1) else 2
        for dx in range(-r, r + 1):
            for dz in range(-r, r + 1):
                if abs(dx) + abs(dz) <= r + (1 if dy in (-2, -1) else 0) and not (abs(dx) == r and abs(dz) == r):
                    if rng.random() < 0.9:
                        _feuille(m, x + dx, top + dy, z + dz, fl)
    _feuille(m, x, top + 1, z, fl)


def epinette(m, x, y, z, rng, h=None):
    """Épinette (conifère conique)."""
    h = h or rng.randint(8, 13)
    fl = S('spruce_leaves', persistent=True, distance=1, waterlogged=False)
    for k in range(h - 1):
        m.set(x, y + k, z, S('spruce_log', axis='y'))
    base = y + 2
    top = y + h
    for yy in range(base, top + 1):
        t = (top - yy) / max(1, top - base)
        r = int(round(0.4 + t * 2.8))
        if (top - yy) % 2 == 1 and r > 1:
            r -= 1
        for dx in range(-r, r + 1):
            for dz in range(-r, r + 1):
                if dx * dx + dz * dz <= r * r + 0.5:
                    _feuille(m, x + dx, yy, z + dz, fl)
    _feuille(m, x, top + 1, z, fl)


def gros_chene(m, x, y, z, rng):
    """Grand chêne à tronc 2x2 (parc)."""
    h = rng.randint(6, 8)
    for k in range(h):
        for dx in (0, 1):
            for dz in (0, 1):
                m.set(x + dx, y + k, z + dz, S('dark_oak_log', axis='y'))
    fl = S('dark_oak_leaves', persistent=True, distance=1, waterlogged=False)
    cy = y + h
    for dy in range(-2, 3):
        rr = 4.2 - abs(dy) * 0.8 - (0.5 if dy > 0 else 0)
        for dx in range(-5, 7):
            for dz in range(-5, 7):
                d = math.sqrt((dx - 0.5) ** 2 + (dz - 0.5) ** 2)
                if d <= rr and not (d > rr - 1 and rng.random() < 0.3):
                    _feuille(m, x + dx, cy + dy, z + dz, fl)
    for (dx, dz) in ((-1, 0), (2, 1), (0, -1), (1, 2)):
        m.set(x + dx, cy - 2, z + dz, S('dark_oak_log', axis='x' if dx in (-1, 2) else 'z'))


def buisson(m, x, y, z, rng, feuilles='oak_leaves'):
    fl = S(feuilles, persistent=True, distance=1, waterlogged=False)
    _feuille(m, x, y, z, fl)
    for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        if rng.random() < 0.5:
            _feuille(m, x + dx, y, z + dz, fl)
    if rng.random() < 0.4:
        _feuille(m, x, y + 1, z, fl)


def haie(m, x1, z1, x2, z2, y=64, h=1, feuilles='oak_leaves'):
    fl = S(feuilles, persistent=True, distance=1, waterlogged=False)
    m.fill(x1, y, z1, x2, y + h - 1, z2, fl)


# =========================================================================== mobilier urbain
def lampadaire(w, x, z, vers, zone=None, y=64, hauteur=5, mat='andesite_wall', chapeau='smooth_stone_slab'):
    """Lampadaire : poteau (muret), bras vers `vers` au-dessus de la rue, tête ochre_froglight sous un chapeau."""
    for k in range(hauteur):
        w.set(x, y + k, z, S(mat))
    dx, dz = DIRS[vers]
    top = y + hauteur
    w.set(x, top, z, S(chapeau, type='bottom'))
    w.set(x + dx, top, z + dz, S(chapeau, type='bottom'))
    w.set(x + dx, top - 1, z + dz, S('ochre_froglight', axis='y'))
    w.lampe(x + dx, top - 1, z + dz, S('ochre_froglight', axis='y'), S('gray_stained_glass'), zone)
    return (x + dx, top - 1, z + dz)


def lampadaire_parc(w, x, z, zone=None, y=64):
    """Lampadaire de parc noir style lanterne : poteau + tête sous un chapeau."""
    for k in range(3):
        w.set(x, y + k, z, S('polished_blackstone_wall'))
    w.set(x, y + 3, z, S('ochre_froglight', axis='y'))
    w.lampe(x, y + 3, z, S('ochre_froglight', axis='y'), S('gray_stained_glass'), zone)
    w.set(x, y + 4, z, S('polished_blackstone_slab', type='bottom'))


def arbre_rue(w, x, z, rng, y=64, kind=None):
    m = w.m
    m.set(x, SOL, z, S('podzol', snowy=False))
    kind = kind or rng.choice(['erable', 'erable', 'tilleul', 'bouleau'])
    if kind == 'bouleau':
        bouleau(m, x, y, z, rng, h=rng.randint(5, 6))
    elif kind == 'tilleul':
        feuillu(m, x, y, z, rng, h=4, tronc='oak_log', feuilles='oak_leaves', r=2)
    else:
        feuillu(m, x, y, z, rng, h=4, tronc='dark_oak_log', feuilles='dark_oak_leaves', r=2)


def banc(w, x, z, regard, y=64, n=2, bois='spruce'):
    """Banc de parc : marches (dos opposé au regard) + accoudoirs (trappes)."""
    step = _VEC[CW[regard]]
    for i in range(n):
        w.set(x + step[0] * i, y, z + step[1] * i, S(bois + '_stairs', facing=OPP[regard], half='bottom', shape='straight', waterlogged=False))
    a0 = (x - step[0], z - step[1])
    a1 = (x + step[0] * n, z + step[1] * n)
    w.set(a0[0], y, a0[1], S('dark_oak_trapdoor', facing=OPP[CW[regard]], half='bottom', open=True))
    w.set(a1[0], y, a1[1], S('dark_oak_trapdoor', facing=OPP[CCW[regard]], half='bottom', open=True))


def poubelle(w, x, z, y=64):
    w.set(x, y, z, S('cauldron'))


def borne_fontaine(w, x, z, y=64):
    w.set(x, y, z, S('red_nether_brick_wall'))
    w.set(x, y + 1, z, S('mangrove_button', face='floor', facing='north', powered=False))


def boite_postale(w, x, z, regard, y=64):
    """Boîte aux lettres rouge (Postes) sur pied."""
    w.set(x, y, z, S('polished_blackstone_wall'))
    w.set(x, y + 1, z, S('red_shulker_box', facing='up'))
    dx, dz = DIRS[regard]
    w.set(x + dx, y + 1, z + dz, S('oak_wall_sign', facing=regard))
    w.sign(x + dx, y + 1, z + dz, ['', 'POSTES', 'Levée : 16 h', ''], 'white', False)


def parcometre(w, x, z, y=64):
    w.set(x, y, z, S('polished_blackstone_wall'))
    w.set(x, y + 1, z, S('lever', face='floor', facing='north', powered=False))


def panneau_rue(w, x, z, y, noms):
    """Poteau avec plaques de rue (panneaux verts) : noms = [(facing, [lignes])]."""
    for k in range(4):
        w.set(x, y + k, z, S('polished_blackstone_wall'))
    for (fa, lignes) in noms:
        dx, dz = DIRS[fa]
        w.set(x + dx, y + 3, z + dz, S('warped_wall_sign', facing=fa))
        w.sign(x + dx, y + 3, z + dz, lignes, 'white', True)


def feu_circulation(w, x, z, bras_vers, long_bras, regard, y=64):
    """Feu de circulation : poteau noir (7), bras au-dessus de la rue, une tête noire (3 feux = boutons colorés)
    au bout du bras + une petite tête piétonne sur le poteau."""
    for k in range(7):
        w.set(x, y + k, z, S('polished_blackstone_wall'))
    dx, dz = DIRS[bras_vers]
    for i in range(1, long_bras + 1):
        w.set(x + dx * i, y + 6, z + dz * i, S('polished_blackstone_wall'))
    hx, hz = x + dx * long_bras, z + dz * long_bras
    rx, rz = DIRS[regard]
    for k, bouton in enumerate(('warped_button', 'bamboo_button', 'mangrove_button')):   # vert, jaune, rouge
        w.set(hx, y + 3 + k, hz, S('black_concrete'))
        w.set(hx + rx, y + 3 + k, hz + rz, S(bouton, face='wall', facing=regard, powered=False))
    # bouton d'appel piéton
    w.set(x - rx if (x - rx, z - rz) else x, y + 1, z - rz, S('stone_button', face='wall', facing=OPP[regard], powered=False)) if False else None


def abribus(ctx, w, x1, z, longueur=6, regard='south', zone=None, y=64):
    """Abribus vitré le long de x (de x1 à x1+longueur-1), dos au nord (z), ouvert vers `regard`."""
    x2 = x1 + longueur - 1
    # dalle
    for x in range(x1, x2 + 1):
        for zz in (z, z + 1):
            w.set(x, 63, zz, S('polished_andesite'))
    # structure : poteaux aux coins, vitres au dos et aux côtés
    for x in range(x1, x2 + 1):
        for k in range(3):
            w.set(x, y + k, z, S('glass_pane') if 0 < x - x1 < longueur - 1 else S('polished_blackstone_wall'))
    for k in range(3):
        w.set(x1, y + k, z + 1, S('glass_pane'))
        w.set(x2, y + k, z + 1, S('glass_pane'))
    # toit
    for x in range(x1 - 1, x2 + 2):
        for zz in (z, z + 1, z + 2):
            w.set(x, y + 3, zz, S('smooth_stone_slab', type='bottom'))
    for x in range(x1, x2 + 1):
        w.set(x, y + 3, z, S('polished_blackstone_slab', type='bottom'))
    w.set(x1 + 2, y + 3, z + 1, S('pearlescent_froglight', axis='y'))
    ctx.lampe(x1 + 2, y + 3, z + 1, S('pearlescent_froglight', axis='y'), S('light_gray_concrete'), zone)
    w.set(x2 - 2, y + 3, z + 1, S('pearlescent_froglight', axis='y'))
    ctx.lampe(x2 - 2, y + 3, z + 1, S('pearlescent_froglight', axis='y'), S('light_gray_concrete'), zone)
    # banc
    for x in range(x1 + 1, x2):
        w.set(x, y, z + 1, S('spruce_slab', type='bottom'))
    # panneau publicitaire (côté est, face à la rue) + panneau d'arrêt
    w.set(x2 + 1, y + 1, z + 1, S('birch_wall_sign', facing='east'))
    w.sign(x2 + 1, y + 1, z + 1, ['CKZA 98,5', 'Le Réveil', 'avec Léa Marchand', '6 h à 9 h'], 'blue', False)
    w.set(x1 + 1, y + 1, z + 1, S('birch_wall_sign', facing='south'))
    w.sign(x1 + 1, y + 1, z + 1, ['ARRÊT', 'Ligne 1', 'Centre - Hôpital', ''], 'black', False)
    return (x1 + longueur // 2, z + 1)


def chevalet(w, x, z, axe, y=64, sign=None, regard=None):
    """Chevalet rayé 3 blocs le long de `axe` ('x' ou 'z') centré en (x,z)."""
    ax = (1, 0) if axe == 'x' else (0, 1)
    for i in (-1, 0, 1):
        xx, zz = x + ax[0] * i, z + ax[1] * i
        if i != 0:
            w.set(xx, y, zz, S('spruce_fence'))
        w.set(xx, y + 1, zz, S('orange_concrete') if i != 0 else S('white_concrete'))
    if sign and regard:
        dx, dz = DIRS[regard]
        w.set(x + dx, y + 1, z + dz, S('birch_wall_sign', facing=regard))
        w.sign(x + dx, y + 1, z + dz, sign, 'red', False)


def cone(w, x, z, y=64):
    w.set(x, y, z, S('orange_terracotta'))
    w.set(x, y + 1, z, S('white_carpet'))


# =========================================================================== véhicules en blocs
def _repere_vehicule(cx, cz, direction):
    f = DIRS[direction]
    r = DIRS[CW[direction]]

    def p(a, c):
        return (cx + f[0] * a + r[0] * c, cz + f[1] * a + r[1] * c)
    return p


def voiture(w, cx, cz, direction, couleur='red', y=64, kind='auto', portes=False):
    """Voiture 3 de large × 5 de long × 2 de haut (centre (cx,cz), avant vers `direction`).
    kind : 'auto' | 'police' | 'taxi' | 'brulee'. Retourne la liste des blocs de gyrophare."""
    p = _repere_vehicule(cx, cz, direction)
    corps = S(couleur + '_concrete')
    capot = corps
    if kind == 'police':
        corps, capot = S('white_concrete'), S('black_concrete')
    vitre = S('black_stained_glass') if kind != 'brulee' else AIR
    roue = S('black_concrete') if kind != 'brulee' else S('blackstone')
    phare = S('white_concrete') if couleur != 'white' else S('smooth_quartz')
    feu = S('redstone_block')
    if kind == 'brulee':
        corps = capot = S('coal_block')
        phare = feu = S('blackstone')
    gyros = []
    for a in range(-2, 3):
        for c in (-1, 0, 1):
            x, z = p(a, c)
            if a == -2:
                st = feu if c != 0 else capot
            elif a == 2:
                st = phare if c != 0 else capot
            elif a in (-1, 1) and c != 0:
                st = roue
            else:
                st = corps
            w.set(x, y, z, st)
    # habitacle
    for c in (-1, 0, 1):
        x, z = p(-1, c)
        w.set(x, y + 1, z, vitre if c == 0 else corps)
        x, z = p(1, c)
        w.set(x, y + 1, z, vitre)
        x, z = p(0, c)
        w.set(x, y + 1, z, vitre if c != 0 else corps)
    if kind == 'brulee':
        x, z = p(0, 0)
        w.set(x, y + 1, z, S('coal_block'))
        x, z = p(-1, 0)
        w.set(x, y + 1, z, S('blackstone_slab', type='bottom'))
    if kind == 'police':
        for c in (-1, 0, 1):
            x, z = p(0, c)
            st = {-1: S('red_stained_glass'), 0: S('light_gray_concrete'), 1: S('blue_stained_glass')}[c]
            w.set(x, y + 2, z, st)
            if c != 0:
                gyros.append((x, y + 2, z))
    if kind == 'taxi':
        x, z = p(0, 0)
        w.set(x, y + 2, z, S('yellow_carpet'))
    if portes:
        # portières ouvertes : trappes ouvertes perpendiculaires de chaque côté
        for c, side in ((-2, CCW[direction]), (2, CW[direction])):
            x, z = p(1, c)
            w.set(x, y + 1, z, S('iron_trapdoor', facing=direction, half='bottom', open=True))
    return gyros


def ambulance_blocs(w, cx, cz, direction, y=64):
    """Ambulance statique en blocs (3 de large × 7 de long × 3 de haut) : cabine avant basse, caisse blanche
    à bande rouge, gyrophares aux 4 coins de la caisse. Retourne la liste des blocs de gyrophare."""
    p = _repere_vehicule(cx, cz, direction)
    B, R_, N = S('white_concrete'), S('red_concrete'), S('black_concrete')
    gyros = []
    for a in range(-3, 4):
        for c in (-1, 0, 1):
            x, z = p(a, c)
            if a in (-2, 2) and c != 0:
                st = N
            elif a == 3:
                st = S('smooth_quartz') if c != 0 else S('light_gray_concrete')
            elif a == -3:
                st = S('redstone_block') if c != 0 else B
            else:
                st = B
            w.set(x, y, z, st)
            if a == 2:
                w.set(x, y + 1, z, S('black_stained_glass'))
            elif a <= 1:
                w.set(x, y + 1, z, R_ if c != 0 else B)
                w.set(x, y + 2, z, B)
    for (a, c, col) in ((1, -1, 'red'), (1, 1, 'blue'), (-3, -1, 'red'), (-3, 1, 'red')):
        x, z = p(a, c)
        w.set(x, y + 3, z, S(col + '_stained_glass'))
        gyros.append((x, y + 3, z))
    return gyros


def autobus_scolaire_blocs(w, x_avant, z1, y=64, porte_ouverte=True):
    """Autobus scolaire jaune orienté vers l'ouest (avant en x_avant), 12 de long, z1..z1+4 (5 de large).
    Retourne un dict d'infos (porte, intérieur)."""
    J = S('yellow_concrete')
    N = S('black_concrete')
    xa = x_avant
    xr = x_avant + 11
    z2 = z1 + 4
    # capot (2 de long, 3 de large)
    for x in (xa, xa + 1):
        for z in range(z1 + 1, z2):
            w.set(x, y, z, N if x == xa else J)
            w.set(x, y + 1, z, J)
        w.set(x, y, z1, N if x == xa + 1 else AIR)
        w.set(x, y, z2, N if x == xa + 1 else AIR)
    w.set(xa, y + 1, z1 + 1, S('white_concrete'))
    w.set(xa, y + 1, z2 - 1, S('white_concrete'))
    w.set(xa, y + 1, z1 + 2, S('iron_bars'))
    # caisse
    for x in range(xa + 2, xr + 1):
        for z in range(z1, z2 + 1):
            cote = z in (z1, z2)
            bout = x in (xa + 2, xr)
            # plancher / châssis
            if cote:
                roue = x in (xa + 8, xa + 9)
                w.set(x, y, z, N if roue else J)
            else:
                w.set(x, y, z, S('gray_concrete') if not bout else J)
            if cote or bout:
                w.set(x, y + 1, z, J)
                w.set(x, y + 2, z, S('glass_pane') if not (bout and z in (z1, z2)) else J)
            w.set(x, y + 3, z, J if (cote or bout) else S('white_concrete'))
    # bande noire (rail de protection) sous les fenêtres : on garde le jaune à y+1 mais on ajoute les feux
    for z in (z1, z2):
        w.set(xa + 2, y + 3, z, S('orange_concrete'))
        w.set(xr, y + 3, z, S('red_concrete'))
    # pare-brise
    for z in range(z1 + 1, z2):
        w.set(xa + 2, y + 2, z, S('glass_pane'))
    # porte avant (côté droit = nord pour un bus vers l'ouest) ouverte
    xp = xa + 3
    w.set(xp, y, z1, S('polished_andesite_stairs', facing='south', half='bottom'))
    w.set(xp, y + 1, z1, AIR)
    w.set(xp, y + 2, z1, AIR)
    # sièges (regardent vers l'avant/ouest)
    for x in range(xa + 5, xr):
        for z in (z1 + 1, z2 - 1):
            w.set(x, y + 1, z, S('red_nether_brick_stairs', facing='east', half='bottom'))
    # siège du chauffeur + volant
    w.set(xa + 3, y + 1, z2 - 1, S('spruce_stairs', facing='east', half='bottom'))
    # porte arrière d'urgence
    w.set(xr, y + 1, z1 + 2, S('iron_block'))
    w.set(xr, y + 2, z1 + 2, S('glass_pane'))
    # panneau ARRÊT (bras d'arrêt, côté gauche = sud)
    w.set(xa + 3, y + 2, z2 + 1, S('mangrove_wall_sign', facing='south'))
    w.sign(xa + 3, y + 2, z2 + 1, ['', 'ARRÊT', '', ''], 'white', True)
    # inscription ÉCOLIERS à l'avant et à l'arrière
    w.set(xa + 1, y + 2, z1 + 2, S('birch_wall_sign', facing='west'))
    w.sign(xa + 1, y + 2, z1 + 2, ['ÉCOLIERS', '', 'Transport', 'Saint-Aurèle'], 'black', False)
    w.set(xr + 1, y + 2, z1 + 2, S('birch_wall_sign', facing='east'))
    w.sign(xr + 1, y + 2, z1 + 2, ['ÉCOLIERS', 'ARRÊT', 'OBLIGATOIRE', 'aux feux rouges'], 'black', False)
    return {'porte': (xp, y, z1 - 1), 'interieur': (xa + 3, y + 1, z1 + 1, xr - 1, y + 2, z2 - 1)}
