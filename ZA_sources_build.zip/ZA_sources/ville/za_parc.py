# -*- coding: utf-8 -*-
"""Parc des Érables (derrière l'immeuble, x 1..67, z 1..39), stationnement de l'immeuble, mobilier urbain."""
import math

from za_blocs import S, AIR, OPP, CW, CCW, DIRS
from za_meubles import Repere, porte, table, chaise, lettres
import za_rue as RU

SENTIER = S('dirt_path')


def parc(ctx):
    m = ctx.m
    rng = ctx.rng
    w = RU.Ecrivain(ctx)
    Z = 'parc'
    ctx.zones[Z] = (34, 20)
    # ---------------------------------------------------------------- étang (centre 17,13)
    cx, cz, rx, rz = 17, 13, 8.5, 5.5
    eau = set()
    for x in range(cx - 10, cx + 11):
        for z in range(cz - 7, cz + 8):
            d = ((x - cx) / rx) ** 2 + ((z - cz) / rz) ** 2
            if d <= 1.0:
                eau.add((x, z))
                m.set(x, 61, z, S('clay'))
                m.set(x, 62, z, S('water', level=0))
                m.set(x, 63, z, S('water', level=0))
            elif d <= 1.35:
                m.set(x, 63, z, S('mud') if rng.random() < 0.5 else S('coarse_dirt'))
                m.set(x, 62, z, S('dirt'))
    for (x, z) in sorted(eau):
        if rng.random() < 0.08:
            m.set(x, 64, z, S('lily_pad'))
        elif rng.random() < 0.1:
            m.set(x, 62, z, S('seagrass'))
    # roseaux et quenouilles (canne à sucre) sur la berge
    for (x, z) in sorted(eau):
        for (dx, dz) in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            p = (x + dx, z + dz)
            if p not in eau and rng.random() < 0.18 and m.est_air(p[0], 64, p[1]):
                m.set(p[0], 64, p[1], S('sugar_cane', age=0))
                m.set(p[0], 65, p[1], S('sugar_cane', age=0))
    # quai de bois
    for x in range(24, 28):
        for z in (13, 14):
            m.set(x, 63, z, S('spruce_slab', type='top'))
            m.set(x, 64, z, AIR)
    for x in range(24, 28):
        m.set(x, 64, 12, S('spruce_fence')) if x > 24 else None
        m.set(x, 64, 15, S('spruce_fence')) if x > 24 else None
    # ---------------------------------------------------------------- sentiers
    def sentier(x1, z1, x2, z2, larg=3):
        n = max(abs(x2 - x1), abs(z2 - z1))
        for i in range(n + 1):
            x = round(x1 + (x2 - x1) * i / n)
            z = round(z1 + (z2 - z1) * i / n)
            for dx in range(-(larg // 2), larg // 2 + 1):
                for dz in range(-(larg // 2), larg // 2 + 1):
                    if (x + dx, z + dz) not in eau:
                        m.set(x + dx, 63, z + dz, SENTIER)
    sentier(68, 22, 36, 22)          # entrée est (rue des Érables)
    sentier(36, 22, 32, 39)          # vers la porte arrière de l'immeuble
    sentier(36, 22, 46, 12)          # vers le kiosque
    sentier(36, 22, 28, 20)
    # boucle autour de l'étang
    for k in range(0, 360, 4):
        t = math.radians(k)
        x = round(cx + (rx + 3) * math.cos(t))
        z = round(cz + (rz + 3) * math.sin(t))
        for dx in (0, 1):
            for dz in (0, 1):
                if (x + dx, z + dz) not in eau and 1 <= x + dx <= 66 and 1 <= z + dz <= 38:
                    m.set(x + dx, 63, z + dz, SENTIER)
    sentier(46, 12, 60, 4)
    sentier(32, 39, 32, 41, 5)
    # ---------------------------------------------------------------- kiosque (centre 46,12)
    kx, kz = 46, 12
    for x in range(kx - 3, kx + 4):
        for z in range(kz - 3, kz + 4):
            if abs(x - kx) + abs(z - kz) <= 5:
                m.set(x, 63, z, S('stone_bricks'))
                m.set(x, 64, z, S('spruce_slab', type='bottom'))
    for (dx, dz) in ((-3, -1), (-3, 1), (3, -1), (3, 1), (-1, -3), (1, -3), (-1, 3), (1, 3), (-2, -2), (2, -2), (-2, 2), (2, 2)):
        if abs(dx) + abs(dz) in (4,):
            for y in (65, 66, 67):
                m.set(kx + dx, y, kz + dz, S('white_concrete') if False else S('birch_fence'))
    for (dx, dz) in ((-2, -2), (2, -2), (-2, 2), (2, 2)):
        for y in (65, 66, 67):
            m.set(kx + dx, y, kz + dz, S('birch_fence'))
    for r, y in ((4, 68), (3, 69), (2, 70), (1, 71)):
        for x in range(kx - r, kx + r + 1):
            for z in range(kz - r, kz + r + 1):
                if abs(x - kx) + abs(z - kz) <= r + 1 and (abs(x - kx) == r or abs(z - kz) == r or abs(x - kx) + abs(z - kz) == r + 1):
                    m.set(x, y, z, S('dark_oak_slab', type='bottom') if abs(x - kx) + abs(z - kz) == r + 1 else S('dark_oak_planks'))
    m.set(kx, 72, kz, S('lightning_rod', facing='up', powered=False))
    ctx.lampe(kx, 67, kz, S('ochre_froglight', axis='y'), S('gray_stained_glass'), Z)
    m.set(kx, 68, kz, S('chain', axis='y'))
    for y in range(68, 72):
        m.set(kx, y, kz, S('dark_oak_planks')) if y > 68 else None
    ctx.poi('parc_kiosque', kx, 65, kz, 0, centre=True)
    # ---------------------------------------------------------------- aire de jeux (x 50..64, z 26..37)
    for x in range(50, 65):
        for z in range(26, 38):
            m.set(x, 63, z, S('orange_terracotta') if (x + z) % 7 else S('red_terracotta'))
    for x in range(49, 66):
        m.set(x, 64, 25, S('spruce_fence')) if x not in (56, 57) else None
        m.set(x, 64, 38, S('spruce_fence'))
    for z in range(25, 39):
        m.set(49, 64, z, S('spruce_fence'))
        m.set(65, 64, z, S('spruce_fence'))
    # balançoires
    for x in (52, 58):
        for y in range(64, 68):
            m.set(x, y, 28, S('dark_oak_fence'))
    for x in range(52, 59):
        m.set(x, 68, 28, S('dark_oak_slab', type='bottom'))
    for x in (54, 56):
        m.set(x, 67, 28, S('chain', axis='y'))
        m.set(x, 66, 28, S('chain', axis='y'))
        m.set(x, 65, 28, S('spruce_trapdoor', facing='north', half='top', open=False))
    # glissoire
    for k in range(3):
        m.set(61, 64 + k, 30 + k, S('ladder', facing='south', waterlogged=False)) if False else None
    m.fill(60, 64, 33, 62, 66, 33, S('yellow_concrete'))
    m.fill(60, 67, 33, 62, 67, 33, S('red_concrete'))
    for k in range(4):
        m.set(61, 66 - k, 34 + k, S('quartz_slab', type='bottom') if k else S('quartz_slab', type='top'))
    for k in range(3):
        m.set(61, 64 + k, 32, S('ladder', facing='north', waterlogged=False))
    m.fill(60, 64, 32, 60, 66, 32, S('red_concrete'))
    m.fill(62, 64, 32, 62, 66, 32, S('red_concrete'))
    # carré de sable (grès lisse, sans gravité)
    for x in range(51, 55):
        for z in range(32, 36):
            m.set(x, 63, z, S('smooth_sandstone'))
            if x in (51, 54) or z in (32, 35):
                m.set(x, 64, z, S('spruce_slab', type='bottom'))
    RU.banc(w, 57, 36, 'north', n=2)
    ctx.poi('parc_jeux', 57, 64, 31, 0)
    # ---------------------------------------------------------------- arbres, fleurs, bancs, lampadaires
    RU.gros_chene(m, 6, 64, 30, rng)
    RU.gros_chene(m, 58, 64, 14, rng)
    arbres = [(4, 4, 'b'), (30, 4, 'e'), (40, 30, 'e'), (26, 32, 'r'), (12, 26, 'b'), (64, 20, 'e'), (62, 6, 'r'),
              (34, 12, 'r'), (4, 18, 'e'), (46, 30, 'b'), (22, 30, 'e'), (14, 36, 'b'), (40, 4, 'b'), (52, 20, 'e'),
              (2, 38, 'e'), (66, 36, 'b'), (30, 28, 'b')]
    for (x, z, t) in arbres:
        if t == 'b':
            RU.bouleau(m, x, 64, z, rng)
        elif t == 'r':
            # érable rouge d'automne (feuilles + blocs de verrue rouge)
            RU.feuillu(m, x, 64, z, rng, h=5, tronc='dark_oak_log', feuilles='oak_leaves', r=3,
                       extra=(S('nether_wart_block'), 0.45))
        else:
            RU.feuillu(m, x, 64, z, rng, h=rng.randint(5, 6), tronc='oak_log', feuilles='oak_leaves', r=3)
    fleurs = ['poppy', 'dandelion', 'azure_bluet', 'oxeye_daisy', 'cornflower', 'allium', 'red_tulip', 'orange_tulip',
              'pink_tulip', 'lily_of_the_valley']
    for (fx, fz) in ((40, 18), (60, 24), (10, 22), (28, 36)):
        for dx in range(-2, 3):
            for dz in range(-1, 2):
                if m.est_air(fx + dx, 64, fz + dz) and m.get(fx + dx, 63, fz + dz) == RU.GAZON:
                    m.set(fx + dx, 63, fz + dz, S('rooted_dirt'))
                    m.set(fx + dx, 64, fz + dz, S(rng.choice(fleurs)))
    for _ in range(500):
        x, z = rng.randint(1, 66), rng.randint(1, 38)
        if m.get(x, 63, z) == RU.GAZON and m.est_air(x, 64, z):
            r = rng.random()
            if r < 0.6:
                m.set(x, 64, z, S('grass'))
            elif r < 0.85:
                m.set(x, 64, z, S(rng.choice(fleurs)))
            elif m.est_air(x, 65, z):
                m.set(x, 64, z, S('tall_grass', half='lower'))
                m.set(x, 65, z, S('tall_grass', half='upper'))
    bancs = [(22, 21, 'north'), (12, 21, 'north'), (30, 8, 'west'), (44, 20, 'south'), (40, 26, 'east')]
    for (x, z, r) in bancs:
        for dx in range(-1, 3):
            for dz in range(-1, 2):
                pass
        if m.get(x, 63, z) != SENTIER:
            m.set(x, 63, z, S('stone_bricks'))
        RU.banc(w, x, z, r, n=2)
    ctx.poi('parc_banc', 22, 64, 21, 180)
    RU.poubelle(w, 21, 21)
    RU.poubelle(w, 43, 20)
    for (x, z) in ((64, 24), (40, 23), (30, 17), (8, 16), (26, 6), (33, 34), (52, 10)):
        RU.lampadaire_parc(w, x, z, Z)
    # panneau d'entrée
    for y in (64, 65):
        m.set(66, y, 19, S('dark_oak_log', axis='y'))
        m.set(66, y, 25, S('dark_oak_log', axis='y'))
    for z in range(19, 26):
        m.set(66, 66, z, S('dark_oak_planks'))
    m.set(67, 66, 22, S('dark_oak_wall_sign', facing='east'))
    m.sign(67, 66, 22, ['PARC', 'DES ÉRABLES', 'Ville de', 'Saint-Aurèle'], 'white', True)
    # clôture nord (limite de la ville)
    for x in range(-1, 68):
        m.set(x, 64, 0, S('spruce_fence')) if x % 1 == 0 else None
    for z in range(0, 40):
        m.set(-1, 64, z, S('spruce_fence'))


def stationnement_immeuble(ctx):
    m = ctx.m
    w = RU.Ecrivain(ctx)
    for x in range(1, 14):
        for z in range(42, 69):
            m.set(x, 63, z, RU.ASPHALTE)
    for z in range(42, 67, 4):
        for x in list(range(1, 6)) + list(range(10, 14)):
            m.set(x, 63, z, RU.BLANC)
    RU.voiture(w, 3, 44, 'west', 'black')
    RU.voiture(w, 11, 48, 'east', 'green')
    RU.voiture(w, 3, 56, 'west', 'yellow', kind='taxi')
    m.set(0, 64, 42, S('spruce_fence'))
    for z in range(42, 69):
        m.set(0, 64, z, S('spruce_leaves', persistent=True, distance=1, waterlogged=False))
    for z in range(41, 67):
        m.set(14, 64, z, S('spruce_leaves', persistent=True, distance=1, waterlogged=False)) if z % 5 else None
    m.set(13, 64, 66, S('birch_wall_sign', facing='south')) if False else None
    m.set(1, 64, 67, S('oak_sign', rotation=8, waterlogged=False))
    m.sign(1, 64, 67, ['STATIONNEMENT', 'Locataires', 'seulement', ''], 'black')


# =========================================================================== mobilier urbain
def mobilier(ctx):
    m = ctx.m
    rng = ctx.rng
    w = RU.Ecrivain(ctx)
    occupe = set()

    def libre(x, z):
        return (x, z) not in occupe and m.est_air(x, 64, z)

    # zones à éviter (entrées charretières, abribus, passages)
    evite_n = set(range(1, 16)) | set(range(94, 102)) | set(range(130, 138)) | set(range(122, 131)) | set(range(62, 90))
    evite_s = set(range(10, 20)) | set(range(118, 128)) | set(range(142, 152)) | set(range(62, 90)) | set(range(84, 113))
    evite_o = set(range(62, 90))
    evite_e = set(range(36, 50)) | set(range(62, 90))
    # lampadaires tous les 12 blocs, décalés de 6 d'un côté à l'autre ; arbres entre les deux
    for x in range(4, 158, 12):
        if x not in evite_n:
            RU.lampadaire(w, x, 71, 'south', 'rue_n_%d' % (x // 40))
            occupe.add((x, 71))
        xt = x + 6
        if xt not in evite_n and xt < 158 and libre(xt, 71):
            RU.arbre_rue(w, xt, 71, rng)
            occupe.add((xt, 71))
    for x in range(10, 158, 12):
        if x not in evite_s:
            RU.lampadaire(w, x, 81, 'north', 'rue_s_%d' % (x // 40))
            occupe.add((x, 81))
        xt = x + 6
        if xt not in evite_s and xt < 158 and libre(xt, 81):
            RU.arbre_rue(w, xt, 81, rng)
            occupe.add((xt, 81))
    for z in range(4, 158, 12):
        if z not in evite_o:
            RU.lampadaire(w, 71, z, 'east', 'rue_o_%d' % (z // 40))
            occupe.add((71, z))
        zt = z + 6
        if zt not in evite_o and zt < 158 and libre(71, zt):
            RU.arbre_rue(w, 71, zt, rng)
            occupe.add((71, zt))
    for z in range(10, 158, 12):
        if z not in evite_e:
            RU.lampadaire(w, 81, z, 'west', 'rue_e_%d' % (z // 40))
            occupe.add((81, z))
        zt = z + 6
        if zt not in evite_e and zt < 158 and libre(81, zt):
            RU.arbre_rue(w, 81, zt, rng)
            occupe.add((81, zt))
    # lampadaires hors-ville (route dans la forêt), côté nord / ouest seulement
    for x in list(range(-60, -8, 16)) + list(range(172, 222, 16)):
        RU.lampadaire(w, x, 71, 'south', 'route_o' if x < 0 else 'route_e')
    for z in list(range(-60, -8, 16)) + list(range(172, 222, 16)):
        RU.lampadaire(w, 71, z, 'east', 'route_n' if z < 0 else 'route_s')
    # feux de circulation aux 4 coins
    RU.feu_circulation(w, 71, 71, 'east', 3, 'north')
    RU.feu_circulation(w, 81, 71, 'south', 3, 'east')
    RU.feu_circulation(w, 81, 81, 'west', 3, 'south')
    RU.feu_circulation(w, 71, 81, 'north', 3, 'west')
    # plaques de rue
    RU.panneau_rue(w, 69, 69, 64, [('south', ['Rue', 'Principale', '', '']), ('east', ['Rue des', 'Érables', '', ''])])
    RU.panneau_rue(w, 83, 83, 64, [('north', ['Rue', 'Principale', '', '']), ('west', ['Rue des', 'Érables', '', ''])])
    # abribus sur la rue Principale (trottoir nord, devant l'hôpital)
    ab = RU.abribus(ctx, w, 124, 69, 6, 'south', 'hopital_parc')
    ctx.poi('abribus', 126, 64, 70, 0)
    # bancs, poubelles, bornes-fontaines, boîtes postales
    for (x, z, r) in ((24, 69, 'south'), (52, 83, 'north'), (40, 83, 'north'), (106, 69, 'south'), (69, 30, 'east'),
                      (83, 118, 'west'), (69, 110, 'east'), (146, 69, 'south')):
        if m.est_air(x, 64, z):
            RU.banc(w, x, z, r, n=2)
            dx, dz = DIRS[CW[r]]
            if m.est_air(x + dx * 3, 64, z + dz * 3):
                RU.poubelle(w, x + dx * 3, z + dz * 3)
    for (x, z) in ((10, 71), (60, 81), (90, 71), (140, 81), (71, 40), (81, 100), (71, 140), (81, 26)):
        if m.est_air(x, 64, z):
            RU.borne_fontaine(w, x, z)
    RU.boite_postale(w, 38, 69, 'south')
    RU.boite_postale(w, 66, 83, 'north')
    for (x, z) in ((28, 70), (50, 82), (126, 70), (71, 55)):
        pass
    # plaques d'égout
    for (x, z) in ((30, 74), (58, 78), (100, 78), (140, 74), (74, 30), (78, 120), (74, 140), (78, 50)):
        m.set(x, 64, z, S('heavy_weighted_pressure_plate', power=0))
    # voitures stationnées le long des rues (côtés libres de la route d'ambulance)
    for (cx, cz, d, c) in ((20, 73, 'west', 'blue'), (44, 73, 'west', 'white'), (30, 79, 'east', 'red'),
                           (56, 79, 'east', 'gray'), (100, 79, 'east', 'black'), (138, 79, 'east', 'light_blue'),
                           (73, 30, 'south', 'orange'), (73, 50, 'south', 'white'), (73, 112, 'south', 'green'),
                           (73, 134, 'south', 'brown'), (79, 146, 'north', 'red')):
        RU.voiture(w, cx, cz, d, c)
