#!/usr/bin/env python3
# Extrait des jars de mods (dossier donné) la liste des blocs et de leurs propriétés connues (blockstates/*.json)
# -> blocs_mods.json.gz, utilisé par za_blocs.S() pour valider les blocs moddés (propriétés partielles acceptées :
#    Bukkit complète les propriétés absentes avec l'état par défaut du bloc).
# Usage : python3 extraire_blocs_mods.py <dossier des jars>
import collections, glob, gzip, json, os, re, sys, zipfile
GARDER = ('mcwbridges', 'mcwlights', 'mcwfences', 'mcwfurnitures', 'mcwwindows', 'mcwdoors', 'mcwstairs', 'mcwroofs',
          'createdeco', 'mcwpaths', 'mcwtrpdoors', 'handcrafted', 'supplementaries')
reg = {}
for j in sorted(glob.glob(os.path.join(sys.argv[1], '*.jar'))):
    z = zipfile.ZipFile(j)
    for n in z.namelist():
        m = re.match(r'assets/([^/]+)/blockstates/([^/]+)\.json$', n)
        if not m or m.group(1) not in GARDER:
            continue
        try:
            d = json.loads(z.read(n))
        except ValueError:
            continue
        props = collections.defaultdict(set)
        if 'variants' in d:
            for k in d['variants']:
                for kv in (k.split(',') if k else []):
                    if '=' in kv:
                        a, v = kv.split('=')
                        props[a].add(v)
        else:
            for part in d.get('multipart', []):
                w = part.get('when', {})
                for c in (w.get('OR', [w]) if isinstance(w, dict) else []):
                    for a, v in c.items():
                        for vv in str(v).split('|'):
                            props[a].add(vv)
        reg['%s:%s' % m.groups()] = {'p': {k: sorted(v) for k, v in props.items()}, 'multi': 'multipart' in d}
with gzip.GzipFile(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'blocs_mods.json.gz'), 'wb', mtime=0) as f:
    f.write(json.dumps(reg, sort_keys=True, separators=(',', ':')).encode())
print(len(reg), 'blocs moddés')
