# -*- coding: utf-8 -*-
"""za_moderne : habillage de la ville avec les mods décoratifs (Macaw's, Create Deco), appliqué juste avant l'export.
Les meubles d'intérieur sont posés directement par za_meubles (Handcrafted, Macaw's Furniture, Macaw's Doors).
Ici : toits (Macaw's Roofs), clôtures à piquets (Macaw's Fences), grilles industrielles (Create Deco),
allées du parc en dalles (Macaw's Paths). Désactivé avec ZA_VANILLE=1.
"""
import collections
from za_blocs import S, parse, MODERNE

TOITS = {'minecraft:spruce_stairs': 'mcwroofs:spruce_roof', 'minecraft:dark_oak_stairs': 'mcwroofs:dark_oak_roof',
         'minecraft:stone_brick_stairs': 'mcwroofs:stone_bricks_roof',
         'minecraft:red_nether_brick_stairs': 'mcwroofs:red_nether_bricks_roof'}
PIQUETS = {'minecraft:spruce_fence': 'mcwfences:spruce_picket_fence', 'minecraft:birch_fence': 'mcwfences:birch_picket_fence',
           'minecraft:dark_oak_fence': 'mcwfences:dark_oak_picket_fence'}
COTES = ('north', 'east', 'south', 'west')


def habiller(ctx):
    if not MODERNE:
        return {}
    m = ctx.m
    n = collections.Counter()
    for i, st in list(enumerate(m.pal)):
        nom, p = parse(st)
        if nom in TOITS:
            neuf = S(TOITS[nom], facing=p['facing'], half=p['half'], shape=p['shape'])
            for (x, y, z) in m.positions({i}):
                # seulement les toitures : en hauteur et à l'air libre (les marches d'entrée restent en pierre)
                if y >= 68 and m.est_air(x, y + 1, z):
                    m.set(x, y, z, neuf)
                    n['toits'] += 1
        elif nom in PIQUETS:
            neuf = S(PIQUETS[nom], **{k: 'true' for k in COTES if p.get(k) == 'true'})
            for (x, y, z) in m.positions({i}):
                m.set(x, y, z, neuf)
                n['piquets'] += 1
        elif nom == 'minecraft:iron_bars':
            neuf = S('createdeco:industrial_iron_bars', **{k: p.get(k, 'false') for k in COTES})
            for (x, y, z) in m.positions({i}):
                m.set(x, y, z, neuf)
                n['grilles'] += 1
        elif nom == 'minecraft:dirt_path':
            for (x, y, z) in m.positions({i}):
                if m.est_air(x, y + 1, z):
                    m.set(x, y, z, S('mcwpaths:andesite_flagstone_path'))
                    n['allees'] += 1
    return dict(n)
