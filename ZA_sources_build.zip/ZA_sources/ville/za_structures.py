# -*- coding: utf-8 -*-
"""Structures du monde principal : arrivée du JOUR 8 (autobus renversé), Hall des survivants, Marché de la Trêve.
Coordonnées relatives à la base de pose (0,0,0) = centre au niveau du sol de marche ; socle de sol à y=-1."""
import math

from za_blocs import Monde, S, AIR, OPP, CW, CCW, DIRS
from za_meubles import Ctx, Repere, porte, lit, chaise, table, tapis, lettres
import za_rue as RU

POI = {}


def _poi(d, nom, x, y, z, yaw=0.0, pitch=0.0):
    d[nom] = {'x': x + 0.5, 'y': y, 'z': z + 0.5, 'yaw': float(yaw), 'pitch': float(pitch)}


# =========================================================================== ARRIVÉE (JOUR 8)
def arrivee(graine=8):
    m = Monde(-24, -1, -24, 48, 14, 48)
    ctx = Ctx(m, graine)
    rng = ctx.rng
    P = {}
    # ---------------------------------------------------------------- socle : rue en ruine
    for x in range(-24, 24):
        for z in range(-24, 24):
            if -6 <= z <= 6:
                r = rng.random()
                st = S('gray_concrete') if r < 0.62 else S('andesite') if r < 0.78 else S('cobblestone') if r < 0.86 \
                    else S('coarse_dirt') if r < 0.93 else S('moss_block')
                if z == 0 and (x // 3) % 2 == 0 and rng.random() < 0.7:
                    st = S('yellow_terracotta')
            elif -9 <= z <= -7 or 7 <= z <= 9:
                r = rng.random()
                st = S('smooth_stone') if r < 0.55 else S('cracked_stone_bricks') if r < 0.72 else S('mossy_cobblestone') if r < 0.84 else S('coarse_dirt')
                if z in (-7, 7) and r < 0.8:
                    st = S('polished_andesite') if r < 0.6 else S('cobblestone')
            else:
                r = rng.random()
                st = S('grass_block', snowy=False) if r < 0.45 else S('coarse_dirt') if r < 0.7 else S('podzol', snowy=False) if r < 0.82 else S('rooted_dirt') if r < 0.92 else S('moss_block')
            m.set(x, -1, z, st)
    # herbes folles qui percent l'asphalte
    for _ in range(260):
        x, z = rng.randint(-23, 23), rng.randint(-23, 23)
        if m.est_air(x, 0, z):
            m.set(x, 0, z, S(rng.choice(['grass', 'grass', 'fern', 'dead_bush', 'grass'])))
    # ---------------------------------------------------------------- autobus scolaire renversé sur le flanc
    # couché sur son flanc gauche (sud) : y 0..4 = largeur, z -2..1 = hauteur (z=-2 dessous/roues au nord, z=1 toit au sud)
    J, N = S('yellow_concrete'), S('black_concrete')
    bx0, bx1 = -9, 2
    for x in range(bx0, bx1 + 1):
        for y in range(0, 5):
            for z in range(-2, 2):
                bord = y in (0, 4) or z in (-2, 1) or x in (bx0, bx1)
                if not bord:
                    continue
                if z == -2:
                    st = N                                           # châssis
                elif z == 1:
                    st = J if y in (0, 4) or x in (bx0, bx1) else S('white_concrete')   # toit
                elif z == 0 and y in (0, 4) and x not in (bx0, bx1):
                    # bande de fenêtres : vitres brisées (trous) ou vitre noire restante
                    r = rng.random()
                    st = AIR if r < 0.55 else S('black_stained_glass_pane') if r < 0.8 else J
                else:
                    st = J
                m.set(x, y, z, st)
    # rail noir sous les fenêtres (un seul, le flanc reste jaune)
    for x in range(bx0 + 1, bx1):
        if rng.random() < 0.8:
            m.set(x, 4, -2, S('yellow_terracotta'))
    # roues (sortent au nord)
    for x in (bx0 + 2, bx0 + 3, bx1 - 3, bx1 - 2):
        for y in (0, 4):
            m.set(x, y, -3, S('coal_block'))
    m.set(bx0 + 3, 4, -3, AIR)
    # capot avant (x bx1+1..bx1+2), plus bas
    for x in (bx1 + 1, bx1 + 2):
        for y in (1, 2, 3):
            m.set(x, y, -2, N if x == bx1 + 2 else J)
            m.set(x, y, -1, J)
    m.set(bx1 + 2, 1, -1, S('white_concrete'))
    m.set(bx1 + 2, 3, -1, AIR)
    # pare-brise brisé, porte (côté droit = en haut) arrachée
    for y in (1, 2, 3):
        m.set(bx1, y, 0, AIR)
    m.set(bx1 - 1, 4, 0, AIR)
    m.set(bx1 - 1, 4, -1, AIR)
    # intérieur : sièges renversés, débris
    for x in range(bx0 + 1, bx1):
        for y in (1, 3):
            if rng.random() < 0.6:
                m.set(x, y, -1, S('red_nether_brick_stairs', facing=rng.choice(['north', 'up'] and ['north', 'south']), half='top'))
    m.set(bx0 + 3, 1, 0, S('brown_carpet'))
    # « ÉCOLIERS » / « ARRÊT » encore lisibles
    m.set(bx1 + 3, 2, -1, S('birch_wall_sign', facing='east'))
    m.sign(bx1 + 3, 2, -1, ['ÉCOLIERS', '', 'Transport', 'Saint-Aurèle'], 'black')
    m.set(bx0 - 1, 2, -1, S('birch_wall_sign', facing='west'))
    m.sign(bx0 - 1, 2, -1, ['ÉVACUATION', 'SAINT-AURÈLE', 'Convoi B-3', ''], 'red')
    # traînée de glissade et éclats de verre
    for x in range(bx1 + 3, bx1 + 12):
        if m.est_air(x, 0, -1):
            m.set(x, 0, -1, S('black_carpet') if rng.random() < 0.5 else S('gray_carpet'))
    for _ in range(40):
        x, z = rng.randint(bx0 - 3, bx1 + 4), rng.randint(1, 6)
        if m.est_air(x, 0, z):
            m.set(x, 0, z, S('light_gray_carpet') if rng.random() < 0.5 else S('white_stained_glass_pane'))
    _poi(P, 'bus', (bx0 + bx1) // 2, 0, 3, 180)
    # ---------------------------------------------------------------- réveil du joueur (à côté de l'autobus)
    _poi(P, 'reveil', bx1 - 1, 0, 3, 45)
    # ---------------------------------------------------------------- bagages éparpillés
    valises = ['brown_shulker_box', 'black_shulker_box', 'blue_shulker_box', 'red_shulker_box', 'gray_shulker_box']
    for _ in range(16):
        x, z = rng.randint(-14, 12), rng.randint(-8, 9)
        if m.est_air(x, 0, z):
            r = rng.random()
            if r < 0.45:
                m.set(x, 0, z, S(rng.choice(valises), facing=rng.choice(['north', 'east', 'up', 'south'])))
            elif r < 0.7:
                m.set(x, 0, z, S('barrel', facing=rng.choice(['east', 'north']), open=True))
            else:
                m.set(x, 0, z, S(rng.choice(['white_carpet', 'blue_carpet', 'red_carpet', 'yellow_carpet'])))
    # ---------------------------------------------------------------- checkpoint militaire abandonné (sud-est)
    for k in range(-5, 6):
        x, z = 13 + k, 12 + int(round(abs(k) * 0.6))
        if rng.random() < 0.85:
            m.set(x, 0, z, S('smooth_sandstone'))
            if rng.random() < 0.7:
                m.set(x, 1, z, S('sandstone_slab', type='bottom'))
    # tente déchirée (x 10..16, z 15..19)
    for x in range(10, 17):
        for z in (15, 19):
            if rng.random() < 0.75:
                m.set(x, 0, z, S('green_wool'))
            if rng.random() < 0.5:
                m.set(x, 1, z, S('green_wool'))
        for z in (16, 17, 18):
            if rng.random() < 0.55:
                m.set(x, 2, z, S('green_wool'))
            elif rng.random() < 0.6:
                m.set(x, 0, z, S('green_carpet'))
    for (x, z) in ((10, 15), (16, 15), (10, 19), (16, 19)):
        m.set(x, 0, z, S('spruce_fence'))
        m.set(x, 1, z, S('spruce_fence'))
    # caisses, barrières renversées, projecteur éteint
    for (x, z) in ((18, 10), (19, 10), (18, 11), (19, 13), (20, 12)):
        m.set(x, 0, z, S('spruce_planks') if (x + z) % 2 else S('barrel', facing='up', open=False))
    m.set(18, 1, 10, S('green_shulker_box', facing='up'))
    for x in range(6, 10):
        m.set(x, 0, 11, S('iron_bars'))
    for y in range(0, 3):
        m.set(21, y, 16, S('iron_bars'))
    m.set(21, 3, 16, S('redstone_lamp', lit=False))
    m.set(12, 0, 13, S('yellow_stained_glass_pane'))
    m.set(13, 0, 13, S('yellow_stained_glass_pane'))
    # ---------------------------------------------------------------- voiture brûlée
    RU.voiture(m, -16, 3, 'north', kind='brulee', y=0)
    for (x, z) in ((-18, 1), (-14, 6), (-17, 6), (-15, 0)):
        if m.est_air(x, 0, z):
            m.set(x, 0, z, S('black_carpet') if rng.random() < 0.5 else S('blackstone_slab', type='bottom'))
    # ---------------------------------------------------------------- feu de camp éteint + bûches
    fx, fz = 4, 15
    m.set(fx, 0, fz, S('campfire', facing='north', lit=False, signal_fire=False, waterlogged=False))
    m.set(fx - 2, 0, fz, S('spruce_log', axis='z'))
    m.set(fx + 2, 0, fz, S('spruce_log', axis='z'))
    m.set(fx, 0, fz + 2, S('spruce_log', axis='x'))
    for (x, z) in ((fx - 1, fz - 1), (fx + 1, fz + 1), (fx + 1, fz - 1)):
        m.set(x, -1, z, S('coarse_dirt'))
    _poi(P, 'feu', fx, 0, fz, 180)
    # ---------------------------------------------------------------- coffre de départ
    cx, cz = fx - 3, fz - 2
    m.set(cx, 0, cz, S('chest', facing='south', type='single', waterlogged=False))
    m.container(cx, 0, cz, [
        {'slot': 0, 'id': 'minecraft:bread', 'n': 2, 'name': 'Pain rassis'},
        {'slot': 1, 'id': 'minecraft:apple', 'n': 1, 'name': 'Pomme talée'},
        {'slot': 2, 'id': 'minecraft:torch', 'n': 3},
        {'slot': 3, 'id': 'minecraft:paper', 'n': 1, 'name': 'Carte de la région (déchirée)'},
    ])
    _poi(P, 'coffre_depart', cx, 0, cz + 1, 180)
    # ---------------------------------------------------------------- ruines autour (murs éventrés, lampadaire tombé)
    for (x1, z1, x2, z2) in ((-23, -23, -8, -14), (6, -23, 22, -15), (-23, 13, -12, 22)):
        for x in range(x1, x2 + 1):
            for z in range(z1, z2 + 1):
                bord = x in (x1, x2) or z in (z1, z2)
                if bord:
                    h = rng.randint(0, 5) if rng.random() < 0.85 else 0
                    for y in range(0, h):
                        m.set(x, y, z, S('bricks') if rng.random() < 0.8 else S('cracked_stone_bricks'))
                    if h and rng.random() < 0.3:
                        m.set(x, h, z, S('brick_slab', type='bottom'))
                elif rng.random() < 0.12:
                    m.set(x, 0, z, S(rng.choice(['cobblestone', 'bricks', 'andesite_slab', 'cobweb', 'brick_stairs'])) if True else AIR)
    # lampadaire couché au travers du trottoir
    for x in range(-4, 2):
        m.set(x, 0, 8, S('andesite_wall'))
    m.set(2, 0, 8, S('gray_stained_glass'))
    # débris et toiles d'araignée
    for _ in range(90):
        x, z = rng.randint(-23, 23), rng.randint(-23, 23)
        if m.est_air(x, 0, z):
            m.set(x, 0, z, S(rng.choice(['cobblestone_slab', 'andesite_slab', 'stone_brick_slab'])) if False else
                  S(rng.choice(['cobblestone_slab', 'andesite_slab', 'stone_brick_slab']), type='bottom', waterlogged=False)
                  if rng.random() < 0.6 else S(rng.choice(['cobweb', 'dead_bush', 'white_carpet', 'brown_carpet'])))
    # quelques arbres morts / sans feuilles
    for (x, z) in ((-20, -5), (20, -10), (-6, 20)):
        for y in range(0, 5):
            m.set(x, y, z, S('oak_log', axis='y'))
        m.set(x + 1, 4, z, S('oak_log', axis='x'))
        m.set(x - 1, 3, z, S('oak_log', axis='x'))
    m.passe_connexions()
    m.passe_escaliers()
    return m, P


# =========================================================================== HALL DES SURVIVANTS
def hall(graine=9):
    """~32×24 ; entrée au sud (z=+11), base = centre du seuil au niveau du sol."""
    m = Monde(-16, -1, -12, 32, 16, 24)
    ctx = Ctx(m, graine)
    rng = ctx.rng
    P = {}
    for x in range(-16, 16):
        for z in range(-12, 12):
            m.set(x, -1, z, S('stone_bricks'))
    # plancher et murs
    x1, x2, z1, z2 = -13, 13, -10, 7
    for x in range(x1, x2 + 1):
        for z in range(z1, z2 + 1):
            m.set(x, 0, z, S('polished_andesite') if (x + z) % 2 else S('polished_diorite'))
    for x in range(x1, x2 + 1):
        m.set(x, 0, z1, S('polished_deepslate'))
        m.set(x, 0, z2, S('polished_deepslate'))
    for y in range(1, 9):
        for x in range(x1, x2 + 1):
            for z in (z1, z2):
                m.set(x, y, z, S('stone_bricks'))
        for z in range(z1, z2 + 1):
            for x in (x1, x2):
                m.set(x, y, z, S('stone_bricks'))
    # chaînages et pilastres
    for y in range(1, 9):
        for (x, z) in ((x1, z1), (x2, z1), (x1, z2), (x2, z2)):
            m.set(x, y, z, S('chiseled_stone_bricks') if y % 3 == 0 else S('polished_andesite'))
    # hautes fenêtres latérales
    for z in range(z1 + 2, z2 - 1, 4):
        for y in range(2, 7):
            for x in (x1, x2):
                m.set(x, y, z, S('glass_pane'))
                m.set(x, y, z + 1, S('glass_pane'))
        for x in (x1, x2):
            m.set(x, 7, z, S('stone_brick_stairs', facing='south', half='top'))
            m.set(x, 7, z + 1, S('stone_brick_stairs', facing='north', half='top'))
    # plafond et toit à deux versants (faîte nord-sud)
    for x in range(x1, x2 + 1):
        for z in range(z1, z2 + 1):
            m.set(x, 9, z, S('dark_oak_planks'))
    for k in range(0, 7):
        for z in range(z1 - 1, z2 + 2):
            m.set(x1 - 1 + k, 10 + k // 2, z, S('deepslate_tile_stairs', facing='east', half='bottom')) if k % 2 == 0 else \
                m.set(x1 - 1 + k, 10 + k // 2, z, S('deepslate_tile_slab', type='top'))
            m.set(x2 + 1 - k, 10 + k // 2, z, S('deepslate_tile_stairs', facing='west', half='bottom')) if k % 2 == 0 else \
                m.set(x2 + 1 - k, 10 + k // 2, z, S('deepslate_tile_slab', type='top'))
    for x in range(x1 + 6, x2 - 5):
        for z in range(z1 - 1, z2 + 2):
            m.set(x, 13, z, S('deepslate_tile_slab', type='bottom'))
    for x in range(x1 + 6, x2 - 5):
        for z in range(z1 - 1, z2 + 2):
            if m.est_air(x, 12, z):
                m.set(x, 12, z, S('deepslate_tiles'))
    # fronton sud et portique à 4 colonnes
    for x in range(x1, x2 + 1):
        for y in range(10, 13):
            if abs(x) <= (13 - (y - 10) * 4):
                m.set(x, y, z2, S('stone_bricks'))
                m.set(x, y, z1, S('stone_bricks'))
    for (xa, ya) in ((0, 12), (-1, 12), (1, 12)):
        m.set(xa, ya, z2 + 1, S('chiseled_stone_bricks'))
    for x in range(x1 + 1, x2):
        for z in (z2 + 1, z2 + 2, z2 + 3):
            m.set(x, 0, z, S('polished_andesite'))
    for x in range(x1 + 1, x2):
        m.set(x, 0, z2 + 4, S('stone_brick_stairs', facing='north', half='bottom'))
    for x in (-9, -4, 4, 9):
        for y in range(1, 8):
            m.set(x, y, z2 + 2, S('quartz_pillar', axis='y'))
        m.set(x, 8, z2 + 2, S('chiseled_quartz_block'))
    for x in range(x1, x2 + 1):
        m.set(x, 9, z2 + 1, S('stone_brick_slab', type='top'))
        m.set(x, 9, z2 + 2, S('stone_brick_slab', type='top'))
        m.set(x, 9, z2 + 3, S('stone_brick_stairs', facing='north', half='top'))
    # porte d'entrée (double, chêne noir) et inscription
    for x in (-1, 0):
        for y in (1, 2, 3):
            m.set(x, y, z2, AIR)
    R = Repere(ctx, 0, 0)
    from za_meubles import porte_double
    porte_double(R, -1, 1, z2, 'north', 'dark_oak')
    m.set(-1, 3, z2, S('glass_pane'))
    m.set(0, 3, z2, S('glass_pane'))
    for x, txt in ((-1, ['HALL DES', 'SURVIVANTS', '', '']), (1, ['Ils ont tenu.', 'Nous nous', 'souvenons.', ''])):
        m.set(x, 5, z2 + 1, S('dark_oak_wall_sign', facing='south'))
        m.sign(x, 5, z2 + 1, txt, 'gold' if x == -1 else 'white', True)
    _poi(P, 'entree', 0, 0, z2 + 3, 180)
    # colonnes intérieures
    for x in (-8, 8):
        for z in (-7, -3, 1, 5):
            for y in range(1, 9):
                m.set(x, y, z, S('polished_andesite') if y not in (1, 8) else S('chiseled_stone_bricks'))
    # 8 socles de monuments (3×3) : deux rangées de 4 dans la nef
    k = 1
    for z in (-6, 0):
        pass
    socles = [(-5, -7), (5, -7), (-5, -3), (5, -3), (-5, 1), (5, 1), (-5, 5), (5, 5)]
    for (sx, sz) in socles:
        for dx in (-1, 0, 1):
            for dz in (-1, 0, 1):
                m.set(sx + dx, 1, sz + dz, S('polished_blackstone_bricks') if (dx or dz) else S('chiseled_polished_blackstone'))
        m.set(sx, 1, sz, S('chiseled_polished_blackstone'))
        _poi(P, 'socle%d' % k, sx, 2, sz, 0)
        k += 1
    # tapis central (allée d'honneur)
    for z in range(z1 + 1, z2):
        for x in (-1, 0, 1):
            m.set(x, 1, z, S('red_carpet') if x == 0 else S('black_carpet'))
    # plaque commémorative (mur nord) : grand panneau de pierre noire + panneaux muraux
    for x in range(-6, 7):
        for y in range(2, 8):
            m.set(x, y, z1, S('polished_blackstone'))
    for x in range(-6, 7):
        m.set(x, 8, z1 + 1, S('polished_blackstone_brick_slab', type='top'))
        m.set(x, 1, z1 + 1, S('polished_blackstone_stairs', facing='south', half='bottom'))
    lettres(R, -6, 3, z1, 'HALL', S('gold_block'), 'east') if False else None
    for x, txt in ((-2, ['HALL', '', '', '']), (0, ['DES', '', '', '']), (2, ['SURVIVANTS', '', '', ''])):
        m.set(x, 7, z1 + 1, S('dark_oak_wall_sign', facing='south'))
        m.sign(x, 7, z1 + 1, txt, 'gold', True)
    # panneaux vierges pour graver les noms
    vierges = []
    for y in (6, 5, 4, 3):
        for x in range(-5, 6):
            m.set(x, y, z1 + 1, S('dark_oak_wall_sign', facing='south'))
            m.sign(x, y, z1 + 1, ['', '', '', ''], 'white', True)
            vierges.append((x, y, z1 + 1))
    P['plaque'] = {'x': -5, 'y': 6, 'z': z1 + 1, 'yaw': 180.0, 'pitch': 0.0}
    P['plaques'] = [[x, y, z] for (x, y, z) in vierges]
    # lutrins
    for (x, z) in ((-3, z1 + 3), (3, z1 + 3)):
        m.set(x, 1, z, S('lectern', facing='south', has_book=False, powered=False))
    # bannières entre les fenêtres + lanternes
    couleurs = ['blue', 'white', 'red', 'black', 'green', 'gray']
    i = 0
    for z in range(z1 + 1, z2, 4):
        for (x, fa) in ((x1 + 1, 'east'), (x2 - 1, 'west')):
            if m.est_air(x, 6, z):
                m.set(x, 6, z, S(couleurs[i % len(couleurs)] + '_wall_banner', facing=fa))
                i += 1
    for (x, z) in ((-8, -5), (8, -5), (-8, 3), (8, 3), (0, -3), (0, 3)):
        m.set(x, 8, z, S('chain', axis='y')) if m.est_air(x, 8, z) else None
        m.set(x, 7, z, S('lantern', hanging=True, waterlogged=False)) if m.est_air(x, 7, z) else None
    for (x, z) in ((-12, -9), (12, -9), (-12, 6), (12, 6)):
        m.set(x, 1, z, S('potted_fern')) if False else m.set(x, 1, z, S('flower_pot'))
    # parvis et haies
    for x in range(-16, 16):
        for z in (10, 11):
            m.set(x, -1, z, S('stone_bricks') if abs(x) <= 3 else S('grass_block', snowy=False))
            if abs(x) > 4 and z == 11:
                m.set(x, 0, z, S('spruce_leaves', persistent=True, distance=1, waterlogged=False))
    for (x, z) in ((-5, 11), (4, 11)):
        m.set(x, 0, z, S('stone_brick_wall'))
        m.set(x, 1, z, S('lantern', hanging=False, waterlogged=False))
    m.passe_connexions()
    m.passe_escaliers()
    return m, P


# =========================================================================== MARCHÉ DE LA TRÊVE (zone neutre)
def zone_neutre(graine=10):
    m = Monde(-20, -1, -20, 40, 16, 40)
    ctx = Ctx(m, graine)
    rng = ctx.rng
    P = {}
    R = Repere(ctx, 0, 0)
    for x in range(-20, 20):
        for z in range(-20, 20):
            r = rng.random()
            st = S('packed_mud') if r < 0.35 else S('coarse_dirt') if r < 0.6 else S('grass_block', snowy=False) if r < 0.85 else S('rooted_dirt')
            m.set(x, -1, z, st)
    # allées de pavés en croix
    for k in range(-19, 20):
        for d in (-1, 0, 1):
            m.set(k, -1, d, S('cobblestone') if rng.random() < 0.7 else S('mossy_cobblestone'))
            m.set(d, -1, k, S('cobblestone') if rng.random() < 0.7 else S('mossy_cobblestone'))
    # murets + palissade (carré 36×36)
    L = 18
    for k in range(-L, L + 1):
        for (x, z) in ((k, -L), (k, L), (-L, k), (L, k)):
            if abs(k) <= 2 and z == L:
                continue            # portail sud
            m.set(x, 0, z, S('cobblestone_wall') if rng.random() < 0.7 else S('mossy_cobblestone_wall'))
            m.set(x, 1, z, S('spruce_log', axis='y'))
            m.set(x, 2, z, S('spruce_log', axis='y') if (x + z) % 2 else S('stripped_spruce_log', axis='y'))
            m.set(x, 3, z, S('spruce_fence') if (x + z) % 2 == 0 else AIR)
    # portail : deux tours de rondins, linteau, enseigne
    for gx in (-3, 3):
        for y in range(0, 6):
            m.set(gx, y, L, S('spruce_log', axis='y'))
            m.set(gx, y, L - 1, S('spruce_log', axis='y')) if y < 1 else None
        m.set(gx, 6, L, S('spruce_slab', type='bottom'))
    for x in range(-3, 4):
        m.set(x, 5, L, S('spruce_log', axis='x'))
    for x, txt in ((-1, ['MARCHÉ DE', 'LA TRÊVE', '', '']), (1, ['ZONE NEUTRE', 'Armes rangées', 'Aucun combat', ''])):
        m.set(x, 4, L + 1, S('spruce_wall_sign', facing='south'))
        m.sign(x, 4, L + 1, txt, 'white', True)
    m.set(-2, 0, L, S('spruce_fence_gate', facing='south', open=True, in_wall=False, powered=False))
    m.set(2, 0, L, S('spruce_fence_gate', facing='south', open=True, in_wall=False, powered=False))
    for gx in (-3, 3):
        m.set(gx, 4, L + 1, S('lantern', hanging=True, waterlogged=False)) if False else None
    m.set(-4, 3, L + 1, S('red_wall_banner', facing='south'))
    m.set(4, 3, L + 1, S('red_wall_banner', facing='south'))
    _poi(P, 'portail', 0, 0, L + 1, 180)
    # feu central + bancs de rondins
    m.set(0, 0, 0, S('campfire', facing='north', lit=True, signal_fire=False, waterlogged=False))
    for (x, z, ax) in ((-3, 0, 'z'), (3, 0, 'z'), (0, -3, 'x'), (0, 3, 'x')):
        for d in (-1, 0, 1):
            xx, zz = (x, z + d) if ax == 'z' else (x + d, z)
            m.set(xx, 0, zz, S('spruce_log', axis=ax))
    for (x, z) in ((-2, -2), (2, -2), (-2, 2), (2, 2)):
        m.set(x, -1, z, S('stone_bricks'))
    _poi(P, 'centre', 0, 0, 1, 180)
    # 4 étals couverts
    etals = [(-11, -11, 'red', 'white'), (11, -11, 'blue', 'yellow'), (-11, 10, 'green', 'white'), (11, 10, 'orange', 'brown')]
    for i, (ex, ez, c1, c2) in enumerate(etals, 1):
        regard = 'south' if ez < 0 else 'north'
        dz = 1 if ez < 0 else -1
        # comptoir (côté allée) + marchandises
        for dx in range(-2, 3):
            m.set(ex + dx, 0, ez + dz, S('barrel', facing='up', open=False) if dx % 2 else S('spruce_planks'))
            m.set(ex + dx, 1, ez + dz, S('spruce_slab', type='bottom'))
        prod = [['hay_block', 'melon', 'pumpkin'], ['barrel', 'chest', 'bookshelf'], ['dried_kelp_block', 'hay_block', 'honeycomb_block'],
                ['iron_block', 'anvil', 'smithing_table']][i - 1]
        for dx, p in zip((-2, 0, 2), prod):
            st = S(p, axis='y') if p == 'hay_block' else S(p, facing='north') if p == 'anvil' else \
                S(p, facing='south', type='single', waterlogged=False) if p == 'chest' else \
                S(p, facing='up', open=False) if p == 'barrel' else S(p)
            if p == 'anvil':
                continue            # enclume = gravité : remplacée
            m.set(ex + dx, 0, ez - dz, st)
        # poteaux et auvent rayé (laine)
        for (px, pz) in ((ex - 3, ez + dz), (ex + 3, ez + dz), (ex - 3, ez - 2 * dz), (ex + 3, ez - 2 * dz)):
            for y in range(0, 3):
                m.set(px, y, pz, S('spruce_fence'))
        for dx in range(-3, 4):
            for k in range(-2, 3):
                zz = ez + k * dz * -1 if False else ez + k
                y = 3 if abs(zz - (ez + dz)) >= 2 else 3
                m.set(ex + dx, 3, zz, S((c1 if dx % 2 else c2) + '_wool'))
            m.set(ex + dx, 2, ez + 2 * dz, S((c1 if dx % 2 else c2) + '_carpet')) if False else None
        m.set(ex, 1, ez + dz, S('lantern', hanging=False, waterlogged=False))
        m.set(ex - 1, 1, ez + dz, S('flower_pot')) if False else None
        m.set(ex + 3, 1, ez + 2 * dz, S('oak_wall_sign', facing=regard)) if False else None
        _poi(P, 'etal%d' % i, ex, 0, ez, 0 if ez < 0 else 180)
    # tableau des contrats (mur de planches avec panneaux) côté ouest de l'allée centrale
    tx, tz = -6, 5
    for x in range(tx - 2, tx + 3):
        for y in range(0, 4):
            m.set(x, y, tz, S('spruce_planks') if y > 0 else S('spruce_log', axis='x'))
    m.set(tx - 3, 0, tz, S('spruce_log', axis='y'))
    m.set(tx + 3, 0, tz, S('spruce_log', axis='y'))
    for x in range(tx - 3, tx + 4):
        m.set(x, 4, tz, S('spruce_slab', type='bottom'))
        m.set(x, 4, tz - 1, S('spruce_slab', type='bottom')) if False else None
    m.set(tx, 3, tz - 1, S('spruce_wall_sign', facing='north'))
    m.sign(tx, 3, tz - 1, ['~ CONTRATS ~', 'Tableau des', 'primes et', 'demandes'], 'black', False)
    exemples = [['RECHERCHÉ', 'Médicaments', 'contre : fer', ''], ['ESCORTE', 'vers la route 5', '2 survivants', ''],
                ['ÉCHANGE', 'Pain ↔ flèches', '', ''], ['', '', '', ''], ['', '', '', ''], ['', '', '', ''],
                ['', '', '', ''], ['', '', '', '']]
    k = 0
    for y in (2, 1):
        for x in range(tx - 2, tx + 3):
            if y == 2 and x == tx:
                pass
            m.set(x, y, tz - 1, S('spruce_wall_sign', facing='north'))
            m.sign(x, y, tz - 1, exemples[k % len(exemples)], 'black', False)
            k += 1
    for x in (tx - 2, tx + 2):
        m.set(x, 3, tz - 1, S('spruce_wall_sign', facing='north'))
        m.sign(x, 3, tz - 1, ['', '', '', ''], 'black', False)
    _poi(P, 'tableau', tx, 0, tz - 2, 0)
    # tour de guet (coin nord-est) 3×3, plateforme à y=7
    gx, gz = 13, -14
    for (x, z) in ((gx - 1, gz - 1), (gx + 1, gz - 1), (gx - 1, gz + 1), (gx + 1, gz + 1)):
        for y in range(0, 10):
            m.set(x, y, z, S('spruce_log', axis='y'))
    for x in range(gx - 2, gx + 3):
        for z in range(gz - 2, gz + 3):
            m.set(x, 7, z, S('spruce_planks'))
    m.set(gx, 7, gz + 1, AIR)
    for y in range(0, 8):
        m.set(gx, y, gz + 1, S('ladder', facing='north', waterlogged=False)) if False else None
    for y in range(0, 8):
        m.set(gx, y, gz + 2, S('ladder', facing='south', waterlogged=False)) if False else None
    for y in range(0, 7):
        m.set(gx, y, gz, S('spruce_planks')) if False else None
    # échelle contre la face sud d'une poutre centrale
    for y in range(0, 7):
        m.set(gx, y, gz, S('stripped_spruce_log', axis='y'))
        m.set(gx, y, gz + 1, S('ladder', facing='south', waterlogged=False))
    m.set(gx, 7, gz, S('spruce_planks'))
    for x in range(gx - 2, gx + 3):
        for z in (gz - 2, gz + 2):
            m.set(x, 8, z, S('spruce_fence'))
    for z in range(gz - 2, gz + 3):
        m.set(gx - 2, 8, z, S('spruce_fence'))
        m.set(gx + 2, 8, z, S('spruce_fence'))
    m.set(gx, 8, gz + 2, AIR)
    for r, y in ((2, 10), (1, 11), (0, 12)):
        for x in range(gx - r - (1 if r == 2 else 0), gx + r + 1 + (1 if r == 2 else 0)):
            for z in range(gz - r - (1 if r == 2 else 0), gz + r + 1 + (1 if r == 2 else 0)):
                m.set(x, y, z, S('spruce_planks') if r == 0 else S('dark_oak_slab', type='bottom'))
    m.set(gx, 9, gz, S('lantern', hanging=True, waterlogged=False))
    m.set(gx, 13, gz, S('red_banner', rotation=0)) if False else m.set(gx, 13, gz, S('spruce_fence'))
    # puits, lanternes sur poteaux, bannières
    for (x, z) in ((-12, -1), (12, 1), (-5, -12), (5, 12), (-14, 14), (14, 14)):
        m.set(x, 0, z, S('spruce_fence'))
        m.set(x, 1, z, S('spruce_fence'))
        m.set(x, 2, z, S('lantern', hanging=False, waterlogged=False))
    wx, wz = 6, -5
    for (x, z) in ((wx - 1, wz), (wx + 1, wz), (wx, wz - 1), (wx, wz + 1), (wx - 1, wz - 1), (wx + 1, wz + 1), (wx - 1, wz + 1), (wx + 1, wz - 1)):
        m.set(x, 0, z, S('mossy_cobblestone'))
    m.set(wx, -1, wz, S('water', level=0))
    m.set(wx, 0, wz, AIR)
    for (x, z) in ((wx - 1, wz - 1), (wx + 1, wz + 1)):
        m.set(x, 1, z, S('spruce_fence'))
        m.set(x, 2, z, S('spruce_fence'))
    for x in range(wx - 1, wx + 2):
        m.set(x, 3, wz, S('spruce_slab', type='bottom'))
    P['rayon'] = 18
    m.passe_connexions()
    m.passe_escaliers()
    return m, P
