# -*- coding: utf-8 -*-
"""za_meubles : contexte de génération, repères locaux orientables et mobilier intérieur.

Convention des repères : chaque bâtiment est dessiné « face au sud » en coordonnées locales
(a = gauche->droite vu de la rue, b = arrière->avant). Le repère transforme positions ET propriétés
(facing, axis, hinge, rotation, connexions) vers le monde. Toutes les fonctions de mobilier prennent un
repère R et des coordonnées locales.
"""
import math
import random

from za_blocs import S, AIR, DIRS, OPP, CW, CCW, YAW, parse, avec, nom_court, emet_lumiere, Monde

COULEURS = ['white', 'orange', 'magenta', 'light_blue', 'yellow', 'lime', 'pink', 'gray', 'light_gray', 'cyan',
            'purple', 'blue', 'brown', 'green', 'red', 'black']


# ============================================================================ contexte
class Ctx:
    def __init__(self, m, graine=1250):
        self.m = m
        self.rng = random.Random(graine)
        self.lampes = []          # dicts {x,y,z,on,off,zone}
        self.pois = {}
        self.calques = {}         # nom -> {(x,y,z): st}
        self.gyros = []           # positions (x,y,z) des blocs de gyrophare (ville de base)
        self.zones = {}           # nom de zone d'éclairage -> centre (x,z)

    def lampe(self, x, y, z, on, off, zone=None):
        self.m.set(x, y, z, on)
        self.lampes = [l for l in self.lampes if (l['x'], l['y'], l['z']) != (x, y, z)]
        self.lampes.append({'x': x, 'y': y, 'z': z, 'on': on, 'off': off, 'zone': zone})

    def calque(self, nom, x, y, z, st):
        self.calques.setdefault(nom, {})[(x, y, z)] = st

    def poi(self, nom, x, y, z, yaw=0.0, pitch=0.0, centre=True):
        if centre:
            x, z = x + 0.5, z + 0.5
        self.pois[nom] = {'x': round(x, 2), 'y': y, 'z': round(z, 2), 'yaw': float(yaw), 'pitch': float(pitch)}


# ============================================================================ repère local
_VEC = {'north': (0, -1), 'south': (0, 1), 'west': (-1, 0), 'east': (1, 0)}


class Repere:
    def __init__(self, ctx, ox, oz, u=(1, 0), v=(0, 1)):
        self.ctx = ctx
        self.m = ctx.m
        self.ox, self.oz = ox, oz
        self.u, self.v = u, v
        self.miroir = (u[0] * v[1] - u[1] * v[0]) < 0

    # -- positions / directions
    def xz(self, a, b):
        return (self.ox + a * self.u[0] + b * self.v[0], self.oz + a * self.u[1] + b * self.v[1])

    def vec(self, d):
        la, lb = _VEC[d]
        return (la * self.u[0] + lb * self.v[0], la * self.u[1] + lb * self.v[1])

    def d(self, dloc):
        if dloc in ('up', 'down'):
            return dloc
        w = self.vec(dloc)
        for k, v in _VEC.items():
            if v == w:
                return k
        raise ValueError(dloc)

    def yaw(self, dloc):
        return YAW[self.d(dloc)]

    def sous(self, a, b, miroir=False, largeur=None):
        """Sous-repère d'origine locale (a,b). miroir=True : l'axe a est inversé (a' croît vers -a),
        origine placée en a+largeur-1 pour que a' ∈ [0, largeur-1] couvre la même zone."""
        if miroir:
            ox, oz = self.xz(a + largeur - 1, b)
            return Repere(self.ctx, ox, oz, (-self.u[0], -self.u[1]), self.v)
        ox, oz = self.xz(a, b)
        return Repere(self.ctx, ox, oz, self.u, self.v)

    # -- états orientés
    def S(self, nom, **p):
        q = dict(p)
        if 'facing' in q and q['facing'] not in ('up', 'down'):
            q['facing'] = self.d(q['facing'])
        if 'axis' in q and q['axis'] in ('x', 'z'):
            loc = (1, 0) if q['axis'] == 'x' else (0, 1)
            w = (loc[0] * self.u[0] + loc[1] * self.v[0], loc[0] * self.u[1] + loc[1] * self.v[1])
            q['axis'] = 'x' if w[0] != 0 else 'z'
        if 'rotation' in q:
            r = int(q['rotation'])
            th = math.radians(r * 22.5)
            lx, lz = -math.sin(th), math.cos(th)
            wx, wz = lx * self.u[0] + lz * self.v[0], lx * self.u[1] + lz * self.v[1]
            ang = math.degrees(math.atan2(-wx, wz)) % 360
            q['rotation'] = int(round(ang / 22.5)) % 16
        if self.miroir:
            if 'hinge' in q:
                q['hinge'] = {'left': 'right', 'right': 'left'}[q['hinge']]
            if q.get('type') in ('left', 'right') and nom.endswith('chest'):
                q['type'] = {'left': 'right', 'right': 'left'}[q['type']]
        cles = [k for k in ('north', 'south', 'east', 'west') if k in q]
        if cles:
            vals = {k: q.pop(k) for k in cles}
            for k, v in vals.items():
                q[self.d(k)] = v
        return S(nom, **q)

    # -- écriture
    def set(self, a, y, b, st):
        x, z = self.xz(a, b)
        self.m.set(x, y, z, st)

    def get(self, a, y, b):
        x, z = self.xz(a, b)
        return self.m.get(x, y, z)

    def est_air(self, a, y, b):
        x, z = self.xz(a, b)
        return self.m.est_air(x, y, z)

    def fill(self, a1, y1, b1, a2, y2, b2, st):
        x1, z1 = self.xz(a1, b1)
        x2, z2 = self.xz(a2, b2)
        self.m.fill(x1, y1, z1, x2, y2, z2, st)

    def vide(self, a1, y1, b1, a2, y2, b2):
        self.fill(a1, y1, b1, a2, y2, b2, AIR)

    def lampe(self, a, y, b, on, off, zone=None):
        x, z = self.xz(a, b)
        self.ctx.lampe(x, y, z, on, off, zone)

    def sign(self, a, y, b, lignes, couleur='black', glow=False):
        x, z = self.xz(a, b)
        self.m.sign(x, y, z, lignes, couleur, glow)

    def container(self, a, y, b, items):
        x, z = self.xz(a, b)
        self.m.container(x, y, z, items)

    def calque(self, nom, a, y, b, st):
        x, z = self.xz(a, b)
        self.ctx.calque(nom, x, y, z, st)

    def poi(self, nom, a, y, b, regard='south', pitch=0.0):
        x, z = self.xz(a, b)
        self.ctx.poi(nom, x, y, z, self.yaw(regard) if isinstance(regard, str) else regard, pitch)

    def monde(self, a, b):
        return self.xz(a, b)


# ============================================================================ éléments de construction
def porte(R, a, y, b, facing, bois='oak', hinge='left', ouverte=False):
    """Porte 2 moitiés. facing = direction de marche pour entrer (panneau côté opposé)."""
    nom = bois + '_door' if not bois.endswith('_door') else bois
    R.set(a, y, b, R.S(nom, facing=facing, half='lower', hinge=hinge, open=ouverte, powered=False))
    R.set(a, y + 1, b, R.S(nom, facing=facing, half='upper', hinge=hinge, open=ouverte, powered=False))


def porte_double(R, a, y, b, facing, bois='oak', axe_a=True, ouverte=False):
    """Deux portes côte à côte (a et a+1 si axe_a) s'ouvrant par le milieu."""
    # vu dans le sens `facing`, gauche = CCW(facing)
    if axe_a:
        p1, p2 = (a, b), (a + 1, b)
    else:
        p1, p2 = (a, b), (a, b + 1)
    # déterminer laquelle est à gauche quand on regarde vers `facing`
    gx, gz = _VEC[CCW[facing]]
    d1 = p1[0] * gx + p1[1] * gz
    d2 = p2[0] * gx + p2[1] * gz
    gauche, droite = (p1, p2) if d1 > d2 else (p2, p1)
    porte(R, gauche[0], y, gauche[1], facing, bois, 'left', ouverte)
    porte(R, droite[0], y, droite[1], facing, bois, 'right', ouverte)


def lit(R, a, y, b, tete, couleur='white'):
    """Pied en (a,b), tête dans la direction `tete`."""
    da, db = _VEC[tete]
    R.set(a, y, b, R.S(couleur + '_bed', facing=tete, part='foot', occupied=False))
    R.set(a + da, y, b + db, R.S(couleur + '_bed', facing=tete, part='head', occupied=False))
    return (a + da, b + db)


def chaise(R, a, y, b, regard, mat='spruce'):
    """Chaise (escalier) : la personne assise regarde vers `regard`."""
    R.set(a, y, b, R.S(mat + '_stairs', facing=OPP[regard], half='bottom'))


def tabouret(R, a, y, b, bois='spruce'):
    R.set(a, y, b, S(bois + '_fence'))
    R.set(a, y + 1, b, S(bois + '_pressure_plate') if bois not in ('quartz',) else S('heavy_weighted_pressure_plate'))


def table(R, a, y, b, bois='spruce', nappe=None):
    R.set(a, y, b, S(bois + '_fence'))
    R.set(a, y + 1, b, S((nappe + '_carpet') if nappe else (bois + '_pressure_plate')))


def table_basse(R, a, y, b, bois='spruce'):
    R.set(a, y, b, R.S(bois + '_trapdoor', facing='north', half='bottom', open=False))


def dessus(R, a, y, b, mat='smooth_quartz_slab'):
    """Plateau de comptoir/table : dalle du haut."""
    R.set(a, y, b, S(mat, type='top'))


def accoudoir(R, a, y, b, cote, bois='spruce'):
    """Trappe ouverte collée au côté `cote` de la case (accoudoir / panneau)."""
    R.set(a, y, b, R.S(bois + '_trapdoor', facing=OPP[cote], half='bottom', open=True))


def canape(R, a, y, b, regard, longueur=3, mat='dark_oak', bras='dark_oak'):
    """Canapé le long de l'axe perpendiculaire à `regard`, à partir de (a,b)."""
    step = _VEC[CW[regard]]
    for i in range(longueur):
        R.set(a + step[0] * i, y, b + step[1] * i, R.S(mat + '_stairs', facing=OPP[regard], half='bottom'))
    # accoudoirs aux deux bouts
    a0, b0 = a - step[0], b - step[1]
    a1, b1 = a + step[0] * longueur, b + step[1] * longueur
    if R.est_air(a0, y, b0):
        accoudoir(R, a0, y, b0, CW[regard], bras)
    if R.est_air(a1, y, b1):
        accoudoir(R, a1, y, b1, CCW[regard], bras)


def fauteuil(R, a, y, b, regard, mat='dark_oak', bras='spruce'):
    canape(R, a, y, b, regard, 1, mat, bras)


def tapis(R, a1, b1, a2, b2, y, couleur, bord=None):
    for a in range(min(a1, a2), max(a1, a2) + 1):
        for b in range(min(b1, b2), max(b1, b2) + 1):
            if R.est_air(a, y, b):
                bordure = bord and (a in (a1, a2) or b in (b1, b2))
                R.set(a, y, b, S((bord if bordure else couleur) + '_carpet'))


def plante(R, a, y, b, kind=None, rng=None):
    rng = rng or random
    kinds = ['potted_fern', 'potted_azalea_bush', 'potted_flowering_azalea_bush', 'potted_oak_sapling',
             'potted_red_tulip', 'potted_cactus', 'potted_bamboo', 'potted_birch_sapling', 'potted_blue_orchid']
    R.set(a, y, b, S(kind or rng.choice(kinds)))


def grande_plante(R, a, y, b, rng=None):
    """Plante d'intérieur en bac : baril + azalée."""
    R.set(a, y, b, S('barrel', facing='up', open=False) if (rng or random).random() < 0.5 else S('composter', level=0))
    R.set(a, y + 1, b, S('azalea') if (rng or random).random() < 0.6 else S('flowering_azalea'))


def commode(R, a, y, b, regard, longueur=2, mat='spruce'):
    step = _VEC[CW[regard]]
    for i in range(longueur):
        R.set(a + step[0] * i, y, b + step[1] * i, R.S('chiseled_bookshelf', facing=regard))


def bibliotheque(R, a, y, b, hauteur=2):
    for k in range(hauteur):
        R.set(a, y + k, b, S('bookshelf'))


def tele(R, a, y, b, regard, largeur=2):
    """Écran plat : vitres noires connectées le long du mur."""
    step = _VEC[CW[regard]]
    for i in range(largeur):
        R.set(a + step[0] * i, y, b + step[1] * i, S('black_stained_glass_pane'))


def frigo(R, a, y, b, regard):
    porte(R, a, y, b, OPP[regard], 'iron', 'left', False)


def cuisiniere(R, a, y, b, regard):
    R.set(a, y, b, R.S('smoker', facing=regard, lit=False))


def evier(R, a, y, b):
    R.set(a, y, b, S('water_cauldron', level=3))


def armoire_haute(R, a, y, b, regard, bois='spruce'):
    """Armoire de cuisine murale : trappe ouverte contre le mur (côté opposé au regard)."""
    R.set(a, y, b, R.S(bois + '_trapdoor', facing=regard, half='top', open=True))


def comptoir_cuisine(R, a, y, b, regard, longueur, bois='spruce', plan='polished_andesite_slab', evier_i=None,
                     cuis_i=None, haut=True):
    step = _VEC[CW[regard]]
    for i in range(longueur):
        aa, bb = a + step[0] * i, b + step[1] * i
        if i == evier_i:
            R.set(aa, y, bb, S('water_cauldron', level=2))
        elif i == cuis_i:
            R.set(aa, y, bb, R.S('smoker', facing=regard, lit=False))
        else:
            R.set(aa, y, bb, R.S('barrel', facing=regard, open=False))
        if haut:
            armoire_haute(R, aa, y + 2, bb, regard, bois)


def lampe_plafond(R, a, y, b, on='ochre_froglight', off='white_concrete', zone=None):
    st = S(on, axis='y') if on.endswith('froglight') else S(on)
    R.lampe(a, y, b, st, S(off), zone)


def toilette(R, a, y, b, regard):
    """Toilette blanche (escalier de quartz, réservoir contre le mur)."""
    R.set(a, y, b, R.S('quartz_stairs', facing=OPP[regard], half='bottom'))


def baignoire(R, a, y, b, regard, longueur=2):
    """Baignoire : chaudrons remplis alignés perpendiculairement à `regard`."""
    step = _VEC[CW[regard]]
    for i in range(longueur):
        R.set(a + step[0] * i, y, b + step[1] * i, S('water_cauldron', level=3))


def lavabo(R, a, y, b, regard):
    """Lavabo (chaudron) + robinet (crochet) sur le mur derrière."""
    R.set(a, y, b, S('water_cauldron', level=1))
    R.set(a, y + 1, b, R.S('tripwire_hook', facing=regard, attached=False, powered=False))


def bureau(R, a, y, b, regard, bois='spruce', ordi=True, chaise_mat='spruce'):
    """Bureau d'une case : plateau + écran ; chaise devant (côté opposé au regard du bureau)."""
    R.set(a, y, b, R.S(bois + '_trapdoor', facing=regard, half='top', open=False))
    if ordi:
        R.set(a, y + 1, b, S('black_stained_glass_pane'))
    da, db = _VEC[OPP[regard]]
    if chaise_mat and R.est_air(a + da, y, b + db):
        chaise(R, a + da, y, b + db, OPP[regard], chaise_mat)


def cadre(R, a, y, b, regard, couleur):
    """« Cadre » au mur : bannière murale colorée (sans motif)."""
    R.set(a, y, b, R.S(couleur + '_wall_banner', facing=regard))


def horloge(R, a, y, b, regard):
    R.set(a, y, b, R.S('stone_button', face='wall', facing=regard, powered=False))


def chiffres_romains():
    return None


# ============================================================================ police de blocs 3x5
_GLYPHES = {
    'A': ['.#.', '#.#', '###', '#.#', '#.#'], 'B': ['##.', '#.#', '##.', '#.#', '##.'],
    'C': ['.##', '#..', '#..', '#..', '.##'], 'D': ['##.', '#.#', '#.#', '#.#', '##.'],
    'E': ['###', '#..', '##.', '#..', '###'], 'F': ['###', '#..', '##.', '#..', '#..'],
    'G': ['.##', '#..', '#.#', '#.#', '.##'], 'H': ['#.#', '#.#', '###', '#.#', '#.#'],
    'I': ['###', '.#.', '.#.', '.#.', '###'], 'J': ['..#', '..#', '..#', '#.#', '.#.'],
    'K': ['#.#', '#.#', '##.', '#.#', '#.#'], 'L': ['#..', '#..', '#..', '#..', '###'],
    'M': ['#...#', '##.##', '#.#.#', '#...#', '#...#'], 'N': ['#..#', '##.#', '#.##', '#..#', '#..#'],
    'O': ['.#.', '#.#', '#.#', '#.#', '.#.'], 'P': ['##.', '#.#', '##.', '#..', '#..'],
    'Q': ['.#.', '#.#', '#.#', '##.', '.##'], 'R': ['##.', '#.#', '##.', '#.#', '#.#'],
    'S': ['.##', '#..', '.#.', '..#', '##.'], 'T': ['###', '.#.', '.#.', '.#.', '.#.'],
    'U': ['#.#', '#.#', '#.#', '#.#', '###'], 'V': ['#.#', '#.#', '#.#', '#.#', '.#.'],
    'W': ['#...#', '#...#', '#.#.#', '##.##', '#...#'], 'X': ['#.#', '#.#', '.#.', '#.#', '#.#'],
    'Y': ['#.#', '#.#', '.#.', '.#.', '.#.'], 'Z': ['###', '..#', '.#.', '#..', '###'],
    '0': ['###', '#.#', '#.#', '#.#', '###'], '1': ['.#.', '##.', '.#.', '.#.', '###'],
    '2': ['##.', '..#', '.#.', '#..', '###'], '3': ['##.', '..#', '.#.', '..#', '##.'],
    '4': ['#.#', '#.#', '###', '..#', '..#'], '5': ['###', '#..', '##.', '..#', '##.'],
    '6': ['.##', '#..', '###', '#.#', '###'], '7': ['###', '..#', '.#.', '.#.', '.#.'],
    '8': ['###', '#.#', '###', '#.#', '###'], '9': ['###', '#.#', '###', '..#', '##.'],
    '-': ['...', '...', '###', '...', '...'], ' ': ['..', '..', '..', '..', '..'], '.': ['.', '.', '.', '.', '#'],
    "'": ['#', '#', '.', '.', '.'],
}
_ACCENTS = {'É': ('E', '..#'), 'È': ('E', '#..'), 'Ê': ('E', '.#.'), 'Ô': ('O', '.#.'), 'À': ('A', '#..'),
            'Â': ('A', '.#.'), 'Ç': ('C', None)}


def largeur_texte(txt):
    return sum(len(_GLYPHES[_ACCENTS.get(c, (c,))[0]][0]) + 1 for c in txt) - 1


def lettres(R, a, y, b, txt, st, sens='east', accent_st=None):
    """Écrit `txt` en lettres de blocs 3x5 sur le plan vertical ; (a,y,b) = coin bas-gauche ;
    les lettres avancent dans la direction locale `sens`. Accents sur une 6e rangée."""
    da, db = _VEC[sens]
    pos = 0
    for c in txt:
        base, acc = _ACCENTS.get(c, (c, None))
        g = _GLYPHES[base]
        w = len(g[0])
        for r, ligne in enumerate(g):
            for i, ch in enumerate(ligne):
                if ch == '#':
                    R.set(a + da * (pos + i), y + 4 - r, b + db * (pos + i), st)
        if acc:
            for i, ch in enumerate(acc):
                if ch == '#':
                    R.set(a + da * (pos + i), y + 5, b + db * (pos + i), accent_st or st)
        pos += w + 1
    return pos - 1
