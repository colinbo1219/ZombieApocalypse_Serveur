#!/usr/bin/env python3
# SAINT-AURÈLE EN RUINES : la ville du prologue telle qu'on la retrouve après le Jour 8 (MISSION §31-32).
# Même plan, mêmes bâtiments, mêmes panneaux : le joueur reconnaît les lieux. Déterministe (graine 1250).
#   - calques de crise appliqués pour de vrai : dépanneur fermé, quarantaine, incident, chaos, checkpoint
#   - toutes les lampes éteintes (bloc « off »)                     - vitres brisées, toiles d'araignée
#   - vignes sur les façades, herbes dans les fissures, débris      - station-service incendiée + cratère
#   - panneaux réécrits (zone militaire, graffitis), mot de Maman dans le coffre de l'appartement 2A
# Sorties : ruines.json.gz + ruines_pois.json (plugins/ZAMonde/) et za_p66_ruines_donnees.sk (lampes par quartier).
# Usage : python3 gen_ruines.py <dossier ZAMonde> <dossier scripts Skript>
import base64, gzip, json, math, os, random, sys, zlib

ICI = os.path.dirname(os.path.abspath(__file__))
ZAM, SK = sys.argv[1], sys.argv[2]
R = random.Random(1250)

t = json.load(gzip.open(os.path.join(ICI, 'town.json.gz')))
W, H, D = t['size']
OX, OY, OZ = t['offset']
pal = list(t['palette'])
raw = zlib.decompress(base64.b64decode(t['blocks']))
blk = [raw[2 * i] | (raw[2 * i + 1] << 8) for i in range(W * H * D)]
idx_pal = {b: i for i, b in enumerate(pal)}


def pid(b):
    if b not in idx_pal:
        idx_pal[b] = len(pal)
        pal.append(b)
    return idx_pal[b]


def dedans(x, y, z):
    return 0 <= x - OX < W and 0 <= y - OY < H and 0 <= z - OZ < D


def get(x, y, z):
    if not dedans(x, y, z):
        return 'minecraft:air'
    return pal[blk[((y - OY) * D + (z - OZ)) * W + (x - OX)]]


def put(x, y, z, b):
    if dedans(x, y, z):
        blk[((y - OY) * D + (z - OZ)) * W + (x - OX)] = pid(b)


AIR = 'minecraft:air'
lamps = json.load(open(os.path.join(ICI, 'lamps.json')))
pois = json.load(open(os.path.join(ICI, 'pois.json')))
proteges = {(l['x'], l['y'], l['z']) for l in lamps}

# ---------------------------------------------------------------- 1. calques de crise (l'état du Jour 7, figé)
layers = json.load(open(os.path.join(ICI, 'layers.json')))
for nom in ('depanneur_ferme', 'quarantaine', 'incident', 'chaos', 'checkpoint'):
    for e in layers[nom]:
        put(e['x'], e['y'], e['z'], e['b'])
        proteges.add((e['x'], e['y'], e['z']))

# ---------------------------------------------------------------- 2. lampes éteintes
for l in lamps:
    put(l['x'], l['y'], l['z'], l['off'])

# ---------------------------------------------------------------- 3. incendie de la station-service + cratère
st = pois['station_service']
cx, cz = int(st['x']), int(st['z'])
NOIRS = ['minecraft:blackstone', 'minecraft:coal_block', 'minecraft:black_concrete', 'minecraft:basalt[axis=y]',
         'minecraft:polished_blackstone', 'minecraft:cracked_polished_blackstone_bricks']
for x in range(cx - 13, cx + 14):
    for z in range(cz - 13, cz + 14):
        d = math.hypot(x - cx, z - cz)
        if d > 13:
            continue
        for y in range(62, 80):
            b = get(x, y, z)
            if b == AIR or (x, y, z) in proteges:
                continue
            if d < 4.5 and y >= 62 and math.hypot(d, (y - 64) * 1.4) < 4.5:
                put(x, y, z, AIR)                                    # cratère
            elif y >= 65:
                if R.random() < 0.35 * (1 - d / 14):
                    put(x, y, z, AIR)
                elif any(k in b for k in ('planks', 'log', 'wool', 'carpet', 'concrete', 'terracotta', 'glass', 'wood', 'bricks', 'fence')):
                    put(x, y, z, R.choice(NOIRS))

# ---------------------------------------------------------------- 4. vitres, rues, végétation, débris
ROUTE = ('gray_concrete', 'black_concrete', 'andesite', 'polished_andesite', 'smooth_stone', 'stone_bricks')
SOLIDE = ('concrete', 'bricks', 'terracotta', 'planks', 'stone', 'andesite', 'quartz', 'sandstone', 'deepslate')
DEBRIS = ['minecraft:cobblestone_slab[type=bottom,waterlogged=false]', 'minecraft:mossy_cobblestone_slab[type=bottom,waterlogged=false]',
          'minecraft:andesite_slab[type=bottom,waterlogged=false]', 'minecraft:stone_button[face=floor,facing=north,powered=false]']
FISSURES = ['minecraft:cobblestone', 'minecraft:mossy_cobblestone', 'minecraft:coarse_dirt', 'minecraft:cracked_stone_bricks']
VOIS = [(1, 0, 'east'), (-1, 0, 'west'), (0, 1, 'south'), (0, -1, 'north')]


def solide(b):
    return b != AIR and any(k in b for k in SOLIDE) and 'slab' not in b and 'stairs' not in b and 'wall' not in b


for x in range(OX, OX + W):
    for z in range(OZ, OZ + D):
        for y in range(OY, OY + H):
            if (x, y, z) in proteges:
                continue
            b = get(x, y, z)
            if b == AIR:
                continue
            nom = b.split('[')[0]
            if nom in ('minecraft:glass', 'minecraft:glass_pane') or nom.endswith('_glass_pane') and 'stained' not in nom:
                r = R.random()
                if r < 0.5:
                    put(x, y, z, AIR)
                elif r < 0.56:
                    put(x, y, z, 'minecraft:cobweb')
            elif y == 64 and any(k in nom for k in ROUTE) and get(x, 65, z) == AIR:
                r = R.random()
                if r < 0.05:
                    put(x, y, z, R.choice(FISSURES))
                    if R.random() < 0.5:
                        put(x, 65, z, 'minecraft:grass')
                elif r < 0.07:
                    put(x, 65, z, R.choice(DEBRIS))
            elif nom == 'minecraft:grass_block' and get(x, y + 1, z) == AIR and y >= 63:
                r = R.random()
                if r < 0.30:
                    put(x, y + 1, z, 'minecraft:grass')
                elif r < 0.34:
                    put(x, y + 1, z, 'minecraft:fern')

# vignes sur les façades (cases d'air collées à un mur, au-dessus du rez-de-chaussée)
for x in range(OX + 1, OX + W - 1):
    for z in range(OZ + 1, OZ + D - 1):
        for y in range(66, OY + H - 1):
            if get(x, y, z) != AIR or R.random() > 0.035:
                continue
            for dx, dz, face in VOIS:
                if solide(get(x + dx, y, z + dz)):
                    etat = {k: 'false' for k in ('east', 'north', 'south', 'up', 'west')}
                    etat[face] = 'true'
                    v = 'minecraft:vine[' + ','.join('%s=%s' % (k, etat[k]) for k in sorted(etat)) + ']'
                    yy = y
                    for _ in range(R.randint(1, 4)):
                        if get(x, yy, z) != AIR or not solide(get(x + dx, yy, z + dz)):
                            break
                        put(x, yy, z, v)
                        yy -= 1
                    break

# ---------------------------------------------------------------- 5. panneaux et coffre
REECRIT = {
    ('ROUTE FERMÉE', '', 'Circulation', 'locale seulement'): ['ZONE MILITAIRE', 'ACCÈS INTERDIT', 'Ordre de tirer', 'à vue'],
    ('', 'HÔPITAL', '', ''): ['NE PAS', 'ENTRER', 'MORTS', 'À L\'INTÉRIEUR'],
    ('URGENCE', 'Triage', 'Attendez', "d'être appelé"): ['URGENCE', 'Triage', 'Personne', 'ne viendra'],
    ('', 'POUTINE', '', ''): ['', 'FERMÉ', 'pour cause de', 'maladie'],
    ('À LOUER', '5 1/2', 'Libre le 1er', 'juillet'): ['ON EST', 'PARTIS', 'VERS LE NORD', '- famille 3B'],
    ('À VENDRE', 'Vélo 10 vitesses', '40 $ - voir 3B', ''): ['', 'ILS SONT', 'DEDANS', ''],
    ('AVIS', 'Collecte des', 'ordures : mardi', '- Le concierge'): ['AVIS', 'Plus de collecte', 'Brûlez vos morts', '- Le concierge'],
    ('NORDA', 'BIOTECH', 'Échantillons', 'Z-01 : NE PAS OUVRIR'): ['NORDA', 'BIOTECH', 'Échantillons', 'Z-01 : OUVERT'],
    ('MENU', 'Café 2,25 $', 'Latté 4,50 $', 'Muffin 3,25 $'): ['MENU', 'Eau : 1 balle', 'Pain : 2 balles', 'Pas de crédit'],
}
for s in t['signs']:
    k = tuple(s['front'])
    if k in REECRIT:
        s['front'] = REECRIT[k]
        s['color'] = 'red' if k[0] in ('ROUTE FERMÉE', '') else s.get('color', 'black')
for c in t['containers']:
    c['items'].append({'slot': 13, 'id': 'minecraft:paper', 'n': 1, 'name': 'Mot de Maman'})
    c['items'].append({'slot': 22, 'id': 'minecraft:bread', 'n': 2, 'name': 'Pain (sec)'})

# ---------------------------------------------------------------- 6. écriture de la structure
buf = bytearray(W * H * D * 2)
for i, v in enumerate(blk):
    buf[2 * i] = v & 0xFF
    buf[2 * i + 1] = v >> 8
out = {'size': [W, H, D], 'offset': [OX, OY, OZ], 'palette': pal,
       'blocks': base64.b64encode(zlib.compress(bytes(buf), 9)).decode(), 'signs': t['signs'], 'containers': t['containers']}
# mtime=0 : deux exécutions donnent le même fichier, octet pour octet
with gzip.GzipFile(os.path.join(ZAM, 'ruines.json.gz'), 'wb', mtime=0) as f:
    f.write(json.dumps(out, ensure_ascii=False, separators=(',', ':')).encode('utf-8'))
with open(os.path.join(ZAM, 'ruines_pois.json'), 'w', encoding='utf-8') as f:
    json.dump(pois, f, ensure_ascii=False, indent=1)

# ---------------------------------------------------------------- 7. données Skript : lampes par quartier + lieux
ANCRES = {'hopital': ['hopital_entree', 'hopital_accueil', 'ambulance_baie', 'hopital_heliport'],
          'police': ['police_entree', 'checkpoint_vega', 'intersection'],
          'commerce': ['depanneur_porte', 'cafe_comptoir', 'station_service', 'rita_comptoir', 'abribus'],
          'residentiel': ['entree_immeuble', 'maison1', 'maison2', 'maison3', 'parc_banc', 'ecole_entree']}
lignes = ['# =====================================================================',
          '#  ZombieApocalypse - SAINT-AURÈLE EN RUINES : données (généré par ZA_sources/ville/gen_ruines.py, ne pas éditer)',
          '#  Lampes : "x;y;z;bloc allumé;bloc éteint" relatives à la base de pose, rangées par quartier du réseau (za_p50).',
          '# =====================================================================', '',
          'function za_ruines_lampes(q: text) :: texts:']
par_q = {q: [] for q in ANCRES}
for l in lamps:
    best, bd = 'residentiel', 1e9
    for q, noms in ANCRES.items():
        for n in noms:
            p = pois[n]
            d = math.hypot(l['x'] - p['x'], l['z'] - p['z'])
            if d < bd:
                best, bd = q, d
    par_q[best].append('%d;%d;%d;%s;%s' % (l['x'], l['y'], l['z'], l['on'], l['off']))
for q, lst in par_q.items():
    lignes.append('    if {_q} is "%s":' % q)
    for i in range(0, len(lst), 8):
        q8 = ['"%s"' % e for e in lst[i:i + 8]]
        liste = q8[0] if len(q8) == 1 else ', '.join(q8[:-1]) + ' and ' + q8[-1]
        lignes.append('        add %s to {_l::*}' % liste)
    lignes.append('        return {_l::*}')
# panneaux utiles à l'exploration (za_p69) : "x;y;z" relatifs à la base de pose
CLES = {'cafe': ('MENU',), 'archives': ('Bureau', 'Archives'), 'lefort': ('Bureau', 'Dr É. Lefort'),
        'norda': ('NORDA', 'BIOTECH'), 'labo': ('LABORATOIRE',), 'chambre104': ('Chambre', '104')}
lignes.append('')
lignes.append('function za_ruines_panneau(n: text) :: text:')
for cle, debut in CLES.items():
    for sg in t['signs']:
        f = sg['front']
        if tuple(f[:len(debut)]) == debut:
            lignes.append('    if {_n} is "%s":' % cle)
            lignes.append('        return "%d;%d;%d"' % (sg['x'], sg['y'], sg['z']))
            break
    else:
        raise SystemExit('panneau introuvable : ' + cle)
lignes.append('    return ""')
lignes.append('')
open(os.path.join(SK, 'za_p66_ruines_donnees.sk'), 'w', encoding='utf-8').write('\n'.join(lignes) + '\n')
print('ruines :', len(pal), 'entrées de palette,', sum(1 for v in blk if v), 'blocs non-air ; lampes', {q: len(v) for q, v in par_q.items()})
