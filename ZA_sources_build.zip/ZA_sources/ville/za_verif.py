# -*- coding: utf-8 -*-
"""Vérifications : accessibilité à pied (BFS en mode aventure : portes de bois ouvrables), sources lumineuses."""
from collections import deque

import numpy as np

from za_blocs import parse, nom_court, emet_lumiere

_TRAVERSABLE_SUFFIXES = ('_carpet', '_sign', '_banner', '_button', '_pressure_plate', '_sapling', '_tulip', '_fence_gate',
                         '_door', 'torch', '_rail', '_coral_fan', '_petals', 'tripwire_hook')
_TRAVERSABLE = {'air', 'grass', 'tall_grass', 'fern', 'large_fern', 'dandelion', 'poppy', 'blue_orchid', 'allium',
                'azure_bluet', 'oxeye_daisy', 'cornflower', 'lily_of_the_valley', 'sunflower', 'lilac', 'rose_bush',
                'peony', 'dead_bush', 'sugar_cane', 'lily_pad', 'vine', 'ladder', 'lever', 'tripwire', 'redstone_wire',
                'light', 'water', 'seagrass', 'cobweb', 'glow_lichen', 'moss_carpet', 'snow', 'fire', 'brown_mushroom',
                'red_mushroom', 'torchflower', 'wither_rose', 'pink_petals'}


def traversable(st):
    n, p = parse(st)
    c = n.split(':', 1)[1]
    if c in _TRAVERSABLE:
        return True
    if c.startswith('iron_door'):
        return False
    if c.endswith('_door'):
        return True
    if c.endswith('_trapdoor'):
        return p.get('open') == 'true' and not c.startswith('iron')
    if c.endswith('_fence_gate'):
        return True
    for s in _TRAVERSABLE_SUFFIXES:
        if c.endswith(s):
            return True
    return False


def haut(st):
    """Blocs de 1,5 de haut (clôtures, murets) : on ne peut pas sauter dessus."""
    c = nom_court(st)
    return c.endswith('_fence') or c.endswith('_wall') or c.endswith('_fence_gate')


def accessibilite(m, depart, cibles, borne=(-5, 164)):
    """BFS sur les positions de pieds. cibles : {nom: (x,y,z)}. Retourne {nom: bool}."""
    pal = m.pal
    trav = np.array([traversable(s) for s in pal], bool)
    hautb = np.array([haut(s) for s in pal], bool)
    marcheb = np.array([nom_court(s).endswith('_stairs') or (nom_court(s).endswith('_slab') and 'type=bottom' in s)
                        for s in pal], bool)
    Mb = marcheb[m.a]
    T = trav[m.a]
    Hh = hautb[m.a]
    H, D, W = m.a.shape
    x0, y0, z0 = m.x0, m.y0, m.z0

    def ok(x, y, z):
        return 0 <= x - x0 < W and 1 <= y - y0 < H - 1 and 0 <= z - z0 < D

    def debout(x, y, z):
        i, j, k = y - y0, z - z0, x - x0
        return T[i, j, k] and T[i + 1, j, k] and not T[i - 1, j, k]

    vu = set()
    q = deque()
    s = tuple(depart)
    if not debout(*s):
        return {n: False for n in cibles}, 0
    vu.add(s)
    q.append(s)
    while q:
        x, y, z = q.popleft()
        for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, nz = x + dx, z + dz
            if not (borne[0] <= nx <= borne[1] and borne[0] <= nz <= borne[1]):
                continue
            for dy in (0, 1, -1, -2, -3):
                ny = y + dy
                if not ok(nx, ny, nz) or (nx, ny, nz) in vu:
                    continue
                if not debout(nx, ny, nz):
                    continue
                if dy == 1:
                    # marche d'escalier / dalle : on monte sans sauter ; sinon saut (dégagement au départ)
                    if not (Mb[ny - 1 - y0, nz - z0, nx - x0] or Mb[y - 1 - y0, z - z0, x - x0]):
                        if not ok(x, y + 2, z) or not T[y + 2 - y0, z - z0, x - x0]:
                            continue
                    if Hh[ny - 1 - y0, nz - z0, nx - x0]:
                        continue
                if dy < 0:
                    # la chute doit être libre dans la colonne d'arrivée
                    libre = all(T[yy - y0, nz - z0, nx - x0] for yy in range(ny, y + 2))
                    if not libre:
                        continue
                vu.add((nx, ny, nz))
                q.append((nx, ny, nz))
                break
    res = {}
    for n, (x, y, z) in cibles.items():
        res[n] = any((x, y + d, z) in vu for d in (0, 1, -1))
    return res, len(vu)


def lampes_manquantes(m, lampes):
    """Toutes les sources lumineuses du monde doivent être dans lamps.json."""
    ids = {i for i, s in enumerate(m.pal) if emet_lumiere(s)}
    pos = m.positions(ids)
    connus = {(l['x'], l['y'], l['z']) for l in lampes}
    return [(int(x), int(y), int(z), m.get(int(x), int(y), int(z))) for (x, y, z) in pos if (int(x), int(y), int(z)) not in connus]
