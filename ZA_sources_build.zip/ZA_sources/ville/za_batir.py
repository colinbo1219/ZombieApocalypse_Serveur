# -*- coding: utf-8 -*-
"""za_batir : primitives de construction en repère local (murs, dalles, fenêtres, cage d'escalier…)."""
from za_blocs import S, AIR, OPP, CW, CCW
from za_meubles import _VEC, porte


def murs(R, a1, b1, a2, b2, y1, y2, st):
    """Périmètre (4 murs) d'un rectangle local."""
    R.fill(a1, y1, b1, a2, y2, b1, st)
    R.fill(a1, y1, b2, a2, y2, b2, st)
    R.fill(a1, y1, b1, a1, y2, b2, st)
    R.fill(a2, y1, b1, a2, y2, b2, st)


def dalle(R, a1, b1, a2, b2, y, st):
    R.fill(a1, y, b1, a2, y, b2, st)


def cloison_a(R, a, b1, b2, y1, y2, st):
    """Cloison le long de b (à a constant)."""
    R.fill(a, y1, b1, a, y2, b2, st)


def cloison_b(R, b, a1, a2, y1, y2, st):
    R.fill(a1, y1, b, a2, y2, b, st)


def fenetre(R, a, y, b, larg, haut, ext='south', vitre='glass_pane', appui='smooth_stone_slab', linteau=None,
            volets=None, jardiniere=None):
    """Fenêtre dans un mur ; (a,y,b) = coin bas-gauche ; le mur court perpendiculairement à `ext`
    (direction de l'extérieur). larg le long du mur (sens CW(ext) vu de l'intérieur...)."""
    step = _VEC[CW[ext]] if ext in ('north', 'south') else _VEC[CW[ext]]
    # on avance le long du mur : pour ext=south, le mur est le long de a -> pas (1,0)
    if ext in ('south', 'north'):
        step = (1, 0)
    else:
        step = (0, 1)
    ea, eb = _VEC[ext]
    for i in range(larg):
        aa, bb = a + step[0] * i, b + step[1] * i
        for k in range(haut):
            R.set(aa, y + k, bb, S(vitre))
        if appui:
            R.set(aa + ea, y - 1, bb + eb, S(appui, type='top') if appui.endswith('_slab') else R.S(appui, facing=OPP[ext], half='top'))
        if linteau:
            R.set(aa, y + haut, bb, S(linteau))
        if jardiniere:
            R.set(aa + ea, y - 1, bb + eb, S('spruce_trapdoor', facing=ext, half='top', open=False) if False else S(jardiniere[0]))
            R.set(aa + ea, y, bb + eb, S(jardiniere[1]))
    if volets:
        # trappes ouvertes de part et d'autre, collées au mur
        for (aa, bb) in ((a - step[0], b - step[1]), (a + step[0] * larg, b + step[1] * larg)):
            for k in range(haut):
                R.set(aa + ea, y + k, bb + eb, R.S(volets + '_trapdoor', facing=ext, half='bottom', open=True))


def cage_escalier(R, a0, b0, h_bas, n_etages, marche='stone_brick_stairs', palier='polished_andesite',
                  mur=None, dernier_rampe='iron_bars', diviseur=None):
    """Cage d'escalier en U (intérieur 5 de large × 7 de profond, a0..a0+4, b0..b0+6), l'avant (b0+6) donne
    sur le corridor. Étages espacés de 5 (marche h -> h+5), géométrie vanilla : chaque marche est 1 plus haut
    et la dernière marche d'une volée est au niveau du palier/plancher d'arrivée (aucun saut nécessaire).
    Montée à l'ouest (a0,a0+1) vers l'arrière : marches h, h+1, h+2 ; palier (b0..b0+2) à h+2 ;
    descente/arrivée à l'est (a0+3,a0+4) : marches h+3, h+4 puis plancher h+4."""
    W = (a0, a0 + 1)
    E = (a0 + 3, a0 + 4)
    L0, L2 = b0, b0 + 2
    S2, S1 = b0 + 3, b0 + 4
    niveaux = [h_bas + 5 * i for i in range(n_etages)]
    haut = niveaux[-1]
    R.vide(a0, h_bas, b0, a0 + 4, haut + 3, b0 + 6)
    for i, h in enumerate(niveaux):
        dernier = (i == n_etages - 1)
        if i > 0:
            for aa in W + (a0 + 2,):
                R.fill(aa, h - 1, S2 if aa in W else S1, aa, h - 1, b0 + 6, S(palier))
            for aa in E:
                R.fill(aa, h - 1, b0 + 5, aa, h - 1, b0 + 6, S(palier))
        if not dernier:
            for aa in W:
                R.set(aa, h, S1, R.S(marche, facing='north', half='bottom'))
                R.set(aa, h + 1, S2, R.S(marche, facing='north', half='bottom'))
                R.set(aa, h + 2, L2, R.S(marche, facing='north', half='bottom'))
                R.set(aa, h, S2, R.S(marche, facing='south', half='top'))
                R.set(aa, h + 1, L2, R.S(marche, facing='south', half='top'))
            R.fill(a0, h + 2, L0, a0 + 4, h + 2, L2 - 1, S(palier))
            R.fill(a0 + 2, h + 2, L2, a0 + 4, h + 2, L2, S(palier))
            for aa in E:
                R.set(aa, h + 3, S2, R.S(marche, facing='south', half='bottom'))
                R.set(aa, h + 4, S1, R.S(marche, facing='south', half='bottom'))
                R.set(aa, h + 2, S2, R.S(marche, facing='north', half='top'))
        else:
            for aa in W:
                R.set(aa, h, S2, S(dernier_rampe))
        R.fill(a0 + 2, h, S2, a0 + 2, h + 3 if not dernier else h + 1, S1, S(diviseur or palier))
    return niveaux
