# Agent B — Territoires de factions (#4) + Relations entre personnages (#14) + conséquences de 2 choix du prologue
Files to create: `za_p45_territoires.sk`, `za_p46_relations.sk` (in /home/claude/za_build/skript/). Read /home/claude/za_build/BRIEF_AGENTS.md first.
You MAY edit `za_p18_pnj.sk` (dialogue nodes of Lefort/Vega/Léa) and `za_p40_histoire.sk` (their chains) minimally — keep a copy
in /home/claude/za_build/skript_bak/ first, keep every existing node working (`chaine`, `escouade`, `mystere`, quests).

## Territoires (#4)
Territories = the special buildings from za_p35 (`za_bat_liste(type)`, keys "type;index"). Default owner by type:
police → milice, caserne → milice, labo2 → scientifiques, hopital → scientifiques, super (zone commerciale) → pilleurs,
station → marchands, ecole → survivants, centrale → contested ("personne"). Also possible owner "morts" (overrun).
Data: `{za::terr::<key>::fac}`, `{za::terr::<key>::ctrl}` (0–100 hold strength), `{za::terr::<key>::jour}` (last change).
Visible presence: a banner + sign "Territoire de la Milice" (colors per faction) at the building; friendly faction guards = villagers
(Milice: "Soldat Milice …" → soldier skin; Scientifiques: "Chercheur …"/"Infirmière …"; Marchands: citizen names; Survivants: citizen)
1–2 per held territory, Invulnerable, NoAI-ish standing; Pilleurs territories: hostile `ZA_Pillard` / `ZA_Pillard_Tireur` spawn when a
player whose `pilleurs` reputation < 25 comes within ~40 blocks (cap 3–5, cooldown); allied players (≥ 25) get "&7Les pillards te
laissent passer." and no spawns.
Dynamics (daily tick, server days): ctrl drops with zombie pressure (`za_danger(center)`, nests within 150 blocks), rival pressure.
Events (random, 1 at a time, radio via `za_radio`): 
- "Défense": a faction asks players to defend a territory → 3 min of waves (zombies or pillards) around it; defenders get jetons +
  faction rep (`za_faction_ajouter`), stat `territoires_defendus`; failure → owner becomes "morts" (or the attacking faction).
- "Reconquête": a lost ("morts") territory can be retaken: clear the zone (kill N zombies within 30 blocks) → the player picks among
  factions he's allied with (rep ≥ 25) via `za_menu` → new owner.
- "Raid": a faction asks to attack an enemy-held territory (milice ↔ pilleurs, scientifiques ↔ culte/pilleurs, marchands neutral):
  defenders spawn (pillards for pilleurs; for friendly factions a raid means "sabotage": destroy supply crates placed there, no villager
  killing) → success transfers control; rivals' reputation drops.
Rewards when a territory is held by a faction the player is allied with (rep ≥ 25), claimable once per server day at the building
(right-click the sign or a "Caisse de ravitaillement" barrel): milice → TaCZ ammo (9mm/556x45) + bandages; scientifiques → Antibiotique/
Serum; pilleurs → cheap black-market goods (and −2 milice rep each claim); marchands → Essence + discount; survivants → a survivor
(console `zasurv creer <x> <y> <z> <monde>` from the survivors module — call it even if not present yet).
Faction hostility: milice ↔ pilleurs, scientifiques ↔ culte; helping one lowers its rival a little.
`/territoires`: list (type name, owner with color, hold %, rough coords, "en danger" flags). Admin `/zaterr etat|defense <key>|raid <key>|
reconquete <key>|tick|owner <key> <faction>` (console-usable).

## Relations (#14)
Trust `{za::rel::<npc>::<uuid>}` for `lefort`, `vega`, `lea` (0–100, default 50). Initial values from prologue choices (apply once,
when the player first talks to that NPC after the apocalypse): `hopital`="aide" → lefort +20; `leblanc`="sauvee" → lefort +10;
`vega`="obei" → vega +20 & milice +10; `vega`="clandestin" → vega −20 & pilleurs +10.
Personalities & tensions: Vega hates the scientists (if the player's scientifiques rep ≥ 50 and milice < 25, Vega is cold, refuses his
missions: "Tu sens le labo."); Lefort suspects Vega hides something; Léa trusts nobody (trust grows slowly by bringing radio parts
"Pièce de radio" (new item from electronics loot/zombie drops) and by keeping her secrets).
Mini-arc "Le dossier Bravo-3": Lefort (trust ≥ 60) asks you to find "Rapport Bravo-3" in a police/caserne territory (place it in a chest
there when the quest starts). Choice via menu: give it to Lefort (scientifiques +, vega −40, Vega later confronts you), give it back to
Vega (milice +, lefort −20, Vega confides: "L'ordre de fermer les portes de l'hôpital venait de NORDA. Pas de l'armée."), or keep it
and bring it to Léa (she reads it on the radio days later → both others react). Remember the outcome in `{za::rel::dossier::<uuid>}`.
Greetings/lines depend on trust and choices: Vega obei → "Je me souviens de toi. T'as fait la file comme tout le monde. C'est rare.";
clandestin → "Toi. La ruelle derrière le checkpoint. Je t'ai vu."; Lefort with hopital aide → "Tu es celui qui a porté les caisses de
soluté, le premier jour..."; leblanc sauvee → "Leblanc est au refuge. Elle parle de toi."; perdue → "Leblanc... ma meilleure infirmière."
Integrate into `za_dial_lefort/vega/lea` "debut" nodes (greeting varies; add 1 option for the relation/dossier arc when relevant).
Low trust has consequences (Vega won't give the escouade chain rewards until trust ≥ 30; Lefort's serum price etc.).
`/relations` shows the three trusts as words (Méfiant, Neutre, Confiance, Loyal) and their current attitude toward each other.
Report: files, commands, variables, stat keys, hooks, what's untested.
