# Agent A — Survivants recrutables (#2) + Camps de survivants vivants (#3) + conséquences de 2 choix du prologue
Files to create: `za_p43_survivants.sk`, `za_p44_camps.sk` (in /home/claude/za_build/skript/). Read /home/claude/za_build/BRIEF_AGENTS.md first.
Do not edit other files.

## Survivants (#2)
Each survivor is a record `{za::surv::<id>::...}` (id = incrementing number, `{za::surv::liste::*}`):
nom (prénom + nom, Québec names), metier (mécanicien, infirmière/infirmier, cuisinier, électricien, ancien soldat, enseignante,
chasseur, pharmacien, ado débrouillard, camionneur…), role at a base (`reparer`|`produire`|`soigner`|`garder`|`commercer`, default
from métier, reassignable), faction affinity, moral 0–100, faim 0–100, confiance per player `{za::surv::<id>::conf::<uuid>}`,
lieu (location), etat (`cache`|`blesse`|`camp`|`base`|`parti`|`mort`|`zombifie`), camp id or base owner uuid, relations with other
survivors (ami/rival id), a one-line backstory, the server day of the meeting.
Friendly NPC = vanilla villager with CustomName (see brief), tags `za_surv` + `za_surv_<id>`, Invulnerable while not in a scripted fight.

Encounters (normal play): every ~15–25 min per active survival player, chance to spawn a survivor in distress 60–120 blocks away
(prefer near a za_p35 building or ruin), hidden/crouched or wounded (`blesse`: needs a Bandage), with a hint (Léa radio or
"&8&oQuelqu'un appelle à l'aide vers le nord-est..."). Cap: 3 unrecruited survivors in the world at once; they leave after a while.
Console command for other modules: `zasurv creer <x> <y> <z> <monde> [metier|prisonnier|enfant]` (spawns a survivor there, state cache).

Interaction (right-click the villager → `za_menu`): parler (backstory, needs), donner nourriture/eau/bandage (confiance ↑, a wounded
one becomes saved: stat `survivants_sauves` +1), "Tu peux venir à notre base ?" (needs confiance ≥ 50 AND the player has a base
`{za::base::<uuid>}`; otherwise a fitting refusal), "Va au camp le plus proche" (sends them to a camp from the camps module: camp pop +1,
stat `camps_aides`), partir.

At a base (radius 40 around `{za::base::<uuid>}`): the survivor goes there (teleport + walk-in feel), stays near the base as an NPC.
Jobs, applied every server day (and small periodic effects):
- `produire`: puts food (bread, baked potatoes, canned-like named items) into the base "Réserve" chest.
- `reparer`: repairs damaged vanilla tools/armor stored in the Réserve chest (+25 % durability each day), and lowers `/reparer` cost for the owner.
- `soigner`: heals players in the base radius slowly; once per day can treat wounds via console `zablessure soigner <joueur>`
  (defined by another module; call it anyway) and makes 2 Bandages.
- `garder`: every ~10 s, if a zombie is within 24 blocks of the base, the guard "shoots" it (damage + `sfx.coup_de_feu` sound),
  and reduces siege danger (publish `{za::base::gardes::<uuid>}` = number of guards).
- `commercer`: at the base, right-click → buy/sell menu (sells basic supplies for jetons, buys loot for a few jetons).
Needs: every server day each base survivor eats 1 food item from the Réserve chest (any edible item); without food faim ↑ and moral ↓.
Moral also: + gifts, + friend at same base, − rival at same base (occasional dispute message), − sieges, − a death at the base,
+ if `{za::reseau::residentiel}` is true (power district, another module). Moral < 15 for 2 days → leaves (state `parti`, message).
During a siege of the base (`za_siege_base` from za_p8) a survivor may be hurt or die (rare, more likely without guards).
Player command `/survivants` (list at your base: nom, métier, rôle, moral, faim), `/survivants role <nom> <rôle>`,
`/survivants reserve` (look at a chest within your base to set it as the Réserve), `/survivants renvoyer <nom>`.
Stats: `survivants_sauves`, `survivants_recrutes`.

## Camps (#3)
3–4 camps max, generated like za_p35 buildings (console `fill`/`setblock`, ~20×20: palisade walls of logs/fences with a gate,
tents (wool), campfire, crates/barrels, a sign board with live stats, a bell) at 80–200 blocks from a player, plus 3–6 visible villager
NPCs and a "Chef de camp" NPC (name e.g. "Chef Bouchard"). Each camp: `{za::camp::liste::*}` ids and
`{za::camp::<id>::loc|nom|pop|nourriture|securite|moral|contam|etat|jour}` (etat `vivant`|`abandonne`|`mort`). Names like
"Refuge Sainte-Anne", "Camp du Moulin", "La Fourrière", "Poste 14".
Daily tick (server day): nourriture −(pop/2) %, sécurité −3, contamination from `{za::contam::<ckey>}` of the camp chunk + nests
within 150 blocks (`{za::nid::liste::*}` / `{za::nid::<id>::loc}`); nourriture 0 → moral −10 and pop −1..2 (they leave or die);
moral 0 → camp `abandonne` (people scatter, sign "Abandonné"); pop 0 → `mort` (ruin: `za_decay`, bones, sign "Camp X — tombé le jour N",
a few zombies); low sécurité → higher attack chance. `{za::reseau::residentiel}` true → moral +, sécurité +.
Chef de camp menu (`za_menu`): état du camp (numbers + a human sentence), donner nourriture (food items → nourriture %, faction
`survivants` +, jetons), donner matériaux (planks/logs/iron/cobble → sécurité), soigner (Bandage/Antibiotique/Serum → contamination ↓, moral ↑),
défendre (starts or joins the next attack), recruter (a camp survivor comes to your base if camp trust ≥ 50 — pop −1),
commercer (camp sells supplies; prices depend on prosperity), partir. Stat `camps_aides` on meaningful help.
Attacks: console `zacamp attaque <id> <zombies|pillards>` + natural ones (chance per day based on sécurité and danger `za_danger`):
Léa radio "Le camp X est attaqué !" (only if a player is within 300 blocks or randomly), waves around the camp for ~3 min
(zombies via `za_spawn_at`, or `ZA_Pillard`/`ZA_Pillard_Tireur` for pillards), result = losses computed from how many attackers
players killed near the camp vs. how many were left: pop/sécurité/moral changes, thank-you + rewards (jetons, faction survivants)
for defenders. Camps can die for real.
`/camps` (player): list camps with state, rough coordinates, needs ("ils manquent de nourriture"). Update the camp sign board.
Admin: `/zacamp creer|attaque <id> <type>|etat <id>|tick|supprimer <id>` (console-usable).

## Prologue choices (from `za_choix`)
- `leblanc` = "sauvee": ensure one camp (the first created, or create a special "Refuge Sainte-Anne") has "Infirmière Leblanc"
  (villager named exactly "Infirmière Leblanc" → nurse skin) as camp doctor: right-click → heals the player fully, calls console
  `zablessure soigner <joueur>`, sells Antibiotique/Serum cheaper; special greeting for players who saved her ("C'est toi... Tu m'as
  tirée de là, devant l'hôpital. Je ne l'oublierai jamais."). If her camp falls she dies: Léa announces it on the radio. If `leblanc`
  = "perdue" for a player: once, near a hospital building (`za_bat_liste("hopital")`) or anywhere at night, spawn a zombie villager named
  "Infirmière Leblanc" near that player (message: "&8&oCe badge... Leblanc. L'infirmière de l'hôpital.").
- `theo` = "appele": survivor "Théo Gagnon" (12 ans; a baby villager kept young: huge negative Age) appears in a camp; only that player
  can recruit him (instant trust); line "Tu m'as appelé, ce soir-là. Mamie... elle est morte, hein ?"; gives the item "Photo de Mamie";
  at a base he `produire`s and gives +10 moral to other survivors there. `theo` = "provisions": once, at night near that player's
  base (or near the player after server day 5), a baby zombie named "Théo" appears (message "&8&oUn enfant... Il porte le chandail des
  Canadiens de sa grand-mère. Théo."). Players with "" (no prologue) get neither.
Report: files, commands, variables, stat keys, hooks, what's untested.
