# Agent F — Succès secrets (#19) + Poids de la mort (#20) + Après-saison (#21) + Évolution entre les saisons (#22)
Files to create: `za_p57_succes.sk`, `za_p58_memoire.sk`, `za_p59_saisons.sk` (in /home/claude/za_build/skript/).
Read /home/claude/za_build/BRIEF_AGENTS.md first. You MAY minimally edit `za_p22_saison.sk` and `za_p41_saison_finale.sk`
(copy them to /home/claude/za_build/skript_bak/ first). Don't edit za_p36 (another agent may).

## Succès secrets (#19)
~22 hidden achievements (`{za::succes::<id>::<uuid>}` = server day unlocked). `/succes`: unlocked ones with name + description, and
"??? — x succès encore cachés". Unlock → toast sound, title (≤ 18 chars) + subtitle, jetons, journal line, and the name becomes a
selectable title: `/succes titre <id>` sets `{za::titre::special::<uuid>}` (used by za_p20 `za_titre`). Mandatory ones:
survivre 7 jours serveur sans mourir; détruire un nid seul (heart = MythicMobs "Coeur du nid" magma cube dies with no other player within
40 blocks); finir le prologue sans l'abandonner (`{za::pro::etat::<uuid>}` is "fini" and `{za::pro::passe::<uuid>}` not set — the lead
sets that flag on `/prologue passer`); sauver 10 survivants (stat `survivants_sauves`); vaincre un Alpha au corps-à-corps (killer not
holding a TaCZ gun `modern_kinetic_gun`); survivre à une nuit entière dehors (sky-exposed at every check through a whole night, not in
base). Others (use stats from the brief + existing variables): première enquête, 3 énigmes, trésor du bunker, 10 ventes au marché,
défendre 3 territoires, aider 5 camps, soigner 10 blessures (healer), "Poids plume" (kill an Alpha/Brute while at ≤ 1 heart),
"Silence radio" (a whole night with noise always low — za_p24 `{za::bruit::<uuid>}`), "Le Confident" (Lefort chain done:
`{za::lefort::etape::<uuid>}` ≥ 8), "Frère d'armes" (Vega chain `{za::vega::etape::<uuid>}` ≥ 2), "Survivant de la saison", "Mort-vivant"
(come back from zombie-player state), "Pyromane" (burn 10 corpses — check za_p13), "Architecte" (base size big — za_p8 `{za::base::taille::<uuid>}`),
etc. Keep checks cheap (event-driven or every 30–60 s).

## Poids de la mort (#20)
When a player dies in an important zone — `za_danger(loc)` ≥ 3, within 60 blocks of a nest/camp/special building/lab/Trêve, or during a
blood moon/horde (`{za::evt::bloodmoon}`, `{za::horde::actif}`) — build a commemorative stone (stone brick wall + candle + sign "Ici est tombé
X — Jour N — <cause>") 1–2 blocks from the death spot (not in water/lava; max one per 48 blocks per server day). za_p30 already puts a grave
sign on every death — don't duplicate its sign; your stone is special. 3+ deaths within ~40 blocks (tracked list of death points) →
create a "Rue des disparus" memorial once (a short wall of signs + candles + lantern) and keep its names updated (append new names,
several signs). `/disparus`: memorial places (rough coords) and names. Provide function `za_memoire_noms() :: texts` (all memorial names)
and call it from `za_saison_ceremonie` (za_p41) to engrave them in the Hall (add a line in the ceremony; minimal edit).

## Après-saison (#21)
After the season finale (za_p41 `za_saison_ceremonie(heros)` — store the hero in `{za::saison::heros::<n>}` there, and the finale
server day in `{za::apres::debut}`), a timeline keyed on server days since the finale:
J+1 calm: set `{za::apres::mult}` = 0.5 (the lead will wire it into the random spawner) + Léa: "C'est... calme. Trop calme.";
J+3 new transmissions (radio militaire + Léa) that name the hero and what happened; J+7 NPC talk: expose `za_apres_ligne(npc: text) :: text`
("lefort"/"vega"/"lea" → a line about the finale, or "" when not in the after-season window) — the lead will call it from dialogues.
Persist outcomes of each season in `{za::histoire::saison::<n>::*}`: hero, days, Overlords, nests destroyed, camps alive/fallen
(`{za::camp::liste::*}`, `{za::camp::<id>::etat}` from the camps module), territories by faction (`{za::terr::*}` from the territories
module), top faction, season resource top contributor (`{za::ressource::top::<n>}`), survivors saved. `/chroniques`: season-by-season
chronicle in book-like chat pages. Some choices remain visible: fallen camps stay ruins, the Hall, memorials, territory owners carry over.

## Évolution des saisons (#22)
Themes by `{za::saison::num}` (cycle after 4, with escalation): S1 "Les morts" (current), S2 "Les vivants" (zombies fewer:
`{za::theme::zombies_mult}` 0.7; pillard warbands (3–6 `ZA_Pillard`/`ZA_Pillard_Tireur`) raid bases and camps every 1–2 server days: radio
warning, spawn near a base (`{za::base::liste::*}`) or call console `zacamp attaque <id> pillards` (camps module) ; rewards for
repelling; betrayal events), S3 "La mutation" (more Spitters/Bloaters/Leapers, infection chance ×1.3 via a variable the infection
script can read — report it), S4 "Le silence" (EMP more often — za_p34 `za_emp()`, darker nights, Stalkers). Publish `{za::theme}`
(text) and `{za::theme::*}` parameters. At the start of a new season (hook where za_p22 `za_saison_finir()` increments the season
number), apply the theme and show every player (on next join if offline) a title card "SAISON <n>" / theme name + a Léa monologue
(5–6 lines) that references the previous season's outcomes (hero, camps fallen, who controlled what).
Admin `/zasaison theme <n>|apres <jour>|chronique <n>|test` (console-usable).
Report: files, commands, variables, stat keys, hooks, what's untested.
