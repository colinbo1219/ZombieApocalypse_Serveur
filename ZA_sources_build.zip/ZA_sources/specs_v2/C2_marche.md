# Agent C2 — Marché entre joueurs (#5) only
Write `/home/claude/za_build/skript/za_p47_marche.sk`. Read /home/claude/za_build/BRIEF_AGENTS.md, then the "Marché (#5)" section of
/home/claude/za_build/specs_v2/C_marche_ressources_armes.md (the resources and weapons parts are ALREADY DONE in za_p48/za_p49 — don't redo them),
and /home/claude/za_build/specs_v2/STATUS_MODULES.md.
Mandatory: define `function za_mk_lieu(l: location) :: text` (used by za_p48_ressources.sk): "Marché de la Trêve" if within 18 blocks of
`{za::treve::loc}`, the camp name if within 25 blocks of a living camp, else "". Market fee is waived while `{za::reseau::commerce}` is true.
Weapons from za_p49 carry lore (tier/state/origin): show it; price history by item name. After writing, reload both za_p47_marche and
za_p48_ressources on the test server and make sure both load clean. Test buy/sell logic from console as much as possible (e.g. an admin
command that simulates a listing with a given item and fake seller uuid). No item duplication possible. Report as in the brief.
