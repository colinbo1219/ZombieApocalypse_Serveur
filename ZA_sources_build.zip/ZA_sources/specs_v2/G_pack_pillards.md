# Agent G — Pack joueurs v1.4 : pillards humains (client resource mod)
Context: the client mod `za_modeles` (Forge 1.20.1 resource mod using Entity Model Features 3.3.9 + Entity Texture Features 7.2.4)
turns villagers into humans and gives skins by entity name (see `/home/claude/za_build/skins/LISEZMOI.md`, tooling in
`/home/claude/za_build/skins/`: `gen_modeles.py` (EMF .jem generation: `villager_jem()`, `humanoid_jem()`, `zombie_jems()`),
`gen_peaux.py` / `peaux_*.py` (procedural 64×64 skins), `build.py`, `mkjar.sh` (builds from base `/tmp/zm` = za_modeles 1.1.0 content + `out/`)).
The CURRENT full client jar (skins + sounds + fonts) is `/home/claude/za_build/modeles/za_modeles-1.2.0.jar` (it's what players have, via the
CurseForge pack `/home/claude/za_build/ZombieApocalypse_Joueurs_CurseForge_v1.3.zip`, builder in `/home/claude/za_build/pack/`).

Goal: new hostile humans exist on the server (MythicMobs): `ZA_Pillard` = VINDICATOR named "Pillard" (iron axe) and
`ZA_Pillard_Tireur` = PILLAGER named "Pillarde" (crossbow) (file `/home/claude/za_build/mm_new/ZA_Humains.yml`). Make them look like
HUMAN raiders on the client:
1. EMF models for `vindicator` and `pillager` (and `illusioner`/`evoker` untouched) → the same human silhouette as our villager humans
   (64×64 player-like skin with outer layers), normal human arms: hide the crossed-arms part, show left/right arms always, arms swing
   when walking (limb_swing), attack/aim poses still readable (pillager aiming crossbow: keep vanilla arm rotations when charging/aiming
   if possible; vindicator: raise right arm when attacking). Hide the illager nose. Held items must still render in the hands.
   Consider scoping the replacement to named raiders only via ETF/EMF `.properties` name rules (regex `(§.)*Pillard.*`), so vanilla
   illagers elsewhere keep vanilla look — preferred if EMF supports variant models by name for these entities (it does via
   `optifine/cem/<entity>.properties` like zombie.properties in our pack).
2. 4–6 raider skins (procedural, same style as our skins): hockey mask, bandana + hood, leather jacket with spikes, gas mask + tactical
   vest, a woman with shaved side + scarf, a man with balaclava. Gritty, dirty, bloodstains. Chosen by name regex `Pillard.*`/
   `Pillarde.*` (stable per UUID random among them).
3. Build the new client jar `za_modeles-1.3.0.jar` = everything from the current 1.2.0 full jar + your additions (version 1.3.0 in
   mods.toml, description updated). Put it in `/home/claude/za_build/modeles/za_modeles-1.3.0.jar`. Then build the player pack
   `/home/claude/za_build/ZombieApocalypse_Joueurs_CurseForge_v1.4.zip` (same as v1.3 but manifest version 1.4 and the new jar in
   overrides/mods, old jar removed). Look at how v1.3 was built (`/home/claude/za_build/pack/`).
4. Verify in a real client: a test client exists (portablemc Forge, Xvfb): scripts in
   `/tmp/claude-0/-home-claude/11e94848-bd76-5e3f-a43b-90e28f9e6572/scratchpad/mc/` (`ctl.sh xvfb`, `ctl.sh client`, `ctl.sh shot <name>`,
   `say.sh "/cmd"`). The client's mods folder is `.../scratchpad/mc/work/mods/` (replace za_modeles-1.2.0.jar by your 1.3.0 jar for the
   test). Local test server (Arclight) is running on 127.0.0.1:25565: send console commands with
   `cd /tmp/claude-0/-home-claude/11e94848-bd76-5e3f-a43b-90e28f9e6572/scratchpad/arc && sh c.sh "<cmd>" <secs>`. The client logs in as
   "Tester". After the client connects (it may show a server list: click to join — earlier we used `xdotool` click (639,417) then
   double-click (600,175) on DISPLAY=:99), spawn raiders near Tester (`mm mobs spawn ZA_Pillard 1 world,x,y,z`, `execute at Tester ...`),
   make Tester creative + invulnerable (`gamemode creative Tester`, `effect give Tester resistance ...`), take screenshots from a few angles
   (walking, attacking, aiming) and iterate until it looks good. Other agents share the server (only via console, Skript reloads): don't
   restart the server; do not `sk reload all`. Keep screenshots of the final result in
   `/home/claude/za_build/specs_v2/G_captures/` (PNG). Don't break the existing villager humans / zombie models (check one villager too).
Report: what you built, file paths, screenshots, known limitations.
