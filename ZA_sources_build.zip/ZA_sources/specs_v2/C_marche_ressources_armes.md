# Agent C — Marché entre joueurs (#5) + Ressources stratégiques de saison (#6) + Progression des armes (#11)
Files to create: `za_p47_marche.sk`, `za_p48_ressources.sk`, `za_p49_armes.sk` (in /home/claude/za_build/skript/).
Read /home/claude/za_build/BRIEF_AGENTS.md first. You MAY minimally edit the convoy chest code in `za_p39_monde_vivant.sk`
(the `item replace ... tacz:modern_kinetic_gun` lines) to use your weapon command (copy to /home/claude/za_build/skript_bak/ first).

## Marché (#5)
`/marche vendre <prix>` (item in hand; listing fee 2 jetons; 5 %% sale tax as a jetons sink), `/marche` (paginated chest GUI, 6 rows:
45 listings + nav; each shows the real item + lore "Prix : X jetons · Vendeur : Y · expire dans Z j"), click → confirmation (`za_menu`
or your own small GUI) → purchase: jetons transferred to the seller even offline (`{za::jetons::<uuid>}`), item to buyer (inventory
full → dropped at feet or put in "à récupérer"). `/marche mes` (own listings; cancel returns the item), `/marche recuperer`
(expired/unsold items), `/marche prix` (item in hand → average of the last 10 sales of that item name/type + number of listings;
"PÉNURIE" when none listed and recent demand). Notable sales (≥ 300 jetons) announced: "&6[Marché] &fM4A1 — Convoi Bravo-3 &7vendue
&6850 jetons". Max 10 listings per player, expire after 7 server days. Store items as Skript item variables (they keep NBT, incl. TaCZ).
Anti-dupe: remove the exact item from the player before creating the listing; verify ownership; handle double clicks; log to
`za_economie.log` via `za_audit`.
Where: buying/selling only at a market place: the Marché de la Trêve (`{za::treve::loc}`, radius 18, za_p40) or any living camp
(`{za::camp::liste::*}`, `{za::camp::<id>::loc}`, radius 25, `{za::camp::<id>::etat}` is "vivant" — another module; if none exist,
only the Trêve). Browsing (read-only) anywhere. Stats `ventes_marche`, `achats_marche` (seller/buyer uuid).

## Ressources stratégiques de saison (#6)
Resource by `{za::saison::num}`: 1 "Composant electronique" (existing item name — keep it exactly, no accent), 2 "Échantillon viral",
3 "Carburant militaire", 4 "Matériau expérimental", then cycle. Publish `{za::ressource::nom}` (update on load and when the season number
changes). Rare sources: kills of ZA_Alpha/ZA_Brute/ZA_Soldat_Infecte/ZA_Armored (5–10 %%), first opening per server day of a chest inside a
za_p35 building (`za_bat_proche(loc, 12)`), convoy crates, labos. Uses: (1) collective "Dépôt de saison" at the Trêve or a camp chief:
`/ressource deposer [n]` → `{za::ressource::depot}` total, contributor counts; milestones 25/50/100/200 → server-wide bonuses (prices −5 %%
via `{za::eco::mult}` carefully, camps sécurité +10 (write `{za::ressource::bonus_camps}`), an extra supply drop, and
`{za::ressource::bonus_pct}` 0–10 that the season % will include — report it so the lead wires it into za_p41); (2) the power plant already
needs 3 "Composant electronique" (za_p39) — keep that; workshops (another module) will read `{za::ressource::nom}`; (3) high market value.
`/ressource`: current resource and lore ("Pourquoi ça compte"), where to find it, your count, depot progress, top 3 contributors (title
"Pourvoyeur de la saison" for #1 at season end: store `{za::ressource::top::<saison>}`).

## Armes (#11)
Tiers by TaCZ gun id: Niveau 1 Civil (glock_17, m1911, cz75, m9a4, p320, taurus943, db_short, db_long, springfield1873, rhino357),
2 Militaire (m4a1, ak47, m870, ump45, hk_mp5a5, uzi, sks_tactical, m16a4, m16a1, spas_12, m1014, type_81, kar98, m700, hk_mk23, b93r,
deagle), 3 Avancé (hk416d, scar_l, scar_h, aug, g36k, vector45, p90, mk14, fn_fal, hk_g3, rpk, m249, aa12, qbz_95, qbz_191, spr15hb,
lonetrail), 4 Expérimental (ai_awp, m107, m95, minigun, rpg7, m320, fn_evolys, timeless50, deagle_golden, taurus500).
Lore on the gun item (added automatically the first time a player holds/picks it up; keep existing lore): "&7Niveau 2 — Militaire",
"&7État : 87 %%" (colored), "&8Origine : Trouvée", "&8Abattus : 12", optional "&6Pièce de collection". Condition drops with zombie kills
made while holding it (tier 1: −1 %%/kill … tier 4: −0.3 %%), faster in acid rain events. At 0 %% the gun jams: replace it with a
placeholder "&8<Nom> — enrayée" (iron ingot) and keep the real item in `{za::arme::enrayee::<serial>}` (serial number in lore) — repairing
gives it back at 100 %%. Repair: `/arme reparer` near the Mécano merchant (villager named "Le Mecano" within 8 blocks) or through console
`zaarme reparer <joueur>` (another module's "Atelier mécanique" calls it): cost jetons by tier (8/15/30/60), tier 3–4 also need
"Ferraille" ×2 (new item: dropped by ZA_Armored/ZA_Shielded/ZA_Brute, or from dismantling vanilla iron tools with `/arme demonter`).
Collection weapons: console `zaarme donner <joueur> <gunid> <origine…>` gives a gun with story lore ("M4A1 — Convoi Bravo-3",
"N° de série BR3-0412", "Ayant appartenu à : Caporal A. Dumas") and "&6Pièce de collection"; `zaarme coffre <x> <y> <z> <monde> <gunid>
<origine…>` puts one in a container. Use it in the convoy chests (za_p39) with origins like "Convoi Bravo-3". Collection guns are worth
more (market shows the lore).
Specialized ammo: TaCZ ammo mods as attachments (`tacz:ammo_mod_fmj/hp/he/i/slug`) + optics/silencers are tier 3–4 loot:
add them to rare sources you control (Alpha/Brute kills, bunker/enigmas can call your give command `zaarme accessoire <joueur> <id>`).
`/arme`: info on the held gun (tier, state bar, kills, origin, serial); `/arme reparer`; `/arme demonter`. Admin `/zaarme ...` (console).
Report: files, commands, variables, stat keys, hooks, what's untested.
