# Agent D — Réseau électrique (#7) + Mécaniques par lieu (#8) + Ateliers spécialisés (#13) + Blessures localisées (#12)
Files to create: `za_p50_reseau.sk`, `za_p51_lieux.sk`, `za_p52_ateliers.sk`, `za_p53_blessures.sk` (in /home/claude/za_build/skript/).
Read /home/claude/za_build/BRIEF_AGENTS.md first. Do not edit other files.

## Réseau électrique (#7)
Existing: the power plant (za_p39: lectern at a `centrale` building, 3 "Composant electronique" → `{za::elec::fin}` = now + 3 days,
`za_courant()` true while powered, activity near plants, prices ×0.9). Add districts: `hopital`, `police`, `commerce`, `residentiel`.
Capacity 2 districts per power cycle, +1 per extra season resource contributed at the plant (`{za::ressource::nom}` if set, else
"Composant electronique"; max 4). Choice: the player who restarts the plant gets a `za_menu` to pick districts; afterwards any player
can `/reseau voter <quartier>` (1 vote per player per cycle; each server day the top-voted districts get the capacity). Publish booleans
`{za::reseau::hopital|police|commerce|residentiel}` (false when no power). `/reseau` shows state (powered districts, capacity, votes, time
left). Radio announcements when the grid changes ("Le quartier résidentiel est rebranché.").
Effects while powered: hopital → hospital buildings get a working "Poste de soins" (see Lieux) and Antibiotique recipes cheaper in
workshops; police → armory lockers restock daily at police buildings + perimeter alarms warn base owners when a horde/zombies approach
their base (message + sound); commerce → nomad merchant prices −15 %% (use a multiplier variable; restore exactly when unpowered;
coordinate with `{za::eco::mult}` which za_p39 already multiplies by 0.9 — prefer a separate factor you apply/restore precisely) and the
market fee is waived (`{za::reseau::commerce}` is read by the market module); residentiel → camps and base survivors get moral/security
bonuses (other modules read `{za::reseau::residentiel}`) and bases get lights (optional). Powered districts attract the dead:
`za_activite_ajouter(<building center>, n)` periodically for powered building types.

## Lieux (#8) — each building type has its own mechanic
Use `za_bat_liste(type)` / `za_bat_centre(key)` / `za_bat_proche(loc, r)`. When a player enters within ~12 blocks of a building center:
action bar once per visit, e.g. "&f[Hôpital] &7Médicaments · Soins · Dossiers médicaux". Per-building daily state (server day) for restocks.
- Hôpital: "Dossiers médicaux" (right-click the lectern inside) → lore snippet about a patient (Z-01 hints) + chance of Antibiotique;
  "Poste de soins" (brewing stand) works only if `{za::reseau::hopital}`: 5 jetons → full heal + infection stage −1 (look at za_infection.sk
  variables, e.g. `{za::infection::<uuid>}`) ; spawns of ZA_Patient_Infecte nearby.
- Police: locked "Armoire à armes" (a chest you place/tag at the building on first visit) opened with "Clé de l'armurerie" (drops from
  ZA_Soldat_Infecte 8 %%, police lockers) → TaCZ pistol + 9mm ammo (use console `zaarme donner <joueur> glock_17 Poste de police` from the
  weapons module; it's fine if absent during your tests); "Dossiers de police" (lore + coordinates hint to an existing stash/enquête);
  cells with a prisoner once per building: console `zasurv creer <x> <y> <z> <monde> prisonnier` (survivors module) after opening the cell
  with the key.
- École: hidden survivors' notes (lore), cafeteria food (canned goods) restock, children's drawings (books) that tell the story.
- Laboratoire (labo2): "Échantillon viral" and "Sang infecte" samples, experiments (risk: spawn ZA_Spitter/ZA_Bloater), rare
  "Matériau expérimental".
- Supermarché: food (some rotten — za_p11 rot rules), shopping carts (decor), a "Réserve" door that needs a crowbar ("Pied-de-biche", iron ingot
  named) → more food; noise when forcing (za_bruit_ajouter).
- Station-service: pump (e.g. a cauldron or iron block tagged as "Pompe") → right-click with "Jerrican" (new item) → "Essence" ×2,
  3 times per server day per station, noise +; explosion risk if shot (optional).
- Caserne: military crates (ammo, armor, rare tier-2/3 gun via `zaarme donner`), guarded by ZA_Soldat_Infecte.
- Centrale: electricity (existing + your grid).
`/lieux`: what each place is for ("Je vais là parce que je cherche X").

## Ateliers (#13)
Built by players inside their base (`{za::base::<uuid>}`, radius 40): `/atelier creer <medical|militaire|mecanique|laboratoire|electronique>`
while looking at the right block (médical: brewing stand; militaire: smithing table; mécanique: anvil; laboratoire: cauldron; électronique:
loom) + cost (jetons + materials; higher levels need the season resource `{za::ressource::nom}`). Level 1–3 (`/atelier ameliorer`).
Right-click the workshop block → `za_menu` of recipes (greyed "!" when missing materials/level/power). Suggested recipes:
Médical: Bandage (paper+string), Attelle (stick+paper+string, for wounds), Antibiotique (honey bottle + Échantillon viral or Sang infecte),
Sérum avancé (L3: 2 Serum + 1 Échantillon viral → cures stage 3). Militaire: TaCZ attachments (scopes/silencers/grips/mags via
`give ... tacz:attachment{AttachmentId:"tacz:..."}`), ammo crafting (gunpowder + iron nuggets → 9mm/556x45/12g). Mécanique: repair held gun
via console `zaarme reparer <joueur>` (weapons module), repair vanilla tools/armor, barricade planks. Laboratoire: analyse de souche (tells
the local strain via `za_souche_nom(za_souche_id(p))`), "Vaccin expérimental" (20 min infection immunity: set a flag the infection
script respects if possible — check za_infection.sk for an existing immunity/antidote variable), research notes (lore). Électronique:
"Radio portable" (item), "Alarme de périmètre" (placed block warns the base owner when zombies within 24 blocks), "Capteur" (warns when a
player enters the base), requires season resource at L2+. Some recipes require power: a running generator near the base (look at
za_p14_generateurs.sk for how a generator's running state is stored) or `{za::reseau::residentiel}`. Stat `ateliers` (+1 per craft).

## Blessures localisées (#12)
On damage (guard `za_pro(victim)`), pick a body part by cause: fall → jambe; projectile → by relative hit height if available else random;
zombie melee → bras 35 %% / torse 35 %% / tête 15 %% / jambe 15 %%; explosion → torse. Only for meaningful hits (≥ 3 damage or crits) and with a
cooldown so it's not spam. Two severities (légère → grave on repeat). Effects: Bras → weakness + mining fatigue ("tes mains tremblent");
Jambe → slowness I/II; Torse → saignement: 0.5 heart every 7 s + red particles until a Bandage is used; Tête → nausea + darkness pulses.
Store per player `{za::bless::<part>::<uuid>}` (0/1/2). Treatments: Bandage (right-click in hand or through `/blessures soigner`) stops
bleeding; "Attelle" fixes bras/jambe (légère; grave needs a doctor); tête heals with sleep or a doctor. Médecin role (`za_role(p)` =
"medecin") can `/blessures soigner <joueur>` (within 4 blocks) to fix everything on someone else; camp doctors and base survivors call
console `zablessure soigner <joueur>` (implement it: heals all wounds). `/blessures`: a small body diagram in chat
("[Tête] ok  [Bras] légère  [Torse] SAIGNE  [Jambe] grave"). Don't conflict with za_p27 plaie infection (different concept; mention it).
Stat `blessures_soignees` +1 for the healer.
Report: files, commands, variables, stat keys, hooks, what's untested.
