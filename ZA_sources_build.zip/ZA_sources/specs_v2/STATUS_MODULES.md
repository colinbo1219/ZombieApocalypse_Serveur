# Modules already written (use their console commands; they are loaded on the test server)
- za_p42_noyau.sk (shared helpers, see brief)
- za_p43_survivants.sk — `zasurv creer <x> <y> <z> <monde> [metier|prisonnier|enfant]`, `/survivants`, vars `{za::surv::*}`, `{za::base::gardes::<uuid>}`
- za_p44_camps.sk — camps `{za::camp::liste::*}`, `{za::camp::<id>::loc|nom|pop|nourriture|securite|moral|contam|etat}` (etat "vivant"|"abandonne"|"mort"),
  `zacamp attaque <id> <zombies|pillards>`, `/camps`
- za_p45_territoires.sk — `{za::terr::<type;index>::fac|ctrl}`, `/territoires`, `zaterr ...`
- za_p46_relations.sk — trust `{za::rel::<lefort|vega|lea>::<uuid>}`, `/relations`
- za_p48_ressources.sk — `{za::ressource::nom}` (season resource item name), `zaress coffre <x> <y> <z> <monde> [n]` (puts resource in a container),
  `zaress donner ...`, `/ressource`. It CALLS `za_mk_lieu(loc) :: text` which must be defined by the market module (za_p47_marche.sk):
  returns the name of the market place the location is in ("Marché de la Trêve" or the camp name) or "" if none.
- za_p49_armes.sk — `zaarme donner <joueur> <gunid> <origine…>`, `zaarme coffre <x> <y> <z> <monde> <gunid> <origine…>`,
  `zaarme accessoire <joueur> <id|rare|fmj|hp|he|i|slug>`, `zaarme reparer <joueur> [remise %]`, `/arme`
- za_p50_reseau.sk — `{za::reseau::hopital|police|commerce|residentiel}` booleans, `/reseau`
- za_p51_lieux.sk — building mechanics, `/lieux`
- za_p53_blessures.sk — `zablessure soigner <joueur>`, `/blessures`
Missing (to write): za_p47_marche.sk, za_p52_ateliers.sk, za_p54–56 (agent E), za_p57–59 (agent F).
