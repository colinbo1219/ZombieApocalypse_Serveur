# Agent F2 — Après-saison (#21) + Évolution des saisons (#22) + branchements de fin de saison
Write `/home/claude/za_build/skript/za_p59_saisons.sk` and make the minimal edits allowed in `za_p22_saison.sk` / `za_p41_saison_finale.sk`
(copy them first to /home/claude/za_build/skript_bak/). Read /home/claude/za_build/BRIEF_AGENTS.md, /home/claude/za_build/specs_v2/STATUS_MODULES.md,
then the "Après-saison (#21)" and "Évolution des saisons (#22)" sections of /home/claude/za_build/specs_v2/F_succes_memoire_saisons.md.
ALREADY DONE (don't redo): za_p57_succes.sk (achievements; has `za_succes_finale_saison(n)`), za_p58_memoire.sk (memorials; has
`za_memoire_hall(n)` and `za_memoire_noms()`; its header says what it expects to be called from the ceremony). Wire them into
`za_saison_ceremonie` (za_p41) if not already wired, store the hero `{za::saison::heros::<n>}` and `{za::apres::debut}` there, record the season
chronicle `{za::histoire::saison::<n>::*}`, implement `za_apres_ligne(npc) :: text`, `/chroniques`, themes S1–S4 with `{za::theme}` +
parameters, S2 pillard raids (ZA_Pillard / ZA_Pillard_Tireur; `zacamp attaque <id> pillards`), new-season title card + Léa monologue (on join
if offline), admin `/zasaison ...`. Publish `{za::apres::mult}` and `{za::theme::zombies_mult}` (the lead wires them into the random spawner).
Reload on the test server until clean; test the admin commands (simulate a ceremony and a season change on the test server: it's a test
world, that's fine). Report as in the brief.
