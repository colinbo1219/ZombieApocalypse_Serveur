# Agent E2 — Énigmes (#9) + Chasse au trésor (#10) + Enquêtes (#15) only
Write `/home/claude/za_build/skript/za_p54_enigmes.sk`. Read /home/claude/za_build/BRIEF_AGENTS.md, /home/claude/za_build/specs_v2/STATUS_MODULES.md,
then the Énigmes / Chasse au trésor / Enquêtes sections of /home/claude/za_build/specs_v2/E_enigmes_catastrophes_ia.md. The catastrophes and
zombie-AI parts are ALREADY DONE (za_p55_catastrophes.sk, za_p56_zombies_ia.sk) — don't redo them. Also already done since STATUS was written:
za_p47_marche.sk (market), za_p52_ateliers.sk (workshops), za_p57_succes.sk (achievements: it reads stats `enigmes`, `tresors`, `enquetes`),
za_p58_memoire.sk. Rewards via `zaarme donner`, `zaarme accessoire`, `zaress donner`/`zaress coffre`, survivors via `zasurv creer`.
"Fragment de carte C" can also come from camps (add it yourself as a rare drop on Alpha / Caporal Dumas kills; camps are optional).
Reload on the test server until clean; test admin/console commands (spawn a puzzle, a scene, a bunker near coordinates you choose, far from
0,0 where other tests happen). Report as in the brief.
