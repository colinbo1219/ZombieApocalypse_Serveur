# Agent E — Énigmes (#9) + Chasse au trésor (#10) + Enquêtes (#15) + Catastrophes (#16) + Zombies intelligents (#17) + Adaptation (#18)
Files to create: `za_p54_enigmes.sk` (énigmes + trésor + enquêtes), `za_p55_catastrophes.sk`, `za_p56_zombies_ia.sk`
(in /home/claude/za_build/skript/). Read /home/claude/za_build/BRIEF_AGENTS.md first.
If you need new MythicMobs mobs/skills, put them in NEW files `/home/claude/za_build/mm_new/ZA_IA.yml` (Mobs) and
`/home/claude/za_build/mm_new/ZA_IA_skills.yml` (Skills) and copy them to the test server `plugins/MythicMobs/Mobs/` and `.../Skills/`
then `mm reload` (don't edit ZombieApocalypse.yml). You may edit `za_p36_apparitions.sk` minimally (copy to skript_bak first).

## Énigmes (#9)
Max 2 active puzzles. A puzzle = locked "Coffre scellé — NORDA" (chest + sign) inside a za_p35 building or a ruin; needs the key "Clé de
casier n°<N>" (placed in a chest of another building, e.g. police/caserne) AND a 4-digit code on "Dossier — casier <N>" (placed in a
contaminated room: a building/ruin with high contamination `{za::contam::<ckey>}` or near a nest). Hints chain: a first "Note de
survivant"-style note found in normal loot/zombie drops points to the key's building (direction + rough distance, "vers le nord-est, à 200
pas"); the key's chest holds a note pointing to the dossier. Open: right-click the chest holding the key → keypad `za_menu` (digits) or
`/code ####`. Reward: rare loot (tier-3 gun via console `zaarme donner <joueur> <gunid> Coffre NORDA` from the weapons module, season
resource `{za::ressource::nom}`, jetons, a "Fragment de carte"). Stat `enigmes`.

## Chasse au trésor (#10)
"Fragment de carte A/B/C" (paper, lore = piece of a hand-drawn map + part of the coordinates). One fragment each from different activities:
A = a solved puzzle, B = an enquête, C = rare drop from an Alpha/Caporal Dumas or a camp trade. `/carte assembler` with A+B+C in inventory →
"Carte du bunker" (approximate coordinates ±30) + a compass objective/hint. Bunker: generated underground at 400–900 blocks from spawn
(console fills: concrete rooms, iron door, lights, lockers, 3 chests, a lectern "Terminal Z-01" with lore, guards ZA_Soldat_Infecte + an
Alpha). Nobody knows the contents: random tier-4 gun (`zaarme donner`), accessories (`zaarme accessoire <joueur> <id>`), season resource,
big jetons, "Matériau expérimental". One active bunker; when looted → radio "Le bunker ... a été pillé" and a new hunt starts after 3 server
days. Stat `tresors`.

## Enquêtes (#15)
Crime scenes (max 1–2 active) generated near buildings/ruins: 5–7 clues as placed things registered by location (blood = red carpet/
redstone, douilles = small item frames/armor stands with an item, journal = lectern book, plaque d'identité, radio (note block/jukebox),
corpse = bone block + skull, key, scribbled coordinates). Right-click a clue to examine → description + entry in `/enquete` (notebook).
All clues found → deduction `za_menu` with 3 hypotheses; right → secret location (stash with loot, or a survivor via console
`zasurv creer <x> <y> <z> <monde>` from the survivors module, or fragment B); wrong → the trail goes cold (small reward). At least 6 scenario
templates (embuscade de pillards contre un convoi, fuite d'une chercheuse de NORDA, famille cachée avec un enfant, dernier combat d'un
policier, trahison entre survivants, dissimulation NORDA/Z-01). Stat `enquetes`.

## Catastrophes (#16) — new world events (check za_p3_evenements.sk flags `{za::evt::...}` so they don't overlap)
Brouillard dense (darkness pulses + message; zombies/Stalkers spawn closer; 10–15 min), Pluie toxique (rain; players under open sky
(`highest block at` above them lower than them) without "Masque a gaz" helmet get poison/infection risk; chunk contamination +),
Tempête (thunderstorm; noise of players halved — see za_p24 noise variables — lightning), Canicule (thirst faster / heat damage outside
in daytime without water nearby; respect Tough As Nails mode `{za::tan}`), Froid extrême (night; need fire nearby `za_pres_du_feu(p)`
or be indoors; slowness/damage otherwise), Nuit anormale (dark red night: time locked around midnight ~6 min, Stalkers/Alphas spawn,
`za_danger` +). Random every 2–4 server days, 1-minute radio warning ("Environnement Canada — alerte..." or Léa), title card, end message.
`/meteo`: current catastrophe + vague forecast. Admin `/catastrophe <nom|stop>` (console-usable).

## Zombies intelligents (#17) — behaviors for existing types (check existing MM skills: ZA_Scream, ZA_AlphaBuff, ZA_BloaterBurst)
Screamer: when it sees a player within 20 blocks → calls the horde: zombies within 48 blocks target that player, spawn 3–5 more, activity +.
Stalker: follows a player at 12–20 blocks, only closes in when the player isn't looking at it (angle between player look vector and
direction to the stalker > 60°), teleports behind the player if stared at for 2 s, hits from behind (bonus damage). Charognard: NEW zombie
`ZA_Charognard` (display "Charognard") that goes to player corpses (za_p13 corpse locations) and eats them (removes loot, heals, grows),
spawns near fresh corpses at night. Alpha: zombies within 16 blocks get speed/strength and copy the Alpha's target; killing the Alpha
breaks the pack (they scatter briefly). Bloater: on death leaves a toxic zone for 20 s (green particles, poison + infection risk without
gas mask, contamination +). Keep it performant: iterate zombies around players only, every 2–5 s.

## Mutations adaptatives (#18)
Track (rolling 3 server days) server-wide: kills with TaCZ guns vs melee, light sources placed (torch/lantern/glowstone/sea lantern),
time players spend inside their base radius at night, TNT/explosions. Each server day decide the dominant habit → adaptation (announce with
Léa radio when it changes, vague wording): guns → more ZA_Armored/ZA_Shielded; lights → "Phototropes" (zombies spawning near lit bases at
night); base camping → more frequent sieges (`za_siege_base(uuid)`); melee → more Runners/Leapers; explosions → more Screamers/Brutes.
Implement via weights in za_p36_apparitions.sk (minimal edit) or your own small extra spawner (respect `{za::calme::fin}`, zone morte,
per-player caps). `/adaptation`: what the dead have learned (text, not numbers). Admin `/zaadapt etat|forcer <habitude>`.
Report: files, commands, variables, stat keys, hooks, what's untested.
