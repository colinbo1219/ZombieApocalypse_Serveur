# Agent D2 — Ateliers spécialisés (#13) only
Write `/home/claude/za_build/skript/za_p52_ateliers.sk`. Read /home/claude/za_build/BRIEF_AGENTS.md, then the "Ateliers (#13)" section of
/home/claude/za_build/specs_v2/D_reseau_lieux_ateliers_blessures.md (grid, places and wounds are ALREADY DONE in za_p50/za_p51/za_p53 — don't redo
them), and /home/claude/za_build/specs_v2/STATUS_MODULES.md (use `zaarme reparer <joueur>`, `zaarme accessoire`, `zablessure soigner`,
`{za::ressource::nom}`, `{za::reseau::*}`; grep za_p53 for the "Attelle" item name it expects and craft exactly that name).
Reload on the test server until it loads clean; test the admin/console commands. Report as in the brief.
