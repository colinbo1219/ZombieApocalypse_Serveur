# Brief for sub-agents — ZombieApocalypse server (Skript 2.9.5 on Arclight 1.20.1)

You are adding gameplay systems to a French-language Minecraft zombie-apocalypse server. The owner (Colin, Québec)
wants something "insane", polished and coherent. All player-facing text is in **French** (Québec-friendly,
proper accents: é è à ç ô …). Code comments in French too (short).

## Where things are
- Deploy source of truth for scripts: `/home/claude/za_build/skript/*.sk` (46 existing + `za_p42_noyau.sk`).
  Write your NEW files there with the exact names you were assigned. Do NOT edit other agents' files.
  Only edit existing files if your assignment explicitly allows it (keep edits minimal, keep a `.bak` copy first:
  `cp file.sk /home/claude/za_build/skript_bak/file.sk` — create the folder if needed).
- Local test server (Arclight + Skript + MythicMobs, same mods as production):
  `S=/tmp/claude-0/-home-claude/11e94848-bd76-5e3f-a43b-90e28f9e6572/scratchpad/arc`
  - scripts folder: `$S/plugins/Skript/scripts/` → copy your file there to test.
  - send a console command and read the log lines produced: `cd $S && sh c.sh "sk reload za_p43_survivants" 8`
    (2nd arg = seconds to wait). The output is every log line since the command (other noise included: filter with grep).
  - Reload ONLY your own file(s): `sk reload <name-without-.sk>`. NEVER `sk reload all` (freezes the server ~60 s).
  - Other agents use the same server at the same time: ignore their log lines; don't restart the server; don't
    touch the in-game client (a test player "Tester" may be online — don't teleport/kill/modify it).
  - A clean load prints `Successfully reloaded <file>.sk`. Any `error` line = fix it. Warnings: fix if easy.
  - You can exercise your commands from console (commands usable by console) and read results in the log.
- Existing scripts to read for context (grep them, don't read everything): see "Existing systems" below.

## Skript 2.9.5 rules & pitfalls (learned the hard way — follow them)
- Every event handler that concerns a player/entity must start with the prologue guard:
  `if za_pro(player) is true: stop` (or `victim`, `attacker`, `loop-player`). The world `za_prologue` is a private
  story instance and must never be touched by survival systems. Use `za_monde_joueurs()` instead of `all players`
  for "players in the survival world", and `za_diffuser("...")` instead of `broadcast`.
- A function that hits a `wait` returns immediately to its caller (the rest runs later). Plan for it.
- Nested loops: `loop-value-1` / `loop-value-2` only when the loops are of the same kind; `loop-number-2` is INVALID
  and `loop-player-2` is invalid if there is only one player loop. Prefer `while` loops with counters for numeric nesting.
- In strings `%` must be written `%%` (e.g. "50 %%"). Options `{@x}` expand inside strings.
- UTF-8 accents work in strings. Colors with `&` codes in `send "..."`.
- To compare item names use `uncolored name of <item>`. Create named items ONLY with
  `za_item("<minecraft material in Skript words>", "Nom", "&couleur", quantité)` (e.g. `za_item("paper", "Bandage", "&f", 3)`).
  Use `za_count_named(p, "Nom")` / `za_take_named(p, "Nom", n)` (compare uncolored names).
- Vanilla/modded commands: `execute console command "..."` (double quotes inside are `""`). Potion effects:
  `za_effet(p, "slowness", secondes, niveau)`.
- Chest GUIs: use the shared menu `za_menu(...)` (see below) instead of writing your own when possible.
- Placing many blocks: `execute console command "execute in %za_dim(world)% run fill ..."` or `set block at ... to ...`.
- Avoid heavy periodic work: `every N seconds` handlers should be ≥ 5 s and loop over players or your own lists,
  never over all entities of the world every second. Keep lists bounded (max counts).
- Variables: global persistent `{za::<module>::...}`. Per-player data keyed by uuid string: `set {_u} to "%player's uuid%"`.
  Local `{_x}`. Don't collide with existing names (grep before choosing).
- Time: `{za::serveur::jours}` = server day counter (+1 every 20 real minutes = one Minecraft day). Use it for
  game-day logic ("dans 3 jours"). Real timespans (`now`, `difference between x and now`) for cooldowns.
- Custom commands: `command /x [<text>] [<player>]:` + `trigger:`. Console-only helper commands:
  `executable by: console`. Admin: `permission: za.admin`. Commands must work from console where it makes sense.
- Sounds (client resource pack is installed on players): `za_zm("son %player% <clé> <vol> <pitch>")`. Useful keys:
  `za_modeles:sfx.radio_statique`, `sfx.sting_danger`, `sfx.sting_revelation`, `sfx.horde_grondement`, `sfx.coeur`,
  `sfx.alarme_auto`, `sfx.helico`, `sfx.camion`, `sfx.bourdon_electrique`, `sfx.coup_de_feu`, `sfx.cri_foule`,
  `sfx.radio_accord`, `sfx.porte_grince`, `sfx.pas_course`; vanilla keys like `minecraft:ui.toast.challenge_complete`,
  `minecraft:block.note_block.bell`, `minecraft:entity.villager.yes` also work.
- Titles: `send title "&c&lTITRE" with subtitle "&7sous-titre" to player for 3 seconds`. Keep titles ≤ 18 characters
  (longer overflows the screen), put the rest in the subtitle.

## Shared helpers you should use (already loaded)
From `za_00_core.sk`: `za_pro(e)`, `za_monde_joueurs()`, `za_diffuser(m)`, `za_effet(p,e,s,l)`, `za_dim(w)`,
`za_spawn_near(p, "ZA_Type", dmin, dmax)`, `za_spawn_at(loc, "ZA_Type", dmin, dmax)`, `za_ckey(loc)`,
`za_jetons(p)`, `za_jetons_ajouter(p, n)` (currency "jetons", can be negative), `za_score(p)`, `za_rang(p)`,
`za_prix(p, base)`, `za_count_named`, `za_take_named`, `za_item`, `za_journal(txt)` (server lore log),
`za_decay(wd,x1,y1,z1,x2,y2,z2,force)` (abandoned look), `za_wrap(texte)` (lore lines).
From `za_p42_noyau.sk` (new, shared):
- `za_choix(uuid, clé)` / `za_choix_p(player, clé)` → prologue choices: keys `hopital` ("aide"/"fui"),
  `leblanc` ("sauvee"/"perdue"), `theo` ("appele"/"provisions"), `vega` ("obei"/"clandestin"); "" if unknown
  (players who skipped the prologue or joined before it).
- `za_stat_ajouter(uuid, clé, n)` / `za_stat(uuid, clé)` → per-player stats. Use these stat keys when relevant
  (the achievements module reads them): `survivants_sauves`, `survivants_recrutes`, `camps_aides`, `nids_seul`,
  `alpha_melee`, `enigmes`, `tresors`, `enquetes`, `ventes_marche`, `achats_marche`, `ateliers`, `blessures_soignees`,
  `territoires_defendus`, `nuits_dehors`.
- `za_menu(player, "<console command>", "Titre", "Texte du PNJ ou de la situation", ("Libellé 1|noeud1", "Libellé 2|noeud2", ...))`
  → opens a chest menu (max 7 options; prefix a label with "!" to show it greyed/unclickable). When clicked, the console runs
  `<console command> <player name> <noeud>` → define in your module:
  ```
  command /zasurvclic <player> <text>:
      executable by: console
      trigger:
          za_surv_noeud(arg-1, arg-2)
  ```
  Node "quit" just closes. Labels must be unique within one menu.
- `za_bat_types()`, `za_bat_nom(type)`, `za_bat_liste(type)` → keys "type;index", `za_bat_centre(clé)` → location,
  `za_bat_proche(loc, rayon)` → key or "". Building types (generated by `za_p35_batiments.sk` near players every few hours,
  small ~13×9 structures, stored as "bx_gy_bz_world" in `{za::bat::<type>::liste::*}`): `hopital`, `police`, `super`
  (supermarché / zone commerciale), `station` (station-service), `labo2` (laboratoire), `caserne`, `ecole`, `centrale`.
- `za_radio("&bLéa", "texte")` → radio message to all survival players (+ static sound + journal).
- `za_sol(loc)` → same x/z at ground level.

## Existing systems (don't duplicate; integrate)
- Factions & reputation (`za_p40_histoire.sk`): `za_faction_ajouter(p, "milice"|"scientifiques"|"marchands"|"pilleurs"|"survivants"|"culte", n)`,
  values in `{za::fac::<faction>::<uuid>}`; `/faction`. Special titles `{za::titre::special::<uuid>}`.
- Story NPCs (`za_p18_pnj.sk`): Dr Lefort, Sergent Vega, Léa (radio) — MythicMobs villagers `ZA_Survivant_Lefort/Vega/Lea`,
  dialogue functions `za_dial_lefort/vega/lea(p, node)` using `za_dial_ui` (chest menu). Lefort 7-part chain, Vega squad
  chain, Léa mystery in `za_p40_histoire.sk`.
- Bases (`za_p8_bases.sk`): `{za::base::<uuid>}` = base location (radius 40), `{za::base::liste::*}` uuids,
  sieges `za_siege_base(uuid)`. Roles (`za_p19_roles.sk`): `za_role(p)` → "medecin"|"soldat"|"eclaireur"|"ingenieur"|"aucun".
- Danger map & world reactions (`za_p39_monde_vivant.sk`): `za_danger(loc)` 0..4, `za_activite_ajouter(loc, n)`,
  nests `{za::nid::liste::*}`, `za_nid_creer(loc)`, convoy, `/extraction`, `/sos`, power plant `{za::elec::fin}`
  (date until which power is on), `za_courant()` (boolean, `za_p14`/generators), evolving places.
- Season (`za_p22_saison.sk`, `za_p41_saison_finale.sk`): `{za::saison::num}`, `za_saison_jours()`, `za_saison_pct()`,
  ceremony `za_saison_ceremonie(heros)`, soft reset `za_saison_finir()`; Hall of survivors.
- Economy (`za_p7_economie.sk`): jetons, `/troc`, `/contrat`, `/dette`, nomad merchants (MythicMobs villagers
  `ZA_Marchand_Charognard|Medecin|Trafiquant|Collectionneur|Mecano`, GUI `za_ouvrir_marchand`), black market.
- Infection (`za_infection.sk`, `za_p26_virus2.sk`), wounds/diseases (`za_p27_maladies.sk`: plaie, grippe, fièvre,
  hygiène, épuisement), temperature (`za_p15`), thirst/food/sleep (`za_p11`), noise (`za_p24_bruit.sk`: `za_bruit_ajouter(p, n)`),
  sanity/horror (`za_p4`), contamination per chunk (`za_p5`: `{za::contam::<ckey>}`), events (`za_p3_evenements.sk`:
  blood moon `{za::evt::bloodmoon}`, acid rain, etc.), weapon wear on vanilla weapons + `/reparer` near Mécano (`za_p23`),
  corpses (`za_p13`), legend/graves (`za_p30`), random zombie spawns with per-player cap (`za_p36_apparitions.sk`).
- Common item names already used: "Bandage", "Antibiotique", "Serum", "Antidote", "Sang infecte", "Jeton de Survie"
  (physical token item, gold nugget), "Composant electronique", "Essence", "Carte d'acces", "Note de survivant",
  "Masque a gaz", "Eau purifiee", "Fusée de détresse", "Plaque d'identité — <nom>", "Disque de données Z-01".
- MythicMobs zombies (spawn with `za_spawn_near/at` or `execute console command "mm mobs spawn <Type> 1 <world>,<x>,<y>,<z>"`):
  ZA_Shambler, ZA_Runner, ZA_Crawler, ZA_Spitter, ZA_Bloater, ZA_Leaper, ZA_Brute, ZA_Screamer, ZA_Stalker, ZA_Alpha,
  ZA_Armored, ZA_Shielded, ZA_FakeDead, ZA_Child, ZA_Soldat_Infecte, ZA_Citoyen_Infecte, ZA_Patient_Infecte (display names:
  "Shambler", "Runner", … "Alpha", "Zombie blindé", …). Hostile HUMANS (added now): ZA_Pillard (melee, VINDICATOR,
  display "Pillard") and ZA_Pillard_Tireur (crossbow, PILLAGER, display "Pillarde") — they also attack villagers.
- Friendly human NPCs = vanilla villagers with a CustomName (the client pack turns every villager into a human with a skin
  chosen by name: "Infirmière …" = nurse, "Soldat …" = soldier, "Médecin …" = street doctor, "Policier …" = police,
  "Le Mécano" = mechanic; ANY other name = one of 14 random citizen skins). Summon example:
  `execute console command "summon villager X Y Z {CustomName:'""Marc""',CustomNameVisible:1b,PersistenceRequired:1b,Invulnerable:1b,NoAI:0b,Silent:1b,VillagerData:{profession:""minecraft:none"",level:1,type:""minecraft:plains""},Tags:[""za_surv"",""za_surv_12""]}"`
  (JSON name inside single quotes; mind the doubled quotes in Skript strings). Find them later with
  `loop all villagers in radius R around LOC: if "%scoreboard tags of loop-entity%" contains "za_surv_12"`.
  Zombies attack villagers and convert them: keep your NPCs `Invulnerable:1b` unless a scripted fight wants otherwise.
- TaCZ guns: give with `execute console command "give %p% tacz:modern_kinetic_gun{GunId:""tacz:m4a1"",GunFireMode:""AUTO"",GunCurrentAmmoCount:0} 1"`,
  ammo `tacz:ammo{AmmoId:""tacz:556x45""} 60`, attachments `tacz:attachment{AttachmentId:""tacz:scope_acog_ta31""} 1`.
  Gun→ammo: glock_17/cz75/m9a4/b93r/uzi/hk_mp5a5 9mm; m1911/p320/hk_mk23/ump45/vector45 45acp; deagle/timeless50 50ae;
  rhino357/deagle_golden 357mag; m870/spas_12/m1014/aa12/db_short/db_long 12g; m4a1/hk416d/m16a4/aug/g36k/scar_l/m249/spr15hb 556x45;
  ak47/rpk/sks_tactical/type_81 762x39; scar_h/fn_fal/hk_g3/mk14/fn_evolys 308; m700/lonetrail 30_06; kar98 792x57;
  ai_awp 338; m107/m95 50bmg; p90 57x28; qbz_95/qbz_191 58x42; rpg7 rpg_rocket; m320 40mm; springfield1873 45_70.
  In Skript a TaCZ gun item's type is "tacz:modern_kinetic_gun" (`"%type of tool of player%" contains "modern_kinetic_gun"`).

## Quality bar
- Every feature must be reachable in normal play (not only by admin commands) and explained in-game (a help line in a
  player command, or clear messages). Provide an admin/test command for each big feature (`permission: za.admin`,
  usable from console).
- Coherent tone: grim, human, Québec setting (Saint-Aurèle, CKZA radio, Léa, Dr Lefort, Sgt Vega, NORDA Biotech, Z-01).
- Load clean (no errors) on the test server. Test your console commands. Report exactly: files created/modified,
  commands, variables used, stat keys incremented, hooks other modules could use, anything untested or risky.

## If the test server is down
The container can be recycled (all processes killed). If `pgrep -f "arclight-5dc8683.jar nogui"` prints nothing, run
`bash /tmp/claude-0/-home-claude/11e94848-bd76-5e3f-a43b-90e28f9e6572/scratchpad/arc/start.sh` (safe if several agents call it) and wait
until `server.log` shows `Loaded ... scripts` (~3 min). Your copied script files stay in the scripts folder.

## Final report format (keep it under ~60 lines)
Files created/modified · player commands · admin/console commands · variables published for others · stat keys incremented ·
hooks you expect from others (console commands you call) · what you tested and how · known limits/risks.

## Work efficiently (shared usage budget)
Grep instead of reading whole big files. Write your .sk files early and save progress often (the machine can be recycled; files in
/home/claude/za_build persist, running processes don't). Don't leave throw-away test scripts in the server scripts folder (delete them).
