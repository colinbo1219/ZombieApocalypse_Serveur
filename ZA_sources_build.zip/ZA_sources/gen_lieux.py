import json
p = json.load(open('ville/pois.json'))
out = ["# =====================================================================",
       "#  ZombieApocalypse - LIEUX DU PROLOGUE (genere automatiquement depuis pois.json, ne pas editer a la main)",
       "#  {za::pro::p::<nom>} = \"x;y;z;yaw;pitch\"  |  {za::pro::b::<nom>} = \"x1;y1;z1;x2;y2;z2\"",
       "# =====================================================================", "", "on load:"]
for k, v in p.items():
    if isinstance(v, dict) and 'x' in v:
        out.append(f'    set {{za::pro::p::{k}}} to "{v["x"]};{v["y"]};{v["z"]};{v.get("yaw",0)};{v.get("pitch",0)}"')
    elif isinstance(v, dict) and 'x1' in v:
        out.append(f'    set {{za::pro::b::{k}}} to "{v["x1"]};{v["y1"]};{v["z1"]};{v["x2"]};{v["y2"]};{v["z2"]}"')
    elif isinstance(v, list) and k == 'spawn_chaos':
        for i, pt in enumerate(v, 1):
            out.append(f'    set {{za::pro::p::chaos{i}}} to "{pt[0]};{pt[1]};{pt[2]};0;0"')
import math
h = json.load(open('ville/hall_pois.json'))
for i in range(1, 9):
    v = h['socle%d' % i]
    out.append(f'    set {{za::hall::socle::{i}}} to "{math.floor(v["x"])};{int(v["y"])};{math.floor(v["z"])}"')
for i, q in enumerate(h['plaques'], 1):
    out.append(f'    set {{za::hall::plaque::{i}}} to "{q[0]};{q[1]};{q[2]}"')
out += ["", "function za_lieu(n: text) :: location:",
        "    set {_s::*} to split {za::pro::p::%{_n}%} at \";\"",
        "    return location(({_s::1} parsed as number), ({_s::2} parsed as number), ({_s::3} parsed as number), world(\"za_prologue\"), ({_s::4} parsed as number), ({_s::5} parsed as number))",
        "",
        "# le joueur est-il dans la boite nommee ?",
        "function za_dans(p: player, n: text) :: boolean:",
        "    if za_pro({_p}) is false:",
        "        return false",
        "    set {_s::*} to split {za::pro::b::%{_n}%} at \";\"",
        "    set {_x} to x-coordinate of {_p}",
        "    set {_y} to y-coordinate of {_p}",
        "    set {_z} to z-coordinate of {_p}",
        "    if {_x} < ({_s::1} parsed as number):",
        "        return false",
        "    if {_x} > (({_s::4} parsed as number) + 1):",
        "        return false",
        "    if {_z} < ({_s::3} parsed as number):",
        "        return false",
        "    if {_z} > (({_s::6} parsed as number) + 1):",
        "        return false",
        "    if {_y} < (({_s::2} parsed as number) - 1):",
        "        return false",
        "    if {_y} > (({_s::5} parsed as number) + 2):",
        "        return false",
        "    return true",
        "",
        "# distance du joueur a un lieu (999 si autre monde)",
        "function za_dist(p: player, n: text) :: number:",
        "    if za_pro({_p}) is false:",
        "        return 999",
        "    return distance between {_p} and za_lieu({_n})",
        ""]
open('skript/za_p38_lieux.sk', 'w', encoding='utf-8').write('\n'.join(out))
print(len(out), 'lignes')
