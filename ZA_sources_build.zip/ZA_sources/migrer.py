# Migration des scripts existants pour le prologue (monde za_prologue) :
#  - broadcast -> za_diffuser(...) (les joueurs du prologue ne recoivent pas les messages du monde en ruine)
#  - "loop all players:" -> corps entoure de "if za_pro(loop-player) is false:"
#  - "size of all players" / "random element out of all players" -> za_monde_joueurs()
#  - gardes en tete des evenements joueurs
import re, sys, os, glob
D = sys.argv[1]
SKIP = {'za_00_core.sk'}  # le core est modifie a la main
GUARD = {
    'on join': 'player', 'on quit': 'player', 'on consume': 'player', 'on bed enter': 'player', 'on respawn': 'player',
    'on break': 'player', 'on place': 'player', 'on right click': 'player',
    'on damage of player': 'victim', 'on death of player': 'victim',
    'on death of zombie': 'victim', 'on damage of zombie': 'victim',
}
stats = {}
def ind(l): return len(l) - len(l.lstrip(' '))
for f in sorted(glob.glob(os.path.join(D, '*.sk'))):
    n = os.path.basename(f)
    if n in SKIP or n.startswith('za_p38') or n.startswith('za_p39') or n.startswith('za_p4') and n[5:6].isdigit() and int(n[4:6]) >= 38:
        continue
    L = open(f, encoding='utf-8').read().split('\n')
    out = []
    c = {'bc': 0, 'loop': 0, 'all': 0, 'guard': 0}
    i = 0
    while i < len(L):
        l = L[i]
        s = l.strip()
        # broadcast
        m = re.match(r'^(\s*)broadcast (.+)$', l)
        if m and not s.startswith('#'):
            l = f'{m.group(1)}za_diffuser({m.group(2)})'
            c['bc'] += 1
        # all players
        if 'size of all players' in l or 'random element out of all players' in l:
            l = l.replace('size of all players', 'size of za_monde_joueurs()').replace('random element out of all players', 'random element out of za_monde_joueurs()')
            c['all'] += 1
        # stopsound / particle @a
        l = l.replace('"stopsound @a ', '"execute as @a at @s if dimension minecraft:overworld run stopsound @s ')
        l = l.replace('"execute at @a run particle minecraft:ash ~ ~2 ~ 10 4 10 0 100 force @a"', '"execute as @a at @s if dimension minecraft:overworld run particle minecraft:ash ~ ~2 ~ 10 4 10 0 100 force @s"')
        # loop all players:
        if s == 'loop all players:':
            base = ind(l)
            out.append(l)
            out.append(' ' * (base + 4) + 'if za_pro(loop-player) is false:')
            j = i + 1
            while j < len(L) and (L[j].strip() == '' or ind(L[j]) > base):
                out.append(('    ' + L[j]) if L[j].strip() else L[j])
                j += 1
            # nettoyage : les lignes vides finales ne sont pas indentees
            i = j
            c['loop'] += 1
            continue
        out.append(l)
        # gardes d'evenements
        if re.match(r'^on [^:]+:\s*$', l):
            ev = l[:-1].strip() if l.rstrip().endswith(':') else l
            key = None
            for k in GUARD:
                if ev == k or ev.startswith(k + ' ') or ev.startswith(k + ':') or (k == 'on right click' and ev.startswith('on right click')):
                    key = k
                    break
            if key:
                who = GUARD[key]
                out.append(f'    if za_pro({who}) is true:')
                out.append('        stop')
                c['guard'] += 1
        i += 1
    txt = '\n'.join(out)
    if txt != '\n'.join(L):
        open(f, 'w', encoding='utf-8').write(txt)
    stats[n] = c
for n, c in stats.items():
    if any(c.values()): print(n, c)
