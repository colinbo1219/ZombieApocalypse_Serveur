#!/bin/sh
# Compile ZAMonde.jar (Java 17 bytecode) contre l'API Spigot embarquée dans Arclight 1.20.1.
# Usage : sh build.sh            (variables surchargeables : ARC, JAVAC, JAR)
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
ARC=${ARC:-/tmp/claude-0/-home-claude/11e94848-bd76-5e3f-a43b-90e28f9e6572/scratchpad/arc}
JAVAC=${JAVAC:-javac}
JAR=${JAR:-jar}
L=$ARC/libraries
CP=$ARC/.arclight/mod_file/arclight-1.20.1-1.0.6-SNAPSHOT-5dc8683.jar
for j in \
  com/google/code/gson/gson/2.10.1/gson-2.10.1.jar \
  com/google/guava/guava/31.1-jre/guava-31.1-jre.jar \
  org/joml/joml/1.10.5/joml-1.10.5.jar \
  org/jetbrains/annotations/24.1.0/annotations-24.1.0.jar \
  io/netty/netty-transport/4.1.82.Final/netty-transport-4.1.82.Final.jar \
  io/netty/netty-common/4.1.82.Final/netty-common-4.1.82.Final.jar \
  io/netty/netty-buffer/4.1.82.Final/netty-buffer-4.1.82.Final.jar ; do
  CP=$CP:$L/$j
done
OUT=$HERE/build
rm -rf "$OUT"; mkdir -p "$OUT/classes"
find "$HERE/src" -name '*.java' > "$OUT/sources.txt"
$JAVAC --release 17 -encoding UTF-8 -Xlint:all,-deprecation,-serial,-processing,-options -nowarn \
  -cp "$CP" -d "$OUT/classes" @"$OUT/sources.txt"
cp "$HERE"/resources/* "$OUT/classes/"
rm -f "$HERE/ZAMonde.jar"
(cd "$OUT/classes" && $JAR --create --file "$HERE/ZAMonde.jar" .)
echo "OK -> $HERE/ZAMonde.jar ($(wc -c < "$HERE/ZAMonde.jar") octets)"
