package za.monde;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.Base64;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;

/** Fichier de structure *.json.gz (voir spec_ville). Décodage hors du fil principal. */
final class Structure {
    final String name;
    final int w, h, d;
    final int ox, oy, oz;
    final String[] palette;
    final short[] blocks;
    final JsonArray signs, containers;

    private Structure(String name, int w, int h, int d, int ox, int oy, int oz, String[] palette, short[] blocks,
                      JsonArray signs, JsonArray containers) {
        this.name = name;
        this.w = w;
        this.h = h;
        this.d = d;
        this.ox = ox;
        this.oy = oy;
        this.oz = oz;
        this.palette = palette;
        this.blocks = blocks;
        this.signs = signs;
        this.containers = containers;
    }

    int index(int x, int y, int z) {
        return (y * d + z) * w + x;
    }

    static String label(File f) {
        String n = f.getName();
        for (String ext : new String[]{".json.gz", ".json", ".gz"}) {
            if (n.endsWith(ext)) return n.substring(0, n.length() - ext.length());
        }
        return n;
    }

    static Structure read(File f) throws IOException {
        JsonObject o = Data.readJson(f).getAsJsonObject();
        JsonArray size = o.getAsJsonArray("size");
        int w = size.get(0).getAsInt(), h = size.get(1).getAsInt(), d = size.get(2).getAsInt();
        if (w <= 0 || h <= 0 || d <= 0 || (long) w * h * d > 64_000_000L) throw new IOException("taille invalide " + w + "x" + h + "x" + d);
        int ox = 0, oy = 0, oz = 0;
        if (o.has("offset")) {
            JsonArray off = o.getAsJsonArray("offset");
            ox = off.get(0).getAsInt();
            oy = off.get(1).getAsInt();
            oz = off.get(2).getAsInt();
        }
        JsonArray pal = o.getAsJsonArray("palette");
        String[] palette = new String[pal.size()];
        for (int i = 0; i < palette.length; i++) palette[i] = pal.get(i).getAsString();
        byte[] z = Base64.getDecoder().decode(o.get("blocks").getAsString().trim());
        int n = w * h * d;
        byte[] raw = inflate(z, n * 2);
        if (raw.length != n * 2) throw new IOException("données de blocs : " + raw.length + " octets, attendu " + (n * 2));
        short[] blocks = new short[n];
        for (int i = 0; i < n; i++) {
            blocks[i] = (short) ((raw[2 * i] & 0xFF) | ((raw[2 * i + 1] & 0xFF) << 8));
        }
        for (int i = 0; i < n; i++) {
            int v = blocks[i] & 0xFFFF;
            if (v >= palette.length) throw new IOException("index de palette hors limites : " + v + " (palette " + palette.length + ")");
        }
        JsonArray signs = o.has("signs") && o.get("signs").isJsonArray() ? o.getAsJsonArray("signs") : new JsonArray();
        JsonArray cont = o.has("containers") && o.get("containers").isJsonArray() ? o.getAsJsonArray("containers") : new JsonArray();
        return new Structure(label(f), w, h, d, ox, oy, oz, palette, blocks, signs, cont);
    }

    private static byte[] inflate(byte[] data, int expected) throws IOException {
        Inflater inf = new Inflater();
        try {
            inf.setInput(data);
            ByteArrayOutputStream bos = new ByteArrayOutputStream(Math.max(1024, expected));
            byte[] buf = new byte[1 << 16];
            while (!inf.finished()) {
                int k = inf.inflate(buf);
                if (k == 0) {
                    if (inf.needsInput() || inf.needsDictionary()) break;
                }
                bos.write(buf, 0, k);
            }
            return bos.toByteArray();
        } catch (DataFormatException e) {
            throw new IOException("zlib invalide : " + e.getMessage());
        } finally {
            inf.end();
        }
    }

    static int[] xyz(JsonElement e) {
        JsonObject o = e.getAsJsonObject();
        return new int[]{o.get("x").getAsInt(), o.get("y").getAsInt(), o.get("z").getAsInt()};
    }
}
