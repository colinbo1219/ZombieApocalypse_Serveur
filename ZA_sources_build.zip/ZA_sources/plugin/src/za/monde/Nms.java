package za.monde;

import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Accès réflexif minimal au serveur (Arclight = classes Minecraft aux noms SRG de Forge).
 * Chaque méthode échoue proprement (retourne false/null) et journalise une seule fois.
 * Les noms SRG ont été relevés sur Forge 47.4.20 / MC 1.20.1 ; une recherche par signature sert de repli.
 */
final class Nms {
    private Nms() {}

    private static final Map<String, Boolean> warned = new ConcurrentHashMap<>();
    private static final Map<Class<?>, Method> handleMethods = new ConcurrentHashMap<>();

    private static Method setPose;          // Entity.setPose(Pose)          m_20124_
    private static Object[] poseValues;
    private static Method absMoveTo;        // Entity.absMoveTo(DDDFF)       m_19890_
    private static Method setYHeadRot;      // Entity.setYHeadRot(F)         m_5616_
    private static Field connField;         // ServerPlayer.connection        f_8906_
    private static Method sendMethod;       // ServerGamePacketListenerImpl.send(Packet) m_9829_
    private static Field netConnField;      // ServerGamePacketListenerImpl.connection f_9742_
    private static Field channelField;      // Connection.channel             f_129468_
    private static Method fromJson;         // CraftChatMessage.fromJSON(String)
    private static Constructor<?> titleCtor, subtitleCtor, timesCtor;

    static void warnOnce(String key, String msg, Throwable t) {
        if (warned.putIfAbsent(key, Boolean.TRUE) == null) {
            ZAMonde.log().log(Level.WARNING, msg + (t != null ? " : " + t : ""));
        }
    }

    static Object handle(Object craft) {
        if (craft == null) return null;
        try {
            Method m = handleMethods.computeIfAbsent(craft.getClass(), c -> {
                try {
                    Method mm = c.getMethod("getHandle");
                    mm.setAccessible(true);
                    return mm;
                } catch (NoSuchMethodException e) {
                    return null;
                }
            });
            return m == null ? null : m.invoke(craft);
        } catch (Throwable t) {
            warnOnce("handle", "getHandle() impossible", t);
            return null;
        }
    }

    private static Method findMethod(Class<?> c, String srg, Class<?> ret, Class<?>... params) {
        for (Class<?> k = c; k != null; k = k.getSuperclass()) {
            try {
                Method m = k.getDeclaredMethod(srg, params);
                m.setAccessible(true);
                return m;
            } catch (NoSuchMethodException ignored) {
                // parent
            } catch (Throwable t) {
                break;
            }
        }
        return null;
    }

    private static Field findFieldByType(Class<?> c, String srg, String typeName) {
        for (Class<?> k = c; k != null; k = k.getSuperclass()) {
            try {
                Field f = k.getDeclaredField(srg);
                f.setAccessible(true);
                return f;
            } catch (NoSuchFieldException ignored) {
                // par type
            } catch (Throwable t) {
                break;
            }
        }
        for (Class<?> k = c; k != null; k = k.getSuperclass()) {
            for (Field f : k.getDeclaredFields()) {
                if (Modifier.isStatic(f.getModifiers())) continue;
                if (isOrExtends(f.getType(), typeName)) {
                    try {
                        f.setAccessible(true);
                        return f;
                    } catch (Throwable t) {
                        return null;
                    }
                }
            }
        }
        return null;
    }

    private static boolean isOrExtends(Class<?> t, String name) {
        for (Class<?> k = t; k != null; k = k.getSuperclass()) {
            if (k.getName().equals(name)) return true;
        }
        for (Class<?> i : t.getInterfaces()) {
            if (i.getName().equals(name)) return true;
        }
        return false;
    }

    // ---------------------------------------------------------------- pose

    /** Change la pose d'une entité (ex. SLEEPING pour « allongé »). */
    static synchronized boolean setPose(Entity e, org.bukkit.entity.Pose pose) {
        Object h = handle(e);
        if (h == null) return false;
        try {
            if (setPose == null) {
                Class<?> poseCls = null;
                Method found = null;
                for (Class<?> k = h.getClass(); k != null && found == null; k = k.getSuperclass()) {
                    for (Method m : k.getDeclaredMethods()) {
                        if (m.getParameterCount() == 1 && m.getReturnType() == void.class
                                && m.getParameterTypes()[0].getName().equals("net.minecraft.world.entity.Pose")) {
                            if (m.getName().equals("m_20124_") || found == null) {
                                found = m;
                                poseCls = m.getParameterTypes()[0];
                                if (m.getName().equals("m_20124_")) break;
                            }
                        }
                    }
                }
                if (found == null) throw new NoSuchMethodException("setPose");
                found.setAccessible(true);
                Object[] vals = poseCls.getEnumConstants();
                if (vals == null || vals.length < org.bukkit.entity.Pose.values().length) {
                    throw new IllegalStateException("enum Pose inattendue");
                }
                poseValues = vals;
                setPose = found;
            }
            setPose.invoke(h, poseValues[pose.ordinal()]);
            return true;
        } catch (Throwable t) {
            warnOnce("pose", "Changement de pose indisponible", t);
            return false;
        }
    }

    // ---------------------------------------------------------------- déplacement

    /** Déplace une entité même si elle a des passagers (Entity#teleport le refuse). */
    static synchronized boolean absMoveTo(Entity e, double x, double y, double z, float yaw, float pitch) {
        Object h = handle(e);
        if (h == null) return false;
        try {
            if (absMoveTo == null) {
                Method m = findMethod(h.getClass(), "m_19890_", void.class, double.class, double.class, double.class, float.class, float.class);
                if (m == null) throw new NoSuchMethodException("absMoveTo");
                absMoveTo = m;
                setYHeadRot = findMethod(h.getClass(), "m_5616_", void.class, float.class);
            }
            absMoveTo.invoke(h, x, y, z, yaw, pitch);
            if (setYHeadRot != null) setYHeadRot.invoke(h, yaw);
            return true;
        } catch (Throwable t) {
            warnOnce("move", "Déplacement direct (absMoveTo) indisponible, repli sur éjecter/téléporter", t);
            return false;
        }
    }

    // ---------------------------------------------------------------- réseau

    static Object gameListener(Player p) {
        Object h = handle(p);
        if (h == null) return null;
        try {
            if (connField == null) {
                connField = findFieldByType(h.getClass(), "f_8906_", "net.minecraft.server.network.ServerGamePacketListenerImpl");
                if (connField == null) throw new NoSuchFieldException("connection");
            }
            return connField.get(h);
        } catch (Throwable t) {
            warnOnce("conn", "Connexion joueur inaccessible", t);
            return null;
        }
    }

    /** Canal Netty du joueur (io.netty.channel.Channel) ou null. */
    static Object channel(Player p) {
        Object l = gameListener(p);
        if (l == null) return null;
        try {
            if (netConnField == null) {
                netConnField = findFieldByType(l.getClass(), "f_9742_", "net.minecraft.network.Connection");
                if (netConnField == null) throw new NoSuchFieldException("Connection");
            }
            Object c = netConnField.get(l);
            if (c == null) return null;
            if (channelField == null) {
                channelField = findFieldByType(c.getClass(), "f_129468_", "io.netty.channel.Channel");
                if (channelField == null) throw new NoSuchFieldException("channel");
            }
            return channelField.get(c);
        } catch (Throwable t) {
            warnOnce("chan", "Canal réseau inaccessible", t);
            return null;
        }
    }

    static boolean send(Player p, Object packet) {
        Object l = gameListener(p);
        if (l == null || packet == null) return false;
        try {
            if (sendMethod == null) {
                Method m = null;
                for (Class<?> k = l.getClass(); k != null && m == null; k = k.getSuperclass()) {
                    try {
                        m = k.getDeclaredMethod("m_9829_", Class.forName("net.minecraft.network.protocol.Packet", false, l.getClass().getClassLoader()));
                    } catch (NoSuchMethodException ignored) {
                        // parent
                    }
                }
                if (m == null) {
                    for (Method mm : l.getClass().getMethods()) {
                        if (mm.getParameterCount() == 1 && mm.getReturnType() == void.class
                                && mm.getParameterTypes()[0].getName().equals("net.minecraft.network.protocol.Packet")) {
                            m = mm;
                            break;
                        }
                    }
                }
                if (m == null) throw new NoSuchMethodException("send(Packet)");
                m.setAccessible(true);
                sendMethod = m;
            }
            sendMethod.invoke(l, packet);
            return true;
        } catch (Throwable t) {
            warnOnce("send", "Envoi de paquet impossible", t);
            return false;
        }
    }

    // ---------------------------------------------------------------- caméra

    private static Constructor<?> cameraCtor;

    /**
     * Change la caméra du client (paquet ClientboundSetCameraPacket) SANS passer par ServerPlayer#setCamera :
     * sur Arclight 1.20.1, Player#setSpectatorTarget plante (téléportation avec un ensemble immuable).
     */
    static synchronized boolean camera(Player p, Entity target) {
        try {
            Object h = handle(target);
            if (h == null) return false;
            ClassLoader cl = h.getClass().getClassLoader();
            if (cameraCtor == null) {
                Class<?> ent = Class.forName("net.minecraft.world.entity.Entity", false, cl);
                cameraCtor = Class.forName("net.minecraft.network.protocol.game.ClientboundSetCameraPacket", false, cl).getConstructor(ent);
            }
            return send(p, cameraCtor.newInstance(h));
        } catch (Throwable t) {
            warnOnce("camera-pkt", "Paquet de caméra indisponible", t);
            return false;
        }
    }

    // ---------------------------------------------------------------- météo (paquets)

    private static Constructor<?> gameEventCtor;
    private static Object evStartRain, evStopRain, evRainLevel;

    /** Pluie visible (ou non) pour ce joueur seulement. */
    static synchronized boolean weather(Player p, boolean rain) {
        try {
            Object h = handle(p);
            if (h == null) return false;
            ClassLoader cl = h.getClass().getClassLoader();
            if (gameEventCtor == null) {
                Class<?> ev = Class.forName("net.minecraft.network.protocol.game.ClientboundGameEventPacket", false, cl);
                Class<?> type = Class.forName("net.minecraft.network.protocol.game.ClientboundGameEventPacket$Type", false, cl);
                gameEventCtor = ev.getConstructor(type, float.class);
                Field f1 = ev.getDeclaredField("f_132154_");
                Field f2 = ev.getDeclaredField("f_132155_");
                Field f7 = ev.getDeclaredField("f_132160_");
                f1.setAccessible(true);
                f2.setAccessible(true);
                f7.setAccessible(true);
                evStartRain = f1.get(null);
                evStopRain = f2.get(null);
                evRainLevel = f7.get(null);
            }
            boolean ok = send(p, gameEventCtor.newInstance(rain ? evStartRain : evStopRain, 0f));
            return ok && send(p, gameEventCtor.newInstance(evRainLevel, rain ? 1f : 0f));
        } catch (Throwable t) {
            warnOnce("weather", "Météo par paquets indisponible", t);
            return false;
        }
    }

    // ---------------------------------------------------------------- titres JSON

    private static Object component(String json) throws ReflectiveOperationException {
        if (fromJson == null) {
            String pkg = Bukkit.getServer().getClass().getPackage().getName();
            Class<?> c = Class.forName(pkg + ".util.CraftChatMessage");
            fromJson = c.getMethod("fromJSON", String.class);
        }
        return fromJson.invoke(null, json);
    }

    /** Titre + sous-titre au format JSON (supporte « font »). Retourne false si l'accès réflexif échoue. */
    static synchronized boolean sendTitle(Player p, String titleJson, String subJson, int in, int stay, int out) {
        try {
            Object h = handle(p);
            if (h == null) return false;
            ClassLoader cl = h.getClass().getClassLoader();
            if (titleCtor == null) {
                Class<?> comp = Class.forName("net.minecraft.network.chat.Component", false, cl);
                titleCtor = Class.forName("net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket", false, cl).getConstructor(comp);
                subtitleCtor = Class.forName("net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket", false, cl).getConstructor(comp);
                timesCtor = Class.forName("net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket", false, cl)
                        .getConstructor(int.class, int.class, int.class);
            }
            Object times = timesCtor.newInstance(in, stay, out);
            Object sub = subtitleCtor.newInstance(component(subJson == null ? "{\"text\":\"\"}" : subJson));
            Object title = titleCtor.newInstance(component(titleJson));
            return send(p, times) && send(p, sub) && send(p, title);
        } catch (Throwable t) {
            warnOnce("title", "Titres JSON par paquets indisponibles, repli sur la commande title", t);
            return false;
        }
    }

    /** Vérifie les accès réflexifs utiles (pour /zamonde etat). */
    static String selfTest() {
        StringBuilder sb = new StringBuilder();
        try {
            String pkg = Bukkit.getServer().getClass().getPackage().getName();
            Class<?> c = Class.forName(pkg + ".util.CraftChatMessage");
            Object comp = c.getMethod("fromJSON", String.class).invoke(null, "{\"text\":\"x\",\"font\":\"za_modeles:ecran\"}");
            ClassLoader cl = comp.getClass().getClassLoader();
            Class.forName("net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket", false, cl);
            Class<?> sp = Class.forName("net.minecraft.server.level.ServerPlayer", false, cl);
            Field f = findFieldByType(sp, "f_8906_", "net.minecraft.server.network.ServerGamePacketListenerImpl");
            Class<?> gl = Class.forName("net.minecraft.server.network.ServerGamePacketListenerImpl", false, cl);
            Field f2 = findFieldByType(gl, "f_9742_", "net.minecraft.network.Connection");
            Class<?> cn = Class.forName("net.minecraft.network.Connection", false, cl);
            Field f3 = findFieldByType(cn, "f_129468_", "io.netty.channel.Channel");
            Class<?> ent = Class.forName("net.minecraft.world.entity.Entity", false, cl);
            Method mv = findMethod(ent, "m_19890_", void.class, double.class, double.class, double.class, float.class, float.class);
            Method ps = findMethod(ent, "m_20124_", void.class, Class.forName("net.minecraft.world.entity.Pose", false, cl));
            sb.append("titres=").append(comp != null ? "ok" : "KO")
              .append(" connexion=").append(f != null && f2 != null && f3 != null ? "ok" : "KO")
              .append(" deplacement=").append(mv != null ? "ok" : "KO")
              .append(" pose=").append(ps != null ? "ok" : "KO");
        } catch (Throwable t) {
            sb.append("KO ").append(t);
        }
        return sb.toString();
    }
}
