package za.monde;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/** Petites fonctions utilitaires (parsing d'arguments, angles, sol). */
final class U {
    private U() {}

    /** Les espaces sont passés par Skript avec « _ ». */
    static String txt(String s) {
        return s == null ? "" : s.replace('_', ' ');
    }

    static double num(String s) {
        return Double.parseDouble(s.trim().replace(',', '.'));
    }

    static boolean isNum(String s) {
        try {
            num(s);
            return true;
        } catch (RuntimeException e) {
            return false;
        }
    }

    static int integer(String s) {
        return (int) Math.round(num(s));
    }

    /** Coordonnée avec support de « ~ » / « ~n » relatif à une valeur de référence. */
    static double coord(String s, double rel) {
        s = s.trim();
        if (s.startsWith("~")) {
            return rel + (s.length() > 1 ? num(s.substring(1)) : 0.0);
        }
        return num(s);
    }

    /** Lit x y z dans args[i..i+2], relatifs à ref si « ~ ». */
    static Location loc(World w, String[] a, int i, Location ref) {
        double rx = ref != null ? ref.getX() : 0, ry = ref != null ? ref.getY() : 0, rz = ref != null ? ref.getZ() : 0;
        return new Location(w, coord(a[i], rx), coord(a[i + 1], ry), coord(a[i + 2], rz));
    }

    /** Yaw Minecraft (0 = sud, 90 = ouest, 180 = nord, -90 = est) pour une direction. */
    static float yawOf(double dx, double dz) {
        return (float) Math.toDegrees(Math.atan2(-dx, dz));
    }

    static float pitchOf(double dx, double dy, double dz) {
        double h = Math.sqrt(dx * dx + dz * dz);
        return (float) -Math.toDegrees(Math.atan2(dy, h));
    }

    /** Ramène un angle dans ]-180, 180]. */
    static float wrap(float a) {
        a %= 360f;
        if (a > 180f) a -= 360f;
        if (a <= -180f) a += 360f;
        return a;
    }

    static double wrapD(double a) {
        a %= 360.0;
        if (a > 180.0) a -= 360.0;
        if (a <= -180.0) a += 360.0;
        return a;
    }

    /** Joueur par nom exact, nom insensible à la casse ou UUID. */
    static Player player(String s) {
        if (s == null) return null;
        Player p = Bukkit.getPlayerExact(s);
        if (p != null) return p;
        for (Player o : Bukkit.getOnlinePlayers()) {
            if (o.getName().equalsIgnoreCase(s)) return o;
        }
        try {
            return Bukkit.getPlayer(UUID.fromString(s));
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    /**
     * Hauteur du sol sous un point : bloc solide le plus haut (avec 2 blocs libres au-dessus) entre y+1 et y-3.
     * Retourne la valeur y d'origine si rien n'est trouvé.
     */
    static double groundY(World w, double x, double y, double z) {
        int bx = (int) Math.floor(x), bz = (int) Math.floor(z);
        int by = (int) Math.floor(y + 0.25);
        if (!w.isChunkLoaded(bx >> 4, bz >> 4)) return y;
        int min = Math.max(w.getMinHeight(), by - 3);
        int max = Math.min(w.getMaxHeight() - 3, by + 1);
        for (int yy = max; yy >= min; yy--) {
            Block b = w.getBlockAt(bx, yy, bz);
            if (b.isPassable()) continue;
            if (!w.getBlockAt(bx, yy + 1, bz).isPassable() || !w.getBlockAt(bx, yy + 2, bz).isPassable()) continue;
            double top = b.getBoundingBox().getMaxY();
            if (top <= yy) top = yy + 1.0;
            return top;
        }
        return y;
    }

    /**
     * Liste de points « x,y,z;x,y,z;... » (3 à 6 nombres par point).
     */
    static List<double[]> points(String s) {
        List<double[]> out = new ArrayList<>();
        for (String part : s.split(";")) {
            part = part.trim();
            if (part.isEmpty()) continue;
            String[] c = part.split(",");
            if (c.length < 3) throw new IllegalArgumentException("point invalide : " + part);
            double[] p = new double[6];
            for (int i = 0; i < Math.min(6, c.length); i++) p[i] = num(c[i]);
            if (c.length < 6) p[5] = 0;
            out.add(p);
        }
        if (out.isEmpty()) throw new IllegalArgumentException("aucun point");
        return out;
    }

    static Vector vec(double[] p) {
        return new Vector(p[0], p[1], p[2]);
    }

    static String fmt(double d) {
        return String.format(Locale.ROOT, "%.2f", d);
    }

    static String fmtLoc(Location l) {
        if (l == null) return "?";
        return (l.getWorld() != null ? l.getWorld().getName() : "?") + " " + fmt(l.getX()) + " " + fmt(l.getY()) + " " + fmt(l.getZ());
    }

    /** Clé compacte d'une position de bloc (x,z sur 26 bits, y sur 12 bits). */
    static long key(int x, int y, int z) {
        return ((long) (x & 0x3FFFFFF) << 38) | ((long) (z & 0x3FFFFFF) << 12) | (long) (y & 0xFFF);
    }

    static int keyX(long k) {
        return (int) (k >> 38);
    }

    static int keyY(long k) {
        return (int) ((k << 52) >> 52);
    }

    static int keyZ(long k) {
        return (int) ((k << 26) >> 38);
    }

    static String join(String[] a, int from) {
        StringBuilder sb = new StringBuilder();
        for (int i = from; i < a.length; i++) {
            if (i > from) sb.append(' ');
            sb.append(a[i]);
        }
        return sb.toString();
    }
}
