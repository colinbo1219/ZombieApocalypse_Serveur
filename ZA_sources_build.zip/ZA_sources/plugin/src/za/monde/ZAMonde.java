package za.monde;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.SoundCategory;
import org.bukkit.WeatherType;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.logging.Logger;

/** Point d'entrée du plugin ZAMonde et répartiteur des commandes /zamonde. */
public final class ZAMonde extends JavaPlugin implements Listener {
    private static ZAMonde inst;

    Data data;
    WorldMgr worlds;
    Builder builder;
    PacketHider hider;
    Privacy privacy;
    Npcs npcs;
    Overlay overlay;
    Cameras cameras;
    Props props;
    Hud hud;
    private long ticks;

    static Logger log() {
        return inst != null ? inst.getLogger() : Logger.getLogger("ZAMonde");
    }

    @Override
    public void onEnable() {
        inst = this;
        saveDefaultConfig();
        reloadConfig();
        data = new Data(this);
        worlds = new WorldMgr(this);
        builder = new Builder(this);
        hider = new PacketHider();
        hider.setEnabled(getConfig().getBoolean("masquage_paquets", true));
        privacy = new Privacy(this);
        npcs = new Npcs(this);
        overlay = new Overlay(this);
        cameras = new Cameras(this);
        props = new Props(this);
        hud = new Hud(this);
        data.loadAll();
        getServer().getPluginManager().registerEvents(this, this);
        getServer().getPluginManager().registerEvents(worlds, this);
        getServer().getPluginManager().registerEvents(npcs, this);
        getServer().getPluginManager().registerEvents(cameras, this);
        Bukkit.getScheduler().runTask(this, () -> {
            try {
                worlds.ensure();
            } catch (Throwable t) {
                getLogger().warning("Monde du prologue : " + t);
            }
            cleanupOrphans();
            for (Player p : Bukkit.getOnlinePlayers()) {
                hider.inject(p);
                privacy.onJoin(p);
            }
        });
        Bukkit.getScheduler().runTaskTimer(this, this::tick, 1L, 1L);
        getLogger().info("ZAMonde prêt (" + Nms.selfTest() + ", masquage " + hider.status() + ")");
    }

    @Override
    public void onDisable() {
        try {
            cameras.stopAll();
        } catch (Throwable ignored) {
            // arrêt
        }
        try {
            props.removeAll();
            npcs.removeEverything();
            overlay.clearAll(false);
            privacy.clearAll();
            hider.uninjectAll();
            builder.cancelAll();
        } catch (Throwable ignored) {
            // arrêt
        }
    }

    private void cleanupOrphans() {
        int n = 0;
        for (World w : Bukkit.getWorlds()) {
            for (Entity e : w.getEntities()) {
                if (e instanceof Player) continue;
                if (e.getScoreboardTags().contains("za_pnj") || e.getScoreboardTags().contains("za_prop")) {
                    e.remove();
                    n++;
                }
            }
        }
        if (n > 0) getLogger().info(n + " entité(s) orpheline(s) ZAMonde retirée(s)");
    }

    private void tick() {
        ticks++;
        try {
            overlay.tick();
        } catch (Throwable t) {
            Nms.warnOnce("t-overlay", "tick calques", t);
        }
        try {
            npcs.tick(ticks);
        } catch (Throwable t) {
            Nms.warnOnce("t-npcs", "tick PNJ", t);
        }
        try {
            cameras.tick();
        } catch (Throwable t) {
            Nms.warnOnce("t-cam", "tick caméras", t);
        }
        try {
            props.tick();
        } catch (Throwable t) {
            Nms.warnOnce("t-props", "tick props", t);
        }
        try {
            hud.tick(ticks);
        } catch (Throwable t) {
            Nms.warnOnce("t-hud", "tick hud", t);
        }
        if (ticks % 100 == 0) {
            worlds.sweepMonsters();
            privacy.purge();
        }
    }

    // ---------------------------------------------------------------- événements joueurs

    @EventHandler(priority = EventPriority.LOWEST)
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        hider.inject(p);
        privacy.onJoin(p);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        npcs.removeAll(id);
        props.removeOwner(id);
        overlay.clear(id, false);
        hud.forget(id);
        if (privacy.isIsolated(id)) privacy.isolate(p, false);
        privacy.onQuit(p);
        hider.uninject(id);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onWorld(PlayerChangedWorldEvent e) {
        Player p = e.getPlayer();
        privacy.onWorldChange(p);
        if (worlds.isPrologue(e.getFrom()) && !worlds.isPrologue(p.getWorld())) {
            // sortie du prologue : on nettoie tout ce qui lui appartenait là-bas
            npcs.removeOutside(p.getUniqueId(), p.getWorld());
            props.removeOwner(p.getUniqueId());
            overlay.clear(p.getUniqueId(), false);
            if (privacy.isIsolated(p.getUniqueId())) privacy.isolate(p, false);
            p.resetPlayerTime();
            p.resetPlayerWeather();
            hider.setTime(p.getUniqueId(), null, 0);
            Nms.weather(p, false);
        } else if (worlds.isPrologue(p.getWorld())) {
            overlay.onEnterPrologue(p);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent e) {
        if (e.getTo() != null && worlds.isPrologue(e.getTo().getWorld())) overlay.scheduleResend(e.getPlayer(), 3);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onRespawn(PlayerRespawnEvent e) {
        if (worlds.isPrologue(e.getRespawnLocation().getWorld())) overlay.scheduleResend(e.getPlayer(), 5);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getClickedBlock() != null && worlds.isPrologue(e.getClickedBlock().getWorld())) overlay.scheduleResend(e.getPlayer(), 1);
    }

    // ---------------------------------------------------------------- commandes

    private static final String AIDE = String.join("\n",
            "§6/zamonde §7(console ou za.admin) — espaces des textes = _",
            "§emonde | construire | placer <fichier> <monde> <x> <y> <z> [degager] | recharger | etat",
            "§etemps <j> <ticks|reset> | meteo <j> <clair|pluie|reset> | isoler <j> <on|off> | tp <j> <poi> [monde]",
            "§epnj <j> <id> <villager|zombie_villager> <x> <y> <z> <yaw> <nom> [ia|fige|dort] [nomvisible]",
            "§emm <j> <id> <TypeMM> <x> <y> <z> [yaw] [nom] | relever <j> <id> <TypeMM> [nom] | retirer <j> <id|tout>",
            "§emarcher <j> <id> <bps> <x,y,z;...|chemin> | regarder <j> <id> <x> <y> <z>|joueur | suivre-regard <j> <id> <on|off>",
            "§eanimer <j> <id> <bras|degat|mort|tousse|tomber>",
            "§ecalque <j> <nom> <on|off> | calques-reset <j> | lampes <j> <on|off> | blackout <j> <ticks> [son] | clignoter <j> <a> <b> <periode> <duree|stop>",
            "§ecamera <j> <chemin|inline> [retour|x,y,z,yaw,pitch] | camera-stop <j> | camera-duree <chemin>",
            "§enoir <j> <in> <reste> <out> | noir-texte <j> <in> <reste> <out> <titre> [sous] | titre <j> <in> <reste> <out> <titre> [sous]",
            "§eobjectif <j> <texte> <x> <y> <z>|<poi>|off",
            "§eprop <j|public> <id> <modele> <x> <y> <z> <yaw> [monde] [son] [boucle] | vehicule <j|public> <id> <modele> <chemin> <bps> [son] [boucle] [reste] [monde]",
            "§eprop-retirer <id> | prop-silence <id> | props-liste",
            "§eson <j|tous|rayon:x,y,z,r[,monde]> <cle> [vol] [pitch] [entite:<id>|x,y,z] | stopson <j> [cle]");

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof ConsoleCommandSender) && !sender.hasPermission("za.admin")) {
            sender.sendMessage("§cPermission za.admin requise.");
            return true;
        }
        if (args.length == 0 || args[0].equalsIgnoreCase("aide")) {
            for (String l : AIDE.split("\n")) sender.sendMessage(l);
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        try {
            String r = run(sender, sub, args);
            if (r != null) reply(sender, r, false);
        } catch (IllegalArgumentException | IllegalStateException | ArrayIndexOutOfBoundsException ex) {
            String m = ex instanceof ArrayIndexOutOfBoundsException ? "arguments manquants (voir /zamonde aide)" : ex.getMessage();
            reply(sender, "§c" + sub + " : " + m, true);
        } catch (Throwable t) {
            getLogger().log(java.util.logging.Level.WARNING, "Erreur /zamonde " + String.join(" ", args), t);
            reply(sender, "§cErreur interne : " + t, true);
        }
        return true;
    }

    private void reply(CommandSender s, String msg, boolean error) {
        if (s instanceof ConsoleCommandSender) {
            if (error || getConfig().getBoolean("console_verbeux", false)) getLogger().info(org.bukkit.ChatColor.stripColor(msg));
        } else {
            s.sendMessage("§7[ZAMonde] §f" + msg);
        }
    }

    private static Player need(String name) {
        Player p = U.player(name);
        if (p == null) throw new IllegalArgumentException("joueur introuvable « " + name + " »");
        return p;
    }

    /** « public » → null ; sinon propriétaire = joueur. */
    private static UUID ownerArg(String s) {
        if (s.equalsIgnoreCase("public")) return null;
        return need(s).getUniqueId();
    }

    private World prologueOr(Player p) {
        World w = worlds.prologue();
        if (w != null) return w;
        if (p != null) return p.getWorld();
        throw new IllegalStateException("monde du prologue indisponible");
    }

    /** Position : x y z, ou un POI (1 argument), relative au monde du joueur si « ~ ». */
    private Location locArgs(Player p, String[] a, int i, World w) {
        if (a.length > i + 2 && U.isNum(a[i + 1].replace("~", "0")) && U.isNum(a[i + 2].replace("~", "0"))) {
            return U.loc(w, a, i, p != null ? p.getLocation() : null);
        }
        Location l = data.poi(a[i], w);
        if (l == null) throw new IllegalArgumentException("position invalide (x y z ou POI) : " + a[i]);
        return l;
    }

    private String run(CommandSender sender, String sub, String[] a) {
        switch (sub) {
            case "monde": {
                World w = worlds.ensure();
                if (w == null) throw new IllegalStateException("création impossible : " + worlds.lastError());
                return "monde " + w.getName() + " prêt (dimension " + worlds.dimension() + ")";
            }
            case "construire": {
                World w = worlds.prologue();
                if (w == null) w = worlds.ensure();
                if (w == null) throw new IllegalStateException("monde du prologue indisponible");
                File f = data.resolve(a.length > 1 ? a[1] : "town");
                if (f == null) throw new IllegalArgumentException("town.json.gz introuvable dans " + data.dir);
                builder.enqueue(sender, f, w, 0, 0, 0, false, true);
                return "construction lancée (" + f.getName() + ")";
            }
            case "placer": {
                File f = data.resolve(a[1]);
                if (f == null) throw new IllegalArgumentException("fichier introuvable « " + a[1] + " »");
                World w = Bukkit.getWorld(a[2]);
                if (w == null) throw new IllegalArgumentException("monde inconnu « " + a[2] + " »");
                int x = (int) Math.floor(U.num(a[3])), y = (int) Math.floor(U.num(a[4])), z = (int) Math.floor(U.num(a[5]));
                boolean clear = a.length > 6 && a[6].equalsIgnoreCase("degager");
                builder.enqueue(sender, f, w, x, y, z, clear, false);
                return "pose de " + f.getName() + " en " + w.getName() + " " + x + " " + y + " " + z;
            }
            case "recharger": {
                reloadConfig();
                hider.setEnabled(getConfig().getBoolean("masquage_paquets", true));
                data.loadAll();
                overlay.reapplyAll();
                return "données rechargées";
            }
            case "etat": {
                List<String> l = new ArrayList<>();
                l.add("monde : " + (worlds.prologue() != null ? worlds.prologue().getName() + " (" + worlds.dimension() + ")" : "absent"));
                l.add("réflexion : " + Nms.selfTest() + " | masquage : " + hider.status());
                l.add("données : " + data.layers.size() + " calques, " + data.lamps.size() + " lampes, " + data.pois.size() + " POIs, " + data.models.size() + " modèles");
                l.add("PNJ : " + npcs.count() + " | privés : " + privacy.count() + " | isolés : " + privacy.isolatedCount()
                        + " | props : " + props.count() + " | caméras : " + cameras.count() + " | objectifs : " + hud.count()
                        + " | calques actifs : " + overlay.activeCount());
                l.add(builder.status());
                for (Player p : Bukkit.getOnlinePlayers()) {
                    List<String> d = overlay.describe(p.getUniqueId());
                    if (!d.isEmpty() || npcs.countFor(p.getUniqueId()) > 0) {
                        l.add(" · " + p.getName() + " : calques " + d + ", PNJ " + npcs.idsFor(p.getUniqueId()));
                    }
                }
                for (String s : l) reply(sender, s, true);
                return null;
            }
            case "temps": {
                Player p = need(a[1]);
                if (a[2].equalsIgnoreCase("reset")) {
                    p.resetPlayerTime();
                    hider.setTime(p.getUniqueId(), null, 0);
                    long t = p.getWorld().getTime();
                    Object pk = hider.setTime(p.getUniqueId(), t, p.getWorld().getFullTime());
                    hider.setTime(p.getUniqueId(), null, 0);
                    if (pk != null) Nms.send(p, pk);
                    return "temps réinitialisé pour " + p.getName();
                }
                long t = (long) U.num(a[2]);
                try {
                    p.setPlayerTime(t, false);
                } catch (Throwable ignored) {
                    // géré par paquets
                }
                Object pk = hider.setTime(p.getUniqueId(), t, p.getWorld().getFullTime());
                if (pk != null) Nms.send(p, pk);
                return "temps " + a[2] + " pour " + p.getName();
            }
            case "meteo": {
                Player p = need(a[1]);
                switch (a[2].toLowerCase(Locale.ROOT)) {
                    case "clair" -> {
                        p.setPlayerWeather(WeatherType.CLEAR);
                        Nms.weather(p, false);
                    }
                    case "pluie", "orage" -> {
                        p.setPlayerWeather(WeatherType.DOWNFALL);
                        Nms.weather(p, true);
                    }
                    default -> {
                        p.resetPlayerWeather();
                        Nms.weather(p, p.getWorld().hasStorm());
                    }
                }
                return "météo " + a[2] + " pour " + p.getName();
            }
            case "isoler": {
                Player p = need(a[1]);
                privacy.isolate(p, a[2].equalsIgnoreCase("on"));
                return "isolement " + a[2] + " pour " + p.getName();
            }
            case "tp": {
                Player p = need(a[1]);
                World w = a.length > 3 ? Bukkit.getWorld(a[3]) : null;
                Location l = data.poi(a[2], w);
                if (l == null) throw new IllegalArgumentException("POI inconnu « " + a[2] + " »");
                p.teleport(l);
                return p.getName() + " → " + a[2];
            }
            case "pnj": {
                Player p = need(a[1]);
                World w = p.getWorld();
                Location l = U.loc(w, a, 4, p.getLocation());
                l.setYaw((float) U.num(a[7]));
                String mode = a.length > 9 ? a[9].toLowerCase(Locale.ROOT) : "ia";
                boolean vis = a.length > 10 && a[10].equalsIgnoreCase("nomvisible");
                return npcs.spawnVillager(p.getUniqueId(), w, a[2], a[3], l, U.txt(a[8]), mode, vis);
            }
            case "mm": {
                UUID owner = ownerArg(a[1]);
                Player p = owner != null ? Bukkit.getPlayer(owner) : null;
                World w = p != null ? p.getWorld() : prologueOr(null);
                Location l = U.loc(w, a, 4, p != null ? p.getLocation() : null);
                if (a.length > 7) l.setYaw((float) U.num(a[7]));
                String name = a.length > 8 ? U.txt(a[8]) : null;
                return npcs.spawnMythic(owner, w, a[2], a[3], l, name);
            }
            case "relever": {
                Player p = need(a[1]);
                return npcs.relever(p.getUniqueId(), p.getWorld(), a[2], a[3], a.length > 4 ? U.txt(a[4]) : null);
            }
            case "retirer": {
                UUID owner = ownerArg(a[1]);
                if (a[2].equalsIgnoreCase("tout")) {
                    int n = owner == null ? npcs.removeAll(null) : npcs.removeAll(owner);
                    return n + " entité(s) retirée(s)";
                }
                return npcs.remove(owner, a[2]) ? "« " + a[2] + " » retiré" : "« " + a[2] + " » introuvable";
            }
            case "marcher": {
                UUID owner = ownerArg(a[1]);
                return npcs.walk(owner, a[2], U.num(a[3]), data.pathOrInline(U.join(a, 4).replace(" ", "")));
            }
            case "regarder": {
                UUID owner = ownerArg(a[1]);
                if (a.length > 5) {
                    Player p = owner != null ? Bukkit.getPlayer(owner) : null;
                    World w = p != null ? p.getWorld() : prologueOr(null);
                    return npcs.lookAt(owner, a[2], U.loc(w, a, 3, null), false);
                }
                return npcs.lookAt(owner, a[2], null, true);
            }
            case "suivre-regard": {
                UUID owner = ownerArg(a[1]);
                return npcs.follow(owner, a[2], a[3].equalsIgnoreCase("on"));
            }
            case "animer": {
                UUID owner = ownerArg(a[1]);
                return npcs.animate(owner, a[2], a[3].toLowerCase(Locale.ROOT));
            }
            case "calque": {
                Player p = need(a[1]);
                return overlay.layer(p, a[2], a[3].equalsIgnoreCase("on"));
            }
            case "calques-reset": {
                return overlay.reset(need(a[1]));
            }
            case "lampes": {
                return overlay.lamps(need(a[1]), a[2].equalsIgnoreCase("on"));
            }
            case "blackout": {
                Player p = need(a[1]);
                String snd = a.length > 3 ? a[3] : "za_modeles:sfx.coupure";
                return overlay.blackout(p, U.integer(a[2]), snd, (float) getConfig().getDouble("blackout_volume", 3.0));
            }
            case "clignoter": {
                Player p = need(a[1]);
                if (a.length > 2 && a[2].equalsIgnoreCase("stop")) return overlay.blinkStop(p);
                if (a.length > 5 && a[5].equalsIgnoreCase("stop")) return overlay.blinkStop(p);
                int dur = a.length > 5 ? U.integer(a[5]) : -1;
                return overlay.blink(p, a[2], a[3], U.integer(a[4]), dur);
            }
            case "camera": {
                Player p = need(a[1]);
                World w = p.getWorld();
                List<double[]> keys = data.pathOrInline(a[2]);
                Location end = null;
                if (a.length > 3 && !a[3].equalsIgnoreCase("retour")) {
                    if (a[3].indexOf(',') >= 0) {
                        double[] e = U.points(a[3]).get(0);
                        end = new Location(w, e[0], e[1], e[2], (float) e[3], (float) e[4]);
                    } else {
                        end = data.poi(a[3], w);
                        if (end == null) throw new IllegalArgumentException("POI de fin inconnu « " + a[3] + " »");
                    }
                }
                return cameras.start(p, keys, w, end);
            }
            case "camera-stop": {
                return cameras.stop(need(a[1]), true);
            }
            case "camera-duree": {
                List<double[]> keys = data.pathOrInline(a[1]);
                return "durée " + Cameras.duration(keys) + " ticks";
            }
            case "noir": {
                Player p = need(a[1]);
                return hud.black(p, U.integer(a[2]), U.integer(a[3]), U.integer(a[4]));
            }
            case "noir-texte": {
                Player p = need(a[1]);
                return hud.blackText(p, U.integer(a[2]), U.integer(a[3]), U.integer(a[4]), U.txt(a[5]), a.length > 6 ? U.txt(a[6]) : null);
            }
            case "logo": {
                Player p = need(a[1]);
                return hud.logo(p, U.integer(a[2]), U.integer(a[3]), U.integer(a[4]), a.length > 5 ? U.txt(a[5]) : null);
            }
            case "titre": {
                Player p = need(a[1]);
                return hud.title(p, U.integer(a[2]), U.integer(a[3]), U.integer(a[4]), U.txt(a[5]).replace('&', '§'),
                        a.length > 6 ? U.txt(a[6]).replace('&', '§') : null);
            }
            case "objectif": {
                Player p = need(a[1]);
                if (a[2].equalsIgnoreCase("off")) return hud.objectiveOff(p);
                Location l = locArgs(p, a, 3, p.getWorld());
                return hud.objective(p, U.txt(a[2]).replace('&', '§'), l);
            }
            case "prop": {
                UUID owner = ownerArg(a[1]);
                Player p = owner != null ? Bukkit.getPlayer(owner) : null;
                World w = a.length > 8 && Bukkit.getWorld(a[8]) != null ? Bukkit.getWorld(a[8]) : (p != null ? p.getWorld() : prologueOr(null));
                Location l = U.loc(w, a, 4, p != null ? p.getLocation() : null);
                l.setYaw((float) U.num(a[7]));
                String snd = a.length > 9 ? a[9] : null;
                int loop = a.length > 10 ? U.integer(a[10]) : 40;
                return props.staticProp(a[2], owner, a[3], l, snd, loop);
            }
            case "vehicule": {
                UUID owner = ownerArg(a[1]);
                Player p = owner != null ? Bukkit.getPlayer(owner) : null;
                String snd = a.length > 6 ? a[6] : null;
                int loop = a.length > 7 ? U.integer(a[7]) : 40;
                boolean keep = a.length > 8 && a[8].equalsIgnoreCase("reste");
                World w = a.length > 9 && Bukkit.getWorld(a[9]) != null ? Bukkit.getWorld(a[9]) : (p != null ? p.getWorld() : prologueOr(null));
                return props.vehicle(a[2], owner, a[3], w, data.pathOrInline(a[4]), U.num(a[5]), snd, loop, keep);
            }
            case "prop-retirer": {
                return props.remove(a[1]);
            }
            case "prop-silence": {
                return props.silence(a[1]);
            }
            case "sol": {
                // /zamonde sol <monde> <x> <z> : hauteur du sol (bloc solide le plus haut + 1) et point d'apparition du monde
                World w = Bukkit.getWorld(a[1]);
                if (w == null) throw new IllegalArgumentException("monde inconnu « " + a[1] + " »");
                int x = (int) Math.floor(U.num(a[2])), z = (int) Math.floor(U.num(a[3]));
                int y = w.getHighestBlockYAt(x, z) + 1;
                Location sp = w.getSpawnLocation();
                String r = "sol en " + x + "," + z + " : y=" + y + " (" + w.getBlockAt(x, y - 1, z).getType() + ") | spawn du monde : "
                        + sp.getBlockX() + " " + sp.getBlockY() + " " + sp.getBlockZ();
                reply(sender, r, true);
                return null;
            }
            case "props-liste": {
                return "props : " + props.ids();
            }
            case "son": {
                return sound(a);
            }
            case "stopson": {
                Player p = need(a[1]);
                if (a.length > 2) p.stopSound(a[2]);
                else p.stopAllSounds();
                return "sons arrêtés pour " + p.getName();
            }
            default:
                throw new IllegalArgumentException("sous-commande inconnue (voir /zamonde aide)");
        }
    }

    private String sound(String[] a) {
        String target = a[1];
        String key = a[2];
        float vol = a.length > 3 ? (float) U.num(a[3]) : 1f;
        float pitch = a.length > 4 ? (float) U.num(a[4]) : 1f;
        String at = a.length > 5 ? a[5] : null;
        SoundCategory cat = key.contains(":voix.") ? SoundCategory.VOICE
                : key.contains(":musique.") ? SoundCategory.MUSIC : SoundCategory.AMBIENT;
        List<Player> who = new ArrayList<>();
        Location center = null;
        if (target.equalsIgnoreCase("tous")) {
            who.addAll(Bukkit.getOnlinePlayers());
        } else if (target.toLowerCase(Locale.ROOT).startsWith("rayon:")) {
            String[] c = target.substring(6).split(",");
            World w = c.length > 4 ? Bukkit.getWorld(c[4]) : worlds.prologue();
            if (w == null) w = Bukkit.getWorlds().get(0);
            center = new Location(w, U.num(c[0]), U.num(c[1]), U.num(c[2]));
            double r = U.num(c[3]);
            for (Player p : w.getPlayers()) if (p.getLocation().distanceSquared(center) <= r * r) who.add(p);
        } else {
            who.add(need(target));
        }
        int n = 0;
        for (Player p : who) {
            if (at != null && at.startsWith("entite:")) {
                Entity e = npcs.find(p.getUniqueId(), at.substring(7));
                if (e == null) {
                    Entity b = props.baseOf(at.substring(7));
                    e = b;
                }
                if (e == null) throw new IllegalArgumentException("entité « " + at.substring(7) + " » introuvable");
                p.playSound(e, key, cat, vol, pitch);
            } else if (at != null && at.indexOf(',') >= 0) {
                double[] c = U.points(at).get(0);
                p.playSound(new Location(p.getWorld(), c[0], c[1], c[2]), key, cat, vol, pitch);
            } else if (center != null) {
                p.playSound(center, key, cat, vol, pitch);
            } else {
                p.playSound(p.getLocation(), key, cat, vol, pitch);
            }
            n++;
        }
        return "son " + key + " → " + n + " joueur(s)";
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> subs = Arrays.asList("aide", "monde", "construire", "placer", "recharger", "etat", "temps", "meteo", "isoler", "tp",
                    "pnj", "mm", "relever", "retirer", "marcher", "regarder", "suivre-regard", "animer", "calque", "calques-reset", "lampes",
                    "blackout", "clignoter", "camera", "camera-stop", "camera-duree", "noir", "noir-texte", "titre", "objectif", "prop",
                    "vehicule", "prop-retirer", "prop-silence", "props-liste", "son", "stopson");
            List<String> out = new ArrayList<>();
            for (String s : subs) if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
            return out;
        }
        return null;
    }
}
