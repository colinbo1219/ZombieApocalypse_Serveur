package za.monde;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.Tag;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.AbstractVillager;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.entity.Pose;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Villager;
import org.bukkit.entity.ZombieVillager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityCombustEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntitySpawnEvent;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.entity.EntityTransformEvent;
import org.bukkit.event.entity.VillagerCareerChangeEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** PNJ et MythicMobs privés : apparition, marche, regard, animations. */
final class Npcs implements Listener {
    static final class Npc {
        final UUID owner; // null = public
        final String id;
        String kind; // villager, zombie_villager, mm:<Type>
        UUID uuid;
        Entity ref;
        Location last;
        String mode = "ia";
        boolean dead;
        boolean follow;
        boolean lying;

        Npc(UUID owner, String id) {
            this.owner = owner;
            this.id = id;
        }

        String key() {
            return key(owner, id);
        }

        static String key(UUID owner, String id) {
            return (owner == null ? "public" : owner.toString()) + "|" + id;
        }
    }

    private static final class Walk {
        final Npc npc;
        final List<Vector> pts;
        final double step;
        int seg;
        double segPos;
        float yaw;
        final boolean hadAI;

        Walk(Npc npc, List<Vector> pts, double step, float yaw, boolean hadAI) {
            this.npc = npc;
            this.pts = pts;
            this.step = step;
            this.yaw = yaw;
            this.hadAI = hadAI;
        }
    }

    private static final class Fall {
        final Npc npc;
        int ticks;
        final boolean hadAI;

        Fall(Npc npc, int ticks, boolean hadAI) {
            this.npc = npc;
            this.ticks = ticks;
            this.hadAI = hadAI;
        }
    }

    private final ZAMonde pl;
    final Map<String, Npc> npcs = new LinkedHashMap<>();
    private final Map<UUID, Npc> byEntity = new HashMap<>();
    private final Map<String, Walk> walks = new HashMap<>();
    private final Map<String, Fall> falls = new HashMap<>();

    // capture des entités créées pendant un appel MythicMobs
    private boolean capturing;
    private UUID captureOwner;
    private final List<Entity> captured = new ArrayList<>();

    Npcs(ZAMonde pl) {
        this.pl = pl;
    }

    // ---------------------------------------------------------------- registre

    Npc get(UUID owner, String id) {
        return npcs.get(Npc.key(owner, id));
    }

    Entity entity(Npc n) {
        if (n == null) return null;
        if (n.ref != null && n.ref.isValid()) return n.ref;
        Entity e = n.uuid == null ? null : Bukkit.getEntity(n.uuid);
        n.ref = e != null && e.isValid() ? e : null;
        return n.ref;
    }

    Npc byEntity(Entity e) {
        return e == null ? null : byEntity.get(e.getUniqueId());
    }

    /** Recherche pour « entite:<id> » : d'abord le joueur, puis public, puis n'importe qui. */
    Entity find(UUID owner, String id) {
        Entity e = entity(get(owner, id));
        if (e != null) return e;
        e = entity(get(null, id));
        if (e != null) return e;
        for (Npc n : npcs.values()) {
            if (n.id.equals(id)) {
                e = entity(n);
                if (e != null) return e;
            }
        }
        return null;
    }

    Location lastLocation(UUID owner, String id) {
        Npc n = get(owner, id);
        if (n == null) n = get(null, id);
        if (n == null) return null;
        Entity e = entity(n);
        return e != null ? e.getLocation() : n.last;
    }

    int countFor(UUID owner) {
        int c = 0;
        for (Npc n : npcs.values()) if (owner == null ? n.owner == null : owner.equals(n.owner)) c++;
        return c;
    }

    int count() {
        return npcs.size();
    }

    List<String> idsFor(UUID owner) {
        List<String> l = new ArrayList<>();
        for (Npc n : npcs.values()) if (owner == null ? n.owner == null : owner.equals(n.owner)) l.add(n.id);
        return l;
    }

    private void tagCommon(Entity e, UUID owner, String id) {
        e.addScoreboardTag("za_pnj");
        e.addScoreboardTag("za_id:" + id);
        e.setPersistent(false);
        if (e instanceof LivingEntity le) {
            le.setRemoveWhenFarAway(false);
            le.setCollidable(false);
        }
        if (owner != null) pl.privacy.makePrivate(e, owner);
    }

    private Npc register(UUID owner, String id, String kind, Entity e, String mode) {
        Npc n = new Npc(owner, id);
        n.kind = kind;
        n.uuid = e.getUniqueId();
        n.ref = e;
        n.last = e.getLocation();
        n.mode = mode;
        npcs.put(n.key(), n);
        byEntity.put(e.getUniqueId(), n);
        return n;
    }

    /** Retire l'entité (et son enregistrement). */
    boolean remove(UUID owner, String id) {
        Npc n = npcs.remove(Npc.key(owner, id));
        if (n == null) return false;
        despawn(n);
        return true;
    }

    private void despawn(Npc n) {
        walks.remove(n.key());
        falls.remove(n.key());
        Entity e = entity(n);
        if (n.uuid != null) byEntity.remove(n.uuid);
        if (e != null) {
            try {
                if (e instanceof Villager v && v.isSleeping()) v.wakeup();
            } catch (Throwable ignored) {
                // déjà réveillé
            }
            pl.privacy.forget(e);
            e.remove();
        }
    }

    int removeAll(UUID owner) {
        int c = 0;
        for (Iterator<Npc> it = npcs.values().iterator(); it.hasNext(); ) {
            Npc n = it.next();
            if (owner == null ? n.owner == null : owner.equals(n.owner)) {
                it.remove();
                despawn(n);
                c++;
            }
        }
        return c;
    }

    /** Retire les entités du joueur qui ne sont pas dans le monde donné. */
    int removeOutside(UUID owner, World keep) {
        int c = 0;
        for (Iterator<Npc> it = npcs.values().iterator(); it.hasNext(); ) {
            Npc n = it.next();
            if (!owner.equals(n.owner)) continue;
            Entity e = entity(n);
            World w = e != null ? e.getWorld() : (n.last != null ? n.last.getWorld() : null);
            if (w != null && keep != null && w.getUID().equals(keep.getUID())) continue;
            it.remove();
            despawn(n);
            c++;
        }
        return c;
    }

    void removeEverything() {
        for (Npc n : new ArrayList<>(npcs.values())) despawn(n);
        npcs.clear();
        byEntity.clear();
        walks.clear();
        falls.clear();
    }

    // ---------------------------------------------------------------- apparitions

    String spawnVillager(UUID owner, World w, String id, String type, Location loc, String name, String mode, boolean nameVisible) {
        remove(owner, id);
        final boolean zombie = type.equalsIgnoreCase("zombie_villager");
        Class<? extends LivingEntity> cls = zombie ? ZombieVillager.class : Villager.class;
        final String m = mode == null ? "ia" : mode;
        LivingEntity le = w.spawn(loc, cls, e -> {
            e.setCustomName(name);
            e.setCustomNameVisible(nameVisible);
            e.setSilent(true);
            e.setInvulnerable(true);
            if (e instanceof Villager v) {
                v.setAdult();
                v.setProfession(Villager.Profession.NONE);
                v.setVillagerLevel(1);
                v.setRecipes(Collections.emptyList());
            }
            if (e instanceof ZombieVillager z) {
                z.setAdult();
                z.setVillagerProfession(Villager.Profession.NONE);
            }
            e.setAI(m.equals("ia"));
            tagCommon(e, owner, id);
        });
        Npc n = register(owner, id, zombie ? "zombie_villager" : "villager", le, m);
        le.setRotation(loc.getYaw(), 0f);
        if (m.equals("dort")) {
            n.lying = true;
            boolean slept = false;
            if (le instanceof Villager v) {
                Block b = loc.getBlock();
                if (!Tag.BEDS.isTagged(b.getType())) b = b.getRelative(0, -1, 0);
                if (Tag.BEDS.isTagged(b.getType())) {
                    try {
                        slept = v.sleep(b.getLocation());
                    } catch (Throwable t) {
                        slept = false;
                    }
                }
            }
            if (!slept) Nms.setPose(le, Pose.SLEEPING);
            return "PNJ " + id + " (" + n.kind + ", " + (slept ? "dort dans le lit" : "allongé") + ") en " + U.fmtLoc(le.getLocation());
        }
        return "PNJ " + id + " (" + n.kind + ", " + m + ") en " + U.fmtLoc(le.getLocation());
    }

    String spawnMythic(UUID owner, World w, String id, String type, Location loc, String name) {
        remove(owner, id);
        Entity e = mythic(owner, type, loc);
        if (name != null && !name.isEmpty()) e.setCustomName(name);
        tagCommon(e, owner, id);
        e.setRotation(loc.getYaw(), 0f);
        register(owner, id, "mm:" + type, e, "ia");
        return "MythicMob " + type + " « " + id + " » en " + U.fmtLoc(e.getLocation()) + (owner == null ? " (public)" : "");
    }

    /** Apparition MythicMobs en capturant les entités créées pour les rendre privées AVANT leur envoi réseau. */
    private Entity mythic(UUID owner, String type, Location loc) {
        capturing = true;
        captureOwner = owner;
        captured.clear();
        Entity e;
        try {
            e = Mythic.spawn(type, loc);
        } finally {
            capturing = false;
            captureOwner = null;
        }
        for (Entity extra : captured) {
            if (extra != e && extra.isValid()) {
                extra.addScoreboardTag("za_pnj");
                extra.setPersistent(false);
            }
        }
        captured.clear();
        if (e instanceof LivingEntity le) le.setRemoveWhenFarAway(false);
        return e;
    }

    String relever(UUID owner, World defWorld, String id, String type, String name) {
        Npc old = get(owner, id);
        if (old == null) throw new IllegalArgumentException("aucune entité « " + id + " »");
        Entity e = entity(old);
        Location loc = e != null ? e.getLocation() : old.last;
        if (loc == null || loc.getWorld() == null) throw new IllegalArgumentException("position inconnue pour « " + id + " »");
        loc = loc.clone();
        loc.setPitch(0f);
        remove(owner, id);
        return spawnMythic(owner, loc.getWorld(), id, type, loc, name) + " (relevé)";
    }

    // ---------------------------------------------------------------- mouvements

    String walk(UUID owner, String id, double speed, List<double[]> pts) {
        Npc n = get(owner, id);
        Entity e = entity(n);
        if (e == null) throw new IllegalArgumentException("entité « " + id + " » introuvable");
        falls.remove(n.key());
        List<Vector> v = new ArrayList<>();
        Location cur = e.getLocation();
        v.add(cur.toVector());
        for (double[] p : pts) v.add(U.vec(p));
        boolean hadAI = e instanceof LivingEntity le && le.hasAI();
        Walk old = walks.remove(n.key());
        if (old != null) hadAI = old.hadAI;
        if (e instanceof Villager vil && vil.isSleeping()) vil.wakeup();
        if (n.lying) {
            Nms.setPose(e, Pose.STANDING);
            n.lying = false;
        }
        if (e instanceof LivingEntity le) le.setAI(false);
        walks.put(n.key(), new Walk(n, v, Math.max(0.01, speed) / 20.0, cur.getYaw(), hadAI));
        return "marche de « " + id + " » : " + pts.size() + " points à " + U.fmt(speed) + " b/s";
    }

    String lookAt(UUID owner, String id, Location target, boolean atOwner) {
        Npc n = get(owner, id);
        Entity e = entity(n);
        if (e == null) throw new IllegalArgumentException("entité « " + id + " » introuvable");
        if (atOwner) {
            Player p = targetPlayer(n, e);
            if (p == null) throw new IllegalArgumentException("aucun joueur à regarder");
            target = p.getEyeLocation();
        }
        face(e, target);
        return "« " + id + " » regarde " + U.fmtLoc(target);
    }

    String follow(UUID owner, String id, boolean on) {
        Npc n = get(owner, id);
        if (entity(n) == null) throw new IllegalArgumentException("entité « " + id + " » introuvable");
        n.follow = on;
        return "suivi du regard « " + id + " » : " + (on ? "on" : "off");
    }

    private Player targetPlayer(Npc n, Entity e) {
        if (n.owner != null) return Bukkit.getPlayer(n.owner);
        Player best = null;
        double bd = Double.MAX_VALUE;
        for (Player p : e.getWorld().getPlayers()) {
            double d = p.getLocation().distanceSquared(e.getLocation());
            if (d < bd) {
                bd = d;
                best = p;
            }
        }
        return best;
    }

    private static void face(Entity e, Location target) {
        Location eye = e instanceof LivingEntity le ? le.getEyeLocation() : e.getLocation();
        double dx = target.getX() - eye.getX(), dy = target.getY() - eye.getY(), dz = target.getZ() - eye.getZ();
        if (dx * dx + dz * dz < 1.0E-6) return;
        e.setRotation(U.yawOf(dx, dz), Math.max(-60f, Math.min(60f, U.pitchOf(dx, dy, dz))));
    }

    /** Appelé à chaque tick. */
    void tick(long now) {
        if (!walks.isEmpty()) {
            for (Iterator<Walk> it = walks.values().iterator(); it.hasNext(); ) {
                Walk w = it.next();
                try {
                    if (stepWalk(w)) it.remove();
                } catch (Throwable t) {
                    Nms.warnOnce("walk", "Erreur de marche", t);
                    it.remove();
                }
            }
        }
        if (!falls.isEmpty()) {
            for (Iterator<Fall> it = falls.values().iterator(); it.hasNext(); ) {
                Fall f = it.next();
                if (--f.ticks > 0) continue;
                it.remove();
                Entity e = entity(f.npc);
                if (e != null) {
                    Nms.setPose(e, Pose.STANDING);
                    f.npc.lying = false;
                    if (e instanceof LivingEntity le) le.setAI(f.hadAI);
                }
            }
        }
        if ((now & 1) == 0) {
            for (Npc n : npcs.values()) {
                if (!n.follow || walks.containsKey(n.key())) continue;
                Entity e = entity(n);
                if (e == null) continue;
                Player p = targetPlayer(n, e);
                if (p != null && p.getWorld().equals(e.getWorld())) face(e, p.getEyeLocation());
            }
        }
        if (now % 20 == 0) {
            for (Npc n : npcs.values()) {
                Entity e = entity(n);
                if (e != null) n.last = e.getLocation();
            }
        }
    }

    private boolean stepWalk(Walk w) {
        Entity e = entity(w.npc);
        if (e == null) return true;
        double remaining = w.step;
        int last = w.pts.size() - 1;
        while (remaining > 0 && w.seg < last) {
            Vector a = w.pts.get(w.seg), b = w.pts.get(w.seg + 1);
            double len = a.distance(b);
            if (w.segPos + remaining >= len) {
                remaining -= (len - w.segPos);
                w.seg++;
                w.segPos = 0;
            } else {
                w.segPos += remaining;
                remaining = 0;
            }
        }
        boolean done = w.seg >= last;
        Vector pos;
        Vector dir;
        if (done) {
            pos = w.pts.get(last).clone();
            dir = last > 0 ? w.pts.get(last).clone().subtract(w.pts.get(last - 1)) : new Vector();
        } else {
            Vector a = w.pts.get(w.seg), b = w.pts.get(w.seg + 1);
            double len = a.distance(b);
            double t = len < 1e-9 ? 1 : w.segPos / len;
            pos = a.clone().add(b.clone().subtract(a).multiply(t));
            dir = b.clone().subtract(a);
        }
        World world = e.getWorld();
        double y = U.groundY(world, pos.getX(), pos.getY(), pos.getZ());
        if (dir.getX() * dir.getX() + dir.getZ() * dir.getZ() > 1e-6) {
            float target = U.yawOf(dir.getX(), dir.getZ());
            float diff = U.wrap(target - w.yaw);
            w.yaw = U.wrap(w.yaw + Math.max(-30f, Math.min(30f, diff)));
        }
        Location to = new Location(world, pos.getX(), y, pos.getZ(), w.yaw, 0f);
        e.teleport(to);
        if (done) {
            if (e instanceof LivingEntity le) le.setAI(w.hadAI);
            w.npc.last = to;
        }
        return done;
    }

    // ---------------------------------------------------------------- animations

    String animate(UUID owner, String id, String anim) {
        Npc n = get(owner, id);
        Entity e = entity(n);
        if (e == null) throw new IllegalArgumentException("entité « " + id + " » introuvable");
        switch (anim) {
            case "bras" -> {
                if (e instanceof LivingEntity le) le.swingMainHand();
            }
            case "degat" -> {
                if (e instanceof LivingEntity le) le.playHurtAnimation(0f);
                Sound s = hurtSound(e);
                for (Player p : viewers(n, e)) p.playSound(e, s, SoundCategory.NEUTRAL, 1f, 1f);
            }
            case "mort" -> {
                walks.remove(n.key());
                falls.remove(n.key());
                n.follow = false;
                n.dead = true;
                n.last = e.getLocation();
                if (n.lying || e.getPose() == Pose.SLEEPING) {
                    // L'animation de mort vanilla d'une entité allongée est incohérente : elle reste allongée, immobile.
                    if (e instanceof LivingEntity le) {
                        le.setAI(false);
                        le.playHurtAnimation(0f);
                    }
                    return "« " + id + " » meurt (reste allongé)";
                }
                if (e instanceof LivingEntity le) {
                    le.setInvulnerable(false);
                    le.setAI(false);
                    try {
                        le.setHealth(0.0);
                    } catch (Throwable t) {
                        le.damage(1.0E6);
                    }
                } else {
                    e.remove();
                }
            }
            case "tousse" -> {
                Location l = e instanceof LivingEntity le ? le.getEyeLocation() : e.getLocation().add(0, 1.5, 0);
                Vector fwd = l.getDirection().setY(0);
                if (fwd.lengthSquared() > 1e-6) fwd.normalize().multiply(0.35);
                Location at = l.clone().add(fwd).add(0, -0.15, 0);
                for (Player p : viewers(n, e)) {
                    p.spawnParticle(Particle.SNEEZE, at, 6, 0.08, 0.05, 0.08, 0.01);
                    p.spawnParticle(Particle.ASH, at, 10, 0.12, 0.08, 0.12, 0.0);
                    p.playSound(e, "za_modeles:sfx.toux", SoundCategory.NEUTRAL, 1f, 1f);
                }
                if (e instanceof LivingEntity le) le.swingMainHand();
            }
            case "tomber" -> {
                walks.remove(n.key());
                boolean hadAI = e instanceof LivingEntity le && le.hasAI();
                Fall old = falls.remove(n.key());
                if (old != null) hadAI = old.hadAI;
                if (e instanceof LivingEntity le) le.setAI(false);
                if (!Nms.setPose(e, Pose.SLEEPING)) throw new IllegalStateException("pose allongée indisponible");
                n.lying = true;
                falls.put(n.key(), new Fall(n, 60, hadAI));
            }
            default -> throw new IllegalArgumentException("animation inconnue « " + anim + " » (bras|degat|mort|tousse|tomber)");
        }
        return "animation " + anim + " de « " + id + " »";
    }

    private static Sound hurtSound(Entity e) {
        try {
            return Sound.valueOf("ENTITY_" + e.getType().name() + "_HURT");
        } catch (IllegalArgumentException ex) {
            return Sound.ENTITY_GENERIC_HURT;
        }
    }

    /** Joueurs qui voient l'entité : le propriétaire, ou les joueurs du monde pour une entité publique. */
    List<Player> viewers(Npc n, Entity e) {
        if (n != null && n.owner != null) {
            Player p = Bukkit.getPlayer(n.owner);
            return p == null ? Collections.emptyList() : Collections.singletonList(p);
        }
        return e.getWorld().getPlayers();
    }

    // ---------------------------------------------------------------- événements

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onSpawn(EntitySpawnEvent e) {
        if (!capturing) return;
        captured.add(e.getEntity());
        if (captureOwner != null) pl.privacy.makePrivate(e.getEntity(), captureOwner);
    }

    private static Entity source(Entity d) {
        if (d instanceof Projectile pr && pr.getShooter() instanceof Entity sh) return sh;
        return d;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onTarget(EntityTargetEvent e) {
        Entity t = e.getTarget();
        if (t == null) return;
        UUID so = pl.privacy.ownerOf(e.getEntity());
        UUID to = pl.privacy.ownerOf(t);
        if (so != null) {
            if (t instanceof Player p && !p.getUniqueId().equals(so)) e.setCancelled(true);
            else if (to != null && !to.equals(so)) e.setCancelled(true);
        } else if (to != null && !(e.getEntity() instanceof Player)) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent e) {
        Entity d = source(e.getDamager());
        Entity v = e.getEntity();
        UUID dOwner = pl.privacy.ownerOf(d), vOwner = pl.privacy.ownerOf(v);
        if (dOwner != null && v instanceof Player p && !p.getUniqueId().equals(dOwner)) e.setCancelled(true);
        else if (vOwner != null && d instanceof Player p && !p.getUniqueId().equals(vOwner)) e.setCancelled(true);
        else if (dOwner != null && vOwner != null && !dOwner.equals(vOwner)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInteract(PlayerInteractEntityEvent e) {
        if (e.getRightClicked() instanceof AbstractVillager && e.getRightClicked().getScoreboardTags().contains("za_pnj")) {
            e.setCancelled(true);
        } else if (e.getRightClicked() instanceof ZombieVillager && e.getRightClicked().getScoreboardTags().contains("za_pnj")) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onOpen(InventoryOpenEvent e) {
        if (e.getInventory().getHolder() instanceof Entity en && en.getScoreboardTags().contains("za_pnj")) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onCareer(VillagerCareerChangeEvent e) {
        if (e.getEntity().getScoreboardTags().contains("za_pnj")) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onCombust(EntityCombustEvent e) {
        Npc n = byEntity.get(e.getEntity().getUniqueId());
        if (n != null && !n.kind.startsWith("mm:")) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onTransform(EntityTransformEvent e) {
        if (e.getEntity().getScoreboardTags().contains("za_pnj")) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDeath(EntityDeathEvent e) {
        if (!e.getEntity().getScoreboardTags().contains("za_pnj")) return;
        e.getDrops().clear();
        e.setDroppedExp(0);
        Npc n = byEntity.get(e.getEntity().getUniqueId());
        if (n != null) {
            n.dead = true;
            n.last = e.getEntity().getLocation();
            walks.remove(n.key());
        }
    }
}
