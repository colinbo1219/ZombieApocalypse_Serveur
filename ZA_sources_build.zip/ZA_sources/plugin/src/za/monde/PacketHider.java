package za.monde;

import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelOutboundHandlerAdapter;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.ChannelPromise;
import org.bukkit.entity.Player;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Masquage d'entités par joueur au niveau réseau.
 *
 * Constat sur Arclight 1.20.1 (build 5dc8683) : le suivi d'entités de Forge (ChunkMap.TrackedEntity#updatePlayer)
 * ne consulte pas CraftPlayer#canSee ; Player#hideEntity retire l'entité une fois, puis elle est renvoyée au
 * prochain recalcul du suivi. Ce gestionnaire Netty supprime donc les paquets d'apparition (seuls ou dans un
 * « bundle ») des entités masquées pour ce joueur ; sans apparition, le client ignore tous les autres paquets
 * qui les concernent. En cas d'erreur, le paquet passe inchangé.
 */
final class PacketHider {
    static final String NAME = "za_monde_masque";

    private final Map<UUID, Set<Integer>> hidden = new ConcurrentHashMap<>();
    /** heure figée par joueur : les paquets d'heure du serveur sont réécrits (setPlayerTime ne marche pas sur Arclight) */
    private final Map<UUID, Long> timeOverride = new ConcurrentHashMap<>();
    private Class<?> timePkt;
    private Method timeGame;
    private Constructor<?> timeCtor;
    private final Map<UUID, Channel> channels = new ConcurrentHashMap<>();
    private volatile boolean ready;
    private volatile boolean enabled = true;

    private Class<?> addEntity, addPlayer, addOrb, bundle;
    private Method addEntityId, addPlayerId, addOrbId, bundleSubs;
    private Constructor<?> bundleCtor;
    private String initError;

    void setEnabled(boolean on) {
        enabled = on;
    }

    boolean isReady() {
        return ready && enabled;
    }

    String status() {
        if (!enabled) return "désactivé (config)";
        if (!ready) return "indisponible" + (initError != null ? " (" + initError + ")" : "");
        return "actif, " + channels.size() + " canal(aux)";
    }

    private void init(ClassLoader cl) {
        if (ready || initError != null) return;
        try {
            String g = "net.minecraft.network.protocol.game.";
            addEntity = Class.forName(g + "ClientboundAddEntityPacket", false, cl);
            addPlayer = Class.forName(g + "ClientboundAddPlayerPacket", false, cl);
            addOrb = Class.forName(g + "ClientboundAddExperienceOrbPacket", false, cl);
            bundle = Class.forName(g + "ClientboundBundlePacket", false, cl);
            addEntityId = intGetter(addEntity, "m_131496_");
            addPlayerId = intGetter(addPlayer, "m_131603_");
            addOrbId = intGetter(addOrb, "m_131524_");
            Class<?> bp = Class.forName("net.minecraft.network.protocol.BundlePacket", false, cl);
            bundleSubs = bp.getDeclaredMethod("m_264216_");
            bundleSubs.setAccessible(true);
            bundleCtor = bundle.getConstructor(Iterable.class);
            timePkt = Class.forName(g + "ClientboundSetTimePacket", false, cl);
            timeGame = timePkt.getDeclaredMethod("m_133358_");
            timeGame.setAccessible(true);
            timeCtor = timePkt.getConstructor(long.class, long.class, boolean.class);
            ready = true;
        } catch (Throwable t) {
            initError = t.toString();
            ZAMonde.log().log(Level.WARNING, "Masquage réseau indisponible : " + t);
        }
    }

    private static Method intGetter(Class<?> c, String srg) throws NoSuchMethodException {
        Method m = c.getDeclaredMethod(srg);
        if (m.getReturnType() != int.class) throw new NoSuchMethodException(c.getSimpleName() + "." + srg);
        m.setAccessible(true);
        return m;
    }

    /** Installe le filtre sur la connexion du joueur (à la connexion). */
    void inject(Player p) {
        if (!enabled) return;
        try {
            Object h = Nms.handle(p);
            if (h == null) return;
            init(h.getClass().getClassLoader());
            if (!ready) return;
            Object o = Nms.channel(p);
            if (!(o instanceof Channel ch)) return;
            UUID id = p.getUniqueId();
            ChannelPipeline pl = ch.pipeline();
            if (pl.get(NAME) != null) pl.remove(NAME);
            Handler hd = new Handler(id);
            if (pl.get("packet_handler") != null) pl.addBefore("packet_handler", NAME, hd);
            else pl.addLast(NAME, hd);
            channels.put(id, ch);
        } catch (Throwable t) {
            Nms.warnOnce("inject", "Installation du filtre réseau impossible pour " + p.getName(), t);
        }
    }

    void uninject(UUID id) {
        Channel ch = channels.remove(id);
        if (ch == null) return;
        try {
            ch.eventLoop().execute(() -> {
                try {
                    if (ch.pipeline().get(NAME) != null) ch.pipeline().remove(NAME);
                } catch (Throwable ignored) {
                    // canal fermé
                }
            });
        } catch (Throwable ignored) {
            // boucle arrêtée
        }
    }

    void uninjectAll() {
        for (UUID id : new ArrayList<>(channels.keySet())) uninject(id);
    }

    /** Heure figée pour ce joueur (null = heure du monde). Retourne le paquet à envoyer tout de suite (ou null). */
    Object setTime(UUID viewer, Long dayTime, long gameTime) {
        if (dayTime == null) {
            timeOverride.remove(viewer);
            return null;
        }
        timeOverride.put(viewer, dayTime);
        try {
            return timeCtor == null ? null : timeCtor.newInstance(gameTime, dayTime, false);
        } catch (Throwable t) {
            return null;
        }
    }

    boolean hasTime(UUID viewer) {
        return timeOverride.containsKey(viewer);
    }

    private Object rewriteTime(UUID viewer, Object msg) {
        Long t = timeOverride.get(viewer);
        if (t == null || timePkt == null || !timePkt.isInstance(msg)) return msg;
        try {
            long game = (long) timeGame.invoke(msg);
            return timeCtor.newInstance(game, t, false);
        } catch (Throwable e) {
            return msg;
        }
    }

    void hide(UUID viewer, int entityId) {
        hidden.computeIfAbsent(viewer, k -> ConcurrentHashMap.newKeySet()).add(entityId);
    }

    void unhide(UUID viewer, int entityId) {
        Set<Integer> s = hidden.get(viewer);
        if (s != null) s.remove(entityId);
    }

    /** L'entité n'existe plus : on l'oublie pour tous les joueurs. */
    void forget(int entityId) {
        for (Set<Integer> s : hidden.values()) s.remove(entityId);
    }

    void forgetViewer(UUID viewer) {
        hidden.remove(viewer);
        timeOverride.remove(viewer);
    }

    int hiddenCount(UUID viewer) {
        Set<Integer> s = hidden.get(viewer);
        return s == null ? 0 : s.size();
    }

    boolean isHidden(UUID viewer, int id) {
        Set<Integer> s = hidden.get(viewer);
        return s != null && s.contains(id);
    }

    private int spawnId(Object pkt) {
        try {
            if (addEntity.isInstance(pkt)) return (int) addEntityId.invoke(pkt);
            if (addPlayer.isInstance(pkt)) return (int) addPlayerId.invoke(pkt);
            if (addOrb.isInstance(pkt)) return (int) addOrbId.invoke(pkt);
        } catch (Throwable ignored) {
            // inconnu
        }
        return Integer.MIN_VALUE;
    }

    /** Retourne le message à écrire (éventuellement reconstruit), ou null pour l'abandonner. */
    Object filter(Set<Integer> ids, Object msg) throws Exception {
        if (bundle.isInstance(msg)) {
            Iterable<?> subs = (Iterable<?>) bundleSubs.invoke(msg);
            boolean hit = false;
            int spawns = 0;
            for (Object s : subs) {
                int id = spawnId(s);
                if (id != Integer.MIN_VALUE) {
                    spawns++;
                    if (ids.contains(id)) hit = true;
                }
            }
            if (!hit) return msg;
            if (spawns <= 1) return null; // « bundle » d'appariement d'une seule entité masquée
            List<Object> keep = new ArrayList<>();
            for (Object s : subs) {
                int id = spawnId(s);
                if (id != Integer.MIN_VALUE && ids.contains(id)) continue;
                keep.add(s);
            }
            if (keep.isEmpty()) return null;
            return bundleCtor.newInstance(Collections.unmodifiableList(keep));
        }
        int id = spawnId(msg);
        if (id != Integer.MIN_VALUE && ids.contains(id)) return null;
        return msg;
    }

    private final class Handler extends ChannelOutboundHandlerAdapter {
        private final UUID viewer;

        Handler(UUID viewer) {
            this.viewer = viewer;
        }

        @Override
        public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) throws Exception {
            Object out = msg;
            try {
                if (enabled && ready) {
                    Set<Integer> ids = hidden.get(viewer);
                    if (ids != null && !ids.isEmpty()) out = filter(ids, msg);
                    if (out != null && !timeOverride.isEmpty()) out = rewriteTime(viewer, out);
                }
            } catch (Throwable t) {
                out = msg;
            }
            if (out == null) {
                promise.trySuccess();
                return;
            }
            super.write(ctx, out, promise);
        }
    }
}
