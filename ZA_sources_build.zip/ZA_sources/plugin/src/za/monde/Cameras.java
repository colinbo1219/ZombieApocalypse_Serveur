package za.monde;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.NamespacedKey;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Cinématiques : le joueur passe en spectateur et « regarde à travers » une entité support invisible (ArmorStand marker)
 * déplacée à chaque tick le long d'images clés [x,y,z,yaw,pitch,ticks] (interpolation Catmull-Rom sur la position,
 * lissée sur les angles). À la fin : mode de jeu et position d'origine (ou position donnée).
 * Si le joueur se déconnecte pendant la caméra, l'état est mémorisé dans ses données persistantes et restauré à la reconnexion.
 */
final class Cameras implements Listener {
    private static final class Shot {
        final UUID player;
        final List<double[]> keys;
        final int[] startTick; // tick de début de chaque segment
        final int total;
        final GameMode mode;
        final Location back;
        final Location end; // null = retour
        ArmorStand stand;
        int t;
        double eye;

        Shot(UUID player, List<double[]> keys, GameMode mode, Location back, Location end) {
            this.player = player;
            this.keys = keys;
            this.mode = mode;
            this.back = back;
            this.end = end;
            startTick = new int[keys.size()];
            int acc = 0;
            for (int i = 0; i < keys.size(); i++) {
                startTick[i] = acc;
                if (i < keys.size() - 1) acc += Math.max(1, (int) Math.round(keys.get(i)[5]));
            }
            total = acc;
        }
    }

    private final ZAMonde pl;
    private final Map<UUID, Shot> shots = new HashMap<>();
    private final NamespacedKey kMode, kBack;

    Cameras(ZAMonde pl) {
        this.pl = pl;
        kMode = new NamespacedKey(pl, "camera_mode");
        kBack = new NamespacedKey(pl, "camera_retour");
    }

    boolean active(Player p) {
        return p != null && shots.containsKey(p.getUniqueId());
    }

    int count() {
        return shots.size();
    }

    static int duration(List<double[]> keys) {
        int acc = 0;
        for (int i = 0; i < keys.size() - 1; i++) acc += Math.max(1, (int) Math.round(keys.get(i)[5]));
        return acc;
    }

    String start(Player p, List<double[]> keys, World w, Location end) {
        if (keys.size() < 2) throw new IllegalArgumentException("il faut au moins 2 images clés");
        stop(p, false);
        GameMode mode = p.getGameMode();
        Location back = p.getLocation().clone();
        Shot s = new Shot(p.getUniqueId(), keys, mode, back, end);
        double[] k0 = keys.get(0);
        Location l0 = new Location(w, k0[0], k0[1], k0[2], (float) k0[3], (float) k0[4]);
        ArmorStand st = w.spawn(l0, ArmorStand.class, a -> {
            a.setInvisible(true);
            a.setMarker(true);
            a.setGravity(false);
            a.setInvulnerable(true);
            a.setSilent(true);
            a.setPersistent(false);
            a.setBasePlate(false);
            a.setCanPickupItems(false);
            a.addScoreboardTag("za_pnj");
            a.addScoreboardTag("za_camera");
            pl.privacy.makePrivate(a, p.getUniqueId());
        });
        s.stand = st;
        s.eye = st.getEyeHeight();
        // mémoire persistante (déconnexion pendant la caméra)
        try {
            p.getPersistentDataContainer().set(kMode, PersistentDataType.STRING, mode.name());
            p.getPersistentDataContainer().set(kBack, PersistentDataType.STRING, ser(end != null ? end : back));
        } catch (Throwable ignored) {
            // sans importance
        }
        shots.put(p.getUniqueId(), s);
        pl.hud.suspend(p, true);
        place(s, 0);
        p.setGameMode(GameMode.SPECTATOR);
        p.teleport(st.getLocation());
        Bukkit.getScheduler().runTaskLater(pl, () -> {
            if (shots.get(p.getUniqueId()) == s && p.isOnline()) Nms.camera(p, st);
        }, 3L);
        return "caméra pour " + p.getName() + " : " + keys.size() + " images clés, " + s.total + " ticks";
    }

    private static String ser(Location l) {
        return l.getWorld().getName() + ";" + l.getX() + ";" + l.getY() + ";" + l.getZ() + ";" + l.getYaw() + ";" + l.getPitch();
    }

    private static Location deser(String s) {
        try {
            String[] a = s.split(";");
            World w = Bukkit.getWorld(a[0]);
            if (w == null) return null;
            return new Location(w, Double.parseDouble(a[1]), Double.parseDouble(a[2]), Double.parseDouble(a[3]),
                    Float.parseFloat(a[4]), Float.parseFloat(a[5]));
        } catch (Throwable t) {
            return null;
        }
    }

    private static double cr(double p0, double p1, double p2, double p3, double t) {
        double t2 = t * t, t3 = t2 * t;
        return 0.5 * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 + (-p0 + 3 * p1 - 3 * p2 + p3) * t3);
    }

    private static double smooth(double t) {
        return t * t * (3 - 2 * t);
    }

    /** Position de la caméra au tick t. */
    private void place(Shot s, int t) {
        List<double[]> k = s.keys;
        int n = k.size();
        int i = 0;
        while (i < n - 2 && t >= s.startTick[i + 1]) i++;
        int len = Math.max(1, s.startTick[Math.min(i + 1, n - 1)] - s.startTick[i]);
        double u = Math.max(0, Math.min(1, (t - s.startTick[i]) / (double) len));
        double[] p0 = k.get(Math.max(0, i - 1)), p1 = k.get(i), p2 = k.get(Math.min(n - 1, i + 1)), p3 = k.get(Math.min(n - 1, i + 2));
        double x = cr(p0[0], p1[0], p2[0], p3[0], u);
        double y = cr(p0[1], p1[1], p2[1], p3[1], u);
        double z = cr(p0[2], p1[2], p2[2], p3[2], u);
        double us = smooth(u);
        double yaw = p1[3] + U.wrapD(p2[3] - p1[3]) * us;
        double pitch = p1[4] + (p2[4] - p1[4]) * us;
        if (s.stand != null && s.stand.isValid()) {
            Nms.absMoveTo(s.stand, x, y - s.eye, z, (float) yaw, (float) pitch);
            s.stand.setRotation((float) yaw, (float) pitch);
            s.stand.setHeadPose(new org.bukkit.util.EulerAngle(Math.toRadians(pitch), 0, 0));
        }
    }

    void tick() {
        if (shots.isEmpty()) return;
        for (Iterator<Map.Entry<UUID, Shot>> it = shots.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<UUID, Shot> en = it.next();
            Shot s = en.getValue();
            Player p = Bukkit.getPlayer(en.getKey());
            try {
                if (p == null || !p.isOnline()) {
                    if (s.stand != null) s.stand.remove();
                    it.remove();
                    continue;
                }
                s.t++;
                if (s.t > s.total) {
                    it.remove();
                    finish(p, s);
                    continue;
                }
                place(s, s.t);
                if (p.getGameMode() != GameMode.SPECTATOR) p.setGameMode(GameMode.SPECTATOR);
                // le serveur ne sait pas que le joueur « regarde » le support : on déplace le joueur avec lui
                // (chargement des tronçons autour de la caméra) et on renvoie le paquet de caméra de temps en temps
                if (s.t % 10 == 0 && s.stand != null) {
                    Location sl = s.stand.getLocation();
                    p.teleport(sl, PlayerTeleportEvent.TeleportCause.PLUGIN);
                }
                if (s.t % 40 == 5 && s.stand != null) Nms.camera(p, s.stand);
            } catch (Throwable t) {
                Nms.warnOnce("camera", "Erreur de caméra", t);
                it.remove();
                if (p != null) finish(p, s);
            }
        }
    }

    private void finish(Player p, Shot s) {
        Nms.camera(p, p);
        Location to = s.end != null ? s.end : s.back;
        p.teleport(to);
        p.setGameMode(s.mode);
        if (s.stand != null) {
            pl.privacy.forget(s.stand);
            s.stand.remove();
        }
        try {
            p.getPersistentDataContainer().remove(kMode);
            p.getPersistentDataContainer().remove(kBack);
        } catch (Throwable ignored) {
            // rien
        }
        pl.hud.suspend(p, false);
    }

    /** Arrête la caméra ; restaure mode et position si demandé. */
    String stop(Player p, boolean restore) {
        Shot s = shots.remove(p.getUniqueId());
        if (s == null) return "aucune caméra pour " + p.getName();
        if (restore) finish(p, s);
        else if (s.stand != null) {
            pl.privacy.forget(s.stand);
            s.stand.remove();
        }
        return "caméra arrêtée pour " + p.getName();
    }

    void stopAll() {
        for (UUID id : new java.util.ArrayList<>(shots.keySet())) {
            Player p = Bukkit.getPlayer(id);
            Shot s = shots.remove(id);
            if (p != null && s != null) finish(p, s);
            else if (s != null && s.stand != null) s.stand.remove();
        }
    }

    // ---------------------------------------------------------------- événements

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onSneak(PlayerToggleSneakEvent e) {
        if (active(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent e) {
        if (!active(e.getPlayer())) return;
        if (e.getCause() == PlayerTeleportEvent.TeleportCause.SPECTATE) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent e) {
        Shot s = shots.remove(e.getPlayer().getUniqueId());
        if (s == null) return;
        Player p = e.getPlayer();
        try {
            p.setGameMode(s.mode);
            p.teleport(s.end != null ? s.end : s.back);
            p.getPersistentDataContainer().remove(kMode);
            p.getPersistentDataContainer().remove(kBack);
        } catch (Throwable ignored) {
            // restauré à la reconnexion via les données persistantes
        }
        if (s.stand != null) s.stand.remove();
    }

    @EventHandler(priority = EventPriority.LOW)
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        try {
            String m = p.getPersistentDataContainer().get(kMode, PersistentDataType.STRING);
            if (m == null) return;
            String b = p.getPersistentDataContainer().get(kBack, PersistentDataType.STRING);
            p.getPersistentDataContainer().remove(kMode);
            p.getPersistentDataContainer().remove(kBack);
            GameMode gm = GameMode.valueOf(m);
            Location back = b != null ? deser(b) : null;
            Bukkit.getScheduler().runTaskLater(pl, () -> {
                if (!p.isOnline()) return;
                p.setGameMode(gm);
                if (back != null) p.teleport(back);
            }, 5L);
        } catch (Throwable ignored) {
            // rien à restaurer
        }
    }

    Entity standOf(Player p) {
        Shot s = shots.get(p.getUniqueId());
        return s == null ? null : s.stand;
    }
}
