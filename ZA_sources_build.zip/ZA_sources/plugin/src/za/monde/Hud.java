package za.monde;

import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Boussole d'objectif (barre d'action) et écrans noirs / titres stylés. */
final class Hud {
    private static final class Goal {
        final String text;
        final Location target;
        boolean reached;

        Goal(String text, Location target) {
            this.text = text;
            this.target = target;
        }
    }

    private static final String[] ARROWS = {"⬆", "⬈", "➡", "⬊", "⬇", "⬋", "⬅", "⬉"};

    private final ZAMonde pl;
    private final Map<UUID, Goal> goals = new HashMap<>();
    private final Set<UUID> suspended = new HashSet<>();

    Hud(ZAMonde pl) {
        this.pl = pl;
    }

    int count() {
        return goals.size();
    }

    String objective(Player p, String text, Location target) {
        goals.put(p.getUniqueId(), new Goal(text, target));
        show(p, goals.get(p.getUniqueId()));
        return "objectif « " + text + " » pour " + p.getName() + " → " + U.fmtLoc(target);
    }

    String objectiveOff(Player p) {
        Goal g = goals.remove(p.getUniqueId());
        if (g != null) {
            try {
                p.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent(""));
            } catch (Throwable ignored) {
                // rien
            }
        }
        return "objectif retiré pour " + p.getName();
    }

    /** Distance à l'objectif (ou -1) — utile à Skript via /zamonde objectif-distance (log). */
    double distance(Player p) {
        Goal g = goals.get(p.getUniqueId());
        if (g == null || g.target.getWorld() == null || !g.target.getWorld().equals(p.getWorld())) return -1;
        return g.target.distance(p.getLocation());
    }

    void suspend(Player p, boolean on) {
        if (on) suspended.add(p.getUniqueId());
        else suspended.remove(p.getUniqueId());
    }

    void forget(UUID id) {
        goals.remove(id);
        suspended.remove(id);
    }

    void tick(long now) {
        if (now % 10 != 0 || goals.isEmpty()) return;
        for (Iterator<Map.Entry<UUID, Goal>> it = goals.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<UUID, Goal> en = it.next();
            Player p = Bukkit.getPlayer(en.getKey());
            if (p == null) {
                it.remove();
                continue;
            }
            if (suspended.contains(p.getUniqueId())) continue;
            show(p, en.getValue());
        }
    }

    private void show(Player p, Goal g) {
        try {
            String msg;
            if (g.target.getWorld() == null || !g.target.getWorld().equals(p.getWorld())) {
                msg = "§e✦ §f" + g.text;
            } else {
                Location l = p.getLocation();
                double dx = g.target.getX() - l.getX(), dz = g.target.getZ() - l.getZ();
                double dy = g.target.getY() - l.getY();
                double d = Math.sqrt(dx * dx + dz * dz + dy * dy * 0.25);
                if (d < 3.0) {
                    msg = "§a✔ §f" + g.text;
                } else {
                    double targetYaw = U.yawOf(dx, dz);
                    double rel = U.wrapD(targetYaw - l.getYaw());
                    int idx = (int) Math.floor(((rel + 360.0 + 22.5) % 360.0) / 45.0) & 7;
                    String etage = "";
                    if (dy > 2.5) etage = " §b▲";
                    else if (dy < -2.5) etage = " §b▼";
                    msg = "§e" + ARROWS[idx] + " §f" + g.text + " §7· " + (int) Math.round(d) + " m" + etage;
                }
            }
            p.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent(msg));
        } catch (Throwable t) {
            Nms.warnOnce("hud", "Barre d'action indisponible", t);
        }
    }

    // ---------------------------------------------------------------- écrans

    private String font() {
        return pl.getConfig().getString("noir.police", "za_modeles:ecran");
    }

    private static String esc(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    /** Envoie un titre JSON ; repli sur la commande vanilla /title si l'accès réseau échoue. */
    void titleJson(Player p, String titleJson, String subJson, int in, int stay, int out) {
        if (Nms.sendTitle(p, titleJson, subJson, in, stay, out)) return;
        String n = p.getName();
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "title " + n + " times " + in + " " + stay + " " + out);
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "title " + n + " subtitle " + (subJson == null ? "\"\"" : subJson));
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "title " + n + " title " + titleJson);
    }

    /** Écran noir plein écran (glyphe du pack client). */
    String black(Player p, int in, int stay, int out) {
        titleJson(p, "{\"text\":\"\ue000\",\"font\":\"" + font() + "\"}", null, in, stay, out);
        return "écran noir pour " + p.getName();
    }

    /**
     * Carte de chapitre : texte blanc sur fond noir. Le sous-titre est dessiné DERRIÈRE le titre : le glyphe noir va donc
     * dans le sous-titre (centré par deux espaces négatifs), suivi d'une 2e ligne grise éventuelle ; le texte principal va dans
     * le titre. Titre « @jour8 » = carte stylisée JOUR 8 du pack, « @logo » = logo du serveur.
     */
    String blackText(Player p, int in, int stay, int out, String title, String sub) {
        String f = font();
        StringBuilder st = new StringBuilder("{\"text\":\"\ue010\ue000\ue011\",\"font\":\"").append(f).append("\"");
        if (sub != null && !sub.isEmpty()) {
            st.append(",\"extra\":[{\"text\":\"").append(esc(sub)).append("\",\"font\":\"minecraft:default\",\"color\":\"gray\"}]");
        }
        st.append("}");
        String tj;
        if ("@jour8".equalsIgnoreCase(title)) tj = "{\"text\":\"\ue002\",\"font\":\"" + f + "\"}";
        else if ("@logo".equalsIgnoreCase(title)) tj = "{\"text\":\"\ue001\",\"font\":\"" + f + "\"}";
        else tj = "{\"text\":\"" + esc(title) + "\",\"color\":\"white\",\"bold\":true}";
        titleJson(p, tj, st.toString(), in, stay, out);
        return "carte « " + title + " » pour " + p.getName();
    }

    /** Logo du serveur (sans fond) avec un sous-titre normal. */
    String logo(Player p, int in, int stay, int out, String sub) {
        String sj = sub == null ? null : "{\"text\":\"" + esc(sub) + "\",\"color\":\"gray\"}";
        titleJson(p, "{\"text\":\"\ue001\",\"font\":\"" + font() + "\"}", sj, in, stay, out);
        return "logo pour " + p.getName();
    }

    /** Titre normal (sans fond) avec couleurs §. */
    String title(Player p, int in, int stay, int out, String title, String sub) {
        p.sendTitle(title, sub == null ? "" : sub, in, stay, out);
        return "titre pour " + p.getName();
    }
}
