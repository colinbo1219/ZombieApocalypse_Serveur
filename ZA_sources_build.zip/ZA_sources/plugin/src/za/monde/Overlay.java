package za.monde;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.block.BlockState;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Blocs factices par joueur (calques de layers.json, lampes, clignotement). Composition dans l'ordre :
 * lampes éteintes, puis calques dans l'ordre d'activation (le dernier l'emporte), puis calque de clignotement.
 * Ré-envoi complet toutes les 3 s et après changement de tronçon / téléportation / interaction.
 */
final class Overlay {
    static final class Blink {
        final String a, b;
        final int period;
        int remaining; // -1 = infini
        int counter;
        boolean phaseB;

        Blink(String a, String b, int period, int remaining) {
            this.a = a;
            this.b = b;
            this.period = period;
            this.remaining = remaining;
        }
    }

    static final class Blackout {
        final int[] groups;
        final int ticksPerGroup;
        final String sound;
        final float volume;
        int idx;
        int counter;

        Blackout(int[] groups, int ticksPerGroup, String sound, float volume) {
            this.groups = groups;
            this.ticksPerGroup = ticksPerGroup;
            this.sound = sound;
            this.volume = volume;
        }
    }

    static final class State {
        final List<String> layers = new ArrayList<>();
        final Set<Integer> lampsOff = new HashSet<>();
        Blink blink;
        Blackout blackout;
        /** ce qui est actuellement affiché (clé position -> bloc factice) */
        Map<Long, BlockData> shown = new HashMap<>();
        /** états prêts à l'envoi (cache) */
        Map<Long, BlockState> cache = new HashMap<>();
        int resendAt = -1;
        int lastFull;

        boolean empty() {
            return layers.isEmpty() && lampsOff.isEmpty() && blink == null && blackout == null;
        }
    }

    private final ZAMonde pl;
    private final Map<UUID, State> states = new HashMap<>();
    private int tick;

    Overlay(ZAMonde pl) {
        this.pl = pl;
    }

    State state(Player p) {
        return states.computeIfAbsent(p.getUniqueId(), k -> new State());
    }

    State peek(UUID id) {
        return states.get(id);
    }

    int activeCount() {
        int n = 0;
        for (State s : states.values()) if (!s.empty()) n++;
        return n;
    }

    // ---------------------------------------------------------------- commandes

    String layer(Player p, String name, boolean on) {
        if (!pl.data.layers.containsKey(name)) throw new IllegalArgumentException("calque inconnu « " + name + " »");
        State s = state(p);
        s.layers.remove(name);
        if (on) s.layers.add(name);
        apply(p, s);
        return "calque " + name + " " + (on ? "on" : "off") + " pour " + p.getName() + " (actifs : " + s.layers + ")";
    }

    String reset(Player p) {
        State s = states.get(p.getUniqueId());
        if (s == null) return "aucun calque pour " + p.getName();
        s.layers.clear();
        s.lampsOff.clear();
        s.blink = null;
        s.blackout = null;
        apply(p, s);
        states.remove(p.getUniqueId());
        return "calques réinitialisés pour " + p.getName();
    }

    String lamps(Player p, boolean on) {
        State s = state(p);
        s.blackout = null;
        s.lampsOff.clear();
        if (!on) for (int g : pl.data.lampGroups) s.lampsOff.add(g);
        apply(p, s);
        return "lampes " + (on ? "allumées" : "éteintes") + " pour " + p.getName() + " (" + pl.data.lamps.size() + " lampes)";
    }

    String blackout(Player p, int ticksPerGroup, String sound, float volume) {
        if (pl.data.lampGroups.length == 0) throw new IllegalArgumentException("lamps.json absent ou vide");
        State s = state(p);
        s.blackout = new Blackout(pl.data.lampGroups.clone(), Math.max(1, ticksPerGroup), sound, volume);
        s.blackout.counter = 0;
        return "blackout de " + pl.data.lampGroups.length + " groupes, " + ticksPerGroup + " ticks/groupe (durée "
                + (ticksPerGroup * pl.data.lampGroups.length) + " ticks)";
    }

    String blink(Player p, String a, String b, int period, int duration) {
        if (!pl.data.layers.containsKey(a)) throw new IllegalArgumentException("calque inconnu « " + a + " »");
        if (!pl.data.layers.containsKey(b)) throw new IllegalArgumentException("calque inconnu « " + b + " »");
        State s = state(p);
        s.blink = new Blink(a, b, Math.max(1, period), duration);
        apply(p, s);
        return "clignotement " + a + "/" + b + " toutes les " + period + " ticks" + (duration < 0 ? "" : " pendant " + duration + " ticks");
    }

    String blinkStop(Player p) {
        State s = states.get(p.getUniqueId());
        if (s == null || s.blink == null) return "aucun clignotement";
        s.blink = null;
        apply(p, s);
        return "clignotement arrêté";
    }

    // ---------------------------------------------------------------- composition & envoi

    private Map<Long, BlockData> compose(State s) {
        Map<Long, BlockData> m = new LinkedHashMap<>();
        if (!s.lampsOff.isEmpty()) {
            for (Data.Lamp l : pl.data.lamps) {
                if (s.lampsOff.contains(l.g)) m.put(U.key(l.x, l.y, l.z), l.off);
            }
        }
        for (String name : s.layers) put(m, pl.data.layers.get(name));
        if (s.blink != null) put(m, pl.data.layers.get(s.blink.phaseB ? s.blink.b : s.blink.a));
        return m;
    }

    private static void put(Map<Long, BlockData> m, Data.Layer l) {
        if (l == null) return;
        for (int i = 0; i < l.size(); i++) m.put(U.key(l.x[i], l.y[i], l.z[i]), l.data[i]);
    }

    /** Recalcule et envoie seulement les différences. */
    void apply(Player p, State s) {
        Map<Long, BlockData> next = compose(s);
        World w = p.getWorld();
        boolean here = pl.worlds.isPrologue(w);
        List<BlockState> out = new ArrayList<>();
        if (here) {
            for (Map.Entry<Long, BlockData> en : s.shown.entrySet()) {
                if (!next.containsKey(en.getKey())) {
                    BlockState real = realState(w, en.getKey());
                    if (real != null) out.add(real);
                }
            }
        }
        Map<Long, BlockState> newCache = new HashMap<>();
        for (Map.Entry<Long, BlockData> en : next.entrySet()) {
            BlockData old = s.shown.get(en.getKey());
            BlockState st = old != null && old.equals(en.getValue()) ? s.cache.get(en.getKey()) : null;
            if (st == null && here) {
                st = fakeState(w, en.getKey(), en.getValue());
                if (st != null) out.add(st);
            }
            if (st != null) newCache.put(en.getKey(), st);
        }
        s.shown = next;
        s.cache = newCache;
        if (here) send(p, out);
    }

    private static BlockState realState(World w, long k) {
        int x = U.keyX(k), y = U.keyY(k), z = U.keyZ(k);
        if (!w.isChunkLoaded(x >> 4, z >> 4)) return null;
        return w.getBlockAt(x, y, z).getState();
    }

    private static BlockState fakeState(World w, long k, BlockData bd) {
        int x = U.keyX(k), y = U.keyY(k), z = U.keyZ(k);
        if (!w.isChunkLoaded(x >> 4, z >> 4)) return null;
        try {
            BlockState st = w.getBlockAt(x, y, z).getState();
            st.setBlockData(bd);
            return st;
        } catch (Throwable t) {
            return null;
        }
    }

    private void send(Player p, List<BlockState> states) {
        if (states.isEmpty()) return;
        try {
            p.sendBlockChanges(states);
        } catch (Throwable t) {
            Nms.warnOnce("sendBlockChanges", "sendBlockChanges indisponible, repli bloc par bloc", t);
            for (BlockState st : states) {
                try {
                    p.sendBlockChange(st.getLocation(), st.getBlockData());
                } catch (Throwable ignored) {
                    // suivant
                }
            }
        }
    }

    /** Ré-envoi complet (blocs factices des tronçons chargés proches du joueur). */
    void resendAll(Player p, State s) {
        World w = p.getWorld();
        if (!pl.worlds.isPrologue(w) || s.shown.isEmpty()) return;
        int pcx = p.getLocation().getBlockX() >> 4, pcz = p.getLocation().getBlockZ() >> 4;
        int vd = Bukkit.getViewDistance() + 1;
        List<BlockState> out = new ArrayList<>();
        for (Map.Entry<Long, BlockData> en : s.shown.entrySet()) {
            long k = en.getKey();
            int cx = U.keyX(k) >> 4, cz = U.keyZ(k) >> 4;
            if (Math.abs(cx - pcx) > vd || Math.abs(cz - pcz) > vd) continue;
            BlockState st = s.cache.get(k);
            if (st == null) {
                st = fakeState(w, k, en.getValue());
                if (st == null) continue;
                s.cache.put(k, st);
            }
            out.add(st);
        }
        send(p, out);
        s.lastFull = tick;
    }

    /** Demande un ré-envoi complet dans « delay » ticks (fusionné). */
    void scheduleResend(Player p, int delay) {
        State s = states.get(p.getUniqueId());
        if (s == null || s.shown.isEmpty()) return;
        int at = tick + Math.max(1, delay);
        if (s.resendAt < 0 || s.resendAt > at) s.resendAt = at;
    }

    void clear(UUID id, boolean sendReal) {
        State s = states.remove(id);
        if (s == null || !sendReal) return;
        Player p = Bukkit.getPlayer(id);
        if (p == null || !pl.worlds.isPrologue(p.getWorld())) return;
        List<BlockState> out = new ArrayList<>();
        for (Long k : s.shown.keySet()) {
            BlockState real = realState(p.getWorld(), k);
            if (real != null) out.add(real);
        }
        send(p, out);
    }

    void clearAll(boolean sendReal) {
        for (UUID id : new ArrayList<>(states.keySet())) clear(id, sendReal);
    }

    /** Après changement de monde : on renvoie tout si le joueur arrive dans le prologue. */
    void onEnterPrologue(Player p) {
        State s = states.get(p.getUniqueId());
        if (s == null) return;
        s.cache.clear();
        s.resendAt = tick + 5;
    }

    /** Données rechargées : on recompose tout. */
    void reapplyAll() {
        for (Map.Entry<UUID, State> en : states.entrySet()) {
            Player p = Bukkit.getPlayer(en.getKey());
            if (p == null) continue;
            State s = en.getValue();
            s.layers.removeIf(n -> !pl.data.layers.containsKey(n));
            s.cache.clear();
            apply(p, s);
        }
    }

    /** Appelé à chaque tick. */
    void tick() {
        tick++;
        for (Iterator<Map.Entry<UUID, State>> it = states.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<UUID, State> en = it.next();
            Player p = Bukkit.getPlayer(en.getKey());
            State s = en.getValue();
            if (p == null) {
                it.remove();
                continue;
            }
            try {
                boolean changed = false;
                Blink b = s.blink;
                if (b != null) {
                    if (++b.counter >= b.period) {
                        b.counter = 0;
                        b.phaseB = !b.phaseB;
                        changed = true;
                    }
                    if (b.remaining >= 0 && --b.remaining <= 0) {
                        s.blink = null;
                        changed = true;
                    }
                }
                Blackout bo = s.blackout;
                if (bo != null) {
                    if (bo.counter-- <= 0) {
                        bo.counter = bo.ticksPerGroup - 1;
                        int g = bo.groups[bo.idx++];
                        s.lampsOff.add(g);
                        changed = true;
                        playGroupSound(p, g, bo);
                        if (bo.idx >= bo.groups.length) s.blackout = null;
                    }
                }
                if (changed) apply(p, s);
                if (s.resendAt >= 0 && tick >= s.resendAt) {
                    s.resendAt = -1;
                    resendAll(p, s);
                } else if (tick - s.lastFull >= 60) {
                    resendAll(p, s);
                    s.lastFull = tick;
                }
            } catch (Throwable t) {
                Nms.warnOnce("overlay", "Erreur de calque pour " + p.getName(), t);
            }
        }
    }

    private void playGroupSound(Player p, int g, Blackout bo) {
        if (bo.sound == null || bo.sound.isEmpty() || bo.sound.equals("-")) return;
        double sx = 0, sy = 0, sz = 0;
        int n = 0;
        for (Data.Lamp l : pl.data.lamps) {
            if (l.g != g) continue;
            sx += l.x + 0.5;
            sy += l.y + 0.5;
            sz += l.z + 0.5;
            n++;
        }
        if (n == 0) return;
        Location at = new Location(p.getWorld(), sx / n, sy / n, sz / n);
        p.playSound(at, bo.sound, SoundCategory.AMBIENT, bo.volume, 1f);
    }

    List<String> describe(UUID id) {
        State s = states.get(id);
        List<String> out = new ArrayList<>();
        if (s == null) return out;
        out.addAll(s.layers);
        if (!s.lampsOff.isEmpty()) out.add("lampes_eteintes:" + s.lampsOff.size() + "/" + pl.data.lampGroups.length);
        if (s.blink != null) out.add("clignote:" + s.blink.a + "/" + s.blink.b);
        if (s.blackout != null) out.add("blackout:" + s.blackout.idx + "/" + s.blackout.groups.length);
        return out;
    }
}
