package za.monde;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/** Pont réflexif vers MythicMobs (optionnel) : MythicBukkit.inst().getAPIHelper(). */
final class Mythic {
    private Mythic() {}

    private static Object helper;
    private static Method getMob, spawn;
    private static Plugin cachedFor;

    static boolean available() {
        Plugin p = Bukkit.getPluginManager().getPlugin("MythicMobs");
        return p != null && p.isEnabled();
    }

    private static synchronized boolean init() {
        Plugin p = Bukkit.getPluginManager().getPlugin("MythicMobs");
        if (p == null || !p.isEnabled()) return false;
        if (helper != null && cachedFor == p) return true;
        try {
            Class<?> mb = Class.forName("io.lumine.mythic.bukkit.MythicBukkit", true, p.getClass().getClassLoader());
            Object inst = mb.getMethod("inst").invoke(null);
            Object h = inst.getClass().getMethod("getAPIHelper").invoke(inst);
            getMob = h.getClass().getMethod("getMythicMob", String.class);
            spawn = h.getClass().getMethod("spawnMythicMob", String.class, Location.class);
            helper = h;
            cachedFor = p;
            return true;
        } catch (Throwable t) {
            Nms.warnOnce("mm-init", "API MythicMobs inaccessible", t);
            helper = null;
            return false;
        }
    }

    static boolean exists(String type) {
        if (!init()) return false;
        try {
            return getMob.invoke(helper, type) != null;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Fait apparaître un MythicMob ; lève IllegalStateException avec un message clair en cas d'échec. */
    static Entity spawn(String type, Location loc) {
        if (!init()) throw new IllegalStateException("MythicMobs absent ou désactivé");
        if (!exists(type)) throw new IllegalStateException("type MythicMobs inconnu : " + type);
        try {
            Object e = spawn.invoke(helper, type, loc);
            if (!(e instanceof Entity ent)) throw new IllegalStateException("MythicMobs n'a rien fait apparaître (annulé ?)");
            return ent;
        } catch (InvocationTargetException ite) {
            Throwable c = ite.getCause() != null ? ite.getCause() : ite;
            throw new IllegalStateException("échec MythicMobs : " + c, c);
        } catch (IllegalAccessException iae) {
            throw new IllegalStateException("échec MythicMobs : " + iae, iae);
        }
    }
}
