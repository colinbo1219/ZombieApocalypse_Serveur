package za.monde;

import org.bukkit.Bukkit;
import org.bukkit.Difficulty;
import org.bukkit.GameMode;
import org.bukkit.GameRule;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.WorldType;
import org.bukkit.entity.Enemy;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.BlockSpreadEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.hanging.HangingBreakByEntityEvent;
import org.bukkit.event.hanging.HangingPlaceEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;

import java.util.logging.Level;

/** Monde vide du prologue : création, règles, protections. */
final class WorldMgr implements Listener {
    private final ZAMonde pl;
    private World world;
    private String lastError;
    private String dimension = "?";

    WorldMgr(ZAMonde pl) {
        this.pl = pl;
    }

    String name() {
        return pl.getConfig().getString("monde.nom", "za_prologue");
    }

    World prologue() {
        if (world != null && Bukkit.getWorld(world.getUID()) != null) return world;
        world = Bukkit.getWorld(name());
        return world;
    }

    boolean isPrologue(World w) {
        World p = prologue();
        return p != null && w != null && p.getUID().equals(w.getUID());
    }

    String dimension() {
        return dimension;
    }

    String lastError() {
        return lastError;
    }

    /** Crée ou charge le monde ; retourne null en cas d'échec (erreur journalisée). */
    World ensure() {
        World w = Bukkit.getWorld(name());
        if (w == null) {
            java.util.List<Integer> sp = pl.getConfig().getIntegerList("monde.spawn");
            double sx = sp.size() > 0 ? sp.get(0) : 80, sy = sp.size() > 1 ? sp.get(1) : 65, sz = sp.size() > 2 ? sp.get(2) : 60;
            long t0 = System.currentTimeMillis();
            Throwable first = null;
            for (WorldType type : new WorldType[]{WorldType.FLAT, WorldType.NORMAL}) {
                try {
                    WorldCreator wc = new WorldCreator(name())
                            .environment(World.Environment.NORMAL)
                            .type(type)
                            .generateStructures(false)
                            .generator(new VoidGen(sx, sy, sz))
                            .biomeProvider(new VoidGen.Plains());
                    w = wc.createWorld();
                    if (w != null) break;
                } catch (Throwable t) {
                    if (first == null) first = t;
                    pl.getLogger().log(Level.WARNING, "Création du monde " + name() + " (type " + type + ") échouée : " + t, t);
                }
            }
            if (w == null) {
                lastError = first != null ? first.toString() : "createWorld a retourné null";
                pl.getLogger().warning("ÉCHEC : le monde " + name() + " n'a pas pu être créé (" + lastError
                        + "). Réessayez avec /zamonde monde.");
                return null;
            }
            pl.getLogger().info("Monde " + name() + " créé/chargé en " + (System.currentTimeMillis() - t0) + " ms");
        }
        world = w;
        lastError = null;
        configure(w);
        try {
            dimension = w.getKey().toString();
        } catch (Throwable t) {
            dimension = "?";
        }
        pl.getLogger().info("Monde " + w.getName() + " prêt : dimension Minecraft = " + dimension
                + " (ex. « execute in " + dimension + " run ... »), environnement " + w.getEnvironment()
                + ", hauteur " + w.getMinHeight() + ".." + w.getMaxHeight());
        return w;
    }

    private void configure(World w) {
        try {
            w.setGameRule(GameRule.DO_MOB_SPAWNING, false);
            w.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
            w.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
            w.setGameRule(GameRule.RANDOM_TICK_SPEED, 0);
            w.setGameRule(GameRule.DO_FIRE_TICK, false);
            w.setGameRule(GameRule.MOB_GRIEFING, false);
            w.setGameRule(GameRule.ANNOUNCE_ADVANCEMENTS, false);
            w.setGameRule(GameRule.DO_INSOMNIA, false);
            w.setGameRule(GameRule.DO_PATROL_SPAWNING, false);
            w.setGameRule(GameRule.DO_TRADER_SPAWNING, false);
            w.setGameRule(GameRule.KEEP_INVENTORY, true);
            w.setGameRule(GameRule.FALL_DAMAGE, true);
            w.setTime(1000);
            w.setDifficulty(Difficulty.HARD);
            w.setStorm(false);
            w.setThundering(false);
            java.util.List<Integer> sp = pl.getConfig().getIntegerList("monde.spawn");
            if (sp.size() >= 3) w.setSpawnLocation(sp.get(0), sp.get(1), sp.get(2));
        } catch (Throwable t) {
            pl.getLogger().log(Level.WARNING, "Configuration du monde " + w.getName() + " incomplète : " + t);
        }
    }

    // ---------------------------------------------------------------- protections

    private static boolean bypass(Player p) {
        return p != null && p.getGameMode() == GameMode.CREATIVE && (p.isOp() || p.hasPermission("za.admin"));
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (isPrologue(e.getBlock().getWorld()) && !bypass(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (isPrologue(e.getBlock().getWorld()) && !bypass(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onBucket(PlayerBucketEmptyEvent e) {
        if (isPrologue(e.getBlock().getWorld()) && !bypass(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onBucket(PlayerBucketFillEvent e) {
        if (isPrologue(e.getBlock().getWorld()) && !bypass(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onHangingBreak(HangingBreakByEntityEvent e) {
        if (!isPrologue(e.getEntity().getWorld())) return;
        Entity r = e.getRemover();
        if (!(r instanceof Player p) || !bypass(p)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onHangingPlace(HangingPlaceEvent e) {
        if (isPrologue(e.getEntity().getWorld()) && !bypass(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onTrample(PlayerInteractEvent e) {
        if (e.getAction() != Action.PHYSICAL || e.getClickedBlock() == null) return;
        if (!isPrologue(e.getClickedBlock().getWorld())) return;
        Material m = e.getClickedBlock().getType();
        if (m == Material.FARMLAND || m == Material.TURTLE_EGG) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onChangeBlock(EntityChangeBlockEvent e) {
        if (isPrologue(e.getBlock().getWorld()) && !(e.getEntity() instanceof Player)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onExplode(EntityExplodeEvent e) {
        if (isPrologue(e.getLocation().getWorld())) {
            e.blockList().clear();
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onExplode(BlockExplodeEvent e) {
        if (isPrologue(e.getBlock().getWorld())) {
            e.blockList().clear();
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onIgnite(BlockIgniteEvent e) {
        if (isPrologue(e.getBlock().getWorld()) && !bypass(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onBurn(BlockBurnEvent e) {
        if (isPrologue(e.getBlock().getWorld())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onSpread(BlockSpreadEvent e) {
        if (isPrologue(e.getBlock().getWorld()) && e.getNewState().getType() == Material.FIRE) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onPvp(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player) || !isPrologue(e.getEntity().getWorld())) return;
        Entity d = e.getDamager();
        if (d instanceof Projectile pr && pr.getShooter() instanceof Entity sh) d = sh;
        if (d instanceof Player) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onFood(FoodLevelChangeEvent e) {
        if (isPrologue(e.getEntity().getWorld())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onFall(EntityDamageEvent e) {
        if (e.getCause() != EntityDamageEvent.DamageCause.FALL || !(e.getEntity() instanceof Player p)) return;
        if (!isPrologue(p.getWorld())) return;
        double max = pl.getConfig().getDouble("monde.chute_max", 4.0);
        double dmg = Math.min(e.getDamage(), max);
        if (p.getHealth() - dmg < 1.0) dmg = Math.max(0.0, p.getHealth() - 1.0);
        if (dmg <= 0) e.setCancelled(true);
        else e.setDamage(dmg);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onSpawn(CreatureSpawnEvent e) {
        if (!isPrologue(e.getLocation().getWorld())) return;
        switch (e.getSpawnReason()) {
            case NATURAL, CHUNK_GEN, JOCKEY, PATROL, RAID, REINFORCEMENTS, VILLAGE_DEFENSE, VILLAGE_INVASION, TRAP,
                 SPAWNER, NETHER_PORTAL, ENDER_PEARL, SILVERFISH_BLOCK, LIGHTNING, BUILD_IRONGOLEM, BUILD_SNOWMAN,
                 BUILD_WITHER, INFECTION, DROWNED, EGG, BREEDING, SLIME_SPLIT, FROZEN, METAMORPHOSIS, PIGLIN_ZOMBIFIED,
                 DUPLICATION -> e.setCancelled(true);
            case DEFAULT -> {
                if (e.getEntity() instanceof Enemy) e.setCancelled(true);
            }
            default -> {
                // CUSTOM (plugins, MythicMobs), COMMAND, SPAWNER_EGG... : autorisé
            }
        }
    }

    /** Toutes les 5 s : supprime les monstres non marqués za_pnj / za_garder. */
    void sweepMonsters() {
        World w = prologue();
        if (w == null) return;
        try {
            for (Entity e : w.getEntities()) {
                if (!(e instanceof Enemy)) continue;
                if (e.getScoreboardTags().contains("za_pnj") || e.getScoreboardTags().contains("za_garder")) continue;
                e.remove();
            }
        } catch (Throwable t) {
            Nms.warnOnce("sweep", "Nettoyage des monstres échoué", t);
        }
    }

    // ---------------------------------------------------------------- boîte

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        Location to = e.getTo();
        if (to == null || !isPrologue(to.getWorld())) return;
        Player p = e.getPlayer();
        if (p.getGameMode() == GameMode.SPECTATOR || bypass(p) || pl.cameras.active(p)) return;
        double min = pl.getConfig().getDouble("monde.boite_min", -6), max = pl.getConfig().getDouble("monde.boite_max", 165);
        double x = to.getX(), z = to.getZ();
        if (x > min + 0.3 && x < max + 0.7 && z > min + 0.3 && z < max + 0.7) return;
        Location back = to.clone();
        back.setX(Math.max(min + 1.0, Math.min(max - 0.0, x)));
        back.setZ(Math.max(min + 1.0, Math.min(max - 0.0, z)));
        Location from = e.getFrom();
        double fx = from.getX(), fz = from.getZ();
        if (fx > min + 0.3 && fx < max + 0.7 && fz > min + 0.3 && fz < max + 0.7) {
            back.setX(fx);
            back.setZ(fz);
            back.setY(from.getY());
        }
        e.setTo(back);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onEnter(PlayerChangedWorldEvent e) {
        Player p = e.getPlayer();
        if (isPrologue(p.getWorld())) {
            p.setFoodLevel(20);
            p.setSaturation(20f);
        }
    }
}
