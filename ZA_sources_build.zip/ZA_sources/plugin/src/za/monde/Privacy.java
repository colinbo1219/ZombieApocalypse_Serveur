package za.monde;

import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Entités privées (visibles seulement par leur propriétaire) et isolement des joueurs.
 * Double mécanisme : API Bukkit (hideEntity / hidePlayer) + filtre réseau (PacketHider), voir LISEZMOI.
 */
final class Privacy {
    static final class Info {
        final UUID owner;
        final UUID entity;

        Info(UUID owner, UUID entity) {
            this.owner = owner;
            this.entity = entity;
        }
    }

    private final ZAMonde pl;
    /** id réseau d'entité -> propriétaire */
    private final Map<Integer, Info> priv = new HashMap<>();
    private final Set<UUID> isolated = new HashSet<>();

    Privacy(ZAMonde pl) {
        this.pl = pl;
    }

    int count() {
        return priv.size();
    }

    int countFor(UUID owner) {
        int n = 0;
        for (Info i : priv.values()) if (owner.equals(i.owner)) n++;
        return n;
    }

    /** À appeler AVANT l'ajout au monde (consommateur de World#spawn ou EntitySpawnEvent) si possible. */
    void makePrivate(Entity e, UUID owner) {
        if (e == null || owner == null) return;
        priv.put(e.getEntityId(), new Info(owner, e.getUniqueId()));
        e.addScoreboardTag("za_owner:" + owner);
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (!p.getUniqueId().equals(owner)) hideFrom(p, e.getEntityId(), e);
        }
    }

    private void hideFrom(Player p, int id, Entity e) {
        pl.hider.hide(p.getUniqueId(), id);
        if (e != null) {
            try {
                p.hideEntity(pl, e);
            } catch (Throwable t) {
                Nms.warnOnce("hideEntity", "Player#hideEntity a échoué", t);
            }
        }
    }

    boolean isPrivate(Entity e) {
        return e != null && priv.containsKey(e.getEntityId());
    }

    UUID ownerOf(Entity e) {
        if (e == null) return null;
        Info i = priv.get(e.getEntityId());
        return i == null ? null : i.owner;
    }

    void forget(Entity e) {
        if (e == null) return;
        forget(e.getEntityId());
    }

    void forget(int id) {
        if (priv.remove(id) != null) pl.hider.forget(id);
    }

    /** Nouveau joueur (connexion) : on lui masque toutes les entités privées des autres et les joueurs isolés. */
    void onJoin(Player p) {
        UUID me = p.getUniqueId();
        for (Map.Entry<Integer, Info> en : priv.entrySet()) {
            if (me.equals(en.getValue().owner)) continue;
            hideFrom(p, en.getKey(), Bukkit.getEntity(en.getValue().entity));
        }
        applyIsolation(p);
    }

    /** Changement de monde : on ré-applique les masquages (sécurité). */
    void onWorldChange(Player p) {
        onJoin(p);
    }

    void onQuit(Player p) {
        pl.hider.forgetViewer(p.getUniqueId());
    }

    /** Nettoyage périodique des entrées dont l'entité n'existe plus. */
    void purge() {
        Iterator<Map.Entry<Integer, Info>> it = priv.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Info> en = it.next();
            Entity e = Bukkit.getEntity(en.getValue().entity);
            if (e == null || !e.isValid()) {
                if (e == null || e.isDead()) {
                    it.remove();
                    pl.hider.forget(en.getKey());
                }
            }
        }
    }

    // ---------------------------------------------------------------- isolement

    boolean isIsolated(UUID id) {
        return isolated.contains(id);
    }

    int isolatedCount() {
        return isolated.size();
    }

    void isolate(Player a, boolean on) {
        UUID ia = a.getUniqueId();
        if (on) {
            isolated.add(ia);
            for (Player b : Bukkit.getOnlinePlayers()) {
                if (b.equals(a)) continue;
                hidePair(a, b);
            }
        } else {
            if (!isolated.remove(ia)) return;
            for (Player b : Bukkit.getOnlinePlayers()) {
                if (b.equals(a) || isolated.contains(b.getUniqueId())) continue;
                showPair(a, b);
            }
        }
    }

    private void applyIsolation(Player p) {
        boolean meIso = isolated.contains(p.getUniqueId());
        for (Player b : Bukkit.getOnlinePlayers()) {
            if (b.equals(p)) continue;
            if (meIso || isolated.contains(b.getUniqueId())) hidePair(p, b);
        }
    }

    private void hidePair(Player a, Player b) {
        pl.hider.hide(a.getUniqueId(), b.getEntityId());
        pl.hider.hide(b.getUniqueId(), a.getEntityId());
        try {
            a.hidePlayer(pl, b);
            b.hidePlayer(pl, a);
        } catch (Throwable t) {
            Nms.warnOnce("hidePlayer", "hidePlayer a échoué", t);
        }
    }

    private void showPair(Player a, Player b) {
        pl.hider.unhide(a.getUniqueId(), b.getEntityId());
        pl.hider.unhide(b.getUniqueId(), a.getEntityId());
        try {
            // Sur Arclight le suivi peut déjà considérer l'entité comme envoyée : on force un cycle masquer/afficher
            a.showPlayer(pl, b);
            b.showPlayer(pl, a);
            a.hidePlayer(pl, b);
            b.hidePlayer(pl, a);
            a.showPlayer(pl, b);
            b.showPlayer(pl, a);
        } catch (Throwable t) {
            Nms.warnOnce("showPlayer", "showPlayer a échoué", t);
        }
    }

    /** Tout annuler (désactivation du plugin). */
    void clearAll() {
        for (UUID id : new ArrayList<>(isolated)) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) isolate(p, false);
        }
        isolated.clear();
        for (Map.Entry<Integer, Info> en : new ArrayList<>(priv.entrySet())) pl.hider.forget(en.getKey());
        priv.clear();
    }
}
