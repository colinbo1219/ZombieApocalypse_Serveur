package za.monde;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.util.Transformation;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Accessoires et véhicules en BlockDisplay, passagers d'un support (ArmorStand invisible marker) que l'on déplace
 * par absMoveTo (téléporter une entité qui a des passagers est refusé par Bukkit). Le client interpole la position
 * du support (entité vivante) et place les passagers dessus : le mouvement est fluide. L'orientation (lacet) est
 * appliquée dans la Transformation de chaque pièce avec une interpolation courte.
 */
final class Props {
    static final class Part {
        final Data.PartDef def;
        final BlockDisplay d;

        Part(Data.PartDef def, BlockDisplay d) {
            this.def = def;
            this.d = d;
        }
    }

    static final class Prop {
        final String id;
        final UUID owner; // null = public
        final Data.Model model;
        ArmorStand base;
        final List<Part> parts = new ArrayList<>();
        double x, y, z;
        float yaw;
        float appliedYaw = Float.NaN;
        double rotor, rotorQ;
        int age;
        boolean lightsB;
        // déplacement
        List<double[]> path; // polyligne lissée
        double speed; // blocs par tick
        int seg;
        double segPos;
        boolean keep;
        String loopSound;
        int loopTicks;
        int nextSound;
        boolean hover; // arrivé et reste : garde les rotors et le son

        Prop(String id, UUID owner, Data.Model model) {
            this.id = id;
            this.owner = owner;
            this.model = model;
        }
    }

    private final ZAMonde pl;
    final Map<String, Prop> props = new LinkedHashMap<>();

    Props(ZAMonde pl) {
        this.pl = pl;
    }

    int count() {
        return props.size();
    }

    List<String> ids() {
        return new ArrayList<>(props.keySet());
    }

    private Data.Model model(String name) {
        Data.Model m = pl.data.models.get(name);
        if (m == null) throw new IllegalArgumentException("modèle inconnu « " + name + " » (connus : " + pl.data.models.keySet() + ")");
        return m;
    }

    private BlockData red, blue;

    private BlockData red() {
        if (red == null) red = Material.RED_CONCRETE.createBlockData();
        return red;
    }

    private BlockData blue() {
        if (blue == null) blue = Material.BLUE_CONCRETE.createBlockData();
        return blue;
    }

    /** Crée le prop à l'arrêt. */
    Prop create(String id, UUID owner, String modelName, Location at) {
        remove(id);
        Data.Model m = model(modelName);
        World w = at.getWorld();
        final Prop P = new Prop(id, owner, m);
        P.x = at.getX();
        P.y = at.getY();
        P.z = at.getZ();
        P.yaw = at.getYaw();
        double dy = pl.getConfig().getDouble("props.decalage_y", 0.0);
        Location baseLoc = new Location(w, P.x, P.y + dy, P.z, 0f, 0f);
        ArmorStand base = w.spawn(baseLoc, ArmorStand.class, a -> {
            a.setInvisible(true);
            a.setMarker(true);
            a.setGravity(false);
            a.setInvulnerable(true);
            a.setSilent(true);
            a.setPersistent(false);
            a.setBasePlate(false);
            a.addScoreboardTag("za_prop");
            a.addScoreboardTag("za_pnj");
            a.addScoreboardTag("za_id:" + id);
            if (owner != null) pl.privacy.makePrivate(a, owner);
        });
        P.base = base;
        float view = (float) pl.getConfig().getDouble("props.distance_vue", 1.5);
        for (Data.PartDef def : m.parts) {
            BlockDisplay d = w.spawn(baseLoc, BlockDisplay.class, b -> {
                b.setBlock(def.block);
                b.setPersistent(false);
                b.setViewRange(view);
                b.setShadowRadius(0f);
                b.addScoreboardTag("za_prop");
                b.addScoreboardTag("za_pnj");
                if (def.tag.startsWith("light")) b.setBrightness(new Display.Brightness(15, 15));
                if (owner != null) pl.privacy.makePrivate(b, owner);
            });
            base.addPassenger(d);
            P.parts.add(new Part(def, d));
        }
        applyTransforms(P, 0);
        props.put(id, P);
        return P;
    }

    String remove(String id) {
        Prop p = props.remove(id);
        if (p == null) return "aucun prop « " + id + " »";
        despawn(p);
        return "prop « " + id + " » retiré";
    }

    private void despawn(Prop p) {
        for (Part part : p.parts) {
            pl.privacy.forget(part.d);
            part.d.remove();
        }
        if (p.base != null) {
            pl.privacy.forget(p.base);
            p.base.remove();
        }
    }

    int removeOwner(UUID owner) {
        int n = 0;
        for (Iterator<Prop> it = props.values().iterator(); it.hasNext(); ) {
            Prop p = it.next();
            if (owner.equals(p.owner)) {
                it.remove();
                despawn(p);
                n++;
            }
        }
        return n;
    }

    void removeAll() {
        for (Prop p : props.values()) despawn(p);
        props.clear();
    }

    // ---------------------------------------------------------------- transformations

    private static final Vector3f ZERO = new Vector3f();

    /** Recalcule la transformation de chaque pièce (lacet + rotors). */
    private void applyTransforms(Prop p, int interp) {
        double a = -Math.toRadians(p.yaw + 90.0);
        Quaternionf R = new Quaternionf().rotateY((float) a);
        for (Part part : p.parts) {
            Data.PartDef d = part.def;
            Vector3f t = new Vector3f(d.t[0], d.t[1], d.t[2]);
            Quaternionf L = new Quaternionf(R);
            if (d.pivot != null && ("rotor".equals(d.tag) || "rotor_queue".equals(d.tag))) {
                Vector3f piv = new Vector3f(d.pivot[0], d.pivot[1], d.pivot[2]);
                Quaternionf Rp = "rotor".equals(d.tag)
                        ? new Quaternionf().rotateY((float) Math.toRadians(p.rotor))
                        : new Quaternionf().rotateZ((float) Math.toRadians(p.rotorQ));
                Vector3f rel = new Vector3f(t).sub(piv);
                Rp.transform(rel);
                t = rel.add(piv);
                L = new Quaternionf(R).mul(Rp);
            }
            Vector3f tr = R.transform(new Vector3f(t));
            Transformation tf = new Transformation(tr, L, new Vector3f(d.s[0], d.s[1], d.s[2]), new Quaternionf());
            try {
                part.d.setInterpolationDelay(0);
                part.d.setInterpolationDuration(interp);
                part.d.setTransformation(tf);
            } catch (Throwable t2) {
                Nms.warnOnce("tf", "Transformation d'affichage impossible", t2);
            }
        }
        p.appliedYaw = p.yaw;
    }

    // ---------------------------------------------------------------- véhicule

    /** Lissage de Chaikin (2 passes) pour arrondir les virages. */
    private static List<double[]> chaikin(List<double[]> pts) {
        List<double[]> cur = pts;
        for (int pass = 0; pass < 2; pass++) {
            if (cur.size() < 3) break;
            List<double[]> nx = new ArrayList<>();
            nx.add(cur.get(0));
            for (int i = 0; i < cur.size() - 1; i++) {
                double[] a = cur.get(i), b = cur.get(i + 1);
                nx.add(new double[]{0.75 * a[0] + 0.25 * b[0], 0.75 * a[1] + 0.25 * b[1], 0.75 * a[2] + 0.25 * b[2]});
                nx.add(new double[]{0.25 * a[0] + 0.75 * b[0], 0.25 * a[1] + 0.75 * b[1], 0.25 * a[2] + 0.75 * b[2]});
            }
            nx.add(cur.get(cur.size() - 1));
            cur = nx;
        }
        return cur;
    }

    String vehicle(String id, UUID owner, String modelName, World w, List<double[]> raw, double bps, String sound, int loopTicks, boolean keep) {
        if (raw.size() < 1) throw new IllegalArgumentException("chemin vide");
        List<double[]> path = raw.size() >= 3 ? chaikin(raw) : raw;
        double[] p0 = path.get(0);
        float yaw0 = 0f;
        if (path.size() >= 2) {
            double[] p1 = path.get(1);
            yaw0 = U.yawOf(p1[0] - p0[0], p1[2] - p0[2]);
        } else if (raw.get(0).length > 3) {
            yaw0 = (float) raw.get(0)[3];
        }
        Prop p = create(id, owner, modelName, new Location(w, p0[0], p0[1], p0[2], yaw0, 0f));
        p.path = path;
        p.speed = Math.max(0.01, bps) / 20.0;
        p.keep = keep;
        p.loopSound = sound == null || sound.equals("-") ? null : sound;
        p.loopTicks = Math.max(10, loopTicks);
        p.nextSound = 0;
        double len = 0;
        for (int i = 0; i < path.size() - 1; i++) len += dist(path.get(i), path.get(i + 1));
        return "véhicule « " + id + " » (" + modelName + ") : " + path.size() + " points, " + U.fmt(len) + " blocs, ~"
                + (int) Math.ceil(len / Math.max(0.01, bps)) + " s";
    }

    String staticProp(String id, UUID owner, String modelName, Location at, String sound, int loopTicks) {
        Prop p = create(id, owner, modelName, at);
        p.hover = true;
        p.loopSound = sound == null || sound.equals("-") ? null : sound;
        p.loopTicks = Math.max(10, loopTicks);
        return "prop « " + id + " » (" + modelName + ") en " + U.fmtLoc(at);
    }

    private static double dist(double[] a, double[] b) {
        double dx = a[0] - b[0], dy = a[1] - b[1], dz = a[2] - b[2];
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    private List<Player> listeners(Prop p) {
        if (p.owner != null) {
            Player pl0 = Bukkit.getPlayer(p.owner);
            return pl0 == null ? List.of() : List.of(pl0);
        }
        return p.base != null ? p.base.getWorld().getPlayers() : List.of();
    }

    void tick() {
        if (props.isEmpty()) return;
        int period = Math.max(2, pl.getConfig().getInt("props.periode_gyro", 8));
        double rotorSpeed = pl.getConfig().getDouble("props.vitesse_rotor", 36.0);
        for (Iterator<Prop> it = props.values().iterator(); it.hasNext(); ) {
            Prop p = it.next();
            try {
                if (p.base == null || !p.base.isValid()) {
                    it.remove();
                    despawn(p);
                    continue;
                }
                p.age++;
                boolean moved = false;
                if (p.path != null && !p.hover) {
                    double remaining = p.speed;
                    int last = p.path.size() - 1;
                    while (remaining > 0 && p.seg < last) {
                        double[] a = p.path.get(p.seg), b = p.path.get(p.seg + 1);
                        double len = dist(a, b);
                        if (p.segPos + remaining >= len) {
                            remaining -= (len - p.segPos);
                            p.seg++;
                            p.segPos = 0;
                        } else {
                            p.segPos += remaining;
                            remaining = 0;
                        }
                    }
                    double[] pos;
                    double[] dir;
                    if (p.seg >= last) {
                        pos = p.path.get(last);
                        dir = last > 0 ? new double[]{pos[0] - p.path.get(last - 1)[0], 0, pos[2] - p.path.get(last - 1)[2]} : new double[]{0, 0, 0};
                    } else {
                        double[] a = p.path.get(p.seg), b = p.path.get(p.seg + 1);
                        double len = Math.max(1e-9, dist(a, b));
                        double t = p.segPos / len;
                        pos = new double[]{a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t};
                        dir = new double[]{b[0] - a[0], 0, b[2] - a[2]};
                    }
                    p.x = pos[0];
                    p.y = pos[1];
                    p.z = pos[2];
                    if (dir[0] * dir[0] + dir[2] * dir[2] > 1e-6) {
                        float target = U.yawOf(dir[0], dir[2]);
                        float diff = U.wrap(target - p.yaw);
                        p.yaw = U.wrap(p.yaw + Math.max(-6f, Math.min(6f, diff)));
                    }
                    double dy = pl.getConfig().getDouble("props.decalage_y", 0.0);
                    Nms.absMoveTo(p.base, p.x, p.y + dy, p.z, 0f, 0f);
                    moved = true;
                    if (p.seg >= last) {
                        if (p.keep) {
                            p.hover = true;
                        } else {
                            it.remove();
                            despawn(p);
                            for (Player pp : listeners(p)) if (p.loopSound != null) pp.stopSound(p.loopSound);
                            continue;
                        }
                    }
                }
                boolean rotors = p.model.has("rotor") || p.model.has("rotor_queue");
                if (rotors) {
                    p.rotor = (p.rotor + rotorSpeed) % 360.0;
                    p.rotorQ = (p.rotorQ + rotorSpeed * 1.5) % 360.0;
                }
                boolean yawChanged = Float.isNaN(p.appliedYaw) || Math.abs(U.wrap(p.yaw - p.appliedYaw)) > 0.3f;
                if (rotors && p.age % 2 == 0) applyTransforms(p, 2);
                else if (yawChanged && (p.age % 2 == 0 || !moved)) applyTransforms(p, 2);
                if ((p.model.has("light_a") || p.model.has("light_b")) && p.age % period == 0) {
                    p.lightsB = !p.lightsB;
                    for (Part part : p.parts) {
                        if ("light_a".equals(part.def.tag)) part.d.setBlock(p.lightsB ? blue() : red());
                        else if ("light_b".equals(part.def.tag)) part.d.setBlock(p.lightsB ? red() : blue());
                    }
                }
                if (p.loopSound != null && p.age >= p.nextSound) {
                    p.nextSound = p.age + p.loopTicks;
                    SoundCategory cat = SoundCategory.AMBIENT;
                    for (Player pp : listeners(p)) {
                        if (!pp.getWorld().equals(p.base.getWorld())) continue;
                        if (pp.getLocation().distanceSquared(p.base.getLocation()) > 160 * 160) continue;
                        pp.playSound(p.base, p.loopSound, cat, 4f, 1f);
                    }
                }
            } catch (Throwable t) {
                Nms.warnOnce("prop", "Erreur de prop « " + p.id + " »", t);
            }
        }
    }

    Location location(String id) {
        Prop p = props.get(id);
        if (p == null || p.base == null) return null;
        return p.base.getLocation();
    }

    Entity baseOf(String id) {
        Prop p = props.get(id);
        return p == null ? null : p.base;
    }

    /** Arrête le son en boucle d'un prop (tout en le laissant en place). */
    String silence(String id) {
        Prop p = props.get(id);
        if (p == null) return "aucun prop « " + id + " »";
        if (p.loopSound != null) for (Player pp : listeners(p)) pp.stopSound(p.loopSound);
        p.loopSound = null;
        return "prop « " + id + " » silencieux";
    }
}
