package za.monde;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.data.BlockData;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeSet;
import java.util.logging.Level;
import java.util.zip.GZIPInputStream;

/** Fichiers de données du dossier plugins/ZAMonde (tous optionnels, rechargeables). */
final class Data {
    static final class Layer {
        final String name;
        final int[] x, y, z;
        final BlockData[] data;

        Layer(String name, int n) {
            this.name = name;
            x = new int[n];
            y = new int[n];
            z = new int[n];
            data = new BlockData[n];
        }

        int size() {
            return x.length;
        }
    }

    static final class Lamp {
        final int x, y, z, g;
        final BlockData on, off;

        Lamp(int x, int y, int z, BlockData on, BlockData off, int g) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.on = on;
            this.off = off;
            this.g = g;
        }
    }

    static final class PartDef {
        final BlockData block;
        final float[] t, s, pivot;
        final String tag;

        PartDef(BlockData block, float[] t, float[] s, float[] pivot, String tag) {
            this.block = block;
            this.t = t;
            this.s = s;
            this.pivot = pivot;
            this.tag = tag;
        }
    }

    static final class Model {
        final String name;
        final List<PartDef> parts;

        Model(String name, List<PartDef> parts) {
            this.name = name;
            this.parts = parts;
        }

        boolean has(String tag) {
            for (PartDef p : parts) if (tag.equals(p.tag)) return true;
            return false;
        }
    }

    private final ZAMonde pl;
    final File dir;
    Map<String, Layer> layers = Collections.emptyMap();
    List<Lamp> lamps = Collections.emptyList();
    int[] lampGroups = new int[0];
    JsonObject pois = new JsonObject();
    Map<String, Model> models = Collections.emptyMap();
    private final Map<String, JsonObject> extraPois = new HashMap<>();
    private final Map<String, BlockData> bdCache = new HashMap<>();
    private final Map<String, Boolean> badData = new HashMap<>();
    private YamlConfiguration placements = new YamlConfiguration();

    Data(ZAMonde pl) {
        this.pl = pl;
        this.dir = pl.getDataFolder();
    }

    // ---------------------------------------------------------------- lecture JSON

    static JsonElement readJson(File f) throws IOException {
        InputStream in = new FileInputStream(f);
        try {
            if (f.getName().endsWith(".gz")) in = new GZIPInputStream(in, 1 << 16);
            try (Reader r = new InputStreamReader(in, StandardCharsets.UTF_8)) {
                return JsonParser.parseReader(r);
            }
        } finally {
            in.close();
        }
    }

    /** Résout un nom de fichier du dossier de données (sans « .. »), en essayant les extensions usuelles. */
    File resolve(String name) {
        if (name == null || name.contains("..") || name.startsWith("/") || name.contains("\\")) return null;
        String[] cand = {name, name + ".json.gz", name + ".json", name + ".gz"};
        for (String c : cand) {
            File f = new File(dir, c);
            if (f.isFile()) return f;
        }
        return null;
    }

    BlockData block(String s, String where) {
        if (s == null) return null;
        BlockData bd = bdCache.get(s);
        if (bd != null) return bd;
        if (badData.containsKey(s)) return null;
        try {
            bd = Bukkit.createBlockData(s);
            bdCache.put(s, bd);
            return bd;
        } catch (Throwable t) {
            badData.put(s, Boolean.TRUE);
            ZAMonde.log().warning("BlockData invalide « " + s + " » (" + where + ") : ignoré");
            return null;
        }
    }

    // ---------------------------------------------------------------- chargement

    void loadAll() {
        if (!dir.isDirectory() && !dir.mkdirs()) {
            ZAMonde.log().warning("Impossible de créer " + dir);
        }
        bdCache.clear();
        badData.clear();
        extraPois.clear();
        List<String> summary = new ArrayList<>();
        loadLayers(summary);
        loadLamps(summary);
        loadPois(summary);
        loadModels(summary);
        loadPlacements();
        ZAMonde.log().info("Données : " + String.join(", ", summary));
    }

    private void loadLayers(List<String> summary) {
        File f = new File(dir, "layers.json");
        if (!f.isFile()) {
            layers = Collections.emptyMap();
            summary.add("layers.json absent");
            return;
        }
        try {
            JsonObject o = readJson(f).getAsJsonObject();
            Map<String, Layer> m = new LinkedHashMap<>();
            long total = 0;
            for (Map.Entry<String, JsonElement> en : o.entrySet()) {
                JsonArray arr = en.getValue().getAsJsonArray();
                List<int[]> pos = new ArrayList<>(arr.size());
                List<BlockData> bds = new ArrayList<>(arr.size());
                for (JsonElement el : arr) {
                    JsonObject b = el.getAsJsonObject();
                    BlockData bd = block(b.get("b").getAsString(), "calque " + en.getKey());
                    if (bd == null) continue;
                    pos.add(new int[]{b.get("x").getAsInt(), b.get("y").getAsInt(), b.get("z").getAsInt()});
                    bds.add(bd);
                }
                Layer l = new Layer(en.getKey(), pos.size());
                for (int i = 0; i < pos.size(); i++) {
                    l.x[i] = pos.get(i)[0];
                    l.y[i] = pos.get(i)[1];
                    l.z[i] = pos.get(i)[2];
                    l.data[i] = bds.get(i);
                }
                total += l.size();
                m.put(en.getKey(), l);
            }
            layers = m;
            summary.add(m.size() + " calques (" + total + " blocs)");
        } catch (Throwable t) {
            ZAMonde.log().log(Level.WARNING, "Lecture de layers.json impossible : " + t);
            summary.add("layers.json illisible");
        }
    }

    private void loadLamps(List<String> summary) {
        File f = new File(dir, "lamps.json");
        if (!f.isFile()) {
            lamps = Collections.emptyList();
            lampGroups = new int[0];
            summary.add("lamps.json absent");
            return;
        }
        try {
            JsonArray arr = readJson(f).getAsJsonArray();
            List<Lamp> l = new ArrayList<>(arr.size());
            TreeSet<Integer> groups = new TreeSet<>();
            for (JsonElement el : arr) {
                JsonObject o = el.getAsJsonObject();
                BlockData on = block(o.has("on") ? o.get("on").getAsString() : null, "lampes");
                BlockData off = block(o.has("off") ? o.get("off").getAsString() : null, "lampes");
                if (off == null) continue;
                int g = o.has("g") ? o.get("g").getAsInt() : 0;
                l.add(new Lamp(o.get("x").getAsInt(), o.get("y").getAsInt(), o.get("z").getAsInt(), on, off, g));
                groups.add(g);
            }
            lamps = l;
            lampGroups = groups.stream().mapToInt(Integer::intValue).toArray();
            summary.add(l.size() + " lampes (" + groups.size() + " groupes)");
        } catch (Throwable t) {
            ZAMonde.log().log(Level.WARNING, "Lecture de lamps.json impossible : " + t);
            summary.add("lamps.json illisible");
        }
    }

    private void loadPois(List<String> summary) {
        File f = new File(dir, "pois.json");
        if (!f.isFile()) {
            pois = new JsonObject();
            summary.add("pois.json absent");
            return;
        }
        try {
            pois = readJson(f).getAsJsonObject();
            summary.add(pois.size() + " POIs");
        } catch (Throwable t) {
            pois = new JsonObject();
            ZAMonde.log().log(Level.WARNING, "Lecture de pois.json impossible : " + t);
            summary.add("pois.json illisible");
        }
    }

    private static float[] vec3(JsonElement e, float def) {
        float[] v = {def, def, def};
        if (e != null && e.isJsonArray()) {
            JsonArray a = e.getAsJsonArray();
            for (int i = 0; i < 3 && i < a.size(); i++) v[i] = a.get(i).getAsFloat();
        }
        return v;
    }

    private void loadModels(List<String> summary) {
        File f = new File(dir, "props.json");
        if (!f.isFile()) {
            models = Collections.emptyMap();
            summary.add("props.json absent");
            return;
        }
        try {
            JsonObject o = readJson(f).getAsJsonObject();
            Map<String, Model> m = new LinkedHashMap<>();
            for (Map.Entry<String, JsonElement> en : o.entrySet()) {
                JsonObject mo = en.getValue().getAsJsonObject();
                List<PartDef> parts = new ArrayList<>();
                for (JsonElement pe : mo.getAsJsonArray("parts")) {
                    JsonObject p = pe.getAsJsonObject();
                    BlockData bd = block(p.get("b").getAsString(), "modèle " + en.getKey());
                    if (bd == null) continue;
                    String tag = p.has("tag") ? p.get("tag").getAsString().toLowerCase(Locale.ROOT) : "body";
                    float[] t = vec3(p.get("t"), 0f);
                    float[] s = vec3(p.get("s"), 1f);
                    float[] pv = p.has("pivot") ? vec3(p.get("pivot"), 0f) : null;
                    parts.add(new PartDef(bd, t, s, pv, tag));
                }
                m.put(en.getKey(), new Model(en.getKey(), parts));
            }
            models = m;
            summary.add(m.size() + " modèles " + m.keySet());
        } catch (Throwable t) {
            ZAMonde.log().log(Level.WARNING, "Lecture de props.json impossible : " + t);
            summary.add("props.json illisible");
        }
    }

    // ---------------------------------------------------------------- placements (structures posées)

    private void loadPlacements() {
        File f = new File(dir, "placements.yml");
        placements = f.isFile() ? YamlConfiguration.loadConfiguration(f) : new YamlConfiguration();
    }

    void savePlacement(String label, World w, int x, int y, int z) {
        try {
            placements.set(label + ".monde", w.getName());
            placements.set(label + ".x", x);
            placements.set(label + ".y", y);
            placements.set(label + ".z", z);
            placements.save(new File(dir, "placements.yml"));
        } catch (Throwable t) {
            ZAMonde.log().log(Level.WARNING, "Écriture de placements.yml impossible : " + t);
        }
    }

    // ---------------------------------------------------------------- POIs

    /** Élément brut d'un POI : « nom » (pois.json) ou « structure:nom » (structure_pois.json, relatif à sa base). */
    private JsonElement rawPoi(String name, double[] offsetOut, String[] worldOut) {
        int c = name.indexOf(':');
        if (c <= 0) {
            return pois.get(name);
        }
        String pre = name.substring(0, c), key = name.substring(c + 1);
        JsonObject o = extraPois.get(pre);
        if (o == null) {
            File f = new File(dir, pre + "_pois.json");
            if (!f.isFile()) return null;
            try {
                o = readJson(f).getAsJsonObject();
                extraPois.put(pre, o);
            } catch (Throwable t) {
                ZAMonde.log().warning("Lecture de " + f.getName() + " impossible : " + t);
                return null;
            }
        }
        if (!placements.contains(pre + ".x")) {
            Nms.warnOnce("noplace:" + pre, "Structure « " + pre + " » jamais posée (/zamonde placer " + pre + " <monde> x y z) : POI " + name + " indisponible", null);
            return null;
        }
        {
            offsetOut[0] = placements.getInt(pre + ".x");
            offsetOut[1] = placements.getInt(pre + ".y");
            offsetOut[2] = placements.getInt(pre + ".z");
            worldOut[0] = placements.getString(pre + ".monde");
        }
        return o.get(key);
    }

    private static double[] pointOf(JsonElement e) {
        if (e == null) return null;
        if (e.isJsonObject()) {
            JsonObject o = e.getAsJsonObject();
            if (o.has("x")) {
                return new double[]{o.get("x").getAsDouble(), o.get("y").getAsDouble(), o.get("z").getAsDouble(),
                        o.has("yaw") ? o.get("yaw").getAsDouble() : 0, o.has("pitch") ? o.get("pitch").getAsDouble() : 0, 0};
            }
            if (o.has("x1")) {
                return new double[]{(o.get("x1").getAsDouble() + o.get("x2").getAsDouble()) / 2.0 + 0.5,
                        Math.min(o.get("y1").getAsDouble(), o.get("y2").getAsDouble()),
                        (o.get("z1").getAsDouble() + o.get("z2").getAsDouble()) / 2.0 + 0.5, 0, 0, 0};
            }
        }
        if (e.isJsonArray()) {
            JsonArray a = e.getAsJsonArray();
            if (a.size() > 0 && a.get(0).isJsonArray()) return pointOf(a.get(0));
            if (a.size() >= 3 && a.get(0).isJsonPrimitive()) {
                double[] p = new double[6];
                for (int i = 0; i < Math.min(6, a.size()); i++) p[i] = a.get(i).getAsDouble();
                return p;
            }
        }
        return null;
    }

    /** Location d'un POI ; monde par défaut = prologue (ou monde de la structure pour « structure:nom »). */
    Location poi(String name, World def) {
        double[] off = new double[3];
        String[] w = new String[1];
        JsonElement e = rawPoi(name, off, w);
        double[] p = pointOf(e);
        if (p == null) return null;
        World world = def;
        if (world == null && w[0] != null) world = Bukkit.getWorld(w[0]);
        if (world == null) world = pl.worlds.prologue();
        return new Location(world, p[0] + off[0], p[1] + off[1], p[2] + off[2], (float) p[3], (float) p[4]);
    }

    boolean hasPoi(String name) {
        double[] off = new double[3];
        return rawPoi(name, off, new String[1]) != null;
    }

    /** Chemin : liste de [x,y,z(,yaw,pitch,ticks)] ; null si absent. */
    List<double[]> path(String name) {
        double[] off = new double[3];
        JsonElement e = rawPoi(name, off, new String[1]);
        if (e == null || !e.isJsonArray()) return null;
        JsonArray a = e.getAsJsonArray();
        if (a.size() == 0 || !a.get(0).isJsonArray()) return null;
        List<double[]> out = new ArrayList<>();
        for (JsonElement pe : a) {
            JsonArray pa = pe.getAsJsonArray();
            double[] p = new double[6];
            for (int i = 0; i < Math.min(6, pa.size()); i++) p[i] = pa.get(i).getAsDouble();
            p[0] += off[0];
            p[1] += off[1];
            p[2] += off[2];
            out.add(p);
        }
        return out;
    }

    /** Chemin nommé (POI) ou liste en ligne « x,y,z(,yaw,pitch,ticks);... ». */
    List<double[]> pathOrInline(String s) {
        if (s.indexOf(',') >= 0) return U.points(s);
        List<double[]> p = path(s);
        if (p == null) throw new IllegalArgumentException("chemin inconnu « " + s + " » (ni POI ni liste x,y,z;...)");
        return p;
    }
}
