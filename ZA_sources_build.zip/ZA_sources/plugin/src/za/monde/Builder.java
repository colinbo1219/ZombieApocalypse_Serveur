package za.monde;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.ChatColor;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.Container;
import org.bukkit.block.Sign;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.sign.Side;
import org.bukkit.block.sign.SignSide;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;

/** Pose de structures par lots (sans physique), puis panneaux et conteneurs. File d'attente séquentielle. */
final class Builder {
    private final ZAMonde pl;
    private final Deque<Job> queue = new ArrayDeque<>();
    private Job current;
    private BukkitTask task;

    Builder(ZAMonde pl) {
        this.pl = pl;
    }

    final class Job {
        final CommandSender sender;
        final Structure s;
        final World world;
        final int bx, by, bz;
        final boolean clear;
        final boolean isTown;
        BlockData[] pal;
        int[][] chunks; // {cx, cz}
        int ci = 0, cy = 0, cz = 0, cx = 0;
        int x0, x1, z0, z1; // bornes locales de la colonne en cours
        boolean columnReady;
        long placed, visited, total;
        int signs, containers;
        final long t0 = System.currentTimeMillis();
        long lastLog = System.currentTimeMillis();
        final List<Chunk> ticketed = new ArrayList<>();

        Job(CommandSender sender, Structure s, World world, int bx, int by, int bz, boolean clear, boolean isTown) {
            this.sender = sender;
            this.s = s;
            this.world = world;
            this.bx = bx;
            this.by = by;
            this.bz = bz;
            this.clear = clear;
            this.isTown = isTown;
            this.total = (long) s.w * s.h * s.d;
        }
    }

    String status() {
        if (current == null) return "aucune construction en cours" + (queue.isEmpty() ? "" : ", " + queue.size() + " en attente");
        Job j = current;
        return "construction de « " + j.s.name + " » : " + (j.total == 0 ? 100 : (100 * j.visited / j.total)) + " %, "
                + j.placed + " blocs posés, " + queue.size() + " en attente";
    }

    private void msg(CommandSender s, String m) {
        pl.getLogger().info(ChatColor.stripColor(m));
        if (s != null && !(s instanceof ConsoleCommandSender)) s.sendMessage("§7[ZAMonde] §f" + m);
    }

    /** Lecture asynchrone du fichier puis mise en file sur le fil principal. */
    void enqueue(CommandSender sender, File f, World w, int bx, int by, int bz, boolean clear, boolean isTown) {
        msg(sender, "Lecture de " + f.getName() + "…");
        Bukkit.getScheduler().runTaskAsynchronously(pl, () -> {
            Structure s;
            try {
                s = Structure.read(f);
            } catch (Throwable t) {
                Bukkit.getScheduler().runTask(pl, () -> {
                    pl.getLogger().log(Level.WARNING, "Structure " + f.getName() + " illisible : " + t);
                    if (sender != null && !(sender instanceof ConsoleCommandSender)) sender.sendMessage("§c[ZAMonde] Structure illisible : " + t);
                });
                return;
            }
            Bukkit.getScheduler().runTask(pl, () -> start(sender, s, w, bx, by, bz, clear, isTown));
        });
    }

    private void start(CommandSender sender, Structure s, World w, int bx, int by, int bz, boolean clear, boolean isTown) {
        try {
            if (Bukkit.getWorld(w.getUID()) == null) {
                msg(sender, "Monde déchargé, construction annulée");
                return;
            }
            Job j = new Job(sender, s, w, bx, by, bz, clear, isTown);
            j.pal = new BlockData[s.palette.length];
            int bad = 0;
            for (int i = 0; i < s.palette.length; i++) {
                if (i == 0 && "minecraft:air".equals(s.palette[i])) {
                    j.pal[i] = Material.AIR.createBlockData();
                    continue;
                }
                j.pal[i] = pl.data.block(s.palette[i], s.name);
                if (j.pal[i] == null) bad++;
            }
            int minX = bx + s.ox, minZ = bz + s.oz;
            int maxX = minX + s.w - 1, maxZ = minZ + s.d - 1;
            List<int[]> ch = new ArrayList<>();
            for (int cx = Math.floorDiv(minX, 16); cx <= Math.floorDiv(maxX, 16); cx++) {
                for (int cz = Math.floorDiv(minZ, 16); cz <= Math.floorDiv(maxZ, 16); cz++) ch.add(new int[]{cx, cz});
            }
            j.chunks = ch.toArray(new int[0][]);
            queue.add(j);
            msg(sender, "Structure « " + s.name + " » " + s.w + "x" + s.h + "x" + s.d + " (palette " + s.palette.length
                    + (bad > 0 ? ", " + bad + " entrées invalides ignorées" : "") + ", " + j.chunks.length + " tronçons) → "
                    + w.getName() + " base " + bx + "," + by + "," + bz + (clear ? " [dégager]" : "") + " : en file");
            if (task == null) task = Bukkit.getScheduler().runTaskTimer(pl, this::tick, 1L, 1L);
        } catch (Throwable t) {
            pl.getLogger().log(Level.WARNING, "Démarrage de la construction impossible : " + t, t);
        }
    }

    void cancelAll() {
        if (task != null) task.cancel();
        task = null;
        if (current != null) releaseTickets(current);
        current = null;
        queue.clear();
    }

    private void releaseTickets(Job j) {
        for (Chunk c : j.ticketed) {
            try {
                c.removePluginChunkTicket(pl);
            } catch (Throwable ignored) {
                // monde déchargé
            }
        }
        j.ticketed.clear();
    }

    private void tick() {
        try {
            if (current == null) {
                current = queue.poll();
                if (current == null) {
                    task.cancel();
                    task = null;
                    return;
                }
            }
            Job j = current;
            if (Bukkit.getWorld(j.world.getUID()) == null) {
                msg(j.sender, "Monde déchargé, construction « " + j.s.name + " » annulée");
                releaseTickets(j);
                current = null;
                return;
            }
            int perTick = Math.max(100, pl.getConfig().getInt("construire.blocs_par_tick", 20000));
            long maxNs = Math.max(5, pl.getConfig().getLong("construire.ms_max_par_tick", 80)) * 1_000_000L;
            long start = System.nanoTime();
            if (step(j, perTick, start, maxNs)) {
                finish(j);
                current = null;
            } else if (System.currentTimeMillis() - j.lastLog > 2000) {
                j.lastLog = System.currentTimeMillis();
                msg(j.sender, "Construction « " + j.s.name + " » : " + (100 * j.visited / Math.max(1, j.total)) + " % ("
                        + j.placed + " blocs posés)");
            }
        } catch (Throwable t) {
            pl.getLogger().log(Level.WARNING, "Erreur pendant la construction : " + t, t);
            if (current != null) releaseTickets(current);
            current = null;
        }
    }

    /** Avance la pose ; retourne true quand tous les blocs sont posés. */
    private boolean step(Job j, int perTick, long start, long maxNs) {
        Structure s = j.s;
        World w = j.world;
        int minH = w.getMinHeight(), maxH = w.getMaxHeight();
        int placedNow = 0, visitedNow = 0;
        int ox = j.bx + s.ox, oy = j.by + s.oy, oz = j.bz + s.oz;
        while (j.ci < j.chunks.length) {
            if (!j.columnReady) {
                int cx = j.chunks[j.ci][0], cz = j.chunks[j.ci][1];
                Chunk c = w.getChunkAt(cx, cz);
                if (c.addPluginChunkTicket(pl)) j.ticketed.add(c);
                j.x0 = Math.max(0, cx * 16 - ox);
                j.x1 = Math.min(s.w - 1, cx * 16 + 15 - ox);
                j.z0 = Math.max(0, cz * 16 - oz);
                j.z1 = Math.min(s.d - 1, cz * 16 + 15 - oz);
                j.cy = 0;
                j.cz = j.z0;
                j.cx = j.x0;
                j.columnReady = true;
            }
            while (j.cy < s.h) {
                int wy = oy + j.cy;
                boolean inWorld = wy >= minH && wy < maxH;
                while (j.cz <= j.z1) {
                    while (j.cx <= j.x1) {
                        int x = j.cx++;
                        visitedNow++;
                        j.visited++;
                        if (!inWorld) continue;
                        int v = s.blocks[s.index(x, j.cy, j.cz)] & 0xFFFF;
                        if (v == 0 && !j.clear) continue;
                        BlockData bd = j.pal[v];
                        if (bd == null) continue;
                        Block b = w.getBlockAt(ox + x, wy, oz + j.cz);
                        b.setBlockData(bd, false);
                        placedNow++;
                        j.placed++;
                        if (placedNow >= perTick) return false;
                        if ((visitedNow & 1023) == 0 && System.nanoTime() - start > maxNs) return false;
                    }
                    j.cx = j.x0;
                    j.cz++;
                    if (visitedNow > perTick * 16 || ((visitedNow & 255) == 0 && System.nanoTime() - start > maxNs)) {
                        return false;
                    }
                }
                j.cz = j.z0;
                j.cy++;
            }
            j.ci++;
            j.columnReady = false;
            if (System.nanoTime() - start > maxNs) return false;
        }
        return true;
    }

    private void finish(Job j) {
        int bx = j.bx, by = j.by, bz = j.bz;
        for (JsonElement e : j.s.signs) {
            try {
                if (placeSign(j.world, bx, by, bz, e.getAsJsonObject())) j.signs++;
            } catch (Throwable t) {
                Nms.warnOnce("sign:" + e, "Panneau invalide " + e, t);
            }
        }
        for (JsonElement e : j.s.containers) {
            try {
                if (fillContainer(j.world, bx, by, bz, e.getAsJsonObject())) j.containers++;
            } catch (Throwable t) {
                Nms.warnOnce("cont:" + e, "Conteneur invalide " + e, t);
            }
        }
        releaseTickets(j);
        long ms = System.currentTimeMillis() - j.t0;
        msg(j.sender, "Construction « " + j.s.name + " » terminée : " + j.placed + " blocs posés, " + j.signs + "/" + j.s.signs.size()
                + " panneaux, " + j.containers + "/" + j.s.containers.size() + " conteneurs en " + String.format(Locale.ROOT, "%.1f", ms / 1000.0) + " s");
        pl.data.savePlacement(j.s.name, j.world, bx, by, bz);
    }

    private boolean placeSign(World w, int bx, int by, int bz, JsonObject o) {
        int[] p = Structure.xyz(o);
        Block b = w.getBlockAt(bx + p[0], by + p[1], bz + p[2]);
        BlockState st = b.getState();
        if (!(st instanceof Sign sign)) {
            Nms.warnOnce("nosign:" + b.getLocation(), "Pas de panneau en " + U.fmtLoc(b.getLocation()) + " (" + b.getType() + ")", null);
            return false;
        }
        DyeColor color = DyeColor.BLACK;
        if (o.has("color")) {
            try {
                color = DyeColor.valueOf(o.get("color").getAsString().toUpperCase(Locale.ROOT));
            } catch (IllegalArgumentException ignored) {
                // noir
            }
        }
        boolean glow = o.has("glow") && o.get("glow").getAsBoolean();
        writeSide(sign.getSide(Side.FRONT), o.has("front") ? o.getAsJsonArray("front") : null, color, glow);
        if (o.has("back")) writeSide(sign.getSide(Side.BACK), o.getAsJsonArray("back"), color, glow);
        sign.setWaxed(true);
        sign.update(true, false);
        return true;
    }

    private static void writeSide(SignSide side, JsonArray lines, DyeColor color, boolean glow) {
        for (int i = 0; i < 4; i++) {
            String l = lines != null && i < lines.size() && !lines.get(i).isJsonNull() ? lines.get(i).getAsString() : "";
            side.setLine(i, l);
        }
        side.setColor(color);
        side.setGlowingText(glow);
    }

    private boolean fillContainer(World w, int bx, int by, int bz, JsonObject o) {
        int[] p = Structure.xyz(o);
        Block b = w.getBlockAt(bx + p[0], by + p[1], bz + p[2]);
        BlockState st = b.getState();
        if (!(st instanceof Container c)) {
            Nms.warnOnce("nocont:" + b.getLocation(), "Pas de conteneur en " + U.fmtLoc(b.getLocation()) + " (" + b.getType() + ")", null);
            return false;
        }
        Inventory inv = c.getInventory();
        inv.clear();
        if (o.has("items")) {
            int auto = 0;
            for (JsonElement ie : o.getAsJsonArray("items")) {
                JsonObject it = ie.getAsJsonObject();
                ItemStack is = item(it);
                if (is == null) continue;
                int slot = it.has("slot") ? it.get("slot").getAsInt() : auto;
                auto = slot + 1;
                if (slot >= 0 && slot < inv.getSize()) inv.setItem(slot, is);
            }
        }
        return true;
    }

    /** Objet depuis {"id","n","name","lore"} ; id vanilla, moddé (espace:nom) ou avec NBT (format /give). */
    static ItemStack item(JsonObject it) {
        String id = it.get("id").getAsString();
        int n = it.has("n") ? it.get("n").getAsInt() : 1;
        ItemStack is = null;
        Material m = id.indexOf('{') < 0 ? material(id) : null;
        if (m != null && m.isItem()) {
            is = new ItemStack(m, Math.max(1, n));
        } else {
            try {
                is = Bukkit.getItemFactory().createItemStack(id);
                is.setAmount(Math.max(1, n));
            } catch (Throwable t) {
                Nms.warnOnce("item:" + id, "Objet inconnu « " + id + " »", null);
                return null;
            }
        }
        if (it.has("name") || it.has("lore")) {
            ItemMeta meta = is.getItemMeta();
            if (meta != null) {
                if (it.has("name")) meta.setDisplayName(it.get("name").getAsString());
                if (it.has("lore") && it.get("lore").isJsonArray()) {
                    List<String> lore = new ArrayList<>();
                    for (JsonElement l : it.getAsJsonArray("lore")) lore.add(l.getAsString());
                    meta.setLore(lore);
                }
                is.setItemMeta(meta);
            }
        }
        return is;
    }

    static Material material(String id) {
        Material m = Material.matchMaterial(id);
        if (m != null) return m;
        NamespacedKey k = NamespacedKey.fromString(id.toLowerCase(Locale.ROOT));
        if (k == null) return null;
        for (Material mm : Material.values()) {
            try {
                if (!mm.isLegacy() && k.equals(mm.getKey())) return mm;
            } catch (Throwable ignored) {
                // matériaux sans clé
            }
        }
        return null;
    }
}
