# ZombieApocalypse - generateur de modeles CEM (EMF/ETF / format OptiFine .jem)
# Coordonnees JEM (comme le template officiel zombie.jem):
#   y = hauteur depuis les pieds (vers le haut), -z = devant (visage), +x = cote droit du zombie.
#   Pivot vanilla de chaque partie; translate = -pivot; boxes en coordonnees absolues.
import json, math, random, zlib
from PIL import Image

PIVOTS = {
    'head': (0, 24, 0), 'headwear': (0, 24, 0), 'body': (0, 24, 0),
    'right_arm': (5, 22, 0), 'left_arm': (-5, 22, 0),
    'right_leg': (1.9, 12, 0), 'left_leg': (-1.9, 12, 0),
}
PARTS = ['head', 'headwear', 'body', 'right_arm', 'left_arm', 'right_leg', 'left_leg']


class Box:
    def __init__(self, x, y, z, w, h, d, mat, face=None, top=None, seed=0, sizeAdd=None, faces=None, hires=1):
        self.x, self.y, self.z, self.w, self.h, self.d = x, y, z, int(w), int(h), int(d)
        assert self.w == w and self.h == h and self.d == d, ('dims entieres requises', w, h, d)
        self.mat = mat
        self.face = face        # decoration de la face avant (nord, -z)
        self.top = top          # decoration de la face du dessus
        self.faces = faces or {}  # materiau different par face: {'north': 'mat'}
        self.seed = seed
        self.sizeAdd = sizeAdd
        self.uv = None
        self.k = int(hires)  # densite de texture (2 = texture 2x plus fine, UV par face)


class Sub:
    """Sous-modele anime (id pour les animations). pivot et boxes en coordonnees JEM absolues."""
    def __init__(self, id, pivot, *items):
        self.id = id
        self.pivot = pivot
        self.boxes = [i for i in items if isinstance(i, Box)]
        self.subs = [i for i in items if isinstance(i, Sub)]

    def all_boxes(self):
        out = list(self.boxes)
        for c in self.subs:
            out += c.all_boxes()
        return out


def box_json(b, origin=(0, 0, 0)):
    ox, oy, oz = origin
    bx = {'coordinates': [r(b.x - ox), r(b.y - oy), r(b.z - oz), b.w, b.h, b.d]}
    if b.k == 1:
        bx['textureOffset'] = list(b.uv)
    else:
        fr = face_rects(b)
        for fname, key in (('north', 'uvNorth'), ('south', 'uvSouth'), ('east', 'uvEast'),
                           ('west', 'uvWest'), ('up', 'uvUp'), ('down', 'uvDown')):
            fx, fy, fw, fh = fr[fname]
            bx[key] = [fx, fy, fx + fw, fy + fh]
    if b.sizeAdd:
        bx['sizeAdd'] = b.sizeAdd
    return bx


def sub_json(sub, parent=(0, 0, 0)):
    # sous-modele (invertAxis xy): translate = pivot relatif au parent, boites relatives au pivot
    px, py, pz = sub.pivot
    j = {'id': sub.id, 'invertAxis': 'xy',
         'translate': [r(px - parent[0]), r(py - parent[1]), r(pz - parent[2])],
         'boxes': [box_json(b, sub.pivot) for b in sub.boxes]}
    if sub.subs:
        j['submodels'] = [sub_json(c, sub.pivot) for c in sub.subs]
    return j


class Model:
    def __init__(self, name, scale=1.0):
        self.name = name
        self.parts = {p: [] for p in PARTS}
        self.anims = {}
        self.scale = scale  # multiplie toutes les coordonnees (pour les bebes)

    def add(self, part, *items):
        self.parts[part].extend(items)
        return self

    def boxes_of(self, part):
        out = []
        for i in self.parts[part]:
            out += [i] if isinstance(i, Box) else i.all_boxes()
        return out


# ----------------------------------------------------------------- couleurs
def clamp(v):
    return max(0, min(255, int(v)))


def mix(a, b, t):
    return tuple(clamp(a[i] * (1 - t) + b[i] * t) for i in range(3))


def shade(c, f):
    return tuple(clamp(v * f) for v in c)


BLOOD = (105, 12, 14)
BLOOD2 = (70, 8, 10)
DARK = (18, 14, 14)

MATS = {
    # nom: (couleur de base, variation, type)
    'rot': ((92, 118, 84), 14, 'skin'),
    'pale': ((150, 158, 146), 12, 'skin'),
    'grey': ((112, 116, 110), 12, 'skin'),
    'dark_skin': ((42, 44, 48), 8, 'skin'),
    'shadow': ((14, 14, 18), 4, 'plain'),
    'bloat_skin': ((128, 140, 78), 16, 'bloat'),
    'brute_skin': ((104, 96, 90), 14, 'scar'),
    'overlord_skin': ((72, 54, 58), 12, 'cracked'),
    'alpha_skin': ((96, 108, 96), 12, 'warpaint'),
    'child_skin': ((128, 140, 118), 12, 'skin'),
    'muscle': ((140, 46, 42), 16, 'muscle'),
    'bone': ((218, 208, 178), 10, 'bone'),
    'flesh': ((150, 38, 38), 18, 'muscle'),
    'blood': ((95, 10, 12), 10, 'plain'),
    'shirt': ((70, 88, 118), 10, 'cloth'),
    'hoodie_red': ((122, 30, 30), 10, 'cloth'),
    'gown': ((186, 192, 182), 8, 'gown'),
    'pajama': ((212, 190, 86), 8, 'pajama'),
    'military': ((78, 88, 56), 10, 'camo'),
    'jeans': ((50, 64, 98), 10, 'cloth'),
    'jeans_dark': ((36, 40, 54), 8, 'cloth'),
    'pants_brown': ((82, 64, 46), 10, 'cloth'),
    'black_cloth': ((24, 24, 28), 6, 'cloth'),
    'kevlar': ((36, 40, 42), 6, 'kevlar'),
    'metal_dark': ((62, 66, 72), 8, 'metal'),
    'metal': ((138, 142, 148), 8, 'metal'),
    'visor': ((34, 54, 66), 6, 'visor'),
    'riot_shield': ((58, 66, 80), 6, 'shield'),
    'acid_sac': ((118, 196, 58), 16, 'glowsac'),
    'acid': ((150, 235, 70), 10, 'glow'),
    'pustule': ((196, 182, 84), 14, 'pustule'),
    'core_glow': ((235, 50, 28), 12, 'glow'),
    'cape': ((78, 20, 26), 10, 'cape'),
    'teddy': ((138, 98, 58), 12, 'fur'),
    'hair': ((46, 34, 26), 8, 'hair'),
    'hair_blond': ((150, 124, 70), 10, 'hair'),
    'gut': ((168, 72, 80), 16, 'muscle'),
}
GLOW_TYPES = {'glow', 'glowsac'}


class Painter:
    def __init__(self, W, H, seed):
        self.img = Image.new('RGBA', (W, H), (0, 0, 0, 0))
        self.emi = Image.new('RGBA', (W, H), (0, 0, 0, 0))
        self.px = self.img.load()
        self.epx = self.emi.load()
        self.rng = random.Random(seed)
        self.W, self.H = W, H
        self.has_emissive = False

    def put(self, x, y, c, glow=False):
        if 0 <= x < self.W and 0 <= y < self.H:
            self.px[x, y] = (c[0], c[1], c[2], 255)
            if glow:
                self.epx[x, y] = (c[0], c[1], c[2], 255)
                self.has_emissive = True

    def get(self, x, y):
        return self.px[x, y][:3]

    # remplissage d'une face (rectangle) selon le materiau
    def fill(self, rx, ry, w, h, mat, facing):
        base, var, kind = MATS[mat]
        r = self.rng
        light = {'up': 1.12, 'down': 0.7, 'north': 1.0, 'south': 0.9, 'east': 0.95, 'west': 0.95}[facing]
        gros = {}
        for j in range(h):
            for i in range(w):
                cle = (i // 2, j // 2)
                if cle not in gros:
                    gros[cle] = r.uniform(-1, 1)
                n = gros[cle] * var * 0.9 + r.uniform(-1, 1) * var * 0.45
                c = tuple(clamp((base[k] + n) * light) for k in range(3))
                # degrade: plus sale vers le bas (crasse brunâtre)
                if facing in ('north', 'south', 'east', 'west') and h > 2:
                    t = j / (h - 1)
                    c = mix(shade(c, 1.0 - 0.26 * t), (58, 44, 30), 0.22 * t * t)
                glow = kind in GLOW_TYPES
                if kind == 'muscle' and (i + (j // 2)) % 3 == 0:
                    c = shade(c, 0.78)
                elif kind == 'bone' and (j == h - 1 or i == 0):
                    c = shade(c, 0.85)
                elif kind == 'camo':
                    v = (math.sin(i * 1.3 + j * 0.7 + rx) + math.cos(j * 1.1 - i * 0.5 + ry)) * 0.5
                    if v > 0.45:
                        c = shade(c, 0.72)
                    elif v < -0.55:
                        c = mix(c, (120, 110, 80), 0.35)
                elif kind == 'pajama':
                    if (i % 4 == 1 and j % 4 == 1):
                        c = (240, 240, 255)
                    elif j % 4 == 3:
                        c = shade(c, 0.9)
                elif kind == 'kevlar':
                    if j % 5 == 0 or i % 6 == 0:
                        c = shade(c, 0.75)
                elif kind == 'metal':
                    if r.random() < 0.06:
                        c = shade(c, 1.35)
                    if i == 0 or j == 0:
                        c = shade(c, 1.2)
                    if i == w - 1 or j == h - 1:
                        c = shade(c, 0.7)
                elif kind == 'visor':
                    if i == j or i == j + 1:
                        c = (120, 170, 190)
                elif kind == 'fur':
                    if r.random() < 0.25:
                        c = shade(c, 0.8)
                elif kind == 'hair':
                    if (i + r.randint(0, 1)) % 2 == 0:
                        c = shade(c, 0.75)
                elif kind == 'cape':
                    if r.random() < 0.08:
                        c = BLOOD2
                elif kind == 'glowsac':
                    if r.random() < 0.15:
                        c = (190, 255, 110)
                elif kind == 'plain':
                    pass
                self.put(rx + i, ry + j, c, glow)
        # details par type
        if kind in ('skin', 'scar', 'bloat', 'cracked', 'warpaint', 'muscle', 'cloth', 'gown', 'pajama', 'camo', 'cape', 'fur'):
            self.splatter(rx, ry, w, h, count=max(1, (w * h) // 30), chance=0.8 if kind not in ('muscle',) else 0.3)
        if kind in ('skin', 'bloat', 'scar'):
            self.spots(rx, ry, w, h, shade(base, 0.7), (w * h) // 18)
        if kind in ('skin', 'scar', 'warpaint', 'cracked') and w * h >= 12:
            self.bruises(rx, ry, w, h, max(1, (w * h) // 70))
            self.veins(rx, ry, w, h, mix(shade(base, 0.55), (70, 40, 80), 0.45))
            if facing != 'up':
                self.wounds(rx, ry, w, h, max(0, (w * h) // 150))
        if kind == 'bloat':
            self.veins(rx, ry, w, h, (96, 64, 104))
        if kind == 'scar':
            self.stitches(rx, ry, w, h)
        if kind == 'cracked':
            self.cracks(rx, ry, w, h)
        if kind == 'warpaint' and facing in ('north', 'south', 'east', 'west'):
            for j in range(h):
                if j % 6 in (1, 2):
                    for i in range(w):
                        if (i + j) % 7 < 3:
                            self.put(rx + i, ry + j, (150, 20, 20))
        if kind in ('cloth', 'gown', 'pajama', 'camo') and facing != 'up' and w >= 3 and h >= 3:
            self.tears(rx, ry, w, h, 'rot')
        if kind == 'gown':
            self.splatter(rx, ry, w, h, count=max(2, (w * h) // 12), chance=1.0)
        if kind == 'pustule':
            cx, cy = rx + w // 2, ry + h // 2
            self.put(cx, cy, (240, 230, 120), True)
        if kind == 'shield' and facing in ('north',) and w >= 8 and h >= 8:
            self.police(rx, ry, w, h)
        if kind == 'shield':
            # bord
            for i in range(w):
                self.put(rx + i, ry, (30, 32, 36)); self.put(rx + i, ry + h - 1, (30, 32, 36))
            for j in range(h):
                self.put(rx, ry + j, (30, 32, 36)); self.put(rx + w - 1, ry + j, (30, 32, 36))

    def splatter(self, rx, ry, w, h, count, chance):
        r = self.rng
        for _ in range(max(1, int(count * 0.4))):
            if r.random() > chance:
                continue
            cx, cy = rx + r.randrange(w), ry + r.randrange(max(1, h * 2 // 3))
            seche = r.random() < 0.55
            c1, c2 = ((74, 30, 22), (52, 20, 16)) if seche else (BLOOD, BLOOD2)
            size = 1 if r.random() < 0.7 else 2
            for dy in range(-size, size + 1):
                for dx in range(-size, size + 1):
                    if dx * dx + dy * dy <= size * size + r.randint(0, 1):
                        x, y = cx + dx, cy + dy
                        if rx <= x < rx + w and ry <= y < ry + h:
                            self.put(x, y, c1 if (dx + dy) % 3 else c2)
            # coulures : le sang descend
            for k in range(r.randint(1, 2)):
                x = cx + r.randint(-size, size)
                for d in range(r.randint(1, 5)):
                    y = cy + size + d
                    if rx <= x < rx + w and ry <= y < ry + h:
                        self.put(x, y, c2 if d > 1 else c1)

    def bruises(self, rx, ry, w, h, n):
        r = self.rng
        for _ in range(n):
            cx, cy = rx + r.randrange(w), ry + r.randrange(h)
            teinte = r.choice(((78, 52, 86), (96, 104, 48), (60, 44, 58)))
            for dy in range(-2, 3):
                for dx in range(-2, 3):
                    x, y = cx + dx, cy + dy
                    d = dx * dx + dy * dy
                    if d <= 4 and rx <= x < rx + w and ry <= y < ry + h and r.random() < 0.85:
                        self.put(x, y, mix(self.get(x, y), teinte, 0.55 if d <= 1 else 0.3))

    def wounds(self, rx, ry, w, h, n):
        # morsure / plaie ouverte : bord sombre, chair, un éclat d'os
        r = self.rng
        for _ in range(n):
            if w < 3 or h < 3:
                return
            cx, cy = rx + r.randrange(1, w - 1), ry + r.randrange(1, h - 1)
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    self.put(cx + dx, cy + dy, (40, 12, 12) if abs(dx) + abs(dy) == 2 else (120, 26, 28))
            self.put(cx, cy, (150, 44, 44))
            if r.random() < 0.5:
                self.put(cx + r.choice((-1, 1)), cy, (214, 204, 176))
            for d in range(r.randint(1, 4)):
                if cy + 2 + d < ry + h:
                    self.put(cx, cy + 2 + d, BLOOD2)

    def spots(self, rx, ry, w, h, col, n):
        r = self.rng
        for _ in range(n):
            x, y = rx + r.randrange(w), ry + r.randrange(h)
            self.put(x, y, col)

    def veins(self, rx, ry, w, h, col):
        r = self.rng
        for _ in range(max(1, (w * h) // 40)):
            x, y = rx + r.randrange(w), ry + r.randrange(h)
            for _k in range(r.randint(3, 7)):
                if rx <= x < rx + w and ry <= y < ry + h:
                    self.put(x, y, col)
                x += r.choice((-1, 0, 1)); y += r.choice((0, 1, 1))

    def stitches(self, rx, ry, w, h):
        r = self.rng
        if w < 4 or h < 4:
            return
        y = ry + r.randrange(1, h - 1)
        x0 = rx + r.randrange(0, max(1, w // 3))
        for i in range(x0, min(rx + w, x0 + w // 2 + 2)):
            self.put(i, y, (60, 30, 30))
            if (i - x0) % 2 == 0:
                self.put(i, y - 1, (30, 26, 26)); self.put(i, y + 1, (30, 26, 26))

    def cracks(self, rx, ry, w, h):
        r = self.rng
        for _ in range(max(1, (w * h) // 30)):
            x, y = rx + r.randrange(w), ry + r.randrange(h)
            for _k in range(r.randint(3, 8)):
                if rx <= x < rx + w and ry <= y < ry + h:
                    self.put(x, y, (255, 70, 30), True)
                x += r.choice((-1, 0, 1)); y += r.choice((-1, 0, 1))

    def tears(self, rx, ry, w, h, under):
        r = self.rng
        base = MATS[under][0]
        for _ in range(max(1, (w * h) // 45)):
            cx, cy = rx + r.randrange(w), ry + r.randrange(h)
            rad = r.randint(1, 2)
            for y in range(cy - rad, cy + rad + 1):
                for x in range(cx - rad, cx + rad + 1):
                    if rx <= x < rx + w and ry <= y < ry + h and r.random() < 0.8:
                        c = mix(base, BLOOD, 0.35) if r.random() < 0.3 else base
                        self.put(x, y, shade(c, 0.9 + r.random() * 0.2))

    def police(self, rx, ry, w, h):
        # bande blanche + "POLICE" en pixels 3x5
        font = {
            'P': ['111', '101', '111', '100', '100'], 'S': ['111', '100', '111', '001', '111'], 'W': ['101', '101', '101', '111', '101'], 'A': ['010', '101', '111', '101', '101'], 'T': ['111', '010', '010', '010', '010'], 'O': ['111', '101', '101', '101', '111'],
            'L': ['100', '100', '100', '100', '111'], 'I': ['111', '010', '010', '010', '111'],
            'C': ['111', '100', '100', '100', '111'], 'E': ['111', '100', '110', '100', '111'],
        }
        word = 'POLICE'
        tw = len(word) * 4 - 1
        by = ry + h // 3
        # bande
        for j in range(-1, 6):
            for i in range(1, w - 1):
                self.put(rx + i, by + j, (220, 222, 226))
        sx = rx + max(1, (w - tw) // 2)
        for k, ch in enumerate(word):
            if sx + k * 4 + 3 > rx + w:
                break
            for j, row in enumerate(font[ch]):
                for i, b in enumerate(row):
                    if b == '1':
                        self.put(sx + k * 4 + i, by + j, (20, 30, 70))
        # fissures
        self.splatter(rx, ry, w, h, 3, 1.0)

    # -------------------------------------------------------- visages
    def face(self, rx, ry, w, h, style, eye=(255, 210, 60)):
        P = self.put
        cx = rx + w // 2
        def eyes(y, gap, col, size=1, socket=True):
            for side in (-1, 1):
                ex = cx + side * gap - (1 if side < 0 else 0)
                for dx in range(size):
                    xx = ex + (dx * side)
                    if socket:
                        # orbite creuse : 2 de large, noire autour de l'oeil
                        for sx in (xx, xx + side):
                            if rx <= sx < rx + w:
                                P(sx, y - 1, shade(self.get(sx, y - 1), 0.3))
                                P(sx, y + 1, shade(self.get(sx, y + 1), 0.4))
                        if rx <= xx + side < rx + w:
                            P(xx + side, y, (16, 10, 10))
                    P(xx, y, col, True)
            # larme de sang sous un oeil
            if socket:
                tx = cx + gap - 1 + (self.rng.random() < 0.5) * (1 - 2 * gap)
                for d in range(2, 2 + self.rng.randint(1, 3)):
                    if ry <= y + d < ry + h:
                        P(tx, y + d, BLOOD2 if d > 2 else BLOOD)
        def mouth(y, x0, x1, teeth=True, depth=1):
            # lèvres arrachées : la bouche déborde d'un côté, dents jaunies irrégulières
            x1b = min(rx + w - 1, x1 + 1)
            for x in range(x0, x1b + 1):
                for dy in range(depth + (1 if x <= x1 else 0)):
                    if ry <= y + dy < ry + h:
                        P(x, y + dy, DARK if x <= x1 else (90, 20, 22))
                if teeth and x <= x1 and (x - x0) % 2 == 0:
                    P(x, y, (196, 184, 140))
                    if self.rng.random() < 0.5 and ry <= y + depth < ry + h:
                        P(x, y + depth, (170, 160, 120))
            # bave de sang qui coule
            for d in range(depth + 1, depth + 1 + self.rng.randint(1, 3)):
                if ry <= y + d < ry + h:
                    P(x0 + 1, y + d, BLOOD if d == depth + 1 else BLOOD2)
        if style == 'zombie':
            eyes(ry + int(h * 0.42), 2, eye)
            mouth(ry + int(h * 0.72), cx - 2, cx + 1)
            P(cx, ry + int(h * 0.58), DARK)  # nez
        elif style == 'runner':
            ey = ry + int(h * 0.4)
            for side in (-1, 1):
                ex = cx + side * 2 - (1 if side < 0 else 0)
                for dx in (0, side):
                    P(ex + dx, ey - 1, DARK); P(ex + dx, ey, DARK)
                P(ex, ey, eye, True)
            y = ry + int(h * 0.7)
            for x in range(cx - 3, cx + 3):
                P(x, y, (210, 200, 165)); P(x, y + 1, DARK if x % 2 else (210, 200, 165))
        elif style == 'spitter':
            eyes(ry + int(h * 0.35), 2, eye)
            P(cx - 1, ry + int(h * 0.62), DARK); P(cx, ry + int(h * 0.62), DARK)
            for x in range(rx + 1, rx + w - 1):
                if x % 2:
                    P(x, ry + h - 1, (205, 196, 160))
        elif style == 'jaw':
            for x in range(rx, rx + w):
                P(x, ry, (210, 200, 165) if x % 2 == 0 else DARK)
                for y in range(ry + 1, ry + h - 1):
                    P(x, y, (60, 20, 20) if (x + y) % 3 else (40, 12, 12))
            for x in (cx - 1, cx + 1):
                P(x, ry + h - 1, (150, 235, 70), True)
        elif style == 'bloater':
            eyes(ry + int(h * 0.45), 1, eye)
            mouth(ry + int(h * 0.75), cx - 1, cx, teeth=False)
        elif style == 'leaper':
            eyes(ry + int(h * 0.25), 2, eye)
            y = ry + int(h * 0.6)
            for x in range(rx + 1, rx + w - 1):
                P(x, y, DARK); P(x, y + 1, DARK)
                if x % 2 == 0:
                    P(x, y, (225, 215, 180));
                else:
                    P(x, y + 1, (225, 215, 180))
        elif style == 'brute':
            ey = ry + int(h * 0.38)
            for x in range(rx + 1, rx + w - 1):
                P(x, ey - 1, shade(self.get(x, ey - 1), 0.5))  # arcade
            eyes(ey, 2, eye)
            y = ry + int(h * 0.72)
            for x in range(cx - 3, cx + 3):
                P(x, y, DARK); P(x, y + 1, DARK)
            for x in (cx - 3, cx + 2):
                P(x, y, (225, 215, 180)); P(x, y - 1, (225, 215, 180))  # crocs
        elif style == 'scream':
            eyes(ry + 2, 2, eye, socket=False)
            top, bot = ry + 4, ry + h - 2
            for y in range(top, bot + 1):
                t = (y - top) / max(1, bot - top)
                half = int(round(1 + (w // 2 - 1.5) * math.sin(t * math.pi)))
                for x in range(cx - half, cx + half):
                    P(x, y, DARK)
                if half >= 2:
                    P(cx - half, y, (205, 196, 160)); P(cx + half - 1, y, (205, 196, 160))
        elif style == 'stalker':
            y = ry + int(h * 0.45)
            for x in range(rx, rx + w):
                P(x, y, (8, 8, 10))
            for side in (-1, 1):
                ex = cx + side * 2 - (1 if side < 0 else 0)
                P(ex, y, (235, 235, 255), True); P(ex + side, y, (200, 200, 230), True)
        elif style == 'overlord':
            ey = ry + int(h * 0.4)
            for x in range(rx + 1, rx + w - 1):
                P(x, ey - 1, shade(self.get(x, ey - 1), 0.45))
            for side in (-1, 1):
                ex = cx + side * 2 - (1 if side < 0 else 0)
                P(ex, ey, (255, 40, 20), True); P(ex + side, ey, (255, 120, 40), True)
            y = ry + int(h * 0.72)
            for x in range(cx - 3, cx + 3):
                P(x, y, DARK); P(x, y + 1, DARK)
                if x % 2 == 0:
                    P(x, y, (230, 220, 190))
            P(cx - 3, y + 2, (230, 220, 190)); P(cx + 2, y + 2, (230, 220, 190))
        elif style == 'child':
            ey = ry + int(h * 0.45)
            for side in (-1, 1):
                ex = cx + side * 2 - (1 if side < 0 else 0)
                P(ex, ey, (230, 230, 220)); P(ex + side, ey, (230, 230, 220))
                P(ex, ey, eye, True)
            mouth(ry + int(h * 0.75), cx - 1, cx, teeth=True)
            self.splatter(rx, ry + h // 2, w, h - h // 2, 2, 1.0)
        elif style == 'alpha':
            eyes(ry + int(h * 0.42), 2, (255, 40, 30))
            for k in range(4):  # cicatrice
                P(cx - 3 + k, ry + 1 + k, (60, 20, 20))
            mouth(ry + int(h * 0.72), cx - 2, cx + 1)
        elif style == 'observer':
            ey = ry + int(h * 0.42)
            for side in (-1, 1):
                ex = cx + side * 2 - (1 if side < 0 else 0)
                P(ex, ey, (255, 255, 255), True); P(ex, ey + 1, (230, 230, 255), True)
        elif style == 'corpse':
            ey = ry + int(h * 0.4)
            for side in (-1, 1):
                ex = cx + side * 2 - (1 if side < 0 else 0)
                P(ex, ey, DARK); P(ex + side, ey, DARK)
            mouth(ry + int(h * 0.7), cx - 1, cx, teeth=True, depth=2)
        elif style == 'helmet':
            pass
        elif style == 'teddy':
            P(cx - 1, ry + 1, DARK); P(cx, ry + 1, DARK); P(cx, ry + 2, (90, 60, 40))


# ------------------------------------------------------------- empaquetage UV
def pack(boxes, W=128):
    x = y = rowh = 0
    for b in boxes:
        bw, bh = (2 * b.d + 2 * b.w) * b.k, (b.d + b.h) * b.k
        if x + bw > W:
            x, y, rowh = 0, y + rowh, 0
        b.uv = (x, y)
        x += bw
        rowh = max(rowh, bh)
    H = y + rowh
    size = 32
    while size < H:
        size *= 2
    return W, size


def face_rects(b):
    u, v = b.uv
    w, h, d = b.w * b.k, b.h * b.k, b.d * b.k
    return {
        'up': (u + d, v, w, d),
        'down': (u + d + w, v, w, d),
        'west': (u, v + d, d, h),
        'north': (u + d, v + d, w, h),
        'east': (u + d + w, v + d, d, h),
        'south': (u + 2 * d + w, v + d, w, h),
    }


def build(model, eye=(255, 210, 60), W=128):
    allb = [b for p in PARTS for b in model.boxes_of(p)]
    # tri par hauteur pour un meilleur empaquetage
    order = sorted(allb, key=lambda b: -(b.d + b.h))
    W, H = pack(order, W)
    if H > 256:
        W, H = pack(order, 256)
    pt = Painter(W, H, zlib.crc32(model.name.encode()))
    for b in allb:
        for fname, (rx, ry, w, h) in face_rects(b).items():
            if w <= 0 or h <= 0:
                continue
            pt.fill(rx, ry, w, h, b.faces.get(fname, b.mat), fname)
        if b.face:
            rx, ry, w, h = face_rects(b)['north']
            pt.face(rx, ry, w, h, b.face, eye)
        if b.top:
            rx, ry, w, h = face_rects(b)['up']
            pt.face(rx, ry, w, h, b.top, eye)
    models = []
    for p in PARTS:
        px, py, pz = PIVOTS[p]
        entry = {
            'part': p, 'id': 'c_' + p, 'invertAxis': 'xy',
            'translate': [-px, -py, -pz],
            'boxes': [box_json(b) for b in model.parts[p] if isinstance(b, Box)],
        }
        subs = [sub_json(i) for i in model.parts[p] if isinstance(i, Sub)]
        if subs:
            entry['submodels'] = subs
        models.append(entry)
    if model.anims:
        models[2]['animations'] = [dict(model.anims)]
    jem = {'texture': f'textures/entity/za/{model.name}.png', 'textureSize': [W, H], 'models': models}
    return jem, pt


def r(v):
    v = round(v, 3)
    return int(v) if v == int(v) else v
