package za.modeles;

import net.minecraftforge.fml.common.Mod;

@Mod("za_modeles")
public class ZAModeles {
    public ZAModeles() {
    }
}
