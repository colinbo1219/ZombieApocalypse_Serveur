#!/usr/bin/env python3
# za_modeles 1.4.0 « horreur » : part du jar DÉPLOYÉ 1.3.0 et :
#  - remplace les 16 zombies de base par ceux de build.py (peintre retravaillé : peau marbrée, ecchymoses, veines,
#    plaies, sang séché qui coule, crasse vers le bas, orbites creuses, bouches déchirées)
#  - passe « horreur » sur les 15 peaux humaines : orbites noires, pupilles laiteuses qui luisent dans le noir
#    (texture _e), larme de sang, bouche arrachée, joue ouverte, morsure au cou, veines, coulures, crasse aux jambes
#  - animations : cou qui craque d'un coup sur le côté, morsure (tête projetée en avant à l'attaque), recul quand
#    il prend un coup, bras qui s'agitent en mourant ; humains : même chose + regard fixe quand il est immobile
#  - sons des nouvelles capacités (za_modeles:zombie.*)
# Usage : python3 build.py sortie_build && python3 extension_1_4.py <za_modeles-1.3.0.jar> sortie_build <sortie.jar>
import io, json, os, random, sys, zipfile
from PIL import Image

SRC, BUILD, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
zin = zipfile.ZipFile(SRC)
files = {n: zin.read(n) for n in zin.namelist() if not n.endswith('/')}

CEM = 'assets/minecraft/optifine/cem/'
TEX = 'assets/minecraft/textures/entity/za/'
HUM = TEX + 'humains/'

# ---------------------------------------------------------------- 1. zombies de base régénérés
for d, prefixe in ((os.path.join(BUILD, 'assets/minecraft/optifine/cem'), CEM),
                   (os.path.join(BUILD, 'assets/minecraft/textures/entity/za'), TEX)):
    for n in sorted(os.listdir(d)):
        if n in ('zombie.properties', 'zombie.jem'):
            continue          # les règles de noms 1.2/1.3 du jar restent la référence
        if n.endswith('.jem') or n.endswith('.png'):
            files[prefixe + n] = open(os.path.join(d, n), 'rb').read()

# ---------------------------------------------------------------- 2. passe « horreur » des peaux humaines 64x64
BAS_FACES = (16, 32, 48, 64)                  # bas des rangées de faces de la peau
JAMBES = [(0, 20, 16, 32), (16, 52, 32, 64), (0, 36, 16, 48), (0, 52, 16, 64)]
SANG, SANG2, NOIR = (100, 14, 16), (62, 10, 12), (16, 10, 10)


def peau(c):
    r, g, b = c[:3]
    return g > r + 6 and g >= b - 4 and 55 < g < 190


def sang(c):
    r, g, b = c[:3]
    return r > 80 and r > g * 1.7 and r > b * 1.7


def mixc(a, b, t):
    return tuple(int(a[i] * (1 - t) + b[i] * t) for i in range(3))


def horreur(nom, data):
    rnd = random.Random('horreur-' + nom)
    im = Image.open(io.BytesIO(data)).convert('RGBA')
    px = im.load()
    emi = Image.new('RGBA', im.size, (0, 0, 0, 0))
    epx = emi.load()
    brule = 'brule' in nom
    oeil = (255, 150, 50) if brule else (222, 216, 160)

    def P(x, y, c):
        if px[x, y][3]:
            px[x, y] = tuple(c[:3]) + (255,)

    # peau : teinte cadavre, marbrures, veines
    for y in range(64):
        for x in range(64):
            c = px[x, y]
            if c[3] and peau(c):
                t = mixc(c, (96, 104, 92), 0.25)
                if rnd.random() < 0.07:
                    t = mixc(t, (70, 46, 78), 0.45)
                px[x, y] = t + (255,)
    for _ in range(26):
        x, y = rnd.randrange(64), rnd.randrange(8, 64)
        for _k in range(rnd.randint(3, 6)):
            if 0 <= x < 64 and 0 <= y < 64 and px[x, y][3] and peau(px[x, y]):
                px[x, y] = mixc(px[x, y], (58, 40, 66), 0.5) + (255,)
            x += rnd.choice((-1, 0, 1)); y += rnd.choice((0, 1))

    # visage (face avant de la tête : x 8-15, y 8-15 ; yeux rangée 12, bouche 14-15)
    for x in (9, 10, 13, 14):
        P(x, 11, NOIR)
        P(x, 13, mixc(px[x, 13], NOIR, 0.6))
    for x in (9, 14):
        P(x, 12, (24, 14, 14))
    for x in (10, 13):                        # pupilles qui fixent le centre, luisent la nuit
        P(x, 12, oeil)
        epx[x, 12] = oeil + (255,)
    P(10, 13, SANG); P(10, 14, SANG2)         # larme de sang
    P(10, 14, (188, 176, 132)); P(11, 14, NOIR); P(12, 14, (176, 164, 120)); P(13, 14, NOIR)
    for x in (10, 11, 12, 13):
        P(x, 15, (34, 8, 8))
    P(11, 15, SANG)
    P(14, 14, (124, 28, 30)); P(14, 15, (86, 18, 20)); P(14, 13, (170, 160, 124))   # joue arrachée, dents
    # morsure au cou (haut du torse, devant)
    for (x, y, c) in ((20, 20, NOIR), (21, 20, (128, 30, 32)), (22, 20, (150, 44, 44)), (23, 20, NOIR),
                      (21, 21, (110, 22, 24)), (22, 21, NOIR), (22, 22, SANG), (22, 23, SANG2)):
        P(x, y, c)

    # coulures : le sang existant descend
    graines = [(x, y) for y in range(64) for x in range(64) if px[x, y][3] and sang(px[x, y])]
    for (x, y) in graines:
        if rnd.random() < 0.45:
            for d in range(1, rnd.randint(2, 5)):
                yy = y + d
                if yy >= 64 or yy in BAS_FACES or not px[x, yy][3]:
                    break
                P(x, yy, SANG2 if d > 1 else SANG)

    # crasse au bas des jambes
    for (x0, y0, x1, y1) in JAMBES:
        for y in range(y1 - 4, y1):
            k = (y - (y1 - 4) + 1) / 4
            for x in range(x0, x1):
                if px[x, y][3]:
                    px[x, y] = mixc(px[x, y], (56, 42, 28), 0.3 * k) + (255,)

    out = io.BytesIO(); im.save(out, 'PNG')
    oute = io.BytesIO(); emi.save(oute, 'PNG')
    return out.getvalue(), oute.getvalue()


for n in sorted(files):
    if n.startswith(HUM) and n.endswith('.png') and not n.endswith('_e.png'):
        files[n], files[n[:-4] + '_e.png'] = horreur(os.path.basename(n)[:-4], files[n])

# ---------------------------------------------------------------- 3. animations
SW = 'sin(swing_progress*pi)'
CRAQUE = 'if(frac((age+id*23)/300) < 0.025, if(sin(id*3.1) > 0, 0.7, -0.7), 0)'   # cou qui craque d'un coup


def ajoute(a, cle, terme, defaut):
    a[cle] = '(' + a.get(cle, defaut) + ') + ' + terme


def renforcer(a, humain):
    ajoute(a, 'head.ry', CRAQUE, 'head.ry')
    if 'head.tz' not in a:
        a['head.tz'] = f'-{SW}*1.6'                                   # morsure : la tête part en avant
    ajoute(a, 'head.rx', f'{SW}*0.25', 'head.rx')
    ajoute(a, 'body.rz', 'sin(hurt_time*1.3)*hurt_time*0.02', '0')    # recul quand il est touché
    for bras in ('right_arm', 'left_arm'):
        if bras + '.rz' not in a:
            a[bras + '.rz'] = f'if(death_time > 0, sin(death_time*1.7+{0 if bras[0] == "r" else 2})*0.5, {bras}.rz)'
    if humain:
        # immobile : il fixe le joueur, puis se remet à balancer la tête
        a['head.rz'] = '(' + a.get('head.rz', '0') + ') * clamp(limb_speed*6 + 0.25, 0, 1)'


for n in sorted(files):
    if not (n.startswith(CEM) and n.endswith('.jem')) or n.endswith('/zombie.jem'):
        continue
    j = json.loads(files[n])
    tex = j.get('texture', '')
    if any(k in tex for k in ('crawler', 'fakedead', 'observer')):
        continue          # rampant, faux mort, observateur : postures à part
    humain = 'humains' in tex
    for m in j['models']:
        if m.get('animations'):
            a = dict(m['animations'][0])
            renforcer(a, humain)
            m['animations'] = [a]
    files[n] = json.dumps(j, indent=1).encode()

# ---------------------------------------------------------------- 4. sons des capacités (événements vanilla)


def ev(nom, p=1.0, v=1.0):
    return {"name": "minecraft:" + nom, "type": "event", "pitch": p, "volume": v}


SONS = {
    "zombie.agrippe": ([ev("entity.zombie.attack_iron_door", 0.6, 0.6), ev("entity.player.hurt_sweet_berry_bush", 0.5)],
                       "Des mains t'agrippent"),
    "zombie.cou": ([ev("entity.skeleton.hurt", 0.5, 0.8), ev("block.bone_block.break", 0.6)], "Un craquement d'os"),
    "zombie.charge": ([ev("entity.ravager.roar", 0.9, 0.9), ev("entity.hoglin.attack", 0.6)], "Quelque chose charge"),
    "zombie.chuchote": ([ev("entity.warden.nearby_close", 1.6, 0.5), ev("ambient.cave", 1.4, 0.4)], "Un murmure tout près"),
}
sons = json.loads(files['assets/za_modeles/sounds.json'])
langs = {n: json.loads(files[n]) for n in files if n.startswith('assets/za_modeles/lang/')}
for cle, (liste, sous) in SONS.items():
    sons[cle] = {"subtitle": "subtitles.za_modeles." + cle, "sounds": liste}
    for n, d in langs.items():
        d["subtitles.za_modeles." + cle] = sous
files['assets/za_modeles/sounds.json'] = json.dumps(sons, indent=1, ensure_ascii=False).encode('utf-8')
for n, d in langs.items():
    files[n] = json.dumps(d, indent=1, ensure_ascii=False).encode('utf-8')

# ---------------------------------------------------------------- version
toml = files['META-INF/mods.toml'].decode('utf-8').replace('version="1.3.0"', 'version="1.4.0"')
files['META-INF/mods.toml'] = toml.encode('utf-8')
if 'META-INF/MANIFEST.MF' in files:
    files['META-INF/MANIFEST.MF'] = files['META-INF/MANIFEST.MF'].replace(b'1.3.0', b'1.4.0')

with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED) as z:
    for n in sorted(files, key=lambda k: (not k.startswith('META-INF/MANIFEST'), k)):
        z.writestr(zipfile.ZipInfo(n, (1980, 1, 1, 0, 0, 0)), files[n], zipfile.ZIP_DEFLATED)
print('OK', OUT, len(files), 'fichiers')
