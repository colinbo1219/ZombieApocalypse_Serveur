import json, os, shutil, sys
from zagen_lib import build
from zamodels import M, EYES, NAMES

OUT = sys.argv[1] if len(sys.argv) > 1 else 'out'
A = os.path.join(OUT, 'assets', 'minecraft')
CEM = os.path.join(A, 'optifine', 'cem')
TEX = os.path.join(A, 'textures', 'entity', 'za')
shutil.rmtree(OUT, ignore_errors=True)
os.makedirs(CEM); os.makedirs(TEX)

# modele principal = zombie vanilla (template officiel), texture vanilla
VANILLA = {"textureSize": [64, 64], "models": [
    {"part": "head", "id": "head", "invertAxis": "xy", "translate": [0, -24, 0], "boxes": [{"coordinates": [-4, 24, -4, 8, 8, 8], "textureOffset": [0, 0]}]},
    {"part": "headwear", "id": "headwear", "invertAxis": "xy", "translate": [0, -24, 0], "boxes": [{"coordinates": [-4, 24, -4, 8, 8, 8], "textureOffset": [32, 0], "sizeAdd": 0.5}]},
    {"part": "body", "id": "body", "invertAxis": "xy", "translate": [0, -24, 0], "boxes": [{"coordinates": [-4, 12, -2, 8, 12, 4], "textureOffset": [16, 16]}]},
    {"part": "left_arm", "id": "left_arm", "invertAxis": "xy", "translate": [5, -22, 0], "mirrorTexture": "u", "boxes": [{"coordinates": [-8, 12, -2, 4, 12, 4], "textureOffset": [40, 16]}]},
    {"part": "right_arm", "id": "right_arm", "invertAxis": "xy", "translate": [-5, -22, 0], "boxes": [{"coordinates": [4, 12, -2, 4, 12, 4], "textureOffset": [40, 16]}]},
    {"part": "left_leg", "id": "left_leg", "invertAxis": "xy", "translate": [1.9, -12, 0], "mirrorTexture": "u", "boxes": [{"coordinates": [-4, 0, -2, 4, 12, 4], "textureOffset": [0, 16]}]},
    {"part": "right_leg", "id": "right_leg", "invertAxis": "xy", "translate": [-1.9, -12, 0], "boxes": [{"coordinates": [0, 0, -2, 4, 12, 4], "textureOffset": [0, 16]}]}]}
json.dump(VANILLA, open(os.path.join(CEM, 'zombie.jem'), 'w'), indent=1)

def propesc(v):
    # format .properties: backslash double, non-ASCII en \uXXXX
    v = v.replace('\\', '\\\\')
    return ''.join(c if ord(c) < 128 else '\\u%04x' % ord(c) for c in v)


props = ['# ZombieApocalypse : un modele par zombie MythicMobs, choisi selon son nom',
         '# (le nom affiche par MythicMobs, sans les couleurs)']
for idx, (display, key) in enumerate(NAMES, start=1):
    jem, pt = build(M[key], EYES[key])
    num = idx + 1  # zombie2.jem ... zombie17.jem
    json.dump(jem, open(os.path.join(CEM, f'zombie{num}.jem'), 'w'), indent=1)
    pt.img.save(os.path.join(TEX, f'{key}.png'))
    if pt.has_emissive:
        pt.emi.save(os.path.join(TEX, f'{key}_e.png'))
    props += ['', f'# {key}', f'models.{idx}={num}', f'name.{idx}=' + propesc(display)]
    print(key, jem['textureSize'], 'emissive' if pt.has_emissive else '')
open(os.path.join(CEM, 'zombie.properties'), 'w', encoding='ascii').write('\n'.join(props) + '\n')

os.makedirs(os.path.join(A, 'optifine'), exist_ok=True)
open(os.path.join(A, 'optifine', 'emissive.properties'), 'w').write('suffix.emissive=_e\n')
json.dump({"pack": {"description": "ZombieApocalypse - modeles des zombies", "pack_format": 15}},
          open(os.path.join(OUT, 'pack.mcmeta'), 'w'), indent=1)
print('ok ->', OUT)
