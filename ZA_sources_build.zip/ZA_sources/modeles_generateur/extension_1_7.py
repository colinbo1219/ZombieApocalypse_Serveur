#!/usr/bin/env python3
# za_modeles 1.7.0 « boss et états » : part du jar 1.6.0 et ajoute
#  - les 4 BOSS RÉGIONAUX (zamodels_boss.py) : modèles et textures uniques, règles de nom
#  - les VARIANTS MUTÉS de l'évolution du virus (Shambler/Runner/Spitter mutés, Colosse) : modèle du type de base,
#    peau mutée (veines cramoisies qui luisent)
#  - les ÉTATS des zombies humains (ETF, tirage par entité) : 1 décomposé (actuel), 2 FRAIS (vient de mourir : peau
#    encore rosée, peu de sang), 3 TRÈS DÉCOMPOSÉ (verdâtre, os apparents), 4 MUTILÉ (œil crevé, brûlure, morsure)
#  - les voix de l'évolution du virus (voix_generer.py, clés lea_evo_*)
# Usage : python3 voix_generer.py <modèles Piper> <ogg> && python3 extension_1_7.py <1.6.0.jar> <ogg> <sortie.jar>
import io, json, os, random, sys, zipfile
from PIL import Image

import zagen_lib as L
import zamodels_boss as ZB
from voix_generer import VOIX

SRC, OGG, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
zin = zipfile.ZipFile(SRC)
files = {n: zin.read(n) for n in zin.namelist() if not n.endswith('/')}
CEM = 'assets/minecraft/optifine/cem/'
TEX = 'assets/minecraft/textures/entity/za/'
HUM = TEX + 'humains/'
RND = 'assets/minecraft/optifine/random/entity/za/humains/'


def png(im):
    b = io.BytesIO(); im.save(b, 'PNG'); return b.getvalue()


def ouvrir(n):
    return Image.open(io.BytesIO(files[n])).convert('RGBA')


def peau(c):
    r, g, b = c[:3]
    return g > r + 4 and 50 < g < 200


def mix(a, b, t):
    return tuple(int(a[i] * (1 - t) + b[i] * t) for i in range(3))


# ---------------------------------------------------------------- 1. états des humains (ETF)
def etat(im, e, rnd):
    im = im.copy(); px = im.load(); W, H = im.size
    for y in range(64):
        for x in range(W):
            c = px[x, y]
            if not c[3]:
                continue
            if e == 2:        # frais : la peau reprend une teinte humaine, le sang pâlit à peine
                if peau(c):
                    px[x, y] = mix(c, (176, 140, 124), 0.45) + (255,)
            elif e == 3:      # très décomposé : vert-gris, taches sombres, os
                if peau(c):
                    t = mix(c, (74, 92, 60), 0.4)
                    if rnd.random() < 0.08:
                        t = (206, 196, 164)           # os qui perce
                    elif rnd.random() < 0.12:
                        t = mix(t, (30, 24, 20), 0.5)
                    px[x, y] = t + (255,)
    if e == 4:                # mutilé : œil crevé, brûlure sur un côté, morsure au bras
        for (x, y, col) in ((13, 12, (60, 6, 8)), (14, 12, (40, 4, 6)), (13, 13, (100, 12, 14)), (13, 14, (80, 10, 12)),
                            (13, 11, (40, 4, 6))):
            px[x, y] = col + (255,)
        for y in range(8, 16):                   # brûlure sur la joue droite (face est de la tête : 16-23)
            for x in range(16, 20):
                if rnd.random() < 0.7:
                    px[x, y] = mix(px[x, y], (38, 24, 18), 0.7) + (255,)
        for (x, y) in ((44, 22), (45, 22), (44, 23), (46, 23), (45, 24)):   # morsure, bras droit
            px[x, y] = (120, 24, 26, 255)
    return im


def etat_emissif(ime, e):
    im = ime.copy(); px = im.load()
    if e == 4:                                    # l'œil crevé ne luit plus
        px[13, 12] = (0, 0, 0, 0)
    if e == 2:                                    # le frais a encore les yeux presque humains : lueur faible
        for y in range(im.size[1]):
            for x in range(im.size[0]):
                r, g, b, a = px[x, y]
                if a:
                    px[x, y] = (r // 2, g // 2, b // 2, a)
    return im


etats = 0
for n in sorted(list(files)):
    if n.startswith(HUM) and n.endswith('.png') and not n.endswith('_e.png'):
        base = os.path.basename(n)[:-4]
        if base == 'z_gagnon':
            continue                              # Mme Gagnon reste elle-même
        rnd = random.Random('etat-' + base)
        im = ouvrir(n)
        e_nom = n[:-4] + '_e.png'
        for e in (2, 3, 4):
            files[RND + '%s%d.png' % (base, e)] = png(etat(im, e, rnd))
            if e_nom in files:
                files[RND + '%s%d_e.png' % (base, e)] = png(etat_emissif(ouvrir(e_nom), e))
        files[RND + base + '.properties'] = ('# états du zombie (tirage par entité) : 1 décomposé, 2 frais, 3 très décomposé, 4 mutilé\n'
                                            'textures.1=1 2 3 4\nweights.1=35 20 25 20\n').encode()
        etats += 1


# ---------------------------------------------------------------- 2. peaux mutées
def mutee(im, rnd, sombre=False):
    im = im.copy(); px = im.load(); W, H = im.size
    emi = Image.new('RGBA', im.size, (0, 0, 0, 0)); epx = emi.load()
    for y in range(H):
        for x in range(W):
            c = px[x, y]
            if c[3]:
                t = mix(c, (96, 20, 30), 0.25)
                if sombre:
                    t = mix(t, (20, 16, 18), 0.35)
                px[x, y] = t + (255,)
    for _ in range((W * H) // 60):              # veines cramoisies qui luisent
        x, y = rnd.randrange(W), rnd.randrange(H)
        for _k in range(rnd.randint(3, 7)):
            if 0 <= x < W and 0 <= y < H and px[x, y][3]:
                px[x, y] = (200, 30, 40, 255); epx[x, y] = (200, 30, 40, 255)
            x += rnd.choice((-1, 0, 1)); y += rnd.choice((0, 1))
    return im, emi


MUTES = [  # (clé, jem de base, texture de base, règle de nom)
    ('shambler_mute', 'zombie6.jem', 'shambler', r'regex:(§.)*Shambler\smut.'),
    ('runner_mute', 'zombie7.jem', 'runner', r'regex:(§.)*Runner\smut.'),
    ('spitter_mute', 'zombie9.jem', 'spitter', r'regex:(§.)*Spitter\smut.'),
    ('colosse', 'zombie12.jem', 'brute', r'regex:(§.)*Colosse'),
]

# ---------------------------------------------------------------- 3. modèles : boss + mutés, règles de nom en tête
props = files[CEM + 'zombie.properties'].decode('utf-8').rstrip('\n').split('\n')
num_modele = max(int(n[len(CEM) + 6:-4]) for n in files if n.startswith(CEM + 'zombie') and n[len(CEM) + 6:-4].isdigit())
nouvelles = []


def propesc(v):
    v = v.replace('\\', '\\\\')
    return ''.join(c if ord(c) < 128 else '\\u%04x' % ord(c) for c in v)


for (regle, cle) in ZB.NOMS_BOSS:
    jem, pt = L.build(ZB.M[cle], ZB.EYES[cle])
    num_modele += 1
    files[CEM + 'zombie%d.jem' % num_modele] = json.dumps(jem, indent=1).encode()
    files[TEX + cle + '.png'] = png(pt.img)
    if pt.has_emissive:
        files[TEX + cle + '_e.png'] = png(pt.emi)
    nouvelles.append((num_modele, regle, cle))
for (cle, jem_base, tex_base, regle) in MUTES:
    rnd = random.Random('mute-' + cle)
    im, emi = mutee(ouvrir(TEX + tex_base + '.png'), rnd, sombre=(cle == 'colosse'))
    files[TEX + cle + '.png'] = png(im)
    files[TEX + cle + '_e.png'] = png(emi)
    j = json.loads(files[CEM + jem_base])
    j['texture'] = 'textures/entity/za/%s.png' % cle
    num_modele += 1
    files[CEM + 'zombie%d.jem' % num_modele] = json.dumps(j, indent=1).encode()
    nouvelles.append((num_modele, regle, cle))

# anciennes règles renumérotées après les nouvelles (la première règle qui correspond l'emporte)
entete = [l for l in props if l.startswith('#') and not l.startswith('# ') or l.startswith('# ZombieApocalypse') or l.startswith('# (le nom')]
regles, cur = [], {}
for l in props:
    if l.startswith('models.') or l.startswith('name.'):
        k, v = l.split('=', 1)
        typ, idx = k.split('.')
        cur.setdefault(int(idx), {})[typ] = v
anciennes = [cur[i] for i in sorted(cur)]
out = ['# ZombieApocalypse : un modele par zombie MythicMobs, choisi selon son nom', '# 1.7.0 : boss regionaux et mutes en tete']
i = 0
for (num, regle, cle) in nouvelles:
    i += 1
    out += ['', '# %s' % cle, 'models.%d=%d' % (i, num), 'name.%d=%s' % (i, propesc(regle))]
for r in anciennes:
    i += 1
    out += ['', 'models.%d=%s' % (i, r['models']), 'name.%d=%s' % (i, r['name'])]
files[CEM + 'zombie.properties'] = ('\n'.join(out) + '\n').encode('utf-8')

# ---------------------------------------------------------------- 4. voix (toutes les clés de voix_generer.py)
sons = json.loads(files['assets/za_modeles/sounds.json'])
langs = {n: json.loads(files[n]) for n in files if n.startswith('assets/za_modeles/lang/')}
for cle, (v, texte) in VOIX.items():
    chemin = os.path.join(OGG, cle + '.ogg')
    if not os.path.exists(chemin):
        continue
    files['assets/za_modeles/sounds/voix/%s.ogg' % cle] = open(chemin, 'rb').read()
    sons['voix.' + cle] = {"subtitle": "subtitles.za_modeles.voix." + cle,
                           "sounds": [{"name": "za_modeles:voix/" + cle, "stream": True, "attenuation_distance": 24}]}
    for n, d in langs.items():
        d["subtitles.za_modeles.voix." + cle] = ('Léa (radio)' if v == 'siwis' else 'Voix') + ' : ' + texte[:60]
files['assets/za_modeles/sounds.json'] = json.dumps(sons, indent=1, ensure_ascii=False).encode('utf-8')
for n, d in langs.items():
    files[n] = json.dumps(d, indent=1, ensure_ascii=False).encode('utf-8')

toml = files['META-INF/mods.toml'].decode('utf-8').replace('version="1.6.0"', 'version="1.7.0"')
files['META-INF/mods.toml'] = toml.encode('utf-8')
if 'META-INF/MANIFEST.MF' in files:
    files['META-INF/MANIFEST.MF'] = files['META-INF/MANIFEST.MF'].replace(b'1.6.0', b'1.7.0')
with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED) as z:
    for n in sorted(files, key=lambda k: (not k.startswith('META-INF/MANIFEST'), k)):
        z.writestr(zipfile.ZipInfo(n, (1980, 1, 1, 0, 0, 0)), files[n], zipfile.ZIP_DEFLATED)
print('OK', OUT, '— boss', len(ZB.NOMS_BOSS), '— mutés', len(MUTES), '— états', etats, 'peaux humaines')
