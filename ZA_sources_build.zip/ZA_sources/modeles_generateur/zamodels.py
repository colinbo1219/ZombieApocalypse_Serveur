# Definitions des 16 zombies ZombieApocalypse (coordonnees JEM, voir zagen_lib.py)
# Animations: expressions EMF/OptiFine CEM. Rappels (verifies en jeu):
#  - "head.rx" etc. = partie vanilla (pivot vanilla). Lire la valeur vanilla puis l'additionner marche.
#  - rx positif: l'avant descend (tete qui regarde en bas / bas du corps qui recule)
#  - ty des parties vanilla: espace modele (y vers le bas): tete 0, corps 0, bras 2, jambes 12
#  - sous-modeles (S): pivot + boites en coordonnees JEM absolues; animer avec des valeurs absolues
#  - swing_progress = attaque, ou "swingarm" lance par un skill MythicMobs (crachat, cri, saut...)
from zagen_lib import Box as B, Sub as S, Model

M = {}
EYES = {}


def model(name, eye=(255, 210, 60)):
    m = Model(name)
    M[name] = m
    EYES[name] = eye
    return m


# ---- petits morceaux d'expressions pour les animations
W = 'limb_swing*0.6662'          # phase de marche
SW = 'sin(swing_progress*pi)'    # 0 -> 1 -> 0 pendant une attaque (ou un "swingarm" MythicMobs)


def twitch(period, amp, speed=3):
    """petit spasme regulier (desynchronise par zombie avec id)"""
    return f'if(frac((age+id*7)/{period}) < 0.05, sin(age*{speed})*{amp}, 0)'


def dying(expr, limp='0.3'):
    """quand il meurt, le membre retombe"""
    return f'if(death_time > 0, {limp}, {expr})'


def breathe(m, amp=0.4, speed=0.1, extra=''):
    b = f'sin(age*{speed}+id)*{amp}{extra}'
    m.anims.update({'head.ty': b, 'body.ty': b, 'right_arm.ty': f'2 + {b}', 'left_arm.ty': f'2 + {b}'})


FLINCH = ' - hurt_time*0.05'     # recul de la tete quand il prend un coup

# 1. SHAMBLER - le zombie de base: chemise dechiree, bras gauche arrache. Boite, tete penchee, spasmes.
m = model('shambler', (255, 214, 64))
m.add('head', B(-4, 24, -5, 8, 8, 8, 'rot', face='zombie'),
      B(-4, 31, -5, 8, 1, 3, 'hair'))
m.add('body', B(-4, 12, -2, 8, 12, 4, 'shirt'),
      B(-2, 15, -2.6, 4, 5, 1, 'flesh'),                 # plaie ouverte
      B(-3, 10, -2.2, 2, 3, 1, 'shirt'))                 # lambeau
m.add('right_arm', B(4, 12, -2, 4, 12, 4, 'rot'))
m.add('left_arm', B(-8, 17, -2, 4, 7, 4, 'shirt'),
      B(-7, 14, -1, 2, 3, 2, 'bone'), B(-7.5, 16, -1.5, 3, 1, 3, 'flesh'))
m.add('right_leg', B(0, 0, -2, 4, 12, 4, 'jeans'))
m.add('left_leg', B(-4, 0, -2, 4, 12, 4, 'jeans'))
m.anims.update({
    'head.rx': 'head.rx + 0.15' + FLINCH,
    'head.rz': f'0.22 + sin(age*0.05+id)*0.06 + {twitch(90, 0.3)}',
    'body.rz': f'sin({W})*0.1*limb_speed + sin(age*0.04+id)*0.03',
    'right_leg.rx': f'cos({W})*1.2*limb_speed',
    'left_leg.rx': f'cos({W}+pi)*0.45*limb_speed',          # la jambe qui traine
    'right_arm.rx': dying('right_arm.rx + sin(age*0.07+id)*0.1'),
    'left_arm.rx': dying('left_arm.rx + 0.4 + sin(age*0.07+id+1)*0.1'),
})

# 2. RUNNER - maigre, capuche rouge. Court penche vers l'avant, bras en arriere.
m = model('runner', (255, 230, 40))
m.add('head', B(-3.5, 24, -3.5, 7, 8, 7, 'pale', face='runner'),
      B(-4, 31, -4, 8, 1, 8, 'hoodie_red'), B(-4.5, 24, -3, 1, 8, 7, 'hoodie_red'),
      B(3.5, 24, -3, 1, 8, 7, 'hoodie_red'), B(-4, 24, 3.5, 8, 7, 1, 'hoodie_red'))
m.add('body', B(-3.5, 12, -1.5, 7, 12, 3, 'hoodie_red'),
      B(-2, 16, -1.9, 3, 4, 1, 'bone'))                   # cotes a l'air
m.add('right_arm', B(3.5, 8, -1.5, 3, 16, 3, 'pale'),
      B(3.5, 6, -1.5, 1, 2, 1, 'bone'), B(5.5, 6, -1.5, 1, 2, 1, 'bone'))
m.add('left_arm', B(-6.5, 8, -1.5, 3, 16, 3, 'pale'),
      B(-6.5, 6, -1.5, 1, 2, 1, 'bone'), B(-4.5, 6, -1.5, 1, 2, 1, 'bone'))
m.add('right_leg', B(0.5, 0, -1.5, 3, 12, 3, 'jeans_dark'))
m.add('left_leg', B(-3.5, 0, -1.5, 3, 12, 3, 'jeans_dark'))
K = 'clamp(limb_speed*1.6, 0, 1)'   # 0 = immobile, 1 = pleine course
m.anims.update({
    'body.rx': f'0.4*{K}',
    'right_leg.tz': f'0.1 + 12*sin(0.4*{K})', 'left_leg.tz': f'0.1 + 12*sin(0.4*{K})',
    'right_leg.ty': f'12*cos(0.4*{K})', 'left_leg.ty': f'12*cos(0.4*{K})',
    'right_leg.rx': f'cos({W})*1.7*limb_speed', 'left_leg.rx': f'cos({W}+pi)*1.7*limb_speed',
    'head.rx': f'head.rx - 0.4*{K}' + FLINCH,
    'head.ry': f'head.ry + {twitch(60, 0.3)}',
    'right_arm.rx': dying(f'lerp({K}, right_arm.rx, 0.9 + cos({W}+pi)*0.9*limb_speed)'),
    'left_arm.rx': dying(f'lerp({K}, left_arm.rx, 0.9 + cos({W})*0.9*limb_speed)'),
})

# 3. CRAWLER - rampe au sol, sans jambes (c'est un "bebe": tout est dessine 2x plus gros)
#    Se tire avec les bras, la tete suit le joueur, le moignon traine.
m = model('crawler', (255, 190, 50))
m.add('body',
      B(-11, 0, -16, 22, 11, 30, 'shirt'),              # torse couche
      S('c_head', (0, 9, -18),
        B(-9, 3, -35, 18, 17, 19, 'rot', face='zombie')),  # tete relevee
      S('c_arm_l', (-17, 4, -12),
        B(-21, 0, -41, 8, 7, 30, 'rot'), B(-21, 0, -45, 8, 4, 4, 'bone')),
      S('c_arm_r', (17, 4, -12),
        B(13, 0, -41, 8, 7, 30, 'rot'), B(13, 0, -45, 8, 4, 4, 'bone')),
      S('c_tail', (0, 3, 14),
        B(-9, 0, 14, 10, 8, 13, 'jeans'),               # moignon de jambe
        B(3, 1, 14, 5, 5, 7, 'bone'),                   # os de l'autre jambe
        B(-3, 0, 14, 5, 3, 19, 'gut')))                 # tripes qui trainent
CW = 'limb_swing*0.9'
m.anims.update({
    'body.ry': f'sin({CW})*limb_speed*0.3',
    'c_arm_l.ry': f'cos({CW})*0.45*limb_speed',
    'c_arm_l.rx': f'-max(0, sin({CW}))*0.35*limb_speed - {SW}*0.6',
    'c_arm_r.ry': f'cos({CW}+pi)*0.45*limb_speed',
    'c_arm_r.rx': f'-max(0, sin({CW}+pi))*0.35*limb_speed - {SW}*0.6',
    'c_head.ry': 'clamp(torad(head_yaw), -1, 1)*0.6',
    'c_head.rx': f'clamp(torad(head_pitch), -0.6, 0.6)*0.5 - {SW}*0.5 + sin(age*0.1+id)*0.05 - hurt_time*0.04',
    'c_tail.ry': f'-sin({CW})*limb_speed*0.45 + sin(age*0.05+id)*0.05',
})

# 4. SPITTER - machoire decrochee, sac d'acide vert qui brille. Le sac palpite; il crache la tete en avant.
m = model('spitter', (170, 255, 60))
m.add('head', B(-4, 25, -5, 8, 7, 8, 'rot', face='spitter'),
      S('s_jaw', (0, 25, 0.5),
        B(-3.5, 20, -5.5, 7, 5, 6, 'rot', face='jaw'),
        B(-1, 17, -5.2, 1, 3, 1, 'acid'), B(1, 18, -5.2, 1, 2, 1, 'acid')))
m.add('body', B(-4, 12, -2, 8, 12, 4, 'gown'),
      S('s_sac', (0, 20, -3.5), B(-3, 17, -5, 6, 6, 3, 'acid_sac')),
      B(3, 22, -1, 3, 3, 3, 'pustule'), B(-6, 21, 0, 3, 3, 3, 'pustule'), B(-2, 13, 1.5, 3, 3, 1, 'pustule'))
m.add('right_arm', B(4, 12, -2, 4, 12, 4, 'rot'), B(7, 16, -1, 2, 2, 2, 'pustule'))
m.add('left_arm', B(-8, 12, -2, 4, 12, 4, 'rot'))
m.add('right_leg', B(0, 0, -2, 4, 12, 4, 'pants_brown'))
m.add('left_leg', B(-4, 0, -2, 4, 12, 4, 'pants_brown'))
SAC = f'1 + sin(age*0.25+id)*0.12 - {SW}*0.35'
m.anims.update({
    's_jaw.rx': f'0.12 + sin(age*0.12+id)*0.08 + {SW}*0.7',
    's_sac.sx': SAC, 's_sac.sy': SAC, 's_sac.sz': SAC,
    'head.rx': f'head.rx + {SW}*0.35' + FLINCH,
    'head.tz': f'-{SW}*2.5',
    'head.rz': 'sin(age*0.09+id)*0.08',
    'body.rx': f'{SW}*0.15',
    'right_arm.rx': dying('right_arm.rx'), 'left_arm.rx': dying('left_arm.rx'),
})

# 5. BLOATER - ventre enorme plein de pustules. Le ventre respire; en mourant il gonfle.
m = model('bloater', (220, 255, 80))
m.add('head', B(-3, 23, -4.5, 6, 6, 6, 'bloat_skin', face='bloater'))
m.add('body', S('b_belly', (0, 16, -0.5),
                B(-7, 8, -6, 14, 16, 11, 'bloat_skin'),
                B(-5, 15, -7, 3, 3, 1, 'pustule'), B(2, 11, -7, 4, 4, 1, 'pustule'), B(0, 19, -7, 2, 2, 1, 'pustule'),
                B(-7.5, 12, -2, 1, 3, 3, 'pustule'), B(6.5, 17, 0, 1, 4, 4, 'pustule'), B(-3, 20, 5, 5, 3, 1, 'pustule')))
m.add('right_arm', B(7, 11, -2.5, 5, 13, 5, 'bloat_skin'))
m.add('left_arm', B(-12, 11, -2.5, 5, 13, 5, 'bloat_skin'))
m.add('right_leg', B(0, 0, -3, 5, 10, 6, 'bloat_skin'))
m.add('left_leg', B(-5, 0, -3, 5, 10, 6, 'bloat_skin'))
BELLY = '1 + sin(age*0.12+id)*0.04 + clamp(death_time/14, 0, 1)*0.5'
m.anims.update({
    'b_belly.sx': BELLY, 'b_belly.sy': BELLY, 'b_belly.sz': BELLY,
    'body.rz': f'sin({W})*0.12*limb_speed',
    'head.ty': 'sin(age*0.12+id)*0.4',
    'head.rz': f'sin({W})*0.1*limb_speed',
    'head.rx': 'head.rx' + FLINCH,
    'right_arm.rx': dying(f'right_arm.rx + 0.5 + cos({W})*0.2*limb_speed'),
    'left_arm.rx': dying(f'left_arm.rx + 0.5 + cos({W}+pi)*0.2*limb_speed'),
})

# 6. LEAPER - muscles a vif, griffes, gueule allongee. Accroupi, renifle, bondit griffes en avant.
m = model('leaper', (255, 150, 20))
m.add('head', B(-3.5, 23, -7, 7, 7, 9, 'muscle', face='leaper'),
      B(-1, 30, -4, 2, 2, 6, 'bone'))
m.add('body', B(-4, 12, -2, 8, 12, 5, 'muscle'),
      B(-1, 22, 3, 2, 2, 2, 'bone'), B(-1, 18, 3, 2, 2, 2, 'bone'), B(-1, 14, 3, 2, 2, 2, 'bone'))
m.add('right_arm', B(4, 6, -1.5, 3, 18, 3, 'muscle'),
      B(4, 3, -1.5, 1, 3, 1, 'bone'), B(6, 3, -1.5, 1, 3, 1, 'bone'), B(5, 3, 0.5, 1, 3, 1, 'bone'))
m.add('left_arm', B(-7, 6, -1.5, 3, 18, 3, 'muscle'),
      B(-7, 3, -1.5, 1, 3, 1, 'bone'), B(-5, 3, -1.5, 1, 3, 1, 'bone'), B(-6, 3, 0.5, 1, 3, 1, 'bone'))
m.add('right_leg', B(0, 4, -2.5, 4, 8, 5, 'muscle'), B(0.5, 0, -1.5, 3, 4, 3, 'rot'),
      B(0.5, 0, -3.5, 1, 1, 2, 'bone'), B(2.5, 0, -3.5, 1, 1, 2, 'bone'))
m.add('left_leg', B(-4, 4, -2.5, 4, 8, 5, 'muscle'), B(-3.5, 0, -1.5, 3, 4, 3, 'rot'),
      B(-3.5, 0, -3.5, 1, 1, 2, 'bone'), B(-1.5, 0, -3.5, 1, 1, 2, 'bone'))
breathe(m, amp=0.6, speed=0.18, extra=' + 1.5')     # accroupi qui "pompe"
m.anims.update({
    'head.ry': 'head.ry + sin(age*0.8+id)*0.05',
    'head.rx': f'head.rx - {SW}*0.3' + FLINCH,
    'body.rx': f'{SW}*0.3',
    'right_arm.rz': 'right_arm.rz + if(is_aggressive, 0.3, 0.1)',
    'left_arm.rz': 'left_arm.rz - if(is_aggressive, 0.3, 0.1)',
    'right_arm.rx': dying(f'right_arm.rx - {SW}*0.7'),
    'left_arm.rx': dying(f'left_arm.rx - {SW}*0.7'),
    'right_leg.rx': f'cos({W})*1.6*limb_speed', 'left_leg.rx': f'cos({W}+pi)*1.6*limb_speed',
})

# 7. BRUTE - colosse. Pas lourds qui balancent, respiration, coup de marteau a deux poings.
m = model('brute', (255, 60, 30))
m.add('head', B(-4, 27, -7, 8, 8, 8, 'brute_skin', face='brute'))
m.add('body', B(-8, 12, -4, 16, 16, 8, 'brute_skin'),
      B(-6, 22, 4, 12, 7, 3, 'brute_skin'),
      B(-4, 27, 6, 2, 4, 2, 'bone'), B(2, 27, 6, 2, 4, 2, 'bone'), B(-1, 24, 7, 2, 3, 2, 'bone'),
      B(-8, 8, -4, 16, 4, 8, 'pants_brown'))
m.add('right_arm', B(8, 6, -3.5, 7, 20, 7, 'brute_skin'), B(7.5, 1, -4, 8, 6, 8, 'brute_skin'))
m.add('left_arm', B(-15, 6, -3.5, 7, 20, 7, 'brute_skin'), B(-15.5, 1, -4, 8, 6, 8, 'brute_skin'))
m.add('right_leg', B(0, 0, -3.5, 6, 12, 7, 'pants_brown'))
m.add('left_leg', B(-6, 0, -3.5, 6, 12, 7, 'pants_brown'))
breathe(m, amp=0.45, speed=0.08)
m.anims.update({
    'body.rz': f'sin({W})*0.09*limb_speed',
    'body.rx': f'{SW}*0.25',
    'head.rz': f'-sin({W})*0.06*limb_speed',
    'head.rx': 'head.rx - hurt_time*0.02',
    'right_arm.rx': dying(f'right_arm.rx - {SW}*1.5 + cos({W})*0.3*limb_speed'),
    'left_arm.rx': dying(f'left_arm.rx - {SW}*1.5 + cos({W}+pi)*0.3*limb_speed'),
})

# 8. SCREAMER - tete allongee, bouche geante. Tremble; pour crier: tete en arriere, bras ouverts.
m = model('screamer', (240, 240, 255))
m.add('head', B(-3, 26, -3.5, 6, 11, 7, 'pale', face='scream'),
      B(-1.5, 23, -1.5, 3, 3, 3, 'pale'))
m.add('body', B(-3.5, 12, -1.5, 7, 12, 3, 'gown'), B(-4, 7, -2, 8, 5, 4, 'gown'))
m.add('right_arm', B(3.5, 7, -1, 3, 17, 3, 'pale'))
m.add('left_arm', B(-6.5, 7, -1, 3, 17, 3, 'pale'))
m.add('right_leg', B(0.5, 0, -1.5, 3, 12, 3, 'pale'))
m.add('left_leg', B(-3.5, 0, -1.5, 3, 12, 3, 'pale'))
m.anims.update({
    'head.rx': f'head.rx - {SW}*0.9' + FLINCH,
    'head.rz': f'sin(age*1.7+id)*0.05*(1 - {SW})',
    'body.rx': f'-{SW}*0.2',
    'body.rz': 'sin(age*1.3+id)*0.02',
    'right_arm.rx': dying(f'right_arm.rx*(1 - {SW})'),
    'left_arm.rx': dying(f'left_arm.rx*(1 - {SW})'),
    'right_arm.rz': f'right_arm.rz + {SW}*1.3',
    'left_arm.rz': f'left_arm.rz - {SW}*1.3',
})

# 9. STALKER - grand, maigre, cape noire. Tete qui penche lentement, bras qui pendent, les leve pour attaquer.
m = model('stalker', (235, 235, 255))
m.add('head', B(-3.5, 28, -3.5, 7, 8, 7, 'dark_skin', face='stalker'),
      B(-4, 35.5, -4, 8, 1, 8, 'black_cloth'), B(-4.5, 28, -3, 1, 8, 7, 'black_cloth'),
      B(3.5, 28, -3, 1, 8, 7, 'black_cloth'), B(-4, 27, 3.5, 8, 9, 1, 'black_cloth'))
m.add('body', B(-3.5, 14, -2, 7, 14, 4, 'black_cloth'), B(-4, 4, -2.5, 8, 10, 5, 'black_cloth'))
m.add('right_arm', B(3.5, 4, -1.5, 3, 22, 3, 'dark_skin'),
      B(3.5, 1, -1.5, 1, 3, 1, 'bone'), B(5.5, 1, -1.5, 1, 3, 1, 'bone'))
m.add('left_arm', B(-6.5, 4, -1.5, 3, 22, 3, 'dark_skin'),
      B(-6.5, 1, -1.5, 1, 3, 1, 'bone'), B(-4.5, 1, -1.5, 1, 3, 1, 'bone'))
m.add('right_leg', B(0.5, 0, -1.5, 3, 14, 3, 'dark_skin'))
m.add('left_leg', B(-3.5, 0, -1.5, 3, 14, 3, 'dark_skin'))
m.anims.update({
    'head.rz': f'sin(age*0.03+id)*0.35 + {twitch(70, 0.4)}',
    'head.rx': 'head.rx - 0.15' + FLINCH,
    'body.rx': '0.15',
    'right_arm.rx': dying(f'if(is_aggressive, right_arm.rx - 0.2, cos({W}+pi)*0.6*limb_speed + 0.05)', '0'),
    'left_arm.rx': dying(f'if(is_aggressive, left_arm.rx - 0.2, cos({W})*0.6*limb_speed + 0.05)', '0'),
    'right_arm.rz': 'if(is_aggressive, right_arm.rz, 0.06 + sin(age*0.05+id)*0.03)',
    'left_arm.rz': 'if(is_aggressive, left_arm.rz, -0.06 - sin(age*0.05+id)*0.03)',
})

# 10. OVERLORD - le boss: geant, couronne d'os, coeur rouge qui bat, cape de chair qui flotte.
m = model('overlord', (255, 40, 20))
m.add('head', B(-4.5, 30, -6, 9, 9, 9, 'overlord_skin', face='overlord'),
      B(-4, 39, -5, 1, 4, 1, 'bone'), B(-1.5, 39, -5.5, 1, 5, 1, 'bone'), B(0.5, 39, -5.5, 1, 5, 1, 'bone'),
      B(3, 39, -5, 1, 4, 1, 'bone'), B(-3, 39, 1, 1, 3, 1, 'bone'), B(2, 39, 1, 1, 3, 1, 'bone'))
m.add('body', B(-9, 12, -5, 18, 20, 10, 'overlord_skin'),
      S('o_core', (0, 24.5, -5.1), B(-2.5, 22, -5.6, 5, 5, 1, 'core_glow')),
      B(-13, 28, -5, 6, 4, 10, 'metal_dark'), B(7, 28, -5, 6, 4, 10, 'metal_dark'),
      S('o_cape', (0, 32, 5.5), B(-8, 6, 5, 16, 26, 1, 'cape')),
      B(-9, 6, -5, 18, 6, 10, 'black_cloth'))
m.add('right_arm', B(9, 0, -4, 8, 26, 8, 'overlord_skin'),
      B(9, -2, -4, 2, 2, 2, 'bone'), B(15, -2, -4, 2, 2, 2, 'bone'), B(12, -2, -4, 2, 2, 2, 'bone'))
m.add('left_arm', B(-17, 0, -4, 8, 26, 8, 'overlord_skin'),
      B(-17, -2, -4, 2, 2, 2, 'bone'), B(-11, -2, -4, 2, 2, 2, 'bone'), B(-14, -2, -4, 2, 2, 2, 'bone'))
m.add('right_leg', B(0.5, 0, -4, 7, 12, 8, 'black_cloth'))
m.add('left_leg', B(-7.5, 0, -4, 7, 12, 8, 'black_cloth'))
breathe(m, amp=0.5, speed=0.07)
CORE = '1 + max(0, sin(age*0.35))*0.25'   # battement de coeur
m.anims.update({
    'o_core.sx': CORE, 'o_core.sy': CORE, 'o_core.sz': CORE,
    'o_cape.rx': '0.05 + limb_speed*0.35 + sin(age*0.08+id)*0.04',
    'body.rz': f'sin({W})*0.07*limb_speed',
    'body.rx': f'-{SW}*0.15',
    'head.rx': f'head.rx - {SW}*0.6 - hurt_time*0.02',
    'right_arm.rx': dying(f'right_arm.rx - {SW}*1.6 + cos({W})*0.25*limb_speed'),
    'left_arm.rx': dying(f'left_arm.rx - {SW}*1.6 + cos({W}+pi)*0.25*limb_speed'),
})

# 11. ENFANT INFECTE - pyjama jaune, cheveux en bataille, ourson qui pend. Sautille, tete penchee.
m = model('child', (255, 255, 120))
m.add('head', B(-4, 24, -4, 8, 8, 8, 'child_skin', face='child'),
      B(-4.5, 30, -4.5, 9, 3, 9, 'hair_blond'), B(-4.5, 26, 2.5, 9, 4, 2, 'hair_blond'))
m.add('body', B(-4, 12, -2, 8, 12, 4, 'pajama'))
m.add('right_arm', B(4, 12, -2, 4, 12, 4, 'pajama'),
      S('t_teddy', (6, 11, -1.5),
        B(4.5, 5, -3, 3, 4, 3, 'teddy'), B(5, 9, -2.5, 2, 2, 2, 'teddy', face='teddy')))
m.add('left_arm', B(-8, 12, -2, 4, 12, 4, 'pajama'))
m.add('right_leg', B(0, 0, -2, 4, 12, 4, 'pajama'))
m.add('left_leg', B(-4, 0, -2, 4, 12, 4, 'pajama'))
HOP = f'abs(sin({W}))*1.6*limb_speed'
m.anims.update({
    'head.ty': f'-{HOP}', 'body.ty': f'-{HOP}', 'right_arm.ty': f'2 - {HOP}', 'left_arm.ty': f'2 - {HOP}',
    'right_leg.ty': f'12 - {HOP}', 'left_leg.ty': f'12 - {HOP}',
    'head.rz': '0.3*sin(age*0.04+id)',
    'head.rx': 'head.rx' + FLINCH,
    't_teddy.rx': '-right_arm.rx + sin(age*0.15+id)*0.15',
    'right_arm.rx': dying('right_arm.rx'), 'left_arm.rx': dying('left_arm.rx'),
})

# 12. ALPHA - chef de meute. Epaules qui roulent; rugit (tete en arriere, bras ouverts) pour booster la meute.
m = model('alpha', (255, 40, 30))
m.add('head', B(-4, 24, -4.5, 8, 8, 8, 'alpha_skin', face='alpha'),
      B(-0.5, 32, -3, 1, 2, 6, 'bone'))
m.add('body', B(-5, 12, -2.5, 10, 13, 5, 'military'),
      B(-7, 24, -1, 2, 4, 2, 'bone'), B(5, 24, -1, 2, 4, 2, 'bone'),
      B(-6.5, 26, -0.5, 1, 3, 1, 'bone'), B(5.5, 26, -0.5, 1, 3, 1, 'bone'),
      B(-1, 20, 2.5, 2, 3, 2, 'bone'), B(-1, 15, 2.5, 2, 3, 2, 'bone'))
m.add('right_arm', B(5, 10, -2.5, 5, 14, 5, 'alpha_skin'),
      B(5, 8, -2.5, 1, 2, 1, 'bone'), B(9, 8, -2.5, 1, 2, 1, 'bone'), B(7, 8, -2.5, 1, 2, 1, 'bone'))
m.add('left_arm', B(-10, 10, -2.5, 5, 14, 5, 'alpha_skin'),
      B(-10, 8, -2.5, 1, 2, 1, 'bone'), B(-6, 8, -2.5, 1, 2, 1, 'bone'), B(-8, 8, -2.5, 1, 2, 1, 'bone'))
m.add('right_leg', B(0, 0, -2.5, 5, 12, 5, 'military'))
m.add('left_leg', B(-5, 0, -2.5, 5, 12, 5, 'military'))
breathe(m, amp=0.4, speed=0.12)
m.anims.update({
    'body.ry': f'sin({W})*0.12*limb_speed',
    'body.rx': f'-{SW}*0.2',
    'head.rx': f'head.rx - {SW}*0.8' + FLINCH,
    'right_arm.rx': dying(f'right_arm.rx*(1 - {SW}*0.8)'),
    'left_arm.rx': dying(f'left_arm.rx*(1 - {SW}*0.8)'),
    'right_arm.rz': f'right_arm.rz + {SW}*1.0',
    'left_arm.rz': f'left_arm.rz - {SW}*1.0',
})

# 13. ZOMBIE BLINDE - equipement SWAT. Marche raide, tete qui bouge peu.
m = model('armored', (255, 214, 64))
m.add('head', B(-4, 24, -4, 8, 8, 8, 'rot', face='zombie'),
      B(-4.5, 28, -4.5, 9, 5, 9, 'metal_dark'), B(-4, 26, -5, 8, 3, 1, 'visor'))
m.add('body', B(-4.5, 13, -2.5, 9, 11, 5, 'kevlar'), B(-4, 12, -2, 8, 1, 4, 'kevlar'),
      B(-7, 21, -2.5, 3, 3, 5, 'metal_dark'), B(4, 21, -2.5, 3, 3, 5, 'metal_dark'),
      B(-3, 15, -3, 2, 3, 1, 'metal_dark'), B(1, 15, -3, 2, 3, 1, 'metal_dark'))
m.add('right_arm', B(4, 12, -2, 4, 12, 4, 'kevlar'), B(4, 12, -2.5, 4, 3, 1, 'rot'))
m.add('left_arm', B(-8, 12, -2, 4, 12, 4, 'kevlar'), B(-8, 12, -2.5, 4, 3, 1, 'rot'))
m.add('right_leg', B(0, 0, -2, 4, 12, 4, 'black_cloth'), B(0, 4, -2.8, 4, 3, 1, 'metal_dark'))
m.add('left_leg', B(-4, 0, -2, 4, 12, 4, 'black_cloth'), B(-4, 4, -2.8, 4, 3, 1, 'metal_dark'))
breathe(m, amp=0.25, speed=0.1)
m.anims.update({
    'head.ry': 'head.ry*0.6',
    'head.rx': 'head.rx*0.6' + FLINCH,
    'right_leg.rx': f'cos({W})*1.0*limb_speed', 'left_leg.rx': f'cos({W}+pi)*1.0*limb_speed',
    'right_arm.rx': dying(f'right_arm.rx + cos({W})*0.15*limb_speed'),
    'left_arm.rx': dying(f'left_arm.rx + cos({W}+pi)*0.15*limb_speed'),
})

# 14. ZOMBIE A BOUCLIER - bouclier anti-emeute POLICE. Bras caches derriere; coup de bouclier en attaque.
m = model('shielded', (255, 214, 64))
m.add('head', B(-4, 24, -4, 8, 8, 8, 'grey', face='zombie'),
      B(-4.5, 29, -4.5, 9, 4, 9, 'metal_dark'))
m.add('body', B(-4, 12, -2, 8, 12, 4, 'kevlar'),
      B(-8, 3, -8, 16, 25, 1, 'riot_shield', hires=2),
      B(-1, 14, -7, 2, 2, 1, 'metal_dark'))
m.add('right_arm', B(4, 12, -2, 4, 12, 4, 'kevlar'))
m.add('left_arm', B(-8, 12, -2, 4, 12, 4, 'kevlar'))
m.add('right_leg', B(0, 0, -2, 4, 12, 4, 'jeans_dark'))
m.add('left_leg', B(-4, 0, -2, 4, 12, 4, 'jeans_dark'))
BASH = f'-{SW}*3'
m.anims.update({
    'right_arm.rx': f'-0.45 - {SW}*0.3', 'left_arm.rx': '-0.45',
    'right_arm.ry': '0', 'left_arm.ry': '0',
    'body.tz': BASH, 'right_arm.tz': BASH, 'left_arm.tz': BASH,
    'body.rx': f'-{SW}*0.1',
    'body.ty': f'abs(sin({W}))*0.6*limb_speed',
    'head.rx': 'head.rx' + FLINCH,
})

# 15. FAUX MORT - cadavre couche sur le dos. La tete se tourne vers toi, la main a des spasmes.
m = model('fakedead', (255, 214, 64))
m.add('body',
      B(-4, 0, -6, 8, 4, 12, 'shirt'),
      S('fd_head', (0, 4, -6), B(-4, 0, -14, 8, 8, 8, 'rot', top='corpse')),
      B(-9, 0, -5, 4, 3, 11, 'rot'),
      S('fd_arm', (7, 1.5, 3), B(5, 0, -8, 4, 3, 11, 'rot')),
      B(-4, 0, 6, 4, 4, 12, 'jeans'), B(0.5, 0, 6, 4, 4, 11, 'jeans'),
      B(-10, -0.9, -16, 20, 1, 30, 'blood'))
m.anims.update({
    'body.rx': '0', 'body.ry': '0',
    'fd_head.rz': 'clamp(torad(head_yaw), -1.2, 1.2)*0.6',
    'fd_arm.ry': twitch(100, 0.25, 5),
})

# 16. OBSERVATEUR "???" - silhouette noire immobile. Tete qui penche, "bug" et disparait une fraction de seconde.
m = model('observer', (255, 255, 255))
m.add('head', B(-3.5, 34, -3.5, 7, 9, 7, 'shadow', face='observer'))
m.add('body', B(-3.5, 18, -2, 7, 16, 4, 'shadow'))
m.add('right_arm', B(3.5, 4, -1.5, 3, 28, 3, 'shadow'))
m.add('left_arm', B(-6.5, 4, -1.5, 3, 28, 3, 'shadow'))
m.add('right_leg', B(0.5, 0, -1.5, 3, 18, 3, 'shadow'))
m.add('left_leg', B(-3.5, 0, -1.5, 3, 18, 3, 'shadow'))
m.anims.update({
    'right_arm.rx': '0', 'left_arm.rx': '0', 'right_arm.rz': '0', 'left_arm.rz': '0',
    'right_leg.rx': '0', 'left_leg.rx': '0',
    'head.rz': 'sin(age*0.02+id)*0.25',
    'varb.hide': 'frac((age+id*5)/53) < 0.025',
    'head.visible': '!varb.hide', 'body.visible': '!varb.hide',
    'right_arm.visible': '!varb.hide', 'left_arm.visible': '!varb.hide',
    'right_leg.visible': '!varb.hide', 'left_leg.visible': '!varb.hide',
})

# Noms MythicMobs (Display, sans couleurs) -> modele
NAMES = [
    # (regle ETF "name", modele). Pas d'espace (ETF coupe les valeurs sur les espaces) ni d'accent.
    # (§.)* = codes couleur eventuels devant le nom. Le plus specifique d'abord, "Zombie" en dernier.
    (r'regex:(§.)*Undead\sOverlord', 'overlord'),
    (r'regex:(§.)*Enfant\sinfect.', 'child'),
    (r'regex:(§.)*Zombie\sblind.', 'armored'),
    (r'regex:(§.)*Zombie\s.\sbouclier', 'shielded'),
    (r'regex:(§.)*Shambler', 'shambler'), (r'regex:(§.)*Runner', 'runner'),
    (r'regex:(§.)*Crawler', 'crawler'), (r'regex:(§.)*Spitter', 'spitter'),
    (r'regex:(§.)*Bloater', 'bloater'), (r'regex:(§.)*Leaper', 'leaper'),
    (r'regex:(§.)*Brute', 'brute'), (r'regex:(§.)*Screamer', 'screamer'),
    (r'regex:(§.)*Stalker', 'stalker'), (r'regex:(§.)*Alpha', 'alpha'),
    (r'regex:(§.)*\?\?\?', 'observer'),
    (r'regex:(§.)*Zombie', 'fakedead'),
]
