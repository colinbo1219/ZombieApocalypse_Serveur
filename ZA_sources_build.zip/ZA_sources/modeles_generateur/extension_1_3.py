#!/usr/bin/env python3
# za_modeles 1.3.0 : part du jar DÉPLOYÉ 1.2.0 (le générateur zamodels.py est plus ancien que lui) et ajoute :
#  - 6 zombies par métier / lieu : policier, médecin, ouvrier, ouvrier brûlé, pompier, prisonnier (textures générées
#    à partir des citoyens infectés, mêmes modèles humains, animations enrichies)
#  - animations des humains infectés : regard qui balaie quand il est immobile, tic de la tête rare, boiterie
#  - identité sonore par type (sons « za_modeles:zombie.* » qui réutilisent des événements vanilla, hauteurs choisies)
# Usage : python3 extension_1_3.py <za_modeles-1.2.0.jar> <sortie.jar>     (Pillow requis)
import io, json, random, sys, zipfile
from PIL import Image

SRC, OUT = sys.argv[1], sys.argv[2]
zin = zipfile.ZipFile(SRC)
files = {n: zin.read(n) for n in zin.namelist() if not n.endswith('/')}

HUM = 'assets/minecraft/textures/entity/za/humains/'
CEM = 'assets/minecraft/optifine/cem/'

# ---------------------------------------------------------------- textures (disposition de peau joueur 64x64)
# zones de vêtements : haut (torse + bras, calques inclus) et bas (jambes, calques inclus)
HAUT = [(16, 16, 40, 32), (16, 32, 40, 48), (40, 16, 56, 32), (40, 32, 56, 48), (32, 48, 48, 64), (48, 48, 64, 64)]
BAS = [(0, 16, 16, 32), (0, 32, 16, 48), (16, 48, 32, 64), (0, 48, 16, 64)]


def dans(x, y, zones):
    return any(a <= x < c and b <= y < d for a, b, c, d in zones)


def peau(r, g, b):
    # peau de zombie : verdâtre
    return g > r + 8 and g >= b and g > 70


def sang(r, g, b):
    return r > 90 and r > g * 1.6 and r > b * 1.6


def recolorer(im, zones, coul):
    px = im.load()
    lums = []
    for y in range(64):
        for x in range(64):
            r, g, b, a = px[x, y]
            if a and dans(x, y, zones) and not peau(r, g, b) and not sang(r, g, b):
                lums.append((r + g + b) / 3)
    moy = max(1.0, sum(lums) / len(lums)) if lums else 1.0
    for y in range(64):
        for x in range(64):
            r, g, b, a = px[x, y]
            if a and dans(x, y, zones) and not peau(r, g, b) and not sang(r, g, b):
                k = max(0.8, min(1.15, ((r + g + b) / 3) / moy))
                px[x, y] = (min(255, int(coul[0] * k)), min(255, int(coul[1] * k)), min(255, int(coul[2] * k)), a)


def pose(im, pts, coul):
    px = im.load()
    for x, y in pts:
        if px[x, y][3]:
            px[x, y] = coul + (255,)


def rang(y, xs):
    return [(x, y) for x in xs]


# faces visibles du torse (avant 20-27, côtés 16-19 / 28-31, dos 32-39) et des bras
TORSE_X = list(range(16, 40))
BRAS_D_X = list(range(40, 56))
BRAS_G_X = list(range(32, 48))


def chapeau(im, coul, bande=None):
    """Couvre-chef sur le calque de chapeau (haut + 3 premières rangées des côtés)."""
    px = im.load()
    for y in range(0, 8):
        for x in range(40, 48):
            px[x, y] = coul + (255,)
    for y in range(8, 11):
        for x in range(32, 64):
            c = bande if (bande and y == 10) else coul
            px[x, y] = c + (255,)


def taches(im, n, rnd):
    px = im.load()
    for _ in range(n):
        x, y = rnd.randrange(16, 40), rnd.randrange(20, 32)
        if px[x, y][3]:
            px[x, y] = (110 + rnd.randrange(40), 10, 10, 255)


def texture(base, metier):
    rnd = random.Random(metier)
    im = Image.open(io.BytesIO(files[HUM + base])).convert('RGBA')
    if metier == 'policier':
        recolorer(im, HAUT, (34, 44, 78))
        recolorer(im, BAS, (28, 28, 36))
        pose(im, [(21, 22), (22, 22), (21, 23)], (212, 175, 55))            # insigne
        pose(im, rang(31, range(20, 28)), (18, 18, 20))                      # ceinturon
        pose(im, [(23, 31), (24, 31)], (190, 190, 190))                      # boucle
        pose(im, rang(20, range(44, 48)) + rang(52, range(36, 40)), (212, 175, 55))  # écussons d'épaule
        chapeau(im, (30, 38, 66), bande=(20, 20, 24))
    elif metier == 'medecin':
        recolorer(im, HAUT, (226, 226, 220))
        recolorer(im, BAS, (62, 122, 132))
        pose(im, [(21, 20), (21, 21), (22, 22), (23, 23), (24, 23), (25, 22), (26, 21), (26, 20), (24, 24)], (40, 40, 44))  # stéthoscope
        pose(im, [(26, 23), (27, 23)], (60, 100, 190))                       # porte-nom
        taches(im, 7, rnd)
    elif metier in ('ouvrier', 'brule'):
        recolorer(im, HAUT, (236, 118, 22))
        recolorer(im, BAS, (48, 68, 108))
        for y in (25, 28):
            pose(im, rang(y, TORSE_X), (205, 205, 200))
        pose(im, rang(27, BRAS_D_X) + rang(59, BRAS_G_X), (205, 205, 200))
        chapeau(im, (232, 200, 32))
    elif metier == 'pompier':
        recolorer(im, HAUT, (52, 50, 40))
        recolorer(im, BAS, (48, 46, 38))
        for y in (26, 27):
            pose(im, rang(y, TORSE_X), (232, 212, 40))
        pose(im, rang(28, TORSE_X), (200, 200, 200))
        pose(im, rang(28, BRAS_D_X) + rang(60, BRAS_G_X), (232, 212, 40))
        pose(im, rang(44, range(0, 16)) + rang(60, range(16, 32)), (232, 212, 40))   # bandes des jambes
        chapeau(im, (22, 22, 22), bande=(22, 22, 22))
        pose(im, [(42, 9), (43, 9), (42, 10), (43, 10)], (200, 40, 30))     # écusson du casque
    elif metier == 'prisonnier':
        recolorer(im, HAUT, (222, 110, 30))
        recolorer(im, BAS, (222, 110, 30))
        pose(im, [(34, 22), (35, 22), (37, 22), (34, 23), (36, 23), (37, 23)], (20, 20, 20))  # numéro au dos
    if metier == 'brule':
        px = im.load()
        for y in range(64):
            for x in range(64):
                r, g, b, a = px[x, y]
                if a:
                    if rnd.random() < 0.05:
                        px[x, y] = (255, 110 + rnd.randrange(60), 20, a)     # braises
                    else:
                        px[x, y] = (int(r * 0.33) + 8, int(g * 0.28) + 6, int(b * 0.25) + 5, a)
    out = io.BytesIO()
    im.save(out, 'PNG')
    return out.getvalue()


# ---------------------------------------------------------------- modèles et règles de noms

NOUVEAUX = [
    # (id, texture de base, règle de nom ETF/EMF)
    ('policier', 'z_citoyen1.png', r'regex:(§.)*Policier\sinfect.*'),
    ('medecin', 'z_citoyen1.png', r'regex:(§.)*M.decin\sinfect.*'),
    ('ouvrier', 'z_citoyen3.png', r'regex:(§.)*Ouvrier\sinfect.*'),
    ('brule', 'z_citoyen3.png', r'regex:(§.)*Ouvrier\sbr.l.*'),
    ('pompier', 'z_citoyen1.png', r'regex:(§.)*Pompier\sinfect.*'),
    ('prisonnier', 'z_citoyen1.png', r'regex:(§.)*Prisonnier\sinfect.*'),
]

# animations des humains infectés (même langage que les modèles 1.2.0) : balayage du regard à l'arrêt, tic rare,
# boiterie (jambe droite raide), bras qui pendent.
ANIM_HUMAIN = {
    "head.rz": "sin(age*0.045 + id)*0.10 + 0.06 + if(frac((age+id*37)/420) < 0.03, sin(age*1.9)*0.45, 0)",
    "head.rx": "head.rx + 0.10 + if(frac((age+id*13)/90) < 0.04, sin(age*2.7)*0.25, 0)",
    "head.ry": "head.ry + if(limb_speed < 0.08, sin(age*0.021 + id)*0.55, 0)",
    "body.rz": "sin(limb_swing*0.6662)*0.07*limb_speed + 0.03",
    "right_leg.rx": "cos(limb_swing*0.6662)*0.55*limb_speed",
    "left_leg.rx": "cos(limb_swing*0.6662+pi)*1.25*limb_speed",
    "right_arm.rx": "if(death_time > 0, 0.3, right_arm.rx + sin(age*0.05+id)*0.06)",
    "left_arm.rx": "if(death_time > 0, 0.3, left_arm.rx + sin(age*0.05+id+1.7)*0.06)",
}


def jem_depuis(modele, tex):
    j = json.loads(files[CEM + modele])
    j['texture'] = 'textures/entity/za/humains/z_' + tex + '.png'
    for m in j['models']:
        if m.get('animations'):
            m['animations'] = [dict(ANIM_HUMAIN)]
    return json.dumps(j, indent=1).encode()


def propesc(v):
    # format .properties : barre oblique inverse doublée, non-ASCII en \\uXXXX (comme build.py)
    v = v.replace('\\', '\\\\')
    return ''.join(c if ord(c) < 128 else '\\u%04x' % ord(c) for c in v)


props = files[CEM + 'zombie.properties'].decode('utf-8').rstrip('\n').split('\n')
num_regle = max(int(l.split('=')[0].split('.')[1]) for l in props if l.startswith('models.'))
num_modele = max(int(n[len(CEM) + 6:-4]) for n in files if n.startswith(CEM + 'zombie') and n[len(CEM) + 6:-4].isdigit())
for ident, base, regle in NOUVEAUX:
    num_modele += 1
    num_regle += 1
    files[HUM + 'z_' + ident + '.png'] = texture(base, ident)
    files[CEM + 'zombie%d.jem' % num_modele] = jem_depuis('zombie24.jem', ident)
    props.append('models.%d=%d' % (num_regle, num_modele))
    props.append('name.%d=%s' % (num_regle, propesc(regle)))
files[CEM + 'zombie.properties'] = ('\n'.join(props) + '\n').encode('utf-8')

# citoyens, patients et soldats existants : mêmes animations enrichies
for n in ('zombie18.jem', 'zombie19.jem', 'zombie20.jem', 'zombie21.jem', 'zombie22.jem', 'zombie24.jem', 'zombie25.jem', 'zombie26.jem'):
    if CEM + n in files:
        j = json.loads(files[CEM + n])
        if 'humains' in j.get('texture', ''):
            for m in j['models']:
                if m.get('animations'):
                    m['animations'] = [dict(ANIM_HUMAIN)]
            files[CEM + n] = json.dumps(j, indent=1).encode()

# ---------------------------------------------------------------- sons : identité par type

def ev(nom, p=1.0, v=1.0):
    return {"name": "minecraft:" + nom, "type": "event", "pitch": p, "volume": v}


SONS = {
    "zombie.shambler.rale": ([ev("entity.zombie.ambient", 0.75), ev("entity.husk.ambient", 0.85)], "Râle traînant"),
    "zombie.runner.souffle": ([ev("entity.wolf.pant", 1.35, 0.9), ev("entity.player.breath", 1.6)], "Respiration rapide"),
    "zombie.runner.cri": ([ev("entity.zombie.ambient", 1.65), ev("entity.hoglin.angry", 1.5, 0.8)], "Cri court"),
    "zombie.crawler.rale": ([ev("entity.spider.ambient", 0.6, 0.7), ev("entity.zombie_villager.ambient", 0.5)], "Râle au ras du sol"),
    "zombie.spitter.gargouille": ([ev("entity.drowned.ambient", 0.7), ev("entity.slime.squish", 0.6)], "Gargouillement"),
    "zombie.bloater.souffle": ([ev("entity.polar_bear.ambient", 0.5), ev("entity.ravager.ambient", 0.6, 0.8)], "Respiration lourde"),
    "zombie.leaper.cri": ([ev("entity.zoglin.angry", 1.4), ev("entity.zombie.ambient", 1.4)], "Glapissement"),
    "zombie.brute.souffle": ([ev("entity.ravager.ambient", 0.8), ev("entity.iron_golem.hurt", 0.5, 0.6)], "Souffle de brute"),
    "zombie.screamer.cri": ([ev("entity.ghast.scream", 0.75, 1.2), ev("entity.ghast.hurt", 0.6, 1.2)], "Hurlement du Screamer"),
    "zombie.stalker.souffle": ([ev("entity.warden.sniff", 1.4, 0.25), ev("entity.player.breath", 0.6, 0.2)], "Quelque chose respire"),
    "zombie.alpha.grondement": ([ev("entity.ravager.roar", 0.5), ev("entity.warden.agitated", 0.7)], "Grondement de l'Alpha"),
    "zombie.armored.pas": ([ev("entity.iron_golem.step", 1.2, 0.7), ev("block.chain.step", 0.8)], "Pas métalliques"),
    "zombie.civil.rale": ([ev("entity.zombie_villager.ambient", 0.7), ev("entity.zombie.ambient", 0.65)], "Infecté qui gémit"),
    "zombie.mange": ([ev("entity.generic.eat", 0.55), ev("entity.player.burp", 0.4, 0.5)], "Quelque chose mange"),
    "zombie.porte": ([ev("entity.zombie.attack_wooden_door", 0.8)], "Coups contre une porte"),
}
sons = json.loads(files['assets/za_modeles/sounds.json'])
langs = {n: json.loads(files[n]) for n in files if n.startswith('assets/za_modeles/lang/')}
for cle, (liste, sous) in SONS.items():
    sons[cle] = {"subtitle": "subtitles.za_modeles." + cle, "sounds": liste}
    for n, d in langs.items():
        d["subtitles.za_modeles." + cle] = sous
files['assets/za_modeles/sounds.json'] = json.dumps(sons, indent=1, ensure_ascii=False).encode('utf-8')
for n, d in langs.items():
    files[n] = json.dumps(d, indent=1, ensure_ascii=False).encode('utf-8')

# ---------------------------------------------------------------- version
toml = files['META-INF/mods.toml'].decode('utf-8').replace('version="1.2.0"', 'version="1.3.0"')
files['META-INF/mods.toml'] = toml.encode('utf-8')
if 'META-INF/MANIFEST.MF' in files:
    files['META-INF/MANIFEST.MF'] = files['META-INF/MANIFEST.MF'].replace(b'1.2.0', b'1.3.0')

with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED) as z:
    for n in sorted(files, key=lambda k: (not k.startswith('META-INF/MANIFEST'), k)):
        z.writestr(n, files[n])
print('OK', OUT, len(files), 'fichiers ;', len(NOUVEAUX), 'nouveaux zombies ;', len(SONS), 'sons')
