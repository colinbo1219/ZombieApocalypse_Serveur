#!/usr/bin/env python3
# za_modeles 1.5.0 « silhouettes » : part du jar 1.4.0 et change la FORME des zombies humains (pas seulement la peau)
#  - mâchoire pendante (sous-modèle de la tête : elle ballotte, claque à l'attaque)
#  - côtes à l'air sur le torse, colonne vertébrale qui sort du dos
#  - bras gauche cassé : coupé au coude, l'avant-bras pend à l'envers, un os perce la peau
# Les peaux passent de 64x64 à 64x96 : les UV d'origine ne bougent pas, les nouvelles pièces sont peintes dans la bande
# 64-96. Coordonnées JEM comme zagen_lib : y vers le haut depuis les pieds, -z = devant (visage), boîtes absolues ;
# sous-modèle : translate = pivot absolu, boîtes relatives au pivot (même forme que le rampant, vérifié en jeu).
# Usage : python3 extension_1_5.py <za_modeles-1.4.0.jar> <sortie.jar>
import io, json, sys, zipfile
from PIL import Image

SRC, OUT = sys.argv[1], sys.argv[2]
zin = zipfile.ZipFile(SRC)
files = {n: zin.read(n) for n in zin.namelist() if not n.endswith('/')}
CEM = 'assets/minecraft/optifine/cem/'

OS, OS2 = (214, 204, 176), (180, 168, 136)
NOIR, CHAIR, CHAIR2, SANG2 = (30, 10, 10), (124, 28, 30), (92, 18, 20), (62, 10, 12)

# pièces par modèle (numéro du .jem) : m = mâchoire, c = côtes, v = vertèbres, b = bras cassé
PIECES = {
    19: 'cv',      # patient : blouse ouverte dans le dos
    20: 'm', 21: 'b', 22: 'c',             # soldats
    23: 'mv',      # Caporal Dumas
    24: 'm', 25: 'c', 26: 'b',             # citoyens
    27: 'b', 28: 'm', 29: 'c', 30: 'mc', 31: 'b', 32: 'mc',
}
# (Mme Gagnon, 18, reste reconnaissable : pas de nouvelle pièce)


def peindre(im):
    """Agrandit 64x64 -> 64x96 et peint les nouvelles pièces dans la bande du bas."""
    src = im.convert('RGBA')
    out = Image.new('RGBA', (64, 96), (0, 0, 0, 0))
    out.paste(src, (0, 0))
    px = out.load()
    peau = src.getpixel((8, 13))[:3]
    if sum(peau) < 60:
        peau = (70, 60, 50)
    sombre = tuple(int(v * 0.7) for v in peau)

    def rect(x, y, w, h, c):
        for j in range(h):
            for i in range(w):
                cc = c(i, j) if callable(c) else c
                px[x + i, y + j] = tuple(cc) + (255,)

    # mâchoire 6x2x4 à (0,64) : dessus (4,64) intérieur de la bouche, dessous (10,64), côtés, avant = dents
    rect(4, 64, 6, 4, lambda i, j: CHAIR2 if (i + j) % 3 else NOIR)
    rect(10, 64, 6, 4, sombre)
    rect(0, 68, 4, 2, peau)
    rect(10, 68, 4, 2, peau)
    rect(4, 68, 6, 2, lambda i, j: (OS if i % 2 == 0 else NOIR) if j == 0 else (SANG2 if i in (1, 4) else peau))
    rect(14, 68, 6, 2, CHAIR)
    # côtes 6x6x1 à (20,64) : avant = côtes et sternum
    rect(21, 64, 6, 1, CHAIR)
    rect(27, 64, 6, 1, CHAIR2)
    rect(20, 65, 1, 6, CHAIR)
    rect(27, 65, 1, 6, CHAIR)
    rect(21, 65, 6, 6, lambda i, j: OS if (j % 2 == 0 or i in (2, 3)) else (NOIR if i in (0, 5) else CHAIR2))
    rect(28, 65, 6, 6, NOIR)
    # vertèbres 1x10x1 à (34,64)
    rect(34, 64, 4, 11, lambda i, j: OS2 if j % 3 else NOIR)
    rect(37, 65, 1, 10, lambda i, j: OS if j % 3 else CHAIR)
    # os qui perce 1x3x1 à (38,64)
    rect(38, 64, 4, 4, lambda i, j: SANG2 if j == 3 else OS)
    # moignon (chair, os au centre) 8x8 à (48,64)
    rect(48, 64, 8, 8, lambda i, j: OS if 3 <= i <= 4 and 3 <= j <= 4 else (CHAIR if (i + j) % 2 else CHAIR2))
    return out


def fr(x1, y1, x2, y2):
    return [x1, y1, x2, y2]


MOIGNON = fr(49, 65, 53, 69)


def bras_casse(j):
    """Coupe le bras gauche (tex 32,48 ; manche 48,48) en bras (6 haut) + avant-bras (sous-modèle, pivot au coude)."""
    m = next(p for p in j['models'] if p.get('part') == 'left_arm')
    haut, bas = [], []
    for (u, v, add) in ((32, 48, None), (48, 48, 0.25)):
        # faces d'origine : west (u,v+4,4,12) north (u+4,v+4) east (u+8,v+4) south (u+12,v+4) up (u+4,v) down (u+8,v)
        def faces(y0, y1):
            return {'uvNorth': fr(u + 4, v + 4 + y0, u + 8, v + 4 + y1), 'uvSouth': fr(u + 12, v + 4 + y0, u + 16, v + 4 + y1),
                    'uvWest': fr(u, v + 4 + y0, u + 4, v + 4 + y1), 'uvEast': fr(u + 8, v + 4 + y0, u + 12, v + 4 + y1)}
        b = {'coordinates': [-8, 18, -2, 4, 6, 4]}
        b.update(faces(0, 6)); b['uvUp'] = fr(u + 4, v, u + 8, v + 4); b['uvDown'] = MOIGNON
        a = {'coordinates': [-2, -6, -2, 4, 6, 4]}
        a.update(faces(6, 12)); a['uvUp'] = MOIGNON; a['uvDown'] = fr(u + 8, v, u + 12, v + 4)
        if add:
            b['sizeAdd'] = add; a['sizeAdd'] = add
        haut.append(b); bas.append(a)
    # l'os qui perce, derrière le coude
    haut.append({'coordinates': [-6.5, 17, 2, 1, 3, 1], 'textureOffset': [38, 64]})
    m['boxes'] = haut
    m.setdefault('submodels', []).append({'id': 'za_avant_bras', 'invertAxis': 'xy', 'translate': [-6, 18, 0], 'boxes': bas})


def appliquer(j, pieces):
    j['textureSize'] = [64, 96]
    parts = {p.get('part'): p for p in j['models']}
    anims = next((p['animations'][0] for p in j['models'] if p.get('animations')), None)
    if 'm' in pieces:
        parts['head'].setdefault('submodels', []).append(
            {'id': 'za_machoire', 'invertAxis': 'xy', 'translate': [0, 24, -0.5],
             'boxes': [{'coordinates': [-3, -2, -4, 6, 2, 4], 'textureOffset': [0, 64]}]})
        if anims is not None:
            anims['za_machoire.rx'] = '0.3 + sin(age*0.23+id)*0.12 + sin(swing_progress*pi)*0.6 + if(death_time > 0, 0.5, 0)'
    if 'c' in pieces:
        parts['body']['boxes'].append({'coordinates': [-3, 15, -2.6, 6, 6, 1], 'textureOffset': [20, 64]})
    if 'v' in pieces:
        parts['body']['boxes'].append({'coordinates': [-0.5, 13, 1.7, 1, 10, 1], 'textureOffset': [34, 64]})
    if 'b' in pieces:
        bras_casse(j)
        if anims is not None:
            # l'avant-bras pend à l'envers et ballotte quand il marche
            anims['za_avant_bras.rx'] = '1.25 + sin(limb_swing*0.6662)*0.35*limb_speed + sin(age*0.09+id)*0.08'
            anims['za_avant_bras.rz'] = '0.25'


textures_faites = set()
for num, pieces in PIECES.items():
    n = CEM + 'zombie%d.jem' % num
    if n not in files:
        continue
    j = json.loads(files[n])
    appliquer(j, pieces)
    files[n] = json.dumps(j, indent=1).encode()
    tex = 'assets/minecraft/' + j['texture']
    if tex not in textures_faites and tex in files:
        textures_faites.add(tex)
        buf = io.BytesIO(); peindre(Image.open(io.BytesIO(files[tex]))).save(buf, 'PNG'); files[tex] = buf.getvalue()
        e = tex[:-4] + '_e.png'
        if e in files:
            im = Image.open(io.BytesIO(files[e])).convert('RGBA')
            grand = Image.new('RGBA', (64, 96), (0, 0, 0, 0)); grand.paste(im, (0, 0))
            buf = io.BytesIO(); grand.save(buf, 'PNG'); files[e] = buf.getvalue()

# toutes les peaux humaines partagées doivent avoir la même taille que leur .jem : les modèles non modifiés gardent
# 64x64 ; une peau agrandie utilisée par un modèle non modifié (Gagnon) n'existe pas ici (textures distinctes).
toml = files['META-INF/mods.toml'].decode('utf-8').replace('version="1.4.0"', 'version="1.5.0"')
files['META-INF/mods.toml'] = toml.encode('utf-8')
if 'META-INF/MANIFEST.MF' in files:
    files['META-INF/MANIFEST.MF'] = files['META-INF/MANIFEST.MF'].replace(b'1.4.0', b'1.5.0')

with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED) as z:
    for n in sorted(files, key=lambda k: (not k.startswith('META-INF/MANIFEST'), k)):
        z.writestr(zipfile.ZipInfo(n, (1980, 1, 1, 0, 0, 0)), files[n], zipfile.ZIP_DEFLATED)
print('OK', OUT, len(textures_faites), 'peaux agrandies')
