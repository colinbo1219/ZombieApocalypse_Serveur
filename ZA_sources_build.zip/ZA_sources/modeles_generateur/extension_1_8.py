#!/usr/bin/env python3
# za_modeles 1.8.0 « Zombies 2.0 » : part du jar 1.7.0 et ajoute, sans nouveau modèle :
#  - des VARIANTES DE PEAU choisies par ETF selon l'entité (premières règles qui correspondent) :
#      contaminé  (équipe za_contamine : zone morte, territoire d'Alpha)  pustules vert-jaune qui luisent
#      brûlé      (équipe za_brule : passé dans un incendie, za_p98)      plaques carbonisées, braises qui luisent
#      blessé     (santé <= 40 %% : l'état après le combat)                plaies ouvertes, sang qui coule
#      givre      (équipe za_givre : l'hiver, za_p78 ; biomes enneigés)    peau bleuie, cristaux ; tuque pour les humains
#      boue       (biomes marais et rivière)                               boue et vase
#      campagne   (citoyens, biomes de forêt et de prairie)               chemise à carreaux de bûcheron
#      puis le tirage des états de 1.7.0 (humains) ou la peau de base
#  - des ANIMATIONS RARES par entité : spasme du bras, renifler l'air à l'arrêt, piquer du nez en avant, et une foulée
#    propre à chacun (certains boitent davantage) : on reconnaît un mort à sa démarche
#  Les équipes sont données côté serveur par za_p100_apparences.sk (team join).
# Usage : python3 extension_1_8.py <1.7.0.jar> <sortie.jar>
import io, json, os, random, sys, zipfile
from PIL import Image

SRC, OUT = sys.argv[1], sys.argv[2]
zin = zipfile.ZipFile(SRC)
files = {n: zin.read(n) for n in zin.namelist() if not n.endswith('/')}
CEM = 'assets/minecraft/optifine/cem/'
TEX = 'assets/minecraft/textures/entity/za/'
HUM = TEX + 'humains/'
RND = 'assets/minecraft/optifine/random/entity/za/'

NEIGE = 'grove snowy_slopes snowy_plains snowy_taiga frozen_river frozen_peaks jagged_peaks ice_spikes snowy_beach'
BOUE = 'swamp mangrove_swamp river'
CAMPAGNE = 'forest birch_forest taiga old_growth_spruce_taiga old_growth_birch_forest old_growth_pine_taiga meadow'


def png(im):
    b = io.BytesIO(); im.save(b, 'PNG'); return b.getvalue()


def ouvrir(n):
    return Image.open(io.BytesIO(files[n])).convert('RGBA')


def mix(a, b, t):
    return tuple(int(a[i] * (1 - t) + b[i] * t) for i in range(3))


def peau(c):
    r, g, b = c[:3]
    return g > r + 4 and g >= b - 4 and 50 < g < 200


def taches(W, H, rnd, n, rmin, rmax):
    """Masque de taches (centres et rayons au hasard) : renvoie une fonction (x, y) -> intensité 0..1."""
    cs = [(rnd.uniform(0, W), rnd.uniform(0, H), rnd.uniform(rmin, rmax)) for _ in range(n)]

    def f(x, y):
        m = 0.0
        for (cx, cy, r) in cs:
            d = ((x - cx) ** 2 + (y - cy) ** 2) ** 0.5
            if d < r:
                m = max(m, 1 - d / r)
        return m
    return f


def variante(im, emi, sorte, rnd, humain):
    im = im.copy(); px = im.load(); W, H = im.size
    e = (emi.copy() if emi is not None else Image.new('RGBA', im.size, (0, 0, 0, 0))); ep = e.load()
    if sorte == 'contamine':
        t = taches(W, H, rnd, max(10, W * H // 120), 1.4, 3.2)
        for y in range(H):
            for x in range(W):
                c = px[x, y]
                if not c[3]:
                    continue
                c2 = mix(c, (96, 120, 48), 0.38)
                m = t(x, y)
                if m > 0.4:
                    c2 = (190, 220, 70) if m > 0.8 else (120, 168, 50)
                    if m > 0.75:
                        ep[x, y] = (170, 255, 60, 255)
                px[x, y] = c2 + (255,)
    elif sorte == 'brule':
        t = taches(W, H, rnd, max(10, W * H // 110), 2.0, 5.0)
        for y in range(H):
            for x in range(W):
                c = px[x, y]
                if not c[3]:
                    continue
                m = t(x, y)
                if m > 0.12:
                    c2 = mix(c, (24, 18, 16), min(1, m * 1.8))
                    if 0.15 < m < 0.3 and rnd.random() < 0.5:
                        c2 = (230, 110, 30)
                        ep[x, y] = (255, 120, 30, 255)
                    px[x, y] = c2 + (255,)
    elif sorte == 'blesse':
        t = taches(W, H, rnd, max(5, W * H // 320), 1.0, 2.6)
        for y in range(H):
            for x in range(W):
                c = px[x, y]
                if not c[3]:
                    continue
                m = t(x, y)
                if m > 0.6:
                    px[x, y] = ((150, 14, 18) if m > 0.85 else (96, 10, 12)) + (255,)
        # le sang coule vers le bas
        for _ in range(W * H // 90):
            x, y = rnd.randrange(W), rnd.randrange(H)
            for k in range(rnd.randint(2, 6)):
                if y + k < H and px[x, y + k][3]:
                    px[x, y + k] = mix(px[x, y + k], (110, 8, 10), 0.75) + (255,)
    elif sorte == 'givre':
        for y in range(H):
            for x in range(W):
                c = px[x, y]
                if not c[3]:
                    continue
                c2 = mix(c, (176, 198, 214), 0.32)
                if rnd.random() < 0.06:
                    c2 = (232, 242, 250)
                px[x, y] = c2 + (255,)
        if humain:
            # une tuque rouge et blanche : dessus et pourtour de la tête (calque de couche externe 32..64 x 0..16)
            for y in range(0, 10):
                for x in range(32, 64):
                    if y < 8 and not (40 <= x < 56):
                        continue
                    col = (176, 30, 34) if ((x // 2 + y // 2) % 3) else (236, 232, 228)
                    px[x, y] = col + (255,)
    elif sorte == 'boue':
        t = taches(W, H, rnd, max(10, W * H // 120), 2.0, 5.0)
        for y in range(H):
            for x in range(W):
                c = px[x, y]
                if not c[3]:
                    continue
                m = t(x, y)
                # plus de boue vers le bas de chaque peau
                m = min(1, m + max(0, (y / H) - 0.4) * 1.2)
                if m > 0.3:
                    px[x, y] = mix(c, (70, 52, 34), min(0.9, m + 0.2)) + (255,)
    elif sorte == 'campagne':
        # chemise à carreaux sur le torse et les bras (disposition de peau standard 64x64)
        zones = [(16, 16, 40, 32), (40, 16, 56, 32), (32, 48, 48, 64), (16, 32, 40, 48), (40, 32, 56, 48), (48, 48, 64, 64)]
        for (x1, y1, x2, y2) in zones:
            for y in range(y1, min(y2, H)):
                for x in range(x1, x2):
                    c = px[x, y]
                    if not c[3] or peau(c):
                        continue
                    a = (x // 2) % 2
                    b = (y // 2) % 2
                    col = (150, 28, 28) if a == b else ((28, 22, 22) if a else (112, 20, 22))
                    px[x, y] = mix(c, col, 0.8) + (255,)
    return im, e


SORTES = ['contamine', 'brule', 'blesse', 'givre', 'boue']


def regles(n_etats, num, campagne):
    """Règles ETF ; num[sorte] = numéro de la variante ; n_etats = nombre de peaux du tirage de base (1 ou 4)."""
    r = ['# za_modeles 1.8.0 : variantes selon l\'entité (la première règle qui correspond l\'emporte)']
    i = 0

    def add(lignes):
        nonlocal i
        i += 1
        for l in lignes:
            r.append(l.replace('#', str(i)))
    add(['textures.#=%d' % num['contamine'], 'teams.#=za_contamine'])
    add(['textures.#=%d' % num['brule'], 'teams.#=za_brule'])
    add(['textures.#=%d' % num['blesse'], 'health.#=0-40%'])
    add(['textures.#=%d' % num['givre'], 'teams.#=za_givre'])
    add(['textures.#=%d' % num['givre'], 'biomes.#=' + NEIGE])
    add(['textures.#=%d' % num['boue'], 'biomes.#=' + BOUE])
    if campagne:
        add(['textures.#=%d' % num['campagne'], 'biomes.#=' + CAMPAGNE])
    if n_etats > 1:
        add(['textures.#=1 2 3 4', 'weights.#=35 20 25 20'])
    else:
        add(['textures.#=1'])
    return '\n'.join(r) + '\n'


nb = 0
for n in sorted(list(files)):
    if not (n.startswith(TEX) and n.endswith('.png') and not n.endswith('_e.png')):
        continue
    base = os.path.basename(n)[:-4]
    if base.startswith('boss_') or base == 'z_gagnon':
        continue                                      # les boss et Mme Gagnon restent eux-mêmes
    humain = n.startswith(HUM)
    rdir = RND + ('humains/' if humain else '')
    im = ouvrir(n)
    e_nom = n[:-4] + '_e.png'
    emi = ouvrir(e_nom) if e_nom in files else None
    rnd = random.Random('za18-' + base)
    premier = 5 if humain else 2                      # les humains ont déjà 2, 3, 4 (états de 1.7.0)
    num = {}
    sortes = SORTES + (['campagne'] if base.startswith('z_citoyen') else [])
    for k, s in enumerate(sortes):
        num[s] = premier + k
        im2, e2 = variante(im, emi, s, rnd, humain)
        files[rdir + '%s%d.png' % (base, num[s])] = png(im2)
        if emi is not None or s in ('contamine', 'brule'):
            files[rdir + '%s%d_e.png' % (base, num[s])] = png(e2)
    files[rdir + base + '.properties'] = regles(4 if humain else 1, num, 'campagne' in num).encode('utf-8')
    nb += 1


# ---------------------------------------------------------------- animations rares
def envelopper(anims, cle, extra):
    for a in anims:
        if cle in a:
            a[cle] = '(%s) + %s' % (a[cle], extra)
            return True
    return False


def ajouter(anims, cle, expr):
    for a in anims:
        if cle in a:
            return False
    anims[-1][cle] = expr
    return True


SPASME = 'if(death_time > 0, 0, if(frac((age+id*53)/640) < 0.02, sin(age*4.1)*0.8, 0))'
RENIFLE = 'if(limb_speed < 0.05, if(frac((age+id*97)/520) < 0.05, -0.55, 0), 0)'
PLONGE = 'if(death_time > 0, 0, if(frac((age+id*71)/900) < 0.025, 0.45, 0))'
nanim = 0
for n in sorted(list(files)):
    if not (n.startswith(CEM) and n.endswith('.jem') and os.path.basename(n).startswith('zombie')):
        continue
    j = json.loads(files[n])
    if 'boss_' in j.get('texture', ''):
        continue
    touche = False
    for m in j.get('models', []):
        an = m.get('animations')
        if not an:
            continue
        touche |= envelopper(an, 'right_arm.rz', SPASME)
        touche |= envelopper(an, 'head.rx', RENIFLE)
        if not any('body.rx' in a for a in an):
            an[-1]['body.rx'] = PLONGE
            touche = True
        # foulée propre à chacun
        for a in an:
            for k in ('right_leg.rx', 'left_leg.rx'):
                if k in a and 'frac(id*0.37)' not in a[k]:
                    a[k] = '(%s)*(0.7+0.6*frac(id*0.37))' % a[k]
                    touche = True
    if touche:
        files[n] = json.dumps(j, indent=1).encode()
        nanim += 1

toml = files['META-INF/mods.toml'].decode('utf-8').replace('version="1.7.0"', 'version="1.8.0"')
files['META-INF/mods.toml'] = toml.encode('utf-8')
if 'META-INF/MANIFEST.MF' in files:
    files['META-INF/MANIFEST.MF'] = files['META-INF/MANIFEST.MF'].replace(b'1.7.0', b'1.8.0')
with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED) as z:
    for n in sorted(files, key=lambda k: (not k.startswith('META-INF/MANIFEST'), k)):
        z.writestr(zipfile.ZipInfo(n, (1980, 1, 1, 0, 0, 0)), files[n], zipfile.ZIP_DEFLATED)
print('OK', OUT, '— peaux avec variantes :', nb, '— modèles animés :', nanim)
