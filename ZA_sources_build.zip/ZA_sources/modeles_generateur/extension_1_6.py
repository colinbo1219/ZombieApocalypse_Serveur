#!/usr/bin/env python3
# za_modeles 1.6.0 « voix » : part du jar 1.5.0 et ajoute les voix de synthèse (voix_generer.py) :
# entractes J2/J4/J6 de Léa, hiver, nids, fin de saison. Sons « za_modeles:voix.<clé> », sous-titres FR.
# Usage : python3 voix_generer.py <modèles Piper> <dossier ogg> && python3 extension_1_6.py <1.5.0.jar> <dossier ogg> <sortie.jar>
import json, os, sys, zipfile

from voix_generer import VOIX

SRC, OGG, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
zin = zipfile.ZipFile(SRC)
files = {n: zin.read(n) for n in zin.namelist() if not n.endswith('/')}

sons = json.loads(files['assets/za_modeles/sounds.json'])
langs = {n: json.loads(files[n]) for n in files if n.startswith('assets/za_modeles/lang/')}
for cle, (v, texte) in VOIX.items():
    chemin = os.path.join(OGG, cle + '.ogg')
    files['assets/za_modeles/sounds/voix/%s.ogg' % cle] = open(chemin, 'rb').read()
    sons['voix.' + cle] = {"subtitle": "subtitles.za_modeles.voix." + cle,
                           "sounds": [{"name": "za_modeles:voix/" + cle, "stream": True, "attenuation_distance": 24}]}
    for n, d in langs.items():
        d["subtitles.za_modeles.voix." + cle] = ('Léa (radio)' if v == 'siwis' else 'Voix') + ' : ' + texte[:60]
files['assets/za_modeles/sounds.json'] = json.dumps(sons, indent=1, ensure_ascii=False).encode('utf-8')
for n, d in langs.items():
    files[n] = json.dumps(d, indent=1, ensure_ascii=False).encode('utf-8')

toml = files['META-INF/mods.toml'].decode('utf-8').replace('version="1.5.0"', 'version="1.6.0"')
files['META-INF/mods.toml'] = toml.encode('utf-8')
if 'META-INF/MANIFEST.MF' in files:
    files['META-INF/MANIFEST.MF'] = files['META-INF/MANIFEST.MF'].replace(b'1.5.0', b'1.6.0')
with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED) as z:
    for n in sorted(files, key=lambda k: (not k.startswith('META-INF/MANIFEST'), k)):
        z.writestr(zipfile.ZipInfo(n, (1980, 1, 1, 0, 0, 0)), files[n], zipfile.ZIP_DEFLATED)
print('OK', OUT, len(VOIX), 'voix')
