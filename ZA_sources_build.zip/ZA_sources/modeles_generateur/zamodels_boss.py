# Modèles des BOSS RÉGIONAUX (za_modeles 1.7.0) : même langage que zamodels.py (coordonnées JEM, voir zagen_lib.py)
#   Le Boucher : massif, tablier sanglant, couperet dans la main droite, crochet à viande dans la gauche
#   La Matriarche : grande, maigre, cheveux longs, blouse d'hôpital, bras trop longs, ventre gonflé de pustules qui luisent
#   Le Gardien : soldat colosse, casque, masque à gaz, gilet pare-balles, sac à dos, marche au pas
#   Le Brûlé : carbonisé, fissures de braise (émissives), casque de chantier fondu, fume
import zagen_lib as L
from zagen_lib import Box as B, Sub as S, Model

L.MATS.setdefault('tablier', ((176, 168, 156), 10, 'gown'))
L.MATS.setdefault('cuir', ((92, 62, 40), 8, 'cloth'))
L.MATS.setdefault('casque_jaune', ((196, 160, 40), 10, 'metal'))

M, EYES = {}, {}
W = 'limb_swing*0.6662'
SW = 'sin(swing_progress*pi)'


def model(name, eye):
    m = Model(name)
    M[name] = m
    EYES[name] = eye
    return m


def dying(expr, limp='0.3'):
    return f'if(death_time > 0, {limp}, {expr})'


# LE BOUCHER
m = model('boss_boucher', (255, 40, 20))
m.add('head', B(-4.5, 28, -6, 9, 9, 9, 'brute_skin', face='brute'))
m.add('body', B(-9, 12, -5, 18, 17, 10, 'brute_skin'),
      B(-8, 8, -5.6, 16, 18, 1, 'tablier'),                       # tablier
      B(-9, 8, -5, 18, 4, 10, 'pants_brown'),
      B(-2, 25, 5, 4, 3, 2, 'bone'))
m.add('right_arm', B(9, 6, -4, 7, 21, 8, 'brute_skin'),
      S('b_couperet', (12.5, 7, -4),
        B(12, -2, -12, 1, 9, 10, 'metal'), B(12, 2, -4, 1, 2, 3, 'cuir')))
m.add('left_arm', B(-16, 6, -4, 7, 21, 8, 'brute_skin'),
      B(-13, -3, -1, 1, 9, 1, 'metal_dark'), B(-14, -4, -1, 3, 1, 1, 'metal_dark'), B(-14, -5, -1, 1, 2, 1, 'metal_dark'))
m.add('right_leg', B(0, 0, -4, 7, 12, 8, 'pants_brown'))
m.add('left_leg', B(-7, 0, -4, 7, 12, 8, 'pants_brown'))
m.anims.update({
    'head.ty': 'sin(age*0.08+id)*0.5', 'body.ty': 'sin(age*0.08+id)*0.5',
    'body.rz': f'sin({W})*0.1*limb_speed',
    'body.rx': f'{SW}*0.3',
    'head.rx': 'head.rx + 0.2 - hurt_time*0.02',
    'right_arm.rx': dying(f'right_arm.rx - {SW}*2.2 + cos({W})*0.3*limb_speed'),
    'left_arm.rx': dying(f'left_arm.rx + 0.3 + cos({W}+pi)*0.3*limb_speed'),
})

# LA MATRIARCHE
m = model('boss_matriarche', (230, 230, 210))
m.add('head', B(-3.5, 34, -3.5, 7, 9, 7, 'pale', face='scream'),
      B(-4, 30, -1, 8, 13, 5, 'hair'))                            # cheveux qui tombent dans le dos
m.add('body', B(-4, 18, -2, 8, 16, 4, 'gown'),
      S('m_ventre', (0, 22, -2.5), B(-4.5, 17, -8, 9, 9, 6, 'bloat_skin'),
        B(-3, 21, -8.5, 2, 2, 1, 'pustule'), B(1, 19, -8.5, 2, 2, 1, 'pustule'), B(-1, 24, -8.5, 2, 2, 1, 'pustule')),
      B(-4.5, 10, -2.5, 9, 8, 5, 'gown'))
m.add('right_arm', B(4, 6, -1.5, 3, 28, 3, 'pale'))
m.add('left_arm', B(-7, 6, -1.5, 3, 28, 3, 'pale'))
m.add('right_leg', B(0.5, 0, -1.5, 3, 18, 3, 'pale'))
m.add('left_leg', B(-3.5, 0, -1.5, 3, 18, 3, 'pale'))
VENTRE = '1 + sin(age*0.1+id)*0.06'
m.anims.update({
    'm_ventre.sx': VENTRE, 'm_ventre.sy': VENTRE, 'm_ventre.sz': VENTRE,
    'head.rz': 'sin(age*0.03+id)*0.3 + if(frac((age+id*11)/140) < 0.04, sin(age*3)*0.5, 0)',
    'head.rx': 'head.rx + 0.25',
    # bras toujours tendus vers l'avant, doigts qui cherchent
    'right_arm.rx': dying(f'-1.3 + sin(age*0.07+id)*0.12 - {SW}*0.5'),
    'left_arm.rx': dying(f'-1.3 + sin(age*0.07+id+1)*0.12 - {SW}*0.5'),
    'right_leg.rx': f'cos({W})*0.5*limb_speed', 'left_leg.rx': f'cos({W}+pi)*0.5*limb_speed',
})

# LE GARDIEN
m = model('boss_gardien', (255, 60, 30))
m.add('head', B(-4.5, 30, -4.5, 9, 9, 9, 'grey', face='helmet'),
      B(-5, 36, -5, 10, 3, 10, 'military'),                      # casque
      B(-3, 30, -5.5, 6, 5, 2, 'visor', face='observer'),        # masque à gaz, yeux blancs derrière
      B(-1, 29, -6.5, 2, 2, 2, 'metal_dark'))                    # cartouche filtrante
m.add('body', B(-7, 12, -3.5, 14, 18, 7, 'military'),
      B(-7.5, 16, -4, 15, 12, 8, 'kevlar'),                      # gilet
      B(-5, 16, 4, 10, 12, 4, 'military'))                       # sac
m.add('right_arm', B(7, 8, -3, 6, 20, 6, 'military'))
m.add('left_arm', B(-13, 8, -3, 6, 20, 6, 'military'))
m.add('right_leg', B(0, 0, -3, 6, 12, 6, 'military'))
m.add('left_leg', B(-6, 0, -3, 6, 12, 6, 'military'))
m.anims.update({
    'head.rx': 'head.rx - hurt_time*0.02',
    'right_leg.rx': f'cos({W})*1.0*limb_speed', 'left_leg.rx': f'cos({W}+pi)*1.0*limb_speed',
    # pas cadencé : bras qui balancent raides ; en tirant, le bras droit se lève
    'right_arm.rx': dying(f'cos({W}+pi)*0.6*limb_speed - {SW}*1.4'),
    'left_arm.rx': dying(f'cos({W})*0.6*limb_speed'),
})

# LE BRÛLÉ
m = model('boss_brule', (255, 150, 40))
m.add('head', B(-4, 26, -4, 8, 8, 8, 'overlord_skin', face='overlord'),
      B(-5, 32, -5, 10, 2, 10, 'casque_jaune'), B(-3, 34, -3, 6, 1, 6, 'casque_jaune'))
m.add('body', B(-5, 12, -2.5, 10, 14, 5, 'overlord_skin'),
      B(-2, 18, -3, 3, 5, 1, 'bone'))
m.add('right_arm', B(5, 8, -2, 4, 17, 4, 'overlord_skin'))
m.add('left_arm', B(-9, 8, -2, 4, 17, 4, 'overlord_skin'))
m.add('right_leg', B(0, 0, -2, 5, 12, 4, 'overlord_skin'))
m.add('left_leg', B(-5, 0, -2, 5, 12, 4, 'overlord_skin'))
m.anims.update({
    'head.rz': 'sin(age*0.9+id)*0.04',                          # il tremble (la douleur)
    'body.rz': 'sin(age*0.7+id)*0.03',
    'head.rx': 'head.rx - hurt_time*0.03',
    'right_arm.rx': dying(f'right_arm.rx - {SW}*1.6'),
    'left_arm.rx': dying(f'left_arm.rx - {SW}*1.6'),
})

NOMS_BOSS = [
    (r'regex:(§.)*Le\sBoucher', 'boss_boucher'),
    (r'regex:(§.)*La\sMatriarche', 'boss_matriarche'),
    (r'regex:(§.)*Le\sGardien', 'boss_gardien'),
    (r'regex:(§.)*Le\sBr.l.', 'boss_brule'),
]
