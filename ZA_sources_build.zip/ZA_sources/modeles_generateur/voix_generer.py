#!/usr/bin/env python3
# Voix de synthèse (Piper, voix françaises siwis = Léa, tom = militaire/narrateur) passées dans un filtre « radio »
# (bande 300-3200 Hz, compression, souffle) : .ogg mono 44,1 kHz comme les voix enregistrées du mod.
# Usage : python3 voix_generer.py <dossier des modèles Piper> <dossier de sortie .ogg>
#   modèles : fr_FR-siwis-medium.onnx(.json), fr_FR-tom-medium.onnx(.json) (huggingface.co/rhasspy/piper-voices)
# Dépendances : pip install piper-tts ; ffmpeg.
import os, subprocess, sys

VOIX = {
    # entractes du prologue (za_p38_prologue, za_pro_vers)
    'radio_j2': ('siwis', "La direction de la santé publique parle d'une grippe sévère. On nous demande de ne pas employer d'autre mot."),
    'radio_j4': ('siwis', "On ne me laisse plus lire les chiffres. Alors ce soir... je vais lire des noms."),
    'radio_j6': ('siwis', "Sergent Vega, si vous m'écoutez : il reste des gens dans les tours de la rue des Érables."),
    # saisons et nids (za_p78_hiver, za_p74_aube)
    'lea_premiere_neige': ('siwis', "Première neige sur Saint-Aurèle. Rentrez du bois. Les morts ralentissent dans le froid... nous aussi."),
    'lea_grand_froid': ('siwis', "Moins trente cette nuit. La rivière Blanche est prise : on peut la traverser à pied. Eux aussi."),
    'lea_degel': ('siwis', "Le dégel. L'eau reprend la rivière, et les morts reprennent leur pas. Profitez des derniers jours calmes."),
    'lea_nids': ('siwis', "Le soleil tombe. Les nids se vident. Rentrez, ou barricadez-vous."),
    # fin de saison : le choix de Saint-Aurèle (za_p80_fin_norda)
    'fin_intro': ('siwis', "Ici Léa. L'Overlord est tombé... mais il n'est pas venu de nulle part. Sous le campus de NORDA, "
                           "au niveau moins deux, tout a commencé. Le dossier Arel le prouve. Maintenant, c'est à vous de décider."),
    'fin_detruire': ('siwis', "Vous avez choisi. Cette nuit, le niveau moins deux de NORDA a sauté. Ce qu'ils cachaient est "
                              "enterré avec eux. Pour toujours, j'espère."),
    'fin_verite': ('siwis', "Vous avez choisi. Ce soir, sur CKZA, je lis le dossier Arel en entier. Chaque nom. Chaque date. "
                            "Que tout le monde sache."),
    'fin_remede': ('siwis', "Vous avez choisi. Le docteur Lefort garde les données Z-01. Il dit qu'avec ça, un vaccin est "
                            "possible. Il dit aussi que NORDA voudra les récupérer."),
}
FILTRE = ("highpass=f=300,lowpass=f=3200,acompressor=threshold=-18dB:ratio=4:attack=5:release=80,"
          "volume=3.4,alimiter=limit=0.9")


def voix_modele(dossier, v):
    return os.path.join(dossier, 'fr_FR-%s-medium.onnx' % v)


def generer(modeles, sortie, seulement=None):
    os.makedirs(sortie, exist_ok=True)
    for cle, (v, texte) in VOIX.items():
        if seulement and cle not in seulement:
            continue
        wav = os.path.join(sortie, cle + '.wav')
        ogg = os.path.join(sortie, cle + '.ogg')
        subprocess.run([sys.executable, '-m', 'piper', '-m', voix_modele(modeles, v), '-f', wav,
                        '--length-scale', '1.08' if v == 'siwis' else '1.0'],
                       input=texte.encode('utf-8'), check=True, capture_output=True)
        # voix filtrée + souffle radio (bruit rose très bas) mélangés, mono 44,1 kHz
        subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', wav,
                        '-f', 'lavfi', '-i', 'anoisesrc=color=pink:amplitude=0.02:sample_rate=22050',
                        '-filter_complex', '[0:a]%s,apad=pad_dur=0.4[v];[1:a]highpass=f=500,lowpass=f=4000[n];'
                        '[v][n]amix=inputs=2:duration=first:weights=1 0.6,aresample=44100' % FILTRE,
                        '-ac', '1', '-c:a', 'libvorbis', '-q:a', '4', ogg], check=True)
        os.remove(wav)
        print(cle, os.path.getsize(ogg))


if __name__ == '__main__':
    generer(sys.argv[1], sys.argv[2], sys.argv[3:] or None)
