# Definitions des 16 zombies ZombieApocalypse (coordonnees JEM, voir zagen_lib.py)
from zagen_lib import Box as B, Model

M = {}
EYES = {}


def model(name, eye=(255, 210, 60)):
    m = Model(name)
    M[name] = m
    EYES[name] = eye
    return m


# Bras qui pendent le long du corps (au lieu des bras tendus des zombies)
HANG_ARMS = {
    'right_arm.rx': 'sin(limb_swing*0.6662)*limb_speed*0.6 - sin(swing_progress*pi)*1.4',
    'left_arm.rx': '-sin(limb_swing*0.6662)*limb_speed*0.6',
    'right_arm.rz': '0.08', 'left_arm.rz': '-0.08',
}

# 1. SHAMBLER - le zombie de base: chemise dechiree, bras gauche arrache
m = model('shambler', (255, 214, 64))
m.add('head', B(-4, 24, -5, 8, 8, 8, 'rot', face='zombie'),
      B(-4, 31, -5, 8, 1, 3, 'hair'))
m.add('body', B(-4, 12, -2, 8, 12, 4, 'shirt'),
      B(-2, 15, -2.6, 4, 5, 1, 'flesh'),                 # plaie ouverte
      B(-3, 10, -2.2, 2, 3, 1, 'shirt'))                 # lambeau
m.add('right_arm', B(4, 12, -2, 4, 12, 4, 'rot'))
m.add('left_arm', B(-8, 17, -2, 4, 7, 4, 'shirt'),
      B(-7, 14, -1, 2, 3, 2, 'bone'), B(-7.5, 16, -1.5, 3, 1, 3, 'flesh'))
m.add('right_leg', B(0, 0, -2, 4, 12, 4, 'jeans'))
m.add('left_leg', B(-4, 0, -2, 4, 12, 4, 'jeans'))

# 2. RUNNER - maigre, capuche rouge, bras longs
m = model('runner', (255, 230, 40))
m.add('head', B(-3.5, 24, -3.5, 7, 8, 7, 'pale', face='runner'),
      B(-4, 31, -4, 8, 1, 8, 'hoodie_red'), B(-4.5, 24, -3, 1, 8, 7, 'hoodie_red'),
      B(3.5, 24, -3, 1, 8, 7, 'hoodie_red'), B(-4, 24, 3.5, 8, 7, 1, 'hoodie_red'))
m.add('body', B(-3.5, 12, -1.5, 7, 12, 3, 'hoodie_red'),
      B(-2, 16, -1.9, 3, 4, 1, 'bone'))                   # cotes a l'air
m.add('right_arm', B(3.5, 8, -1.5, 3, 16, 3, 'pale'),
      B(3.5, 6, -1.5, 1, 2, 1, 'bone'), B(5.5, 6, -1.5, 1, 2, 1, 'bone'))
m.add('left_arm', B(-6.5, 8, -1.5, 3, 16, 3, 'pale'),
      B(-6.5, 6, -1.5, 1, 2, 1, 'bone'), B(-4.5, 6, -1.5, 1, 2, 1, 'bone'))
m.add('right_leg', B(0.5, 0, -1.5, 3, 12, 3, 'jeans_dark'))
m.add('left_leg', B(-3.5, 0, -1.5, 3, 12, 3, 'jeans_dark'))

# 3. CRAWLER - rampe au sol, sans jambes (c'est un "bebe": tout est dessine 2x plus gros)
m = model('crawler', (255, 190, 50))
m.add('body',
      B(-11, 0, -16, 22, 11, 30, 'shirt'),              # torse couche
      B(-9, 3, -35, 18, 17, 19, 'rot', face='zombie'),  # tete relevee
      B(-21, 0, -41, 8, 7, 30, 'rot'),                  # bras droit tendu vers l'avant
      B(13, 0, -41, 8, 7, 30, 'rot'),                   # bras gauche
      B(-21, 0, -45, 8, 4, 4, 'bone'), B(13, 0, -45, 8, 4, 4, 'bone'),  # griffes
      B(-9, 0, 14, 10, 8, 13, 'jeans'),                 # moignon de jambe
      B(3, 1, 14, 5, 5, 7, 'bone'),                     # os de l'autre jambe
      B(-3, 0, 14, 5, 3, 19, 'gut'))                    # tripes qui trainent
m.anims.update({'body.ry': 'sin(limb_swing*0.9)*limb_speed*0.35'})

# 4. SPITTER - machoire decrochee, sac d'acide vert qui brille
m = model('spitter', (170, 255, 60))
m.add('head', B(-4, 25, -5, 8, 7, 8, 'rot', face='spitter'),
      B(-3.5, 20, -5.5, 7, 5, 6, 'rot', face='jaw'),
      B(-1, 17, -5.2, 1, 3, 1, 'acid'), B(1, 18, -5.2, 1, 2, 1, 'acid'))
m.add('body', B(-4, 12, -2, 8, 12, 4, 'gown'),
      B(-3, 17, -5, 6, 6, 3, 'acid_sac'),
      B(3, 22, -1, 3, 3, 3, 'pustule'), B(-6, 21, 0, 3, 3, 3, 'pustule'), B(-2, 13, 1.5, 3, 3, 1, 'pustule'))
m.add('right_arm', B(4, 12, -2, 4, 12, 4, 'rot'), B(7, 16, -1, 2, 2, 2, 'pustule'))
m.add('left_arm', B(-8, 12, -2, 4, 12, 4, 'rot'))
m.add('right_leg', B(0, 0, -2, 4, 12, 4, 'pants_brown'))
m.add('left_leg', B(-4, 0, -2, 4, 12, 4, 'pants_brown'))

# 5. BLOATER - ventre enorme plein de pustules
m = model('bloater', (220, 255, 80))
m.add('head', B(-3, 23, -4.5, 6, 6, 6, 'bloat_skin', face='bloater'))
m.add('body', B(-7, 8, -6, 14, 16, 11, 'bloat_skin'),
      B(-5, 15, -7, 3, 3, 1, 'pustule'), B(2, 11, -7, 4, 4, 1, 'pustule'), B(0, 19, -7, 2, 2, 1, 'pustule'),
      B(-7.5, 12, -2, 1, 3, 3, 'pustule'), B(6.5, 17, 0, 1, 4, 4, 'pustule'), B(-3, 20, 5, 5, 3, 1, 'pustule'))
m.add('right_arm', B(7, 11, -2.5, 5, 13, 5, 'bloat_skin'))
m.add('left_arm', B(-12, 11, -2.5, 5, 13, 5, 'bloat_skin'))
m.add('right_leg', B(0, 0, -3, 5, 10, 6, 'bloat_skin'))
m.add('left_leg', B(-5, 0, -3, 5, 10, 6, 'bloat_skin'))

# 6. LEAPER - muscles a vif, griffes, gueule allongee
m = model('leaper', (255, 150, 20))
m.add('head', B(-3.5, 23, -7, 7, 7, 9, 'muscle', face='leaper'),
      B(-1, 30, -4, 2, 2, 6, 'bone'))
m.add('body', B(-4, 12, -2, 8, 12, 5, 'muscle'),
      B(-1, 22, 3, 2, 2, 2, 'bone'), B(-1, 18, 3, 2, 2, 2, 'bone'), B(-1, 14, 3, 2, 2, 2, 'bone'))
m.add('right_arm', B(4, 6, -1.5, 3, 18, 3, 'muscle'),
      B(4, 3, -1.5, 1, 3, 1, 'bone'), B(6, 3, -1.5, 1, 3, 1, 'bone'), B(5, 3, 0.5, 1, 3, 1, 'bone'))
m.add('left_arm', B(-7, 6, -1.5, 3, 18, 3, 'muscle'),
      B(-7, 3, -1.5, 1, 3, 1, 'bone'), B(-5, 3, -1.5, 1, 3, 1, 'bone'), B(-6, 3, 0.5, 1, 3, 1, 'bone'))
m.add('right_leg', B(0, 4, -2.5, 4, 8, 5, 'muscle'), B(0.5, 0, -1.5, 3, 4, 3, 'rot'),
      B(0.5, 0, -3.5, 1, 1, 2, 'bone'), B(2.5, 0, -3.5, 1, 1, 2, 'bone'))
m.add('left_leg', B(-4, 4, -2.5, 4, 8, 5, 'muscle'), B(-3.5, 0, -1.5, 3, 4, 3, 'rot'),
      B(-3.5, 0, -3.5, 1, 1, 2, 'bone'), B(-1.5, 0, -3.5, 1, 1, 2, 'bone'))

# 7. BRUTE - colosse, epaules enormes, os dans le dos
m = model('brute', (255, 60, 30))
m.add('head', B(-4, 27, -7, 8, 8, 8, 'brute_skin', face='brute'))
m.add('body', B(-8, 12, -4, 16, 16, 8, 'brute_skin'),
      B(-6, 22, 4, 12, 7, 3, 'brute_skin'),
      B(-4, 27, 6, 2, 4, 2, 'bone'), B(2, 27, 6, 2, 4, 2, 'bone'), B(-1, 24, 7, 2, 3, 2, 'bone'),
      B(-8, 8, -4, 16, 4, 8, 'pants_brown'))
m.add('right_arm', B(8, 6, -3.5, 7, 20, 7, 'brute_skin'), B(7.5, 1, -4, 8, 6, 8, 'brute_skin'))
m.add('left_arm', B(-15, 6, -3.5, 7, 20, 7, 'brute_skin'), B(-15.5, 1, -4, 8, 6, 8, 'brute_skin'))
m.add('right_leg', B(0, 0, -3.5, 6, 12, 7, 'pants_brown'))
m.add('left_leg', B(-6, 0, -3.5, 6, 12, 7, 'pants_brown'))

# 8. SCREAMER - tete allongee, bouche geante, blouse d'hopital
m = model('screamer', (240, 240, 255))
m.add('head', B(-3, 26, -3.5, 6, 11, 7, 'pale', face='scream'),
      B(-1.5, 23, -1.5, 3, 3, 3, 'pale'))
m.add('body', B(-3.5, 12, -1.5, 7, 12, 3, 'gown'), B(-4, 7, -2, 8, 5, 4, 'gown'))
m.add('right_arm', B(3.5, 7, -1, 3, 17, 3, 'pale'))
m.add('left_arm', B(-6.5, 7, -1, 3, 17, 3, 'pale'))
m.add('right_leg', B(0.5, 0, -1.5, 3, 12, 3, 'pale'))
m.add('left_leg', B(-3.5, 0, -1.5, 3, 12, 3, 'pale'))

# 9. STALKER - grand, maigre, cape noire, que des yeux
m = model('stalker', (235, 235, 255))
m.add('head', B(-3.5, 28, -3.5, 7, 8, 7, 'dark_skin', face='stalker'),
      B(-4, 35.5, -4, 8, 1, 8, 'black_cloth'), B(-4.5, 28, -3, 1, 8, 7, 'black_cloth'),
      B(3.5, 28, -3, 1, 8, 7, 'black_cloth'), B(-4, 27, 3.5, 8, 9, 1, 'black_cloth'))
m.add('body', B(-3.5, 14, -2, 7, 14, 4, 'black_cloth'), B(-4, 4, -2.5, 8, 10, 5, 'black_cloth'))
m.add('right_arm', B(3.5, 4, -1.5, 3, 22, 3, 'dark_skin'),
      B(3.5, 1, -1.5, 1, 3, 1, 'bone'), B(5.5, 1, -1.5, 1, 3, 1, 'bone'))
m.add('left_arm', B(-6.5, 4, -1.5, 3, 22, 3, 'dark_skin'),
      B(-6.5, 1, -1.5, 1, 3, 1, 'bone'), B(-4.5, 1, -1.5, 1, 3, 1, 'bone'))
m.add('right_leg', B(0.5, 0, -1.5, 3, 14, 3, 'dark_skin'))
m.add('left_leg', B(-3.5, 0, -1.5, 3, 14, 3, 'dark_skin'))

# 10. OVERLORD - le boss: geant, couronne d'os, coeur rouge qui brille, cape de chair
m = model('overlord', (255, 40, 20))
m.add('head', B(-4.5, 30, -6, 9, 9, 9, 'overlord_skin', face='overlord'),
      B(-4, 39, -5, 1, 4, 1, 'bone'), B(-1.5, 39, -5.5, 1, 5, 1, 'bone'), B(0.5, 39, -5.5, 1, 5, 1, 'bone'),
      B(3, 39, -5, 1, 4, 1, 'bone'), B(-3, 39, 1, 1, 3, 1, 'bone'), B(2, 39, 1, 1, 3, 1, 'bone'))
m.add('body', B(-9, 12, -5, 18, 20, 10, 'overlord_skin'),
      B(-2.5, 22, -5.6, 5, 5, 1, 'core_glow'),
      B(-13, 28, -5, 6, 4, 10, 'metal_dark'), B(7, 28, -5, 6, 4, 10, 'metal_dark'),
      B(-8, 6, 5, 16, 26, 1, 'cape'), B(-9, 6, -5, 18, 6, 10, 'black_cloth'))
m.add('right_arm', B(9, 0, -4, 8, 26, 8, 'overlord_skin'),
      B(9, -2, -4, 2, 2, 2, 'bone'), B(15, -2, -4, 2, 2, 2, 'bone'), B(12, -2, -4, 2, 2, 2, 'bone'))
m.add('left_arm', B(-17, 0, -4, 8, 26, 8, 'overlord_skin'),
      B(-17, -2, -4, 2, 2, 2, 'bone'), B(-11, -2, -4, 2, 2, 2, 'bone'), B(-14, -2, -4, 2, 2, 2, 'bone'))
m.add('right_leg', B(0.5, 0, -4, 7, 12, 8, 'black_cloth'))
m.add('left_leg', B(-7.5, 0, -4, 7, 12, 8, 'black_cloth'))

# 11. ENFANT INFECTE - pyjama jaune, cheveux en bataille, ourson
m = model('child', (255, 255, 120))
m.add('head', B(-4, 24, -4, 8, 8, 8, 'child_skin', face='child'),
      B(-4.5, 30, -4.5, 9, 3, 9, 'hair_blond'), B(-4.5, 26, 2.5, 9, 4, 2, 'hair_blond'))
m.add('body', B(-4, 12, -2, 8, 12, 4, 'pajama'))
m.add('right_arm', B(4, 12, -2, 4, 12, 4, 'pajama'),
      B(4.5, 5, -3, 3, 4, 3, 'teddy'), B(5, 9, -2.5, 2, 2, 2, 'teddy', face='teddy'))
m.add('left_arm', B(-8, 12, -2, 4, 12, 4, 'pajama'))
m.add('right_leg', B(0, 0, -2, 4, 12, 4, 'pajama'))
m.add('left_leg', B(-4, 0, -2, 4, 12, 4, 'pajama'))

# 12. ALPHA - chef de meute, os qui sortent des epaules, peintures rouges
m = model('alpha', (255, 40, 30))
m.add('head', B(-4, 24, -4.5, 8, 8, 8, 'alpha_skin', face='alpha'),
      B(-0.5, 32, -3, 1, 2, 6, 'bone'))
m.add('body', B(-5, 12, -2.5, 10, 13, 5, 'military'),
      B(-7, 24, -1, 2, 4, 2, 'bone'), B(5, 24, -1, 2, 4, 2, 'bone'),
      B(-6.5, 26, -0.5, 1, 3, 1, 'bone'), B(5.5, 26, -0.5, 1, 3, 1, 'bone'),
      B(-1, 20, 2.5, 2, 3, 2, 'bone'), B(-1, 15, 2.5, 2, 3, 2, 'bone'))
m.add('right_arm', B(5, 10, -2.5, 5, 14, 5, 'alpha_skin'),
      B(5, 8, -2.5, 1, 2, 1, 'bone'), B(9, 8, -2.5, 1, 2, 1, 'bone'), B(7, 8, -2.5, 1, 2, 1, 'bone'))
m.add('left_arm', B(-10, 10, -2.5, 5, 14, 5, 'alpha_skin'),
      B(-10, 8, -2.5, 1, 2, 1, 'bone'), B(-6, 8, -2.5, 1, 2, 1, 'bone'), B(-8, 8, -2.5, 1, 2, 1, 'bone'))
m.add('right_leg', B(0, 0, -2.5, 5, 12, 5, 'military'))
m.add('left_leg', B(-5, 0, -2.5, 5, 12, 5, 'military'))

# 13. ZOMBIE BLINDE - equipement SWAT: casque, visiere, gilet, genouilleres
m = model('armored', (255, 214, 64))
m.add('head', B(-4, 24, -4, 8, 8, 8, 'rot', face='zombie'),
      B(-4.5, 28, -4.5, 9, 5, 9, 'metal_dark'), B(-4, 26, -5, 8, 3, 1, 'visor'))
m.add('body', B(-4.5, 13, -2.5, 9, 11, 5, 'kevlar'), B(-4, 12, -2, 8, 1, 4, 'kevlar'),
      B(-7, 21, -2.5, 3, 3, 5, 'metal_dark'), B(4, 21, -2.5, 3, 3, 5, 'metal_dark'),
      B(-3, 15, -3, 2, 3, 1, 'metal_dark'), B(1, 15, -3, 2, 3, 1, 'metal_dark'))
m.add('right_arm', B(4, 12, -2, 4, 12, 4, 'kevlar'), B(4, 12, -2.5, 4, 3, 1, 'rot'))
m.add('left_arm', B(-8, 12, -2, 4, 12, 4, 'kevlar'), B(-8, 12, -2.5, 4, 3, 1, 'rot'))
m.add('right_leg', B(0, 0, -2, 4, 12, 4, 'black_cloth'), B(0, 4, -2.8, 4, 3, 1, 'metal_dark'))
m.add('left_leg', B(-4, 0, -2, 4, 12, 4, 'black_cloth'), B(-4, 4, -2.8, 4, 3, 1, 'metal_dark'))

# 14. ZOMBIE A BOUCLIER - bouclier anti-emeute POLICE devant lui
m = model('shielded', (255, 214, 64))
m.add('head', B(-4, 24, -4, 8, 8, 8, 'grey', face='zombie'),
      B(-4.5, 29, -4.5, 9, 4, 9, 'metal_dark'))
m.add('body', B(-4, 12, -2, 8, 12, 4, 'kevlar'),
      B(-8, 3, -8, 16, 25, 1, 'riot_shield', hires=2),
      B(-1, 14, -7, 2, 2, 1, 'metal_dark'))
m.add('right_arm', B(4, 12, -2, 4, 12, 4, 'kevlar'))
m.add('left_arm', B(-8, 12, -2, 4, 12, 4, 'kevlar'))
m.add('right_leg', B(0, 0, -2, 4, 12, 4, 'jeans_dark'))
m.add('left_leg', B(-4, 0, -2, 4, 12, 4, 'jeans_dark'))
m.anims.update({'right_arm.rx': '-0.45 - sin(swing_progress*pi)*1.3', 'left_arm.rx': '-0.45',
                'right_arm.ry': '0', 'left_arm.ry': '0'})

# 15. FAUX MORT - cadavre couche sur le dos dans une flaque de sang
m = model('fakedead', (255, 214, 64))
m.add('body',
      B(-4, 0, -6, 8, 4, 12, 'shirt'),
      B(-4, 0, -14, 8, 8, 8, 'rot', top='corpse'),
      B(-9, 0, -5, 4, 3, 11, 'rot'), B(5, 0, -8, 4, 3, 11, 'rot'),
      B(-4, 0, 6, 4, 4, 12, 'jeans'), B(0.5, 0, 6, 4, 4, 11, 'jeans'),
      B(-10, -0.9, -16, 20, 1, 30, 'blood'))
m.anims.update({'body.rx': '0', 'body.ry': '0'})

# 16. OBSERVATEUR "???" - silhouette noire immobile, yeux blancs
m = model('observer', (255, 255, 255))
m.add('head', B(-3.5, 34, -3.5, 7, 9, 7, 'shadow', face='observer'))
m.add('body', B(-3.5, 18, -2, 7, 16, 4, 'shadow'))
m.add('right_arm', B(3.5, 4, -1.5, 3, 28, 3, 'shadow'))
m.add('left_arm', B(-6.5, 4, -1.5, 3, 28, 3, 'shadow'))
m.add('right_leg', B(0.5, 0, -1.5, 3, 18, 3, 'shadow'))
m.add('left_leg', B(-3.5, 0, -1.5, 3, 18, 3, 'shadow'))
m.anims.update({'right_arm.rx': '0', 'left_arm.rx': '0', 'right_arm.rz': '0', 'left_arm.rz': '0',
                'right_leg.rx': '0', 'left_leg.rx': '0'})

# Noms MythicMobs (Display, sans couleurs) -> modele
NAMES = [
    # (regle ETF "name", modele). Pas d'espace (ETF coupe les valeurs sur les espaces) ni d'accent.
    # (§.)* = codes couleur eventuels devant le nom. Le plus specifique d'abord, "Zombie" en dernier.
    (r'regex:(§.)*Undead\sOverlord', 'overlord'),
    (r'regex:(§.)*Enfant\sinfect.', 'child'),
    (r'regex:(§.)*Zombie\sblind.', 'armored'),
    (r'regex:(§.)*Zombie\s.\sbouclier', 'shielded'),
    (r'regex:(§.)*Shambler', 'shambler'), (r'regex:(§.)*Runner', 'runner'),
    (r'regex:(§.)*Crawler', 'crawler'), (r'regex:(§.)*Spitter', 'spitter'),
    (r'regex:(§.)*Bloater', 'bloater'), (r'regex:(§.)*Leaper', 'leaper'),
    (r'regex:(§.)*Brute', 'brute'), (r'regex:(§.)*Screamer', 'screamer'),
    (r'regex:(§.)*Stalker', 'stalker'), (r'regex:(§.)*Alpha', 'alpha'),
    (r'regex:(§.)*\?\?\?', 'observer'),
    (r'regex:(§.)*Zombie', 'fakedead'),
]
