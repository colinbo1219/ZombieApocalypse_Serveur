# Liste finale (276) — suivi d'implémentation
Codes : ✅ existe déjà (module) · 🔧 existe, à compléter · 🆕 à faire. Chaque ligne est cochée [x] quand c'est fait ET testé en local.

## 1. Gameplay
- [x] 1 Mémoire du monde ✅ p62
- [ ] 2 Évolution des quartiers normal→abandonné→contaminé→zone morte 🆕 (quartiers de la nouvelle map, état + visuel)
- [ ] 3 Carte mondiale du danger 🆕 (carte en jeu dessinée par ZAMonde + /danger)
- [ ] 4 Événements qui modifient durablement une zone 🔧 (branchés sur l'état des quartiers)
- [ ] 5 Ruines évolutives 🆕 (dégradation physique progressive des bâtiments)
- [ ] 6 Reconstruction par les survivants 🆕
- [ ] 7 Catastrophes locales aléatoires 🆕 (incendie de quartier, effondrement, fuite chimique, inondation)
- [ ] 8 Zones temporairement interdites 🆕
- [x] 9 Nids à cœur destructible ✅ p39
- [ ] 10 Hiérarchie zombie Alpha → chef régional → boss 🔧 (chefs régionaux)
- [x] 11 Comportements spéciaux ✅ p56
- [x] 12 Charognards ✅ p56
- [ ] 13 Imitateurs 🆕
- [ ] 14 Embusqués 🔧 (FakeDead/Stalker → vrai embusqué)
- [x] 15 Zombies qui attirent (Screamer) ✅ p56
- [x] 16 Mutations adaptatives ✅ p56
- [ ] 17 Variants régionaux visuels 🆕
- [ ] 18 Boss régionaux uniques 🆕
- [ ] 19 Évolution mondiale des zombies avec la saison 🔧
- [ ] 20 Mutation visible du joueur 🆕
- [ ] 21 Effets temporaires de l'infection à risque 🆕
- [ ] 22 Médicaments expérimentaux à effets secondaires 🔧
- [ ] 23 Résistances individuelles rares 🔧
- [x] 24 Infection selon la région ✅ p26
- [ ] 25 Épidémies locales 🆕
- [ ] 26 Propagation d'une souche 🆕

## 2. Électricité Create (27–45) 🆕 tout le module (CC&A réel + réseau par quartier)

## 3. Map custom (46–68) 🆕 tout (nouvelle map complète)

## 4. Lore
- [x] 69–79 ✅ (prologue p38, histoire p40, chapitres p60, relations p46, destins p64)
- [ ] 80 PNJ qui se déplacent réellement 🆕
- [x] 81–83 ✅ (dossiers p51, rapports, Bravo-3)
- [ ] 84 Enregistrements audio 🆕
- [x] 85 ✅  - [ ] 86 Propagande / messages contradictoires 🆕
- [x] 87–90 ✅ (Arel, Overlord, enquêtes, révélations) — indices à répartir par quartier 🔧

## 5. Immersion (91–104) 🆕 téléphone, SMS, appels, alertes, TV avant/après, radio à fréquences (militaire, scientifique, pirate), détresse, faux SOS, enregistrements trouvés

## 6. Survivants (105–116) ✅ p43/p44 — 🔧 111 conflits internes, 115 survivants infectés

## 7. Camps & factions (117–133) ✅ p44/p45/p47 — 🔧 122 électricité du camp, 128 offensive de faction, 130 traités

## 8. Économie (134–144) ✅ p47/p48/p7 — 🔧 138 inflation locale, 139 commerce entre factions, 140 contrats dynamiques, 141 premium

## 9. Armes (145–153) ✅ p49/p52 — 🔧 145 visuel, 149 munitions spécialisées, 152 arsenal de faction

## 10. Médical (154–164) ✅ p53 — 🔧 159 fractures, 161 chirurgie, 162 bloc médical

## 11. Exploration (165–177) ✅ p54/p51 — 🔧 168 pièces secrètes, 169 passages souterrains (map), 175 loot par région, 176 loot par saison

## 12. Catastrophes (178–195) ✅ p3/p34/p55/p64 — 🔧 179 blackout régional (réseau), 189 crash d'avion visuel, 192 évacuation, 194 massacre

## 13. Visuel zombies (196–214) 🆕 Zombies custom 2.0 (métiers, états, blessures, animations, boss)

## 14. Visuel combat (215–223) 🆕 sang, impacts, feu, explosions, cadavres, traces

## 15. Ambiance visuelle (224–235) 🆕 brouillard, ciel, lumière, blackouts, fumée, poussière, cendres, incendies, végétation, zones mortes, pluie

## 16. Son (236–249) 🔧 moteur d'ambiance par zone + sons par zombie + mods son

## 17. Ville avant/après (250–264) ✅ prologue — 🆕 habillage de la nouvelle map (épaves, barricades, feux, corps, débris, graffitis, affiches, avis, messages)

## 18. Fin de saison (265–276) ✅ p41/p59/p64 — 🔧 272 reliques de saison
